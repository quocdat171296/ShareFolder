-- ******************************************************************************
-- * ���[�U��          �F�������ʁ@�������
-- * �V�X�e����        �F�󔭒��Ǘ�
-- * �T�u�V�X�e����    �F�����X�V
-- * �\�[�X�t�@�C����  �FCRHBQ110_RUN.SQL
-- * �\�[�X�t�@�C���a���F�����X�V(�󒍍폜) 
-- * �쐬��            �FISHIDA�j����@���O
-- * ���t              �F1.00 2011/09/18
-- ******************************************************************************
--
SET SERVEROUTPUT ON;
--
VAR I_SubKbn VARCHAR2(128) ;
VAR I_GymKbn VARCHAR2(128) ;
VAR I_MstCod VARCHAR2(128) ;
VAR I_MstNam VARCHAR2(128) ;
VAR I_PrcKbn VARCHAR2(128) ;
VAR I_CnvCnt NUMBER        ;
VAR I_ErrCnt NUMBER        ;
VAR I_TnmNam VARCHAR2(128) ;
VAR I_PrgNum VARCHAR2(128) ;
VAR I_PrgNam VARCHAR2(128) ;
VAR I_YobI01 VARCHAR2(128) ;
VAR I_YobI02 VARCHAR2(128) ;
VAR I_TanCod VARCHAR2(128) ;
VAR O_RETMSG VARCHAR2(128) ;
VAR O_RETCOD NUMBER        ;
VAR ret      NUMBER        ;
--
DECLARE
--
BEGIN
--
    CRHBQ110.CRHBQ110(:O_RETCOD ,:O_RETMSG ) ;
--
    IF :O_RETCOD = 0 THEN
        COMMIT;
--
        :I_YobI01 := '1'                               ;
        :I_YobI02 := '��  �󒍏��폜����I�� (�폜�N����:' || TO_CHAR(ADD_MONTHS(SYSDATE, -14), 'YYYYMMDD') || ')'     ;
    ELSE
        ROLLBACK;
--
        :I_YobI01 := '0'                               ;
        :I_YobI02 := '��  �󒍏��폜�ُ�I��  (�ڍ�:' || :O_RETMSG || ')'    ;
        
    END IF;
--
    :I_SubKbn := '99'                                  ;
    :I_GymKbn := '1'                                   ;
    :I_MstCod := ' '                                   ;
    :I_MstNam := ' '                                   ;
    :I_PrcKbn := '9'                                   ;
    :I_CnvCnt := 0                                     ;
    :I_ErrCnt := 0                                     ;
    :I_TnmNam := ' '                                   ;
    :I_PrgNum := 'CRHBQ110'                            ;
    :I_PrgNam := '�����X�V(�󒍍폜)'                  ;
    :I_TanCod := '000000'                              ;
--
    :O_RETCOD := 0                                     ;
    :O_RETMSG := NULL                                  ;
--
    CRCO000S.CLGFILADD (:I_SubKbn ,
                        :I_GymKbn ,
                        :I_MstCod ,
                        :I_MstNam ,
                        :I_PrcKbn ,
                        :I_CnvCnt ,
                        :I_ErrCnt ,
                        :I_TnmNam ,
                        :I_PrgNum ,
                        :I_PrgNam ,
                        :I_YobI01 ,
                        :I_YobI02 ,
                        :I_TanCod ,
                        :O_RETCOD ,
                        :O_RETMSG ) ;
--
    IF :O_RETCOD = 0 THEN
        COMMIT;
--
       :ret := 0;
    ELSE
        ROLLBACK;
--
       :ret := -1;
    END IF;
--
END;
/
EXIT :ret
