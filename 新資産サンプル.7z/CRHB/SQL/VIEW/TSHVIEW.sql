-- ********************************************************************
-- *  �̔��Ǘ��V�X�e��
-- *  ���Ӑ揤�i�}�X�^���
-- *  TSHVIEW
-- *  2020.07.02                                        By M.FUJII
-- ********************************************************************
--
--
CREATE OR REPLACE VIEW TSHVIEW
    (TSH_SHOCOD,
     TSH_TOKCOD,
     TSH_TOKKNA,
     TSH_SNTCOD)
AS
SELECT
    ARE.SHOCOD        AS  TSH_SHOCOD,
    ARE.TOKCOD        AS  TSH_TOKCOD,
    TOK_TOKKNA        AS  TSH_TOKKNA,
    BAS_SNTCOD        AS  TSH_SNTCOD
FROM BASTABL, (SELECT
                   BAG_TOKCOD  AS TOKCOD,
                   TSH_SHOCOD  AS SHOCOD,
                   BAG_ARECOD  AS ARECOD
               FROM TSHMAST, BAGTABL
               WHERE TSH_TOKCOD = BAG_TOKCOD
               GROUP BY
                   BAG_TOKCOD,
                   TSH_SHOCOD,
                   BAG_ARECOD) ARE,
     TOKMAST
WHERE BAS_SHOCOD = ARE.SHOCOD
AND   BAS_ARECOD = ARE.ARECOD
AND   BAS_DATKBN = '3'
AND   ARE.TOKCOD = TOK_TOKCOD
GROUP BY
    ARE.SHOCOD,
    ARE.TOKCOD,
    TOK_TOKKNA,
    BAS_SNTCOD
UNION
SELECT
    TSH_SHOCOD        AS  TSH_SHOCOD,
    TSH_TOKCOD        AS  TSH_TOKCOD,
    TOK_TOKKNA        AS  TSH_TOKKNA,
    JPT_SNTCOD        AS  TSH_SNTCOD
FROM JPTTABL, TSHMAST, TOKMAST
WHERE JPT_TRICOD = TSH_TRICOD
AND   JPT_STNCOD = TSH_STNCOD
AND   JPT_DATKBN = '3'
AND   TSH_TOKCOD = TOK_TOKCOD
GROUP BY
    TSH_SHOCOD,
    TSH_TOKCOD,
    TOK_TOKKNA,
    JPT_SNTCOD
ORDER BY
    TSH_TOKCOD,
    TSH_SHOCOD
/
COMMENT ON TABLE  TSHVIEW IS '�q�揤�i�}�X�^�u�h�d�v' ;

