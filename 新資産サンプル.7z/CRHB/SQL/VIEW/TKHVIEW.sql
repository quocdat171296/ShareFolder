-- ********************************************************************
-- *  �̔��Ǘ��V�X�e��
-- *  TKHVIEW
-- *  2020.07.02                                        By M.FUJII
-- ********************************************************************
--
--
CREATE OR REPLACE VIEW TKHVIEW
    (TKH_TOKCOD,TKH_TOKNAM,TKH_TKSCOD,TKH_TKSNAM,TKH_TKBCOD,TKH_TKBNAM,
    TKH_SSWCOD,TKH_SSWNAM,TKH_TANCOD,TKH_TANNAM,TKH_BMNCOD,TKH_BMNNAM,TKH_URIBCD,
    TKH_URIBNM)
AS
SELECT
    KKK.TOK_TOKCOD  AS TKH_TOKCOD ,
    KKK.TOK_TOKNAM  AS TKH_TOKNAM ,
    KKK.TKS_TKSCOD  AS TKH_TKSCOD ,
    KKK.TKS_TKSNAM  AS TKH_TKSNAM ,
    KKK.TKB_TKBCOD  AS TKH_TKBCOD ,
    KKK.TKB_TKBNAM  AS TKH_TKBNAM ,
    KKK.TKJ_SSWCOD  AS TKH_SSWCOD ,
    KKK.TKJ_SSWNAM  AS TKH_SSWNAM ,
    TTN.TTN_TANCOD  AS TKH_TANCOD ,
    TAN.TAN_TANNAM  AS TKH_TANNAM ,
    TAN.TAN_BMNCOD  AS TKH_BMNCOD ,
    BMN.BMN_BMNNAM  AS TKH_BMNNAM ,
    TTN.TTN_URIBCD  AS TKH_URIBCD ,
    UBN.BMN_BMNNAM  AS TKH_URIBNM 
FROM
   (SELECT
          TOK_TOKCOD,
          TOK_TOKNAM,
          TKS_TKSCOD,
          TKS_TKSNAM,
          TKB_TKBCOD,
          TKB_TKBNAM,
          TOK_TDNPTN,
          TKJ_SSWCOD,
          TKJ_SSWNAM
    FROM  TOKMAST   ,
          TKSMAST   ,
          TKBTABL   ,
          TKJTABL
    WHERE TOK_TOKCOD = TKS_TOKCOD
    AND   TOK_TOKCOD = TKB_TOKCOD
    AND   TOK_TOKCOD = TKJ_TOKCOD ) KKK ,
    TTNTABL                         TTN ,
    TANTABL                         TAN ,
    BMNTABL                         BMN ,
    BMNTABL                         UBN
WHERE     KKK.TOK_TOKCOD = TTN.TTN_TOKCOD (+)
AND       KKK.TKS_TKSCOD = TTN.TTN_TKSCOD (+)
AND       KKK.TKB_TKBCOD = TTN.TTN_TKBCOD (+)
AND       KKK.TKJ_SSWCOD = TTN.TTN_SSWCOD (+)
AND       TTN.TTN_TANCOD = TAN.TAN_TANCOD (+)
AND       TAN.TAN_BMNCOD = BMN.BMN_BMNCOD (+)
AND       TTN.TTN_URIBCD = UBN.BMN_BMNCOD (+)
/
COMMENT ON TABLE CHUBUTEST.TKHVIEW IS '���v������{�u�h�d�v'
/
