SET LINESIZE 10000
SET PAGESIZE 0
--SET FEEDBACK OFF
SET SERVEROUTPUT ON FORMAT WRAPPED
--
-- *************************************************************************
-- IFRS�ڍs�p�ꎞ�e�[�u���쐬����
-- *************************************************************************
CREATE GLOBAL TEMPORARY TABLE
    IFRSWORK (
        WRK_DENNUM      CHAR( 8)                    /* �y����`�[No�z */                   ,
        WRK_JDENNO      CHAR( 8)                    /* �y�󒍓`�[No�z */                   ,
        WRK_SDENNO      CHAR( 8)                    /* �y�d���`�[No�z */                   ,
        WRK_URIDAY      CHAR( 8)                    /* �y������z */                       ,
        WRK_TOKCOD      CHAR( 8)                    /* �y�q��R�[�h�z */                   ,
        WRK_TKSCOD      CHAR( 5)                    /* �y�q��x�X�R�[�h�z */               ,
        WRK_NOUCOD      CHAR( 8)                    /* �y�[�i��R�[�h�z */                 ,
        WRK_NHSCOD      CHAR( 5)                    /* �y�[�i��x�X�R�[�h�z */             ,
        WRK_ARECOD      CHAR( 3)                    /* �y�����G���A�R�[�h�z */             ,
        WRK_GYONUM      CHAR( 2)                    /* �y����sNo�z */                     ,
        WRK_SHOCOD      CHAR(13)                    /* �y���i�R�[�h�z */                   ,
        WRK_IFSSNT      CHAR( 6)        DEFAULT ' ' /* �y���Ѝ݌ɃZ���^�[�R�[�h(IFRS)�z */ ,
        WRK_IFSSIR      CHAR( 7)        DEFAULT ' ' /* �y�d����R�[�h(IFRS)�z */           ,
        WRK_IFSMSR      CHAR( 7)        DEFAULT ' ' /* �yIFRS�W�v�p�d����R�[�h�z */       ,
        CONSTRAINT
            IFRSWORKPK1
        PRIMARY KEY (
            WRK_DENNUM
          , WRK_GYONUM
        )
)
ON COMMIT DELETE ROWS
;
CREATE INDEX IFRSWORK1 ON IFRSWORK (WRK_SDENNO);
CREATE INDEX IFRSWORK2 ON IFRSWORK (WRK_JDENNO,WRK_SDENNO);
CREATE INDEX IFRSWORK3 ON IFRSWORK (WRK_IFSMSR);
--
--
--
--
--
--
--
--
--
--
--
/* ************************************************************************** */
/* ����f�[�^IFRS���ڈڍs����                                                 */
/* ************************************************************************** */
DECLARE
    IFRS_STT_NENGTU     CONSTANT    CHAR(6) := '201904';
--
    TYPE        ARR_NENGTU  IS  VARRAY(25)  OF  CHAR(6) ;
--
    nengtu      ARR_NENGTU;                                     --  �����N���w��ϐ�
    dsp_nengtu  VARCHAR2(12);
--
    msg         VARCHAR2(4096);                                 --  ���b�Z�[�W
--
    updcnt      NUMBER( 8, 0);                                  --  �X�V�����J�E���^
--
    sqlbuf      VARCHAR2(32767);                                --  SQL���ϐ�
--
--
    -- *************************************************************************
    -- �󒍃f�[�^�폜�ςݕ��J�[�\��
    -- *************************************************************************
    CURSOR
        CReadNOTJYH
    IS
        SELECT
            WRK_DENNUM      AS  DENNUM
          , WRK_GYONUM      AS  GYONUM
        FROM
            IFRSWORK
            LEFT    JOIN
                JYHFILE
                ON
                    JYH_DELFLG   =   '0'
                AND
                    WRK_JDENNO   =   JYH_DENNUM
        WHERE
            WRK_JDENNO  <>   '00000000'
        AND
            JYH_DENNUM  IS NULL
    ;
--
    -- *************************************************************************
    -- �p�^�[���P�F�d���`�[�ƘA�g���锄��`�[�̍X�V���J�[�\��
    -- *************************************************************************
    CURSOR
        CReadPatern1
    IS
        SELECT
            WRK_DENNUM      AS  DENNUM
          , WRK_GYONUM      AS  GYONUM
          , SRH_SIRCOD      AS  SIRCOD
        FROM
            IFRSWORK
            INNER   JOIN
                SRHFILE
                ON
                    SRH_DELFLG   =   '0'
                AND
                    WRK_SDENNO   =   SRH_DENNUM
    ;
--
    -- *************************************************************************
    -- �p�^�[���Q�F�󒍓`�[�ƘA�g���锄��`�[�̍X�V���J�[�\��
    -- *************************************************************************
    CURSOR
        CReadPatern2
    IS
        SELECT
            WRK_DENNUM      AS  DENNUM
          , WRK_GYONUM      AS  GYONUM
          , JYH_SNTCOD      AS  SNTCOD
          , JYH_SIRCOD      AS  SIRCOD
          , CASE
                WHEN    TRIM(JYH_SIRCOD)    IS NOT NULL THEN
                    JYH_SIRCOD
                WHEN    BSH_SIRCOD          IS NOT NULL THEN
                    BSH_SIRCOD
                ELSE
                    TSH_SIRCOD
            END             AS  SUMSIR
        FROM
            IFRSWORK
            INNER   JOIN
                JYHFILE
                ON
                    JYH_DELFLG   =   '0'
                AND
                    WRK_JDENNO   =   JYH_DENNUM
            INNER   JOIN
                TSHMAST
                ON
                    WRK_TOKCOD   =   TSH_TOKCOD
                AND
                    WRK_SHOCOD   =   TSH_SHOCOD
            LEFT    JOIN
                BSHTABL
                ON
                    JYH_SNTCOD   =   BSH_SNTCOD
                AND
                    WRK_SHOCOD   =   BSH_SHOCOD
        WHERE
            WRK_SDENNO   =   '00000000'
    ;
--
    -- *************************************************************************
    -- �p�^�[���R�[�P�F�����R�[�h��ALL0�ȊO�̔���`�[�̍X�V���J�[�\��
    -- *************************************************************************
    CURSOR
        CReadPatern31
    IS
        SELECT
            WRK_DENNUM      AS  DENNUM
          , WRK_GYONUM      AS  GYONUM
          , JPT_SNTCOD      AS  SNTCOD
          , JPT_SIRCOD      AS  SIRCOD
          , CASE
                WHEN    TRIM(JPT_SIRCOD)    IS NOT NULL THEN
                    JPT_SIRCOD
                WHEN    BSH_SIRCOD          IS NOT NULL THEN
                    BSH_SIRCOD
                ELSE
                    TSH_SIRCOD
            END             AS  SUMSIR
        FROM
            IFRSWORK
            INNER   JOIN
                TSHMAST
                ON
                    TSH_TRICOD  <>   '0000000000000'
                AND
                    WRK_TOKCOD   =   TSH_TOKCOD
                AND
                    WRK_SHOCOD   =   TSH_SHOCOD
            INNER   JOIN
                JPTTABL
                ON
                    JPT_DELFLG   =   '0'
                AND
                    JPT_DATKBN  <>   '9'
                AND
                    WRK_ARECOD   =   JPT_ARECOD
                AND
                    TSH_TRICOD   =   JPT_TRICOD
                AND
                    TSH_STNCOD   =   JPT_STNCOD
            LEFT    JOIN
                BSHTABL
                ON
                    JPT_SNTCOD   =   BSH_SNTCOD
                AND
                    WRK_SHOCOD   =   BSH_SHOCOD
        WHERE
            WRK_JDENNO   =   '00000000'
        AND
            WRK_SDENNO   =   '00000000'
    ;
--
    -- *************************************************************************
    -- �p�^�[���R�[�Q�F�����R�[�h��ALL0�̔���`�[�̍X�V���J�[�\��
    -- *************************************************************************
    CURSOR
        CReadPatern32
    IS
        WITH
           BASMAXU
        AS (
            SELECT
                WRK_DENNUM          AS BAS_MAXDEN
              , WRK_GYONUM          AS BAS_MAXGYO
              , MAX(BAS_STRDAY)     AS BAS_MAXDAY
            FROM
                IFRSWORK
                INNER   JOIN
                    BASTABL
                    ON
                        BAS_DELFLG   =   '0'
                    AND
                        WRK_SHOCOD   =   BAS_SHOCOD
                    AND
                        WRK_URIDAY  >=   BAS_STRDAY
            WHERE
                WRK_JDENNO   =   '00000000'
            AND
                WRK_SDENNO   =   '00000000'
            GROUP BY
                WRK_DENNUM
              , WRK_GYONUM
        )
        SELECT
            WRK_DENNUM      AS  DENNUM
          , WRK_GYONUM      AS  GYONUM
          , BAS_SNTCOD      AS  SNTCOD
          , BAS_SIRCOD      AS  SIRCOD
          , CASE
                WHEN    TRIM(BAS_SIRCOD)    IS NOT NULL THEN
                    BAS_SIRCOD
                WHEN    BSH_SIRCOD          IS NOT NULL THEN
                    BSH_SIRCOD
                ELSE
                    TSH_SIRCOD
            END             AS  SUMSIR
        FROM
            IFRSWORK
            INNER   JOIN
                TSHMAST
                ON
                    TSH_TRICOD   =   '0000000000000'
                AND
                    WRK_TOKCOD   =   TSH_TOKCOD
                AND
                    WRK_SHOCOD   =   TSH_SHOCOD
            INNER   JOIN
                BASTABL
                ON
                    BAS_DELFLG   =   '0'
                AND
                    BAS_DATKBN  <>   '9'
                AND
                    WRK_SHOCOD   =   BAS_SHOCOD
                AND
                    WRK_ARECOD   =   BAS_ARECOD
            LEFT    JOIN
                BSHTABL
                ON
                    BAS_SNTCOD   =   BSH_SNTCOD
                AND
                    WRK_SHOCOD   =   BSH_SHOCOD
    ;
--
    -- *************************************************************************
    -- �p�^�[���S�F�o�׌������Z���^�[�̔���`�[�̍X�V
    -- (�p�^�[���P�`�R�ōX�V����Ă��Ȃ��`�[)
    -- *************************************************************************
    CURSOR
        CReadPatern4
    IS
        SELECT
            WRK_DENNUM      AS  DENNUM
          , WRK_GYONUM      AS  GYONUM
          , TSH_SIRCOD      AS  SUMSIR
        FROM
            IFRSWORK
            INNER   JOIN
                TSHMAST
                ON
                    WRK_TOKCOD   =   TSH_TOKCOD
                AND
                    WRK_SHOCOD   =   TSH_SHOCOD
        WHERE
            WRK_IFSMSR   =   '       '
    ;
BEGIN
    msg :=
        '[' || TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') || '] �F' ||
        '����f�[�^�@IFRS�Ή��@�ڍs�����J�n'
    ;
--
    DBMS_OUTPUT.PUT_LINE(msg);
    DBMS_OUTPUT.NEW_LINE;
--
--
    nengtu := ARR_NENGTU();                                                     --  �z��̏�����
    nengtu.extend(25);                                                          --  ��v�f�ǉ�
--
    -- �Ώ۔N�������l�Z�b�g
    FOR
        lop IN  nengtu.FIRST..nengtu.LAST
    LOOP
        IF lop = 25 THEN
            nengtu(lop) := '000000';
        ELSE
            nengtu(lop) := TO_CHAR(ADD_MONTHS(TO_DATE(IFRS_STT_NENGTU || '01', 'YYYYMMDD'), lop - 1), 'YYYYMM');
        END IF ;
    END LOOP ;
--
--
    -- �J�n�N�����1�������Ǝ��{
    FOR
        lop IN  nengtu.FIRST..nengtu.LAST
    LOOP
        msg :=
            '[' || TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') || '] �F' ||
            '*******************************************************'
        ;
--
        DBMS_OUTPUT.PUT_LINE(msg);
--
--
        IF lop = 25 THEN
            dsp_nengtu := '�������{' ;
        ELSE
            dsp_nengtu := SUBSTR(nengtu(lop), 1, 4) || '�N' || SUBSTR(nengtu(lop), 5, 2) || '����' ;
        END IF ;
--
        msg :=
            '[' || TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') || '] �F' ||
            '�@' || dsp_nengtu || '���@�����J�n'
        ;
--
        DBMS_OUTPUT.PUT_LINE(msg);
        DBMS_OUTPUT.NEW_LINE;
--
        -- *************************************************************************
        -- IFRS�ڍs�Ώۃ��R�[�h���o����(���ߏ��������{)
        -- *************************************************************************
        msg :=
            '[' || TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') || '] �F' ||
            '�@�@IFRS�ڍs�Ώۃ��R�[�h���o�J�n(' || dsp_nengtu || '��)'
        ;
--
        DBMS_OUTPUT.PUT_LINE(msg);
--
        -- IFRS�ڍs�Ώۃf�[�^���o
        INSERT INTO
            IFRSWORK
            WITH
               BAGMAX
            AS (
                SELECT
                    URH_DENNUM          AS  MAX_DENNUM
                  , MAX(BAG_STRDAY)     AS  MAX_STRDAY
                FROM
                    URHFILE
                    INNER   JOIN
                        BAGTABL
                        ON
                            BAG_DELFLG   =   '0'
                        AND
                            URH_NOUCOD   =   BAG_TOKCOD
                        AND
                            URH_NHSCOD   =   BAG_TKSCOD
                        AND
                            URH_URIDAY  >=   BAG_STRDAY
                WHERE
                    URH_DELFLG   =   '0'
                AND
                    URH_GKURYM   =   nengtu(lop)
                GROUP BY
                    URH_DENNUM
            )
            SELECT
                URH_DENNUM
              , URH_JDENNO
              , URH_SDENNO
              , URH_URIDAY
              , URH_TOKCOD
              , URH_TKSCOD
              , URH_NOUCOD
              , URH_NHSCOD
              , BAG_ARECOD
              , URB_GYONUM
              , URB_SHOCOD
              , '      '
              , '       '
              , '       '
            FROM
                BAGMAX
                INNER   JOIN
                    URHFILE
                    ON
                        MAX_DENNUM   =   URH_DENNUM
                INNER   JOIN
                    URBFILE
                    ON
                        URB_DELFLG   =   '0'
                    AND
                        URH_DENNUM   =   URB_DENNUM
                INNER   JOIN
                    BAGTABL
                    ON
                        BAG_DELFLG   =   '0'
                    AND
                        URH_NOUCOD   =   BAG_TOKCOD
                    AND
                        URH_NHSCOD   =   BAG_TKSCOD
                    AND
                        MAX_STRDAY   =   BAG_STRDAY
        ;
--
        msg :=
            '[' || TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') || '] �F' ||
            '�@�@IFRS�ڍs�Ώۃ��R�[�h���o�I��(' || dsp_nengtu || '��)' ||
            ' (' || TO_CHAR(SQL%ROWCOUNT, 'FM99,999,990') || '�� ���o)'
        ;
--
        DBMS_OUTPUT.PUT_LINE(msg);
        DBMS_OUTPUT.NEW_LINE;
--
--
        -- *************************************************************************
        -- IFRS�ڍs�Ώۃ��R�[�h���o����(�G���A���擾��)
        -- *************************************************************************
        msg :=
            '[' || TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') || '] �F' ||
            '�@�@IFRS�ڍs�Ώۃ��R�[�h���o�J�n(�G���A���擾��)'
        ;
--
        DBMS_OUTPUT.PUT_LINE(msg);
--
        -- IFRS�ڍs�Ώۃf�[�^���o
        INSERT INTO
            IFRSWORK
            SELECT
                URH_DENNUM
              , URH_JDENNO
              , URH_SDENNO
              , URH_URIDAY
              , URH_TOKCOD
              , URH_TKSCOD
              , URH_NOUCOD
              , URH_NHSCOD
              , '   '
              , URB_GYONUM
              , URB_SHOCOD
              , '      '
              , '       '
              , '       '
            FROM
                URHFILE
                INNER   JOIN
                    URBFILE
                    ON
                        URB_DELFLG   =   '0'
                    AND
                        URH_DENNUM   =   URB_DENNUM
                LEFT    JOIN
                    IFRSWORK
                    ON
                        URH_DENNUM   =   WRK_DENNUM
                    AND
                        URB_GYONUM   =   WRK_GYONUM
            WHERE
                URH_DELFLG   =   '0'
            AND
                URH_GKURYM   =   nengtu(lop)
            AND
                WRK_DENNUM  IS NULL
        ;
--
        msg :=
            '[' || TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') || '] �F' ||
            '�@�@IFRS�ڍs�Ώۃ��R�[�h���o�I��(�G���A���擾��)'         ||
            ' (' || TO_CHAR(SQL%ROWCOUNT, 'FM99,999,990') || '�� ���o)'
        ;
--
        DBMS_OUTPUT.PUT_LINE(msg);
        DBMS_OUTPUT.NEW_LINE;
--
--
        -- *************************************************************************
        -- �󒍃f�[�^�폜�ςݕ��󒍔ԍ�������
        -- *************************************************************************
        msg :=
            '[' || TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') || '] �F' ||
            '�@�@�󒍃f�[�^�폜�ςݕ��󒍔ԍ�������'
        ;
--
        DBMS_OUTPUT.PUT_LINE(msg);
--
        updcnt := 0 ;
        FOR
            CRecNOTJYH IN CReadNOTJYH
        LOOP
            UPDATE
                IFRSWORK
            SET
                WRK_JDENNO = '00000000'
            WHERE
                WRK_DENNUM   =   CRecNOTJYH.DENNUM
            AND
                WRK_GYONUM   =   CRecNOTJYH.GYONUM
            ;
--
            updcnt := updcnt + 1;
        END LOOP ;
--
        msg :=
            '[' || TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') || '] �F' ||
            '�@�@�󒍃f�[�^�폜�ςݕ��󒍔ԍ�������'                   ||
            ' (' || TO_CHAR(updcnt, 'FM99,999,990') || '�� �X�V)'
        ;
--
        DBMS_OUTPUT.PUT_LINE(msg);
        DBMS_OUTPUT.NEW_LINE;
--
--
        -- *************************************************************************
        -- �p�^�[���P�F�d���`�[�ƘA�g���锄��`�[�̍X�V
        -- *************************************************************************
        msg :=
            '[' || TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') || '] �F' ||
            '�@�@�p�^�[���P�X�V�J�n'
        ;
--
        DBMS_OUTPUT.PUT_LINE(msg);
--
        updcnt := 0 ;
        FOR
            CRecIFRS IN CReadPatern1
        LOOP
            UPDATE
                IFRSWORK
            SET
                WRK_IFSSNT = '      '
              , WRK_IFSSIR = CRecIFRS.SIRCOD
              , WRK_IFSMSR = CRecIFRS.SIRCOD
            WHERE
                WRK_DENNUM   =   CRecIFRS.DENNUM
            AND
                WRK_GYONUM   =   CRecIFRS.GYONUM
            ;
--
            UPDATE
                URBFILE
            SET
                URB_IFSSNT = '      '
              , URB_IFSSIR = CRecIFRS.SIRCOD
              , URB_IFSMSR = CRecIFRS.SIRCOD
            WHERE
                URB_DENNUM   =   CRecIFRS.DENNUM
            AND
                URB_GYONUM   =   CRecIFRS.GYONUM
            ;
--
            updcnt := updcnt + 1;
        END LOOP ;
--
        msg :=
            '[' || TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') || '] �F' ||
            '�@�@�p�^�[���P�X�V�I��'                                   ||
            ' (' || TO_CHAR(updcnt, 'FM99,999,990') || '�� �X�V)'
        ;
--
        DBMS_OUTPUT.PUT_LINE(msg);
        DBMS_OUTPUT.NEW_LINE;
--
--
        -- *************************************************************************
        -- �p�^�[���Q�F�󒍓`�[�ƘA�g���锄��`�[�̍X�V
        -- *************************************************************************
        msg :=
            '[' || TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') || '] �F' ||
            '�@�@�p�^�[���Q�X�V�J�n'
        ;
--
        DBMS_OUTPUT.PUT_LINE(msg);
--
        updcnt := 0 ;
        FOR
            CRecIFRS IN CReadPatern2
        LOOP
            UPDATE
                IFRSWORK
            SET
                WRK_IFSSNT = CRecIFRS.SNTCOD
              , WRK_IFSSIR = CRecIFRS.SIRCOD
              , WRK_IFSMSR = CRecIFRS.SUMSIR
            WHERE
                WRK_DENNUM   =   CRecIFRS.DENNUM
            AND
                WRK_GYONUM   =   CRecIFRS.GYONUM
            ;
--
            UPDATE
                URBFILE
            SET
                URB_IFSSNT = CRecIFRS.SNTCOD
              , URB_IFSSIR = CRecIFRS.SIRCOD
              , URB_IFSMSR = CRecIFRS.SUMSIR
            WHERE
                URB_DENNUM   =   CRecIFRS.DENNUM
            AND
                URB_GYONUM   =   CRecIFRS.GYONUM
            ;
--
            updcnt := updcnt + 1;
        END LOOP ;
--
        msg :=
            '[' || TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') || '] �F' ||
            '�@�@�p�^�[���Q�X�V�I��'                                   ||
            ' (' || TO_CHAR(updcnt, 'FM99,999,990') || '�� �X�V)'
        ;
--
        DBMS_OUTPUT.PUT_LINE(msg);
        DBMS_OUTPUT.NEW_LINE;
--
--
        -- *************************************************************************
        -- �p�^�[���R�F�d���`�[�E�󒍓`�[�ƘA�g���Ȃ�����`�[�̍X�V
        -- *************************************************************************
        msg :=
            '[' || TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') || '] �F' ||
            '�@�@�p�^�[���R�X�V�J�n'
        ;
--
        DBMS_OUTPUT.PUT_LINE(msg);
--
        -- *************************************************************************
        -- �p�^�[���R�[�P�F�����R�[�h��ALL0�ȊO�̔���`�[�̍X�V
        -- *************************************************************************
        msg :=
            '[' || TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') || '] �F' ||
            '�@�@�@�p�^�[���R�[�P�X�V�J�n'
        ;
--
        DBMS_OUTPUT.PUT_LINE(msg);
--
        updcnt := 0 ;
        FOR
            CRecIFRS IN CReadPatern31
        LOOP
            UPDATE
                IFRSWORK
            SET
                WRK_IFSSNT = CRecIFRS.SNTCOD
              , WRK_IFSSIR = CRecIFRS.SIRCOD
              , WRK_IFSMSR = CRecIFRS.SUMSIR
            WHERE
                WRK_DENNUM   =   CRecIFRS.DENNUM
            AND
                WRK_GYONUM   =   CRecIFRS.GYONUM
            ;
--
            UPDATE
                URBFILE
            SET
                URB_IFSSNT = CRecIFRS.SNTCOD
              , URB_IFSSIR = CRecIFRS.SIRCOD
              , URB_IFSMSR = CRecIFRS.SUMSIR
            WHERE
                URB_DENNUM   =   CRecIFRS.DENNUM
            AND
                URB_GYONUM   =   CRecIFRS.GYONUM
            ;
--
            updcnt := updcnt + 1;
        END LOOP ;
--
        msg :=
            '[' || TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') || '] �F' ||
            '�@�@�@�p�^�[���R�[�P�X�V�I��'                             ||
            ' (' || TO_CHAR(updcnt, 'FM99,999,990') || '�� �X�V)'
        ;
--
        DBMS_OUTPUT.PUT_LINE(msg);
--
        -- *************************************************************************
        -- �p�^�[���R�[�Q�F�����R�[�h��ALL0�̔���`�[�̍X�V
        -- *************************************************************************
        msg :=
            '[' || TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') || '] �F' ||
            '�@�@�@�p�^�[���R�[�Q�X�V�J�n'
        ;
--
        DBMS_OUTPUT.PUT_LINE(msg);
--
        updcnt := 0 ;
        FOR
            CRecIFRS IN CReadPatern32
        LOOP
            UPDATE
                IFRSWORK
            SET
                WRK_IFSSNT = CRecIFRS.SNTCOD
              , WRK_IFSSIR = CRecIFRS.SIRCOD
              , WRK_IFSMSR = CRecIFRS.SUMSIR
            WHERE
                WRK_DENNUM   =   CRecIFRS.DENNUM
            AND
                WRK_GYONUM   =   CRecIFRS.GYONUM
            ;
--
            UPDATE
                URBFILE
            SET
                URB_IFSSNT = CRecIFRS.SNTCOD
              , URB_IFSSIR = CRecIFRS.SIRCOD
              , URB_IFSMSR = CRecIFRS.SUMSIR
            WHERE
                URB_DENNUM   =   CRecIFRS.DENNUM
            AND
                URB_GYONUM   =   CRecIFRS.GYONUM
            ;
--
            updcnt := updcnt + 1;
        END LOOP ;
--
        msg :=
            '[' || TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') || '] �F' ||
            '�@�@�@�p�^�[���R�[�Q�X�V�I��'                             ||
            ' (' || TO_CHAR(updcnt, 'FM99,999,990') || '�� �X�V)'
        ;
--
        DBMS_OUTPUT.PUT_LINE(msg);
--
        msg :=
            '[' || TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') || '] �F' ||
            '�@�@�p�^�[���R�X�V�I��'
        ;
--
        DBMS_OUTPUT.PUT_LINE(msg);
        DBMS_OUTPUT.NEW_LINE;
--
--
        -- *************************************************************************
        -- �p�^�[���S�F�o�׌������Z���^�[�̔���`�[�̍X�V
        -- (�p�^�[���P�`�R�ōX�V����Ă��Ȃ��`�[)
        -- *************************************************************************
        msg :=
            '[' || TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') || '] �F' ||
            '�@�p�^�[���S�X�V�J�n'
        ;
--
        DBMS_OUTPUT.PUT_LINE(msg);
--
        updcnt := 0 ;
        FOR
            CRecIFRS IN CReadPatern4
        LOOP
            UPDATE
                IFRSWORK
            SET
                WRK_IFSSNT = '      '
              , WRK_IFSSIR = '       '
              , WRK_IFSMSR = CRecIFRS.SUMSIR
            WHERE
                WRK_DENNUM   =   CRecIFRS.DENNUM
            AND
                WRK_GYONUM   =   CRecIFRS.GYONUM
            ;
--
            UPDATE
                URBFILE
            SET
                URB_IFSSNT = '      '
              , URB_IFSSIR = '       '
              , URB_IFSMSR = CRecIFRS.SUMSIR
            WHERE
                URB_DENNUM   =   CRecIFRS.DENNUM
            AND
                URB_GYONUM   =   CRecIFRS.GYONUM
            ;
--
            updcnt := updcnt + 1;
        END LOOP ;
--
--
        msg :=
            '[' || TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') || '] �F' ||
            '�@�@�p�^�[���S�X�V�I��'                                   ||
            ' (' || TO_CHAR(updcnt, 'FM99,999,990') || '�� �X�V)'
        ;
--
        DBMS_OUTPUT.PUT_LINE(msg);
        DBMS_OUTPUT.NEW_LINE;
--
        COMMIT ;
--
        msg :=
            '[' || TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') || '] �F' ||
            '�@' || dsp_nengtu || '���@�����I��'
        ;
--
        DBMS_OUTPUT.PUT_LINE(msg);
--
        msg :=
            '[' || TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') || '] �F' ||
            '*******************************************************'
        ;
--
        DBMS_OUTPUT.PUT_LINE(msg);
        DBMS_OUTPUT.NEW_LINE;
    END LOOP;
--
--
    msg :=
        '[' || TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') || '] �F' ||
        '����f�[�^�@IFRS�Ή��@�ڍs�����I��'
    ;
--
    DBMS_OUTPUT.PUT_LINE(msg);
END ;
/
--
COMMIT ;
--ROLLBACK ;
--
DROP TABLE IFRSWORK;
--
SET SERVEROUTPUT OFF
SET FEEDBACK ON
--
/*
Quit ;
*/
