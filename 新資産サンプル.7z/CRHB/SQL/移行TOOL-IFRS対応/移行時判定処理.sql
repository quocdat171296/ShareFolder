SET LINESIZE 10000
SET PAGESIZE 0
--SET FEEDBACK OFF
SET SERVEROUTPUT ON FORMAT WRAPPED
--
--
--
/* ************************************************************************** */
/* IFRS����@�ڍs����                                                         */
/* ************************************************************************** */
DECLARE
    IFRS_STT_NENGTU     CONSTANT    CHAR(6) := '201904';
--
    TYPE        ARR_NENGTU  IS  VARRAY(25)  OF  CHAR(6) ;
--
    nengtu      ARR_NENGTU;                                     --  �����N���w��ϐ�
    dsp_nengtu  VARCHAR2(12);
--
    msg         VARCHAR2(4096);                                 --  ���b�Z�[�W
--
    runmod      CRHBG110.VCHAR2ARRAY ;
    strymd      CRHBG110.VCHAR2ARRAY ;
    endymd      CRHBG110.VCHAR2ARRAY ;
    tancod      CRHBG110.VCHAR2ARRAY ;
    wstnam      CRHBG110.VCHAR2ARRAY ;
    retcod      CRHBG110.NUMARRAY    ;
    retmsg      CRHBG110.VCHAR2ARRAY ;
BEGIN
    msg :=
        '[' || TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') || '] �F' ||
        '����E�d���f�[�^�@���菈���@�J�n'
    ;
--
    DBMS_OUTPUT.PUT_LINE(msg);
    DBMS_OUTPUT.NEW_LINE;
--
--
    nengtu := ARR_NENGTU();                                                     --  �z��̏�����
    nengtu.extend(24);                                                          --  ��v�f�ǉ�
--
    -- �Ώ۔N�������l�Z�b�g
    FOR
        lop IN  nengtu.FIRST..nengtu.LAST
    LOOP
        nengtu(lop) := TO_CHAR(ADD_MONTHS(TO_DATE(IFRS_STT_NENGTU || '01', 'YYYYMMDD'), lop - 1), 'YYYYMM');
    END LOOP ;
--
--
    FOR
        lop IN  nengtu.FIRST..nengtu.LAST
    LOOP
        msg :=
            '[' || TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') || '] �F' ||
            '*******************************************************'
        ;
--
        DBMS_OUTPUT.PUT_LINE(msg);
--
        runmod(1) := '9'                 ;
        strymd(1) := nengtu(lop) || '01' ;
        endymd(1) := nengtu(lop) || '99' ;
        tancod(1) := '000000'            ;
        wstnam(1) := 'AWS'               ;
        retcod(1) := 0                   ;
        retmsg(1) := NULL                ;
--
        dsp_nengtu := SUBSTR(nengtu(lop), 1, 4) || '�N' || SUBSTR(nengtu(lop), 5, 2) || '����' ;
--
        msg :=
            '[' || TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') || '] �F' ||
            '�@' || dsp_nengtu || '���@���菈���@�J�n'
        ;
--
        DBMS_OUTPUT.PUT_LINE(msg);
--
        CRHBG110.CRHBG110A (
            runmod
          , strymd
          , endymd
          , tancod
          , wstnam
          , retcod, retmsg
        ) ;
--
        COMMIT ;
--
        msg :=
            '[' || TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') || '] �F' ||
            '�@' || dsp_nengtu || '���@���菈���@�I��'
        ;
--
        DBMS_OUTPUT.PUT_LINE(msg);
--
        msg :=
            '[' || TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') || '] �F' ||
            '*******************************************************'
        ;
--
        DBMS_OUTPUT.PUT_LINE(msg);
        DBMS_OUTPUT.NEW_LINE;
    END LOOP ;
--
--
    msg :=
        '[' || TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') || '] �F' ||
        '����E�d���f�[�^�@���菈���@�I��'
    ;
--
    DBMS_OUTPUT.PUT_LINE(msg);
END ;
/
--
COMMIT ;
--ROLLBACK ;
--
SET SERVEROUTPUT OFF
SET FEEDBACK ON
--
/*
Quit ;
*/
