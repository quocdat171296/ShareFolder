Truncate Table BRBTABL ;

Insert Into BRBTABL
Select
    '00' || BRB_BRBCOD ,
    BRB_BRBNAM ,
    '0'        ,
    '999998'   ,
    BRB_UPDDAY ,
    BRB_UPDTIM ,
    '999998'   ,
    BRB_UPDDAY ,
    BRB_UPDTIM 
From
    (
        Select
            *
        From
            CHUBU.BRBTABL
    );
--
Commit ;
--
/*
Quit ;
*/
--