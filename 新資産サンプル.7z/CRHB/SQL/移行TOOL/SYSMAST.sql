Truncate Table SYSMAST ;

Insert Into SYSMAST
Select
    SYS_KAICOD          AS  SYS_KAICOD ,
    Trim(SYS_KAIKNA)    AS  SYS_KAIKNA ,
    Trim(SYS_KAINAM)    AS  SYS_KAINAM ,
    ' '                 AS  SYS_INVNUM ,        /* Todo �b��I�� ' ' �Ƃ��� */
    ' '                 AS  SYS_GLNCOD ,        /* ToDo �b��I�� ' ' �Ƃ��� */
    SYS_ZIPCOD          AS  SYS_ZIPCOD ,
    Trim(SYS_ADRES1)    AS  SYS_ADRES1 ,
    Trim(SYS_ADRES2)    AS  SYS_ADRES2 ,
    SYS_TELNUM          AS  SYS_TELNUM ,
    SYS_FAXNUM          AS  SYS_FAXNUM ,
    Trim(SYS_MILADR)    AS  SYS_MILADR ,
    Trim(SYS_DAINAM)    AS  SYS_DAINAM ,
    SYS_KISMON          AS  SYS_KISMON ,
    SYS_NENDOO          AS  SYS_NENDOO ,
    SYS_MONTAI          AS  SYS_MONTAI ,
    SYS_MONDAY          AS  SYS_MONDAY ,
    SYS_MONYMD          AS  SYS_MONYMD ,
    CASE SYS_SIRHAS
		WHEN '1' THEN '0'
		WHEN '2' THEN '1'
		WHEN '3' THEN '2'
 		ELSE SYS_SIRHAS
	END                 AS  SYS_SIRHAS ,
    0                   AS  SYS_KJDAYS ,        /* Todo �b��I�� 0 �Ƃ��� */
    SYS_SYSKBN          AS  SYS_SYSKBN ,
    '20190101'          AS  SYS_MTSTDY ,        /* Todo �b��I�� '20190101' �Ƃ��� */
    '000000'            AS  SYS_MTSTTM ,        /* Todo �b��I�� '000000' �Ƃ��� */
    '20190101'          AS  SYS_MTEDDY ,        /* Todo �b��I�� '20190101' �Ƃ��� */
    '120000'            AS  SYS_MTEDTM ,        /* Todo �b��I�� '120000' �Ƃ��� */
    SYS_STRTIM          AS  SYS_STRTIM ,
    SYS_ENDTIM          AS  SYS_ENDTIM ,
    Trim(SYS_SNDMSG)    AS  SYS_SNDMSG ,
    SYS_JSNDAY          AS  SYS_JSNDAY ,
    '0'                 AS  SYS_NOUKBN ,        /* Todo �b��I�� '0' �Ƃ��� */
    '1'                 AS  SYS_LOGKBN ,        /* Todo �b��I�� '1' �Ƃ��� */
    '0'                 AS  SYS_DELFLG ,
    '999998'            AS  SYS_ADDTAN ,
    SYS_UPDDAY          AS  SYS_ADDDAY ,
    SYS_UPDTIM          AS  SYS_ADDTIM ,
    '999998'            AS  SYS_UPDTAN ,
    SYS_UPDDAY          AS  SYS_UPDDAY ,
    SYS_UPDTIM          AS  SYS_UPDTIM
From
    (
        Select
            *
        From
            CHUBU.SYSMAST
    );
--
Commit ;
--
/*
Quit ;
*/
--
