Truncate Table ARETABL ;
--
Insert Into ARETABL
Select
    '0' || ARE_ARECOD ,
    ARE_ARENAM ,
    ARE_RECKBN ,
    '999998'   ,
    ARE_UPDDAY ,
    ARE_UPDTIM ,
    '999998'   ,
    ARE_UPDDAY ,
    ARE_UPDTIM 
From
    (
        Select
            *
        From
            CHUBU.ARETABL
    );
--
Commit;
--
/*
Quit ;
*/
--