Truncate Table SIRMAST ;

Insert Into SIRMAST
Select
    SIR_SIRCOD          AS  SIR_SIRCOD ,
    Trim(SIR_SIRKNA)    AS  SIR_SIRKNA ,
    Trim(SIR_SIRNAM)    AS  SIR_SIRNAM ,
    Trim(SIR_SIRRYK)    AS  SIR_SIRRYK ,
    SIR_ZIPCOD          AS  SIR_ZIPCOD ,
    Trim(SIR_ADRES1)    AS  SIR_ADRES1 ,
    Trim(SIR_ADRES2)    AS  SIR_ADRES2 ,
    SIR_TELNUM          AS  SIR_TELNUM ,
    SIR_FAXNUM          AS  SIR_FAXNUM ,
    Trim(SIR_MILADR)    AS  SIR_MILADR ,
    SIR_TUSADR          AS  SIR_TUSADR ,
    Trim(SIR_SIRTAN)    AS  SIR_SIRTAN ,
    SIR_SIHCOD          AS  SIR_SIHCOD ,
    Trim(SIR_HONKNA)    AS  SIR_HONKNA ,
    Trim(SIR_HONNAM)    AS  SIR_HONNAM ,
    SIR_HONZIP          AS  SIR_HONZIP ,
    Trim(SIR_HONAD1)    AS  SIR_HONAD1 ,
    Trim(SIR_HONAD2)    AS  SIR_HONAD2 ,
    SIR_HONTEL          AS  SIR_HONTEL ,
    SIR_HONFAX          AS  SIR_HONFAX ,
    SIR_SIMDAY          AS  SIR_SIMDAY ,
    SIR_KESCLE          AS  SIR_KESCLE ,
    SIR_KESDAY          AS  SIR_KESDAY ,
    SIR_SIHHOU          AS  SIR_SIHHOU ,
    Trim(SIR_KOUMIG)    AS  SIR_KOUMIG ,
    Trim(SIR_KOUMEI)    AS  SIR_KOUMEI ,
    SIR_KOUNUM          AS  SIR_KOUNUM ,
    SIR_SYZKBN          AS  SIR_SYZKBN ,
    SIR_HASKBN          AS  SIR_HASKBN ,
    SIR_GTIKBN          AS  SIR_GTIKBN ,
    Trim(SIR_SIRBKO)    AS  SIR_SIRBKO ,
    SIR_HONCOD          AS  SIR_HONCOD ,
    Trim(SIR_GKONAM)    AS  SIR_GKONAM ,
    SIR_SHNKIN          AS  SIR_SHNKIN ,
    SIR_SUKKBN          AS  SIR_SUKKBN ,
    SIR_SMSKBN          AS  SIR_SMSKBN ,
    Trim(SIR_EMLADR)    AS  SIR_EMLADR ,
    SIR_RBTKBN          AS  SIR_RBTKBN ,
    Nvl2(EHS_TRICOD,'1','0') AS  SIR_HCEKBN ,
    Nvl2(EHS_TRICOD,'0','1') AS  SIR_ASNKBN ,
    '1'                 AS  SIR_JRYKBN ,
    '1'                 AS  SIR_SIHKBN ,
    CASE SYS_SIRHAS
		WHEN '1' THEN '0'
		WHEN '2' THEN '1'
		WHEN '3' THEN '2'
 		ELSE SYS_SIRHAS
	END             AS  SIR_SIRHAS ,
    '0'                 AS  SIR_KJOKBN ,
    '0'                 AS  SIR_TNKKBN ,
    '2'                 AS  SIR_DATKBN ,
    SIR_RECKBN          AS  SIR_DELFLG ,
    Nvl2(EHS_TRICOD,'0000000' || EHS_TRICOD ,'0000000000000') AS  SIR_JTTKCD ,
    Nvl2(EHS_STNCOD,'000' || EHS_STNCOD ,'00000')             AS  SIR_JTSCCD ,
    '999998'            AS  SIR_ADDTAN ,
    SIR_ADDDAY          AS  SIR_ADDDAY ,
    SIR_ADDTIM          AS  SIR_ADDTIM ,
    '999998'            AS  SIR_UPDTAN ,
    SIR_UPDDAY          AS  SIR_UPDDAY ,
    SIR_UPDTIM          AS  SIR_UPDTIM 
From
    (
        Select
            *
        From
            CHUBU.SIRMAST
    )
    Inner Join (
        Select
            SYS_KAICOD,
            SYS_SIRHAS
        From
            CHUBU.SYSMAST
    )
    On (
        '000000' = SYS_KAICOD
    ) 
    Left Outer Join (
        Select
            EHS_SIRCOD ,
            EHS_TRICOD ,
            EHS_STNCOD 
        From
            CHUBU.EHSTABL
    )
    On (
        SIR_SIRCOD = EHS_SIRCOD
    ) ;
--
Update
	SIRMAST
Set
	SIR_HCEKBN = '1' ,
	SIR_ASNKBN = '0'
Where
	SIR_SIRCOD In (
		Select
			DISTINCT JPT_SNDCOD
		From
			CHUBU.JPTTABL
		Where
			JPT_DATKBN = '1'
		And JPT_JUKKBN = '0'
	);
--
Commit ;
--
/*
Quit ;
*/
--
