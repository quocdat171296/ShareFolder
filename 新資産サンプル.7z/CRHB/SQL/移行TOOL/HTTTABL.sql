Truncate Table HTTTABL ;
--
Insert Into HTTTABL
Select
    '0' || SubstrB(HTT_TOKCOD,1,4) || '0' || SubstrB(HTT_TOKCOD,5,2) As HTT_TOKCOD ,
	'0' || SubstrB(HTT_TTKCOD,1,4) || '0' || SubstrB(HTT_TTKCOD,5,2) As HTT_TTKCOD ,
    '0'        ,
    '999998'   ,
    HTT_UPDDAY ,
    HTT_UPDTIM ,
    '999998'   ,
    HTT_UPDDAY ,
    HTT_UPDTIM 
From
    (
        Select
            *
        From
            CHUBU.HTTTABL
    ) ;
--
Commit ;
--
/*
Quit ;
*/
--
