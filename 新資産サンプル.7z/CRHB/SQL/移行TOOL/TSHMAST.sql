--2020/03/28 �q��P���P�ʖ��g�p

Truncate Table TSHMAST ;

Insert Into TSHMAST
Select
    '0' || SUBSTRB(TSH_TOKCOD, 1, 4) || '0' || SUBSTRB(TSH_TOKCOD, 5, 3)    AS  TSH_TOKCOD ,
    TSH_SHOCOD                                                              AS  TSH_SHOCOD ,
    Trim(TSH_TSHNAM)                                                        AS  TSH_TSHNAM ,
    TSH_JYTNKB                                                              AS  TSH_JYTNKB ,
    TSH_JYTNSU                                                              AS  TSH_JYTNSU ,
    '0'                                                                     AS  TSH_TNTNKB ,
    0                                                                       AS  TSH_TNTNSU ,
    TSH_SYZKBN                                                              AS  TSH_SYZKBN ,
    TSH_TANNAM                                                              AS  TSH_TANNAM ,
    TSH_TABNAM                                                              AS  TSH_TABNAM ,
    TSH_SIRCOD                                                              AS  TSH_SIRCOD ,
    '0000000' || TSH_TRICOD                                                 AS  TSH_TRICOD ,
    '000' || TSH_STNCOD                                                     AS  TSH_STNCOD ,
    TSH_KBNGRP                                                              AS  TSH_KBNGRP ,
    TSH_KBNCOD                                                              AS  TSH_KBNCOD ,
    TSH_EJKKBN                                                              AS  TSH_EJKKBN ,
    TSH_STHSUU                                                              AS  TSH_STHSUU ,
    '0' || SUBSTRB(TSH_NOUCOD, 1, 4) || '0' || SUBSTRB(TSH_NOUCOD, 5, 3)    AS  TSH_NOUCOD ,
    TSH_TSHBKO                                                              AS  TSH_TSHBKO ,
    TSH_SNTNKB                                                              AS  TSH_SNTNKB ,
    TSH_LURDAY                                                              AS  TSH_LURDAY ,
    '0'                                                                     AS  TSH_BTNKBN ,
    '0'                                                                     AS  TSH_SNDKBN ,
    TSH_RECKBN                                                              AS  TSH_DELFLG ,
    '999998'                                                                AS  TSH_ADDTAN ,
    TSH_ADDDAY                                                              AS  TSH_ADDDAY ,
    TSH_ADDTIM                                                              AS  TSH_ADDTIM ,
    '999998'                                                                AS  TSH_UPDTAN ,
    TSH_UPDDAY                                                              AS  TSH_UPDDAY ,
    TSH_UPDTIM                                                              AS  TSH_UPDTIM
From
    (
        Select
            *
        From
            CHUBU.TSHMAST
    ) ;
--
Commit ;
--
/*
Quit ;
*/
--
