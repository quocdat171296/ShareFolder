Truncate Table HBSTABL ;
--
Insert Into HBSTABL
Select
    HBS_SHOCOD ,
    '0' || SubstrB(BAG_TOKCOD,1,4) || '0' || SubstrB(BAG_TOKCOD,5,2) As HBS_TOKCOD ,
    '0' || HBS_ARECOD ,
    HBS_UPDYMD ,
    '0'        ,
    '999998'   ,
    HBS_UPDYMD ,
    HBS_UPDHMS ,
    '999998'   ,
    HBS_UPDYMD ,
    HBS_UPDHMS  
From
    (
        Select
            *
        From
            CHUBU.HBSTABL
    )
    Inner Join (
        Select 
            BAG_TOKCOD ,
			BAG_ARECOD
        From
            CHUBU.BAGTABL
        Group By 
            BAG_TOKCOD ,
			BAG_ARECOD
    )
    On (
        HBS_ARECOD = BAG_ARECOD
    ) 
    Inner Join (
		Select
			*
		From
			CHUBU.TSHMAST
	)
	On (
		HBS_SHOCOD = TSH_SHOCOD
	AND BAG_TOKCOD = TSH_TOKCOD 
	);
--
Commit ;
--
/*
Quit ;
*/
--
