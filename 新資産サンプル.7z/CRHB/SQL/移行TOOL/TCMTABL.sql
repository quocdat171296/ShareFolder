Truncate Table TCMTABL ;

/* �I�I�I�I�I�@�����f�[�^�����͎��{���Ȃ��@�I�I�I�I�I   */
/* �������������́u�q��ϊ��e�[�u��(CHAIN-FLOW)�v�Ɠ��� */
--Insert Into TCMTABL
--Select
--    '0' || TOK_TDNPTN || GRP_SSWCOD                                         AS  TCW_TDNPTN ,
--    TCW_STIKCD                                                              AS  TCW_STIKCD ,
--    TCW_STIECO                                                              AS  TCW_STIECO ,
--    '0092'                                                                  AS  TCW_STIBMN ,        /* Todo �b��� '0092' ��ݒ� */
--    '0' || SUBSTRB(TCW_TOKCOD, 1, 4) || '0' || SUBSTRB(TCW_TOKCOD, 5, 3)    AS  TCW_TOKCOD ,
--    '00'       || TCW_TKBCOD                                                AS  TCW_TKBCOD ,
--    '0' || TCW_SSWCOD                                                       AS  TCW_SSWCOD ,
--    '0' || SUBSTRB(TCW_TOKCOD, 1, 4) || '0' || SUBSTRB(TCW_TOKCOD, 5, 3)    AS  TCW_ASNSID ,        /* Todo �b��� [CR�E�q��R�[�h] ��ݒ� */
--    '0'                                                                     AS  TCW_DELFLG ,
--    '999998'                                                                AS  TCW_ADDTAN ,
--    TCW_UPDDAY                                                              AS  TCW_ADDDAY ,
--    TCW_UPDTIM                                                              AS  TCW_ADDTIM ,
--    '999998'                                                                AS  TCW_UPDTAN ,
--    TCW_UPDDAY                                                              AS  TCW_UPDDAY ,
--    TCW_UPDTIM                                                              AS  TCW_UPDTIM
--From
--    (
--        Select
--            *
--        From
--            CHUBU.TCWTABL
--    )
--    Inner Join (
--        Select
--            TOK_TOKCOD,
--            TOK_TDNPTN
--        From
--            CHUBU.TOKMAST
--    )
--    On (
--        TCW_TOKCOD = TOK_TOKCOD
--    )
--    Inner Join (
--        Select
--            *
--        From
--            CHUBU.TKJTABL
--        Where
--            TKJ_SSWCOD = '6'
--    )
--    On (
--        TOK_TDNPTN  = TKJ_TDNPTN
--    )
--    Inner Join (
--        Select
--            TKJ_TDNPTN                                          AS  GRP_TDNPTN,
--            TKJ_DNETYP                                          AS  GRP_DNETYP,
--            TKJ_DNHTYP                                          AS  GRP_DNHTYP,
--            Trim(To_Char(To_Number(Min(TKJ_SSWCOD)) -1, '000')) AS  GRP_SSWCOD
--        From
--            CHUBU.TKJTABL
--        Group By
--            TKJ_TDNPTN ,
--            TKJ_DNETYP ,
--            TKJ_DNHTYP
--    )
--    On (
--        TOK_TDNPTN = TKJ_TDNPTN
--    )
--Order By
--    TCW_TOKCOD ;
--
Commit ;
--
/*
Quit ;
*/
--
