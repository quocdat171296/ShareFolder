Truncate Table BSCTABL ;
--
Insert Into BSCTABL
Select
    '0' || SUBSTRB(BSC_TOKCOD, 1, 4) || '0' || SUBSTRB(BSC_TOKCOD, 5, 2) ,
    BSC_SHOCOD ,
    BSC_UPDDAY ,
    BSC_GENTNK ,
    '0'        ,
    '999998'   ,
    BSC_UPDDAY ,
    BSC_UPDTIM ,
    '999998'   ,
    BSC_UPDDAY ,
    BSC_UPDTIM
From
    (
        Select
            *
        From
            CHUBU.BSCTABL
    );
--
Commit ;
--
/*
Quit ;
*/
--
