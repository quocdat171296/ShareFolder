Truncate Table TKBTABL;

Insert Into TKBTABL
Select
    '0' || SUBSTRB(TKB_TOKCOD, 1, 4) || '0' || SUBSTRB(TKB_TOKCOD, 5, 3)    AS  TKB_TOKCOD ,
    '00' || TKB_TKBCOD                                                      AS  TKB_TKBCOD ,
    Trim(TKB_TKBNAM)                                                        AS  TKB_TKBNAM ,
    '000000' || TKB_STIBCO                                                  AS  TKB_STIBCO ,
    Trim(TKB_STIBMN)                                                        AS  TKB_STIBMN ,
    TKB_NIRRTU                                                              AS  TKB_NIRRTU ,
    TKB_RECKBN                                                              AS  TKB_DELFLG ,
    '999998'                                                                AS  TKB_ADDTAN ,
    TKB_ADDDAY                                                              AS  TKB_ADDDAY ,
    TKB_ADDTIM                                                              AS  TKB_ADDTIM ,
    '999998'                                                                AS  TKB_UPDTAN ,
    TKB_UPDDAY                                                              AS  TKB_UPDDAY ,
    TKB_UPDTIM                                                              AS  TKB_UPDTIM
From
    (
        Select
            *
        From
            CHUBU.TKBTABL
    ) ;
--
Commit ;
--
/*
Quit ;
*/
--
