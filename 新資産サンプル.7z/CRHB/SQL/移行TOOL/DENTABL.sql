Truncate Table DENTABL;
--
Insert Into DENTABL
Select
    DEN_DENKBN ,
    DEN_DENNUM ,
    '0'        ,
    '999998'   ,
    DEN_UPDDAY ,
    DEN_UPDTIM ,
    '999998'   ,
    DEN_UPDDAY ,
    DEN_UPDTIM 
From
    (
        Select
            *
        From
            CHUBU.DENTABL
    );
-
Insert Into DENTABL
Select
    '14'       ,
    '00000001' ,
    '0'        ,
    '999998'   ,
    '20200101' ,
    '000000'   ,
    '999998'   ,
    '20200101' ,
    '000000' 
From
	DUAL ;
--
Commit ;
--
/*
QUIT ;
*/
--
