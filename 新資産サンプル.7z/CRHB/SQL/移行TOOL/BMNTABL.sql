Truncate Table BMNTABL ;
--
Insert Into BMNTABL
Select
    '00' || BMN_BMNCOD As BMN_BMNCOD ,
    BMN_BMNNAM ,
    BMN_RECKBN ,
    '999998'   ,
    BMN_UPDDAY ,
    BMN_UPDTIM ,
    '999998'   ,
    BMN_UPDDAY ,
    BMN_UPDTIM 
From
    (
        Select
            *
        From
            CHUBU.BMNTABL
    )
--
Commit ;
--
/*
Quit ;
*/
--