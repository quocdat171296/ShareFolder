Truncate Table DNKTABL;
-- WEB�ȊO
Insert Into DNKTABL
Select
	'0' || DNK_TDNPTN || '000' As DNK_TDNPTN ,
	DNK_SYRKBN ,
	DNK_DNKKBN ,
	Trim(DNK_DNKNAM) As DNK_DNKNAM ,
	DNK_DSPKBN ,
	DNK_SYUKBN ,
	'0'        ,
	'0'        ,
	'999998'   ,
	DNK_UPDDAY ,
	DNK_UPDTIM ,
	'999998'   ,
	DNK_UPDDAY ,
	DNK_UPDTIM 
From
	(
		Select
			*
		From
			CHUBU.DNKTABL
    );
-- WEB�p
Insert Into DNKTABL
Select
	'90000000'       As DNK_TDNPTN ,
	DNK_SYRKBN ,
	DNK_DNKKBN ,
	Trim(DNK_DNKNAM) As DNK_DNKNAM ,
	DNK_DSPKBN ,
	DNK_SYUKBN ,
	'0'        ,
	'0'        ,
	'999998'   ,
	DNK_UPDDAY ,
	DNK_UPDTIM ,
	'999998'   ,
	DNK_UPDDAY ,
	DNK_UPDTIM 
--	*
From
	(
		Select
			*
		From
			CHUBU.DNKTABL
		Where
			DNK_TDNPTN = '0001'
	);
--
--Insert Into DNKTABL
--Select
--	'99999999' As DNK_TDNPTN ,
--	DNK_SYRKBN ,
--	DNK_DNKKBN ,
--	Trim(DNK_DNKNAM) As DNK_DNKNAM ,
--	DNK_DSPKBN ,
--	DNK_SYUKBN ,
--	'0'        ,
--	'0'        ,
--	'999998'   ,
--	DNK_UPDDAY ,
--	DNK_UPDTIM ,
--	'999998'   ,
--	DNK_UPDDAY ,
--	DNK_UPDTIM 
--From
--	(
--		Select
--			*
--		From
--			CHUBU.DNKTABL
--		Where
--			DNK_TDNPTN = '0000'
--	);
--
--  �d���p(WEB)
Insert
Into
	DNKTABL (
	    DNK_TDNPTN , 
		DNK_SYRKBN , 
		DNK_DNKKBN , 
		DNK_DNKNAM , 
		DNK_DSPKBN , 
		DNK_SYUKBN , 
		DNK_DFTFLG , 
		DNK_DELFLG , 
		DNK_ADDTAN , 
		DNK_ADDDAY , 
		DNK_ADDTIM , 
		DNK_UPDTAN , 
		DNK_UPDDAY , 
		DNK_UPDTIM
	)
	Values (
		'99999999' , 
		'3'        , 
		'01'       , 
		'�d��(WEB)', 
		'0'        , 
		'01'       , 
		'0'        , 
		'0'        , 
		'999998'   , 
	    TO_CHAR(SYSDATE, 'YYYYMMDD') ,
	    TO_CHAR(SYSDATE, 'HH24MISS') ,
		'999998'   , 
	    TO_CHAR(SYSDATE, 'YYYYMMDD') ,
	    TO_CHAR(SYSDATE, 'HH24MISS')
	);
--
Insert
Into
	DNKTABL (
	    DNK_TDNPTN , 
		DNK_SYRKBN , 
		DNK_DNKKBN , 
		DNK_DNKNAM , 
		DNK_DSPKBN , 
		DNK_SYUKBN , 
		DNK_DFTFLG , 
		DNK_DELFLG , 
		DNK_ADDTAN , 
		DNK_ADDDAY , 
		DNK_ADDTIM , 
		DNK_UPDTAN , 
		DNK_UPDDAY , 
		DNK_UPDTIM
	)
	Values (
		'99999999' , 
		'3'        , 
		'02'       , 
		'�ԕi(WEB)', 
		'0'        , 
		'02'       , 
		'0'        , 
		'0'        , 
		'999998'   , 
	    TO_CHAR(SYSDATE, 'YYYYMMDD') ,
	    TO_CHAR(SYSDATE, 'HH24MISS') ,
		'999998'   , 
	    TO_CHAR(SYSDATE, 'YYYYMMDD') ,
	    TO_CHAR(SYSDATE, 'HH24MISS')
	);
--
Insert
Into
	DNKTABL (
	    DNK_TDNPTN , 
		DNK_SYRKBN , 
		DNK_DNKKBN , 
		DNK_DNKNAM , 
		DNK_DSPKBN , 
		DNK_SYUKBN , 
		DNK_DFTFLG , 
		DNK_DELFLG , 
		DNK_ADDTAN , 
		DNK_ADDDAY , 
		DNK_ADDTIM , 
		DNK_UPDTAN , 
		DNK_UPDDAY , 
		DNK_UPDTIM
	)
	Values (
		'99999999' , 
		'3'        , 
		'03'       , 
		'�l��(WEB)', 
		'0'        , 
		'03'       , 
		'0'        , 
		'0'        , 
		'999998'   , 
	    TO_CHAR(SYSDATE, 'YYYYMMDD') ,
	    TO_CHAR(SYSDATE, 'HH24MISS') ,
		'999998'   , 
	    TO_CHAR(SYSDATE, 'YYYYMMDD') ,
	    TO_CHAR(SYSDATE, 'HH24MISS')
	);
--
Insert
Into
	DNKTABL (
	    DNK_TDNPTN , 
		DNK_SYRKBN , 
		DNK_DNKKBN , 
		DNK_DNKNAM , 
		DNK_DSPKBN , 
		DNK_SYUKBN , 
		DNK_DFTFLG , 
		DNK_DELFLG , 
		DNK_ADDTAN , 
		DNK_ADDDAY , 
		DNK_ADDTIM , 
		DNK_UPDTAN , 
		DNK_UPDDAY , 
		DNK_UPDTIM
	)
	Values (
		'99999999' , 
		'3'        , 
		'04'       , 
		'����(WEB)', 
		'0'        , 
		'04'       , 
		'0'        , 
		'0'        , 
		'999998'   , 
	    TO_CHAR(SYSDATE, 'YYYYMMDD') ,
	    TO_CHAR(SYSDATE, 'HH24MISS') ,
		'999998'   , 
	    TO_CHAR(SYSDATE, 'YYYYMMDD') ,
	    TO_CHAR(SYSDATE, 'HH24MISS')
	);
--
--  �d���p(�ʏ�`�[)
--
Insert
Into
	DNKTABL (
	    DNK_TDNPTN , 
		DNK_SYRKBN , 
		DNK_DNKKBN , 
		DNK_DNKNAM , 
		DNK_DSPKBN , 
		DNK_SYUKBN , 
		DNK_DFTFLG , 
		DNK_DELFLG , 
		DNK_ADDTAN , 
		DNK_ADDDAY , 
		DNK_ADDTIM , 
		DNK_UPDTAN , 
		DNK_UPDDAY , 
		DNK_UPDTIM
	)
	Values (
		'99999999' , 
		'3'        , 
		'18'       , 
		'�d��(+)'  , 
		'1'        , 
		'01'       , 
		'1'        , 
		'0'        , 
		'999998'   , 
	    TO_CHAR(SYSDATE, 'YYYYMMDD') ,
	    TO_CHAR(SYSDATE, 'HH24MISS') ,
		'999998'   , 
	    TO_CHAR(SYSDATE, 'YYYYMMDD') ,
	    TO_CHAR(SYSDATE, 'HH24MISS')
	);
Insert
Into
	DNKTABL (
	    DNK_TDNPTN , 
		DNK_SYRKBN , 
		DNK_DNKKBN , 
		DNK_DNKNAM , 
		DNK_DSPKBN , 
		DNK_SYUKBN , 
		DNK_DFTFLG , 
		DNK_DELFLG , 
		DNK_ADDTAN , 
		DNK_ADDDAY , 
		DNK_ADDTIM , 
		DNK_UPDTAN , 
		DNK_UPDDAY , 
		DNK_UPDTIM
	)
	Values (
		'99999999'    , 
		'3'           , 
		'26'          , 
		'�ԕi/�ԓ`(-)', 
		'1'           , 
		'02'          , 
		'1'           , 
		'0'           , 
		'999998'      , 
	    TO_CHAR(SYSDATE, 'YYYYMMDD') ,
	    TO_CHAR(SYSDATE, 'HH24MISS') ,
		'999998'   , 
	    TO_CHAR(SYSDATE, 'YYYYMMDD') ,
	    TO_CHAR(SYSDATE, 'HH24MISS')
	);
--
Insert
Into
	DNKTABL (
	    DNK_TDNPTN , 
		DNK_SYRKBN , 
		DNK_DNKKBN , 
		DNK_DNKNAM , 
		DNK_DSPKBN , 
		DNK_SYUKBN , 
		DNK_DFTFLG , 
		DNK_DELFLG , 
		DNK_ADDTAN , 
		DNK_ADDDAY , 
		DNK_ADDTIM , 
		DNK_UPDTAN , 
		DNK_UPDDAY , 
		DNK_UPDTIM
	)
	Values (
		'99999999'    , 
		'3'           , 
		'28'          , 
		'�l���`�['    , 
		'1'           , 
		'03'          , 
		'1'           , 
		'0'           , 
		'999998'      , 
	    TO_CHAR(SYSDATE, 'YYYYMMDD') ,
	    TO_CHAR(SYSDATE, 'HH24MISS') ,
		'999998'   , 
	    TO_CHAR(SYSDATE, 'YYYYMMDD') ,
	    TO_CHAR(SYSDATE, 'HH24MISS')
	);
--
-- �����`���WEB�̂ݍ쐬
--
--Insert
--Into
--	DNKTABL (
--	    DNK_TDNPTN , 
--		DNK_SYRKBN , 
--		DNK_DNKKBN , 
--		DNK_DNKNAM , 
--		DNK_DSPKBN , 
--		DNK_SYUKBN , 
--		DNK_DFTFLG , 
--		DNK_DELFLG , 
--		DNK_ADDTAN , 
--		DNK_ADDDAY , 
--		DNK_ADDTIM , 
--		DNK_UPDTAN , 
--		DNK_UPDDAY , 
--		DNK_UPDTIM
--	)
--	Values (
--		'99999999'    , 
--		'3'           , 
--		'29'          , 
--		'�����`�['    , 
--		'0'           , 
--		'04'          , 
--		'0'           , 
--		'0'           , 
--		'999998'      , 
--	    TO_CHAR(SYSDATE, 'YYYYMMDD') ,
--	    TO_CHAR(SYSDATE, 'HH24MISS') ,
--		'999998'   , 
--	    TO_CHAR(SYSDATE, 'YYYYMMDD') ,
--	    TO_CHAR(SYSDATE, 'HH24MISS')
--	);
--
Update
	DNKTABL
Set
	DNK_DFTFLG = '1'
Where
	DNK_DNKKBN = '18';
--
Commit;
--
/*
QUIT ;
*/
--
