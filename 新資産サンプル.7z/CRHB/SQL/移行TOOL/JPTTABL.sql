Truncate Table JPTTABL ;
-- 2020/03/28 �󒍉ۋ敪�ǉ��ɔ����ύX

--
Insert Into
	JPTTABL (
		JPT_ARECOD ,
		JPT_TRICOD ,
		JPT_STNCOD ,
		JPT_DATKBN ,
		JPT_SNDCOD ,
		JPT_SIRCOD ,
		JPT_SNTCOD ,
		JPT_SSWCOD ,
		JPT_DELFLG ,
		JPT_ADDTAN ,
		JPT_ADDDAY ,
		JPT_ADDTIM ,
		JPT_UPDTAN ,
		JPT_UPDDAY ,
		JPT_UPDTIM ,
		JPT_JUKKBN 
	)
Select
    '0' || JPT_ARECOD ,
    '0000000' || JPT_TRICOD As JPT_TRICOD ,
    '000' || JPT_STNCOD As JPT_STNCOD ,
    JPT_DATKBN ,
    JPT_SNDCOD ,
    JPT_SIRCOD ,
    JPT_SNTCOD ,
    '0' || JPT_SSWCOD ,
    '0'        ,
    '999998'   ,
    JPT_UPDDAY ,
    JPT_UPDTIM ,
    '999998'   ,
    JPT_UPDDAY ,
    JPT_UPDTIM ,
    JPT_JUKKBN 
From
    (
        Select
            *
        From
            CHUBU.JPTTABL
    ) ;
--
Commit ;
--
/*
Quit ;
*/
--
