Truncate Table CATTABL;
--
Insert Into CATTABL
Select
    CAT_CATEGO ,
    CAT_CATNAM ,
    '0'        ,
    '999998'   ,
    CAT_UPDDAY ,
    CAT_UPDTIM ,
    '999998'   ,
    CAT_UPDDAY ,
    CAT_UPDTIM 
From
    (
        Select
            *
        From
            CHUBU.CATTABL
    );
--
Commit ;
--
/*
QUIT ;
*/
--
