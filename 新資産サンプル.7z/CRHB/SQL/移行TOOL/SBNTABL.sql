Truncate Table SBNTABL ;
--
Insert Into SBNTABL
Select
    SBN_BURCOD ,
    Trim(SBN_BBUNAM) As SBN_BBUNAM ,
    Trim(SBN_CBUNAM) As SBN_CBUNAM ,
    Trim(SBN_SBUNAM) As SBN_SBUNAM ,
    SBN_SNTBUR ,
    '0'        ,
    '999998'   ,
    BBN_UPDDAY ,
    BBN_UPDTIM ,
    '999998'   ,
    BBN_UPDDAY ,
    BBN_UPDTIM 
From
    (
        Select
            *
        From
            CHUBU.SBNTABL
    ) ;
--
Commit ;
--
/*
Quit ;
*/
--
