Truncate Table SCGTABL ;
--
Insert   Into  SCGTABL
(
    SCG_TOKCOD ,
    SCG_TKBCOD ,
    SCG_TSHCOD ,
    SCG_SSWCOD ,
    SCG_SHOCOD ,
    SCG_TSHDAI ,
    SCG_MSG061 ,
    SCG_DELFLG ,
    SCG_ADDTAN ,
    SCG_ADDDAY ,
    SCG_ADDTIM ,
    SCG_UPDTAN ,
    SCG_UPDDAY ,
    SCG_UPDTIM  
)
Select
    '0'   || SUBSTRB(SCG_TOKCOD, 1, 4) || '0' || SUBSTRB(SCG_TOKCOD, 5, 2)    AS  SCG_TOKCOD ,
    '00'  || SCG_TKBCOD                                                       AS  SCG_TKBCOD ,
    '000' || SCG_TSHCOD AS SCG_TSHCOD,
    '00'                             ,
    SCG_SHOCOD ,
    '000' || SCG_TSHDAI AS SCG_TSHDAI,
    ' '        ,
    '0'        ,
    '999998'   ,
    SCG_UPDDAY ,
    SCG_UPDTIM ,
    '999998'   ,
    SCG_UPDDAY ,
    SCG_UPDTIM 
From
    (
        Select
            *
        From
            CHUBU.SCGTABL
    );
--

Commit ;
--
/*
Quit ;
*/
--
