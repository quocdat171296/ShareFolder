Truncate Table KYSTABL ;

Insert Into KYSTABL
Select
    KYS_KAIMON ,
    KYS_KKMCOD ,
    KYS_YSNGAK ,
    '0'        ,
    '999998'   ,
    TO_CHAR(SYSDATE, 'YYYYMMDD') ,
    TO_CHAR(SYSDATE, 'HH24MISS') ,
    '999998'   ,
    TO_CHAR(SYSDATE, 'YYYYMMDD') ,
    TO_CHAR(SYSDATE, 'HH24MISS')
From
    (
        Select
            *
        From
            CHUBU.KYSTABL
    );
--
Commit ;
--
/*
Quit ;
*/
--
