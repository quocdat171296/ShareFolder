Truncate Table TANTABL ;

Insert Into TANTABL
Select
    TAN_TANCOD                  AS  TAN_TANCOD ,
    Trim(TAN_TANNAM)            AS  TAN_TANNAM ,
    ' '                         AS  TAN_TANKNA ,
    TAN_PASWRD                  AS  TAN_PASWRD ,
    Trim(TAN_MILADR)            AS  TAN_MILADR ,
    '00' || TAN_BMNCOD          AS  TAN_BMNCOD ,
    TAN_BSYCOD                  AS  TAN_BSYCOD ,
    TAN_MNTKBN                  AS  TAN_MNTKBN ,
    '0' || TAN_KNRKBN           AS  TAN_KNRKBN ,
    NVL(Trim(TAN_USEPCN), ' ')  AS  TAN_USEPCN ,
    ' '                         AS  TAN_MNUVER ,
    ' '                         AS  TAN_TMPDIR ,
    TAN_RECKBN                  AS  TAN_DELFLG ,
    '999998'                    AS  TAN_ADDTAN ,
    TAN_ADDDAY                  AS  TAN_ADDDAY ,
    TAN_ADDTIM                  AS  TAN_ADDTIM ,
    '999998'                    AS  TAN_UPDTAN ,
    TAN_UPDDAY                  AS  TAN_UPDDAY ,
    TAN_UPDTIM                  AS  TAN_UPDTIM
From
    (
        Select
            *
        From
            CHUBU.TANTABL
    );
--
Update
	TANTABL
Set
	TAN_KNRKBN = '09'
Where
	TAN_KNRKBN = '01';
--
Update
	TANTABL
Set
	TAN_KNRKBN = '01'
Where
	TAN_KNRKBN = '00';
--
Commit ;
--
/*
Quit ;
*/
--
