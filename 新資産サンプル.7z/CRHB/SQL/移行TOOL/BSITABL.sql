Truncate Table BSITABL ;

Insert Into BSITABL
Select
    BSI_SNTCOD ,
    BSI_SHOCOD ,
    BSI_COMNT1 ,
    BSI_COMNT2 ,
    BSI_COMNT3 ,
    BSI_COMNT4 ,
    BSI_COMNT5 ,
    '0'        ,
    BSI_JTNKBN ,
    BSI_KNKKBN ,
    BSI_RKJZK0 ,
    BSI_RKHCT0 ,
    BSI_RKJZK1 ,
    BSI_RKHCT1 ,
    BSI_RKJZK2 ,
    BSI_RKHCT2 ,
    999.99     ,
    BSI_RECKBN ,
    '999998'   ,
    BSI_ADDDAY ,
    BSI_ADDTIM ,
    '999998'   ,
    BSI_UPDDAY ,
    BSI_UPDTIM                                                                                                                                                                                                                                                                                                                                                               
From
    (
        Select
            *
        From
            CHUBU.BSITABL
    );
--
Commit ;
--
/*
Quit ;
*/
--