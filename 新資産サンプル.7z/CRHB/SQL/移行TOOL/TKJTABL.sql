Truncate Table TKJTABL;
--
Insert Into TKJTABL ( 
    TKJ_TOKCOD,
    TKJ_TDNPTN,
    TKJ_SSWCOD,
    TKJ_SSWNAM,
    TKJ_SWKCOD,
    TKJ_NHSCOD,
    TKJ_SZSKBN,
    TKJ_DNHCMT,
    TKJ_DELFLG,
    TKJ_ADDTAN,
    TKJ_ADDDAY,
    TKJ_ADDTIM,
    TKJ_UPDTAN,
    TKJ_UPDDAY,
    TKJ_UPDTIM
)
Select
    '0' || SUBSTRB(TOK_TOKCOD, 1, 4) || '0' || SUBSTRB(TOK_TOKCOD, 5, 2)    AS  TKJ_TOKCOD,
    '0' || TOK_TDNPTN || '000'                                              AS  TKJ_TDNPTN,
    '0' || TKJ_SSWCOD                                                       AS  TKJ_SSWCOD,
    TKJ_SSWNAM                                                              AS  TKJ_SSWNAM,
    '0000000' || TKJ_SWKCOD                                                 AS  TKJ_SWKCOD,
    NVL(TKS_HSOTOK, '00000000')                                             AS  TKJ_NHSCOD,
    TKJ_SZSKBN                                                              AS  TKJ_SZSKBN,
    NVL(TKJ_DNHCMT, ' ')                                                    AS  TKJ_DNHCMT,
    '0'                                                                     AS  TKJ_DELFLG,
    '999998'                                                                AS  TKJ_ADDTAN,
    TKJ_UPDDAY                                                              AS  TKJ_ADDDAY,
    TKJ_UPDTIM                                                              AS  TKJ_ADDTIM,
    '999998'                                                                AS  TKJ_UPDTAN,
    TKJ_UPDDAY                                                              AS  TKJ_UPDDAY,
    TKJ_UPDTIM                                                              AS  TKJ_UPDTIM
From
    (
        Select
            TOK_TOKCOD,
            TOK_TDNPTN
        From
            CHUBU.TOKMAST
    )
    Inner Join (
        Select
            *
        From
            CHUBU.TKJTABL
    )
    On (
        TOK_TDNPTN  = TKJ_TDNPTN
    )
    Left  Join (
        Select
            TKS_TOKCOD,
            '0' || SUBSTRB(Min(TKS_HSOTOK), 1, 4) || '0' || SUBSTRB(Min(TKS_HSOTOK), 5, 3)  AS  TKS_HSOTOK
        From
            CHUBU.TKSMAST
        Where
            TKS_HSOTOK != '000000'
        Group By
            TKS_TOKCOD
        Order By
            TKS_TOKCOD
    )
    On (
        TOK_TOKCOD  = TKS_TOKCOD
    )
Order By
    TOK_TOKCOD;
--  WEB�����߯�
Update
	TKJTABL
Set
	TKJ_TDNPTN = '90000000'
Where
	(
		TKJ_TOKCOD,
		TKJ_SSWCOD
	)
	In (
		Select
		    '0' || SUBSTRB(TCW_TOKCOD, 1, 4) || '0' || SUBSTRB(TCW_TOKCOD, 5, 3)    AS  TCW_TOKCOD ,
			'0' || TCW_SSWCOD As TCW_SSWCOD
		From
			CHUBU.TCWTABL
		Group By
			TCW_TOKCOD ,
			TCW_SSWCOD
	);
--
/* �������ߏ����̊���Ȗڈꗗ�\���p�̃��R�[�h�ǉ� */
INSERT INTO TKJTABL
SELECT
    '99999999'  AS  TKJ_TOKCOD,
    TKJ_SSWCOD  AS  TKJ_SSWCOD,
    TKJ_SSWNAM  AS  TKJ_SSWNAM,
    '99999999'  AS  TKJ_TDNPTN,
    '000000'    AS  TKJ_SWKCOD,
    '00000000'  AS  TKJ_NHSCOD,
    '2'         AS  TKJ_SZSKBN,
    ' '         AS  TKJ_DNHCMT,
    '0'         AS  TKJ_DELFLG,
    '999998'    AS  TKJ_ADDTAN,
    '20190612'  AS  TKJ_ADDDAY,
    '000000'    AS  TKJ_ADDTIM,
    '999998'    AS  TKJ_UPDTAN,
    '20190612'  AS  TKJ_UPDDAY,
    '000000'    AS  TKJ_UPDTIM
FROM    TKJTABL
WHERE   TKJ_TOKCOD   = '00001001'
AND     TKJ_DELFLG   = '0' ;
--
Commit ;
--
/*
Quit ;
*/
--
