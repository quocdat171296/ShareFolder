Truncate Table TTNTABL ;

Insert Into TTNTABL
Select
    '0' || SUBSTRB(TTN_TOKCOD, 1, 4) || '0' || SUBSTRB(TTN_TOKCOD, 5, 3)    AS  TTN_TOKCOD ,
    '0'  || TTN_TKSCOD                                                      AS  TTN_TKSCOD ,
    '00' || TTN_TKBCOD                                                      AS  TTN_TKBCOD ,
    TTN_TANCOD                                                              AS  TTN_TANCOD ,
    '0'  || TTN_SSWCOD                                                      AS  TTN_SSWCOD ,
    '00' || TTN_URIBCD                                                      AS  TTN_URIBCD ,
    '0'                                                                     AS  TTN_DELFLG ,
    '999998'                                                                AS  TTN_ADDTAN ,
    TTN_UPDDAY                                                              AS  TTN_ADDDAY ,
    TTN_UPDTIM                                                              AS  TTN_ADDTIM ,
    '999998'                                                                AS  TTN_UPDTAN ,
    TTN_UPDDAY                                                              AS  TTN_UPDDAY ,
    TTN_UPDTIM                                                              AS  TTN_UPDTIM
From
    (
        Select
            *
        From
            CHUBU.TTNTABL
    ) ;
--
Update
	TTNTABL
Set
	TTN_TKSCOD = '99999'
Where
	TTN_TKSCOD = '09999';
--
Commit ;
--
/*
Quit ;
*/
--
