Truncate Table STTTABL ;

Insert Into STTTABL
Select
    '0' || SUBSTRB(STT_TOKCOD, 1, 4) || '0' || SUBSTRB(STT_TOKCOD, 5, 3)    AS  STT_TOKCOD ,
    '0' || SUBSTRB(STT_TTKCOD, 1, 4) || '0' || SUBSTRB(STT_TTKCOD, 5, 3)    AS  STT_TTKCOD ,
    '0'                                                                     AS  STT_DELFLG ,
    '999998'                                                                AS  STT_ADDTAN ,
    STT_UPDDAY                                                              AS  STT_ADDDAY ,
    STT_UPDTIM                                                              AS  STT_ADDTIM ,
    '999998'                                                                AS  STT_UPDTAN ,
    STT_UPDDAY                                                              AS  STT_UPDDAY ,
    STT_UPDTIM                                                              AS  STT_UPDTIM
From
    (
        Select
            *
        From
            CHUBU.STTTABL
    );
--
Commit ;
--
/*
Quit ;
*/
--
