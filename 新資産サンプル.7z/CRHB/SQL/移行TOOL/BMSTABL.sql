Truncate Table BMSTABL ;

Insert Into BMSTABL
Select
    '0' || SubstrB(BMS_TOKCOD,1,4) || '0' || SubstrB(BMS_TOKCOD,5,2) As BMS_TOKCOD ,
    BMS_MSG001 ,
    BMS_MSG002 ,
    BMS_MSG004 ,
    BMS_MSG005 ,
    BMS_MSG007 ,
    BMS_MSG009 ,
    '01'       ,
    '0'        ,
    '999998'   ,
    BMS_UPDDAY ,
    BMS_UPDTIM ,
    '999998'   ,
    BMS_UPDDAY ,
    BMS_UPDTIM 
From
    (
        Select
            *
        From
            CHUBU.BMSTABL
    ) ;
--
Commit ;
--
/*
Quit ;
*/
--