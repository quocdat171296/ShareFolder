Truncate Table SHGTABL ;
--
Insert Into SHGTABL
Select
    SHG_SHGCOD ,
    Trim(SHG_SHGKNA) As SHG_SHGKNA ,
    Trim(SHG_SHGNAM) As SHG_SHGNAM ,
    SHG_SYZKBN ,
    '00'       ,
    '0'        ,
    '999998'   ,
    SHG_UPDDAY ,
    SHG_UPDTIM ,
    '999998'   ,
    SHG_UPDDAY ,
    SHG_UPDTIM 
From
    (
        Select
            *
        From
            CHUBU.SHGTABL
    ) ;
--
Commit ;
--
/*
Quit ;
*/
--
