Truncate Table TNSTABL;

Insert Into TNSTABL
Select
    '0' || SUBSTRB(TKS_TOKCOD, 1, 4) || '0' || SUBSTRB(TKS_TOKCOD, 5, 2) AS TNS_TOKCOD ,
    '0' || TKS_TKSCOD                                                    AS TNS_TKSCOD ,
	'01'                                                                 AS TNS_TNSCOD ,
    Trim(TKS_TKSNAM)                                                     AS TNS_TNSNAM ,
    TKS_RECKBN                                                           AS TNS_DELFLG ,
    '999998'                                                             AS TNS_ADDTAN ,
    TKS_ADDDAY                                                           AS TNS_ADDDAY ,
    TKS_ADDTIM                                                           AS TNS_ADDTIM ,
    '999998'                                                             AS TNS_UPDTAN ,
    TKS_UPDDAY                                                           AS TNS_UPDDAY ,
    TKS_UPDTIM                                                           AS TNS_UPDTIM 
From
    (
        Select
            *
        From
            CHUBU.TKSMAST
            Where
                TKS_TOKCOD IS NOT NULL
    ) ;
--
/* ���Z�����͎x�X�R�[�h���u9999�v�ō쐬����Ă��邽��            */
/* �x�X�R�[�h���u09999�v�̃��R�[�h�̎x�X�R�[�h���u999990�v�֕ϊ� */
Update TNSTABL
Set TNS_TKSCOD = '99999'
Where
    TNS_TKSCOD = '09999';
--
--
Commit ;
--
/*
Quit ;
*/
--
