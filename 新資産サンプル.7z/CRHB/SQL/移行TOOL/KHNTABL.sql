Truncate Table KHNTABL ;
--
Commit ;
--
/*
Quit ;
*/
--
