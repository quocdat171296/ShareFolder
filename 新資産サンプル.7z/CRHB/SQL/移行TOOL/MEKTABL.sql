Truncate Table MEKTABL ;
--
Insert Into MEKTABL
Select 
    '00' || MEK_MEKCOD As MEK_MEKCOD ,
    MEK_SUBCOD ,
    MEK_MEKKNA ,
    MEK_MEKNAM ,
    MEK_ZIPCOD ,
    Replace(Replace(MEK_ADRES1,Chr(10),''),Chr(13),'') As MEK_ADRES1 ,
    Replace(Replace(MEK_ADRES2,Chr(10),''),Chr(13),'') As MEK_ADRES2 ,
    MEK_TELNUM ,
    MEK_FAXNUM ,
    MEK_SENTER ,
    MEK_RECKBN ,
    '999998'   ,
    MEK_ADDDAY ,
    MEK_ADDTIM ,
    '999998'   ,
    MEK_UPDDAY ,
    MEK_UPDTIM  
From
    (
        Select
            *
        From
            CHUBU.MEKTABL
    ) ;
--
Commit ;
--
/*
Quit ;
*/
--
