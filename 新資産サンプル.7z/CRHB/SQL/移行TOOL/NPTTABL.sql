Truncate Table NPTTABL ;
--
Insert Into NPTTABL
Select
    '0' || SubstrB(NPT_TOKCOD,1,4) || '0' || SubstrB(NPT_TOKCOD,5,2) As NPT_TOKCOD ,
    '0' || NPT_TKSCOD ,
    '00' || NPT_TKBCOD ,
    '0' || NPT_SSWCOD As NPT_SSWCOD ,
    '00000101' ,
    '99991231' ,
    NPT_MONDAY ,
    NPT_TUEDAY ,
    NPT_WEDDAY ,
    NPT_THUDAY ,
    NPT_FRIDAY ,
    NPT_SATDAY ,
    NPT_SUNDAY ,
    '0'        ,
    '0'        ,
    '999998'   ,
    NPT_UPDDAY ,
    NPT_UPDTIM ,
    '999998'   ,
    NPT_UPDDAY ,
    NPT_UPDTIM  
From
    (
        Select
            *
        From
            CHUBU.NPTTABL
    ) ;
--
Commit ;
--
/*
Quit ;
*/
--
