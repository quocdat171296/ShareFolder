-------------------------------------------
-- 2020/10/07 �����TCE��TCB�ύX
-------------------------------------------
--
Truncate Table TCBTABL ;

Insert Into TCBTABL
-- BMS
Select
    '0' || TCB_TDNPTN || '000'                                              AS  TCB_TDNPTN ,
    TCB_STIKCD                                                              AS  TCB_STIKCD ,
    '00000000' || TCB_STIECO                                                AS  TCB_STIECO ,
    '000000'   || TCB_STIBMN                                                AS  TCB_STIBMN ,
    '0' || SUBSTRB(TCB_TOKCOD, 1, 4) || '0' || SUBSTRB(TCB_TOKCOD, 5, 2)    AS  TCB_TOKCOD ,
    '0'        || TCB_TKSCOD                                                AS  TCB_TKSCOD ,
    '00'       || TCB_TKBCOD                                                AS  TCB_TKBCOD ,
    '0' || SUBSTRB(TCB_ASNSID, 1, 4) || '0' || SUBSTRB(TCB_ASNSID, 5, 2)    AS  TCB_ASNSID ,
    TCB_FILKBN                                                              AS  TCB_FILKBN ,
    '0'                                                                     AS  TCB_DELFLG ,
    '999998'                                                                AS  TCB_ADDTAN ,
    TCB_UPDDAY                                                              AS  TCB_ADDDAY ,
    TCB_UPDTIM                                                              AS  TCB_ADDTIM ,
    '999998'                                                                AS  TCB_UPDTAN ,
    TCB_UPDDAY                                                              AS  TCB_UPDDAY ,
    TCB_UPDTIM                                                              AS  TCB_UPDTIM
From
    (
        Select
            *
        From
            CHUBU.TCBTABL
		Where
			TCB_TOKCOD <> '000305'
    )
UNION
-- V-EDI
Select
    '0' || TCV_TDNPTN || '000'                                              AS  TCB_TDNPTN ,
    TCV_STIKCD                                                              AS  TCB_STIKCD ,
    '00000000' || TCV_STIECO                                                AS  TCB_STIECO ,
    '000000'   || TCV_STIBMN                                                AS  TCB_STIBMN ,
    '0' || SUBSTRB(TCV_TOKCOD, 1, 4) || '0' || SUBSTRB(TCV_TOKCOD, 5, 2)    AS  TCB_TOKCOD ,
    '0'        || TCV_TKSCOD                                                AS  TCB_TKSCOD ,
    '00'       || TCV_TKBCOD                                                AS  TCB_TKBCOD ,
    '0' || SUBSTRB(TCV_ASNSID, 1, 4) || '0' || SUBSTRB(TCV_ASNSID, 5, 2)    AS  TCB_ASNSID ,
    TCV_FILKBN                                                              AS  TCB_FILKBN ,
    '0'                                                                     AS  TCB_DELFLG ,
    '999998'                                                                AS  TCB_ADDTAN ,
    TCV_UPDDAY                                                              AS  TCB_ADDDAY ,
    TCV_UPDTIM                                                              AS  TCB_ADDTIM ,
    '999998'                                                                AS  TCB_UPDTAN ,
    TCV_UPDDAY                                                              AS  TCB_UPDDAY ,
    TCV_UPDTIM                                                              AS  TCB_UPDTIM
From
    (
        Select
            *
        From
            CHUBU.TCVTABL
        Where
            TCV_TDNPTN <> '0004'                                                -- ���[�X���͏d�����������邪�A�����Ȃ��ߏ��O����
		And TCV_TOKCOD <> '000302'
    )
UNION
--EOS(JCA)
Select
    '0' || TCE_TDNPTN || '000'                                              AS  TCB_TDNPTN ,
    '000000000' || TCE_STIKCD                                               AS  TCB_STIKCD ,
    '00000000'  || TCE_STIECO                                               AS  TCB_STIECO ,
    '000000'    || TCE_STIBMN                                               AS  TCB_STIBMN ,
    '0' || SUBSTRB(TCE_TOKCOD, 1, 4) || '0' || SUBSTRB(TCE_TOKCOD, 5, 3)    AS  TCB_TOKCOD ,
    '0'         || TCE_TKSCOD                                               AS  TCB_TKSCOD ,
    '00'        || TCE_TKBCOD                                               AS  TCB_TKBCOD ,
    Nvl2(
		ASF_ASNSID ,
		'0' || SUBSTRB(ASF_ASNSID, 1, 4) || '0' || SUBSTRB(ASF_ASNSID, 5, 3) ,
		'0' || SUBSTRB(TCE_ASNSID, 1, 4) || '0' || SUBSTRB(TCE_ASNSID, 5, 3) 
	)   																    AS  TCB_ASNSID ,
    '3'                                                                     AS  TCB_FILKBN ,
    '0'                                                                     AS  TCB_DELFLG ,
    '999998'                                                                AS  TCB_ADDTAN ,
    TCE_UPDDAY                                                              AS  TCB_ADDDAY ,
    TCE_UPDTIM                                                              AS  TCB_ADDTIM ,
    '999998'                                                                AS  TCB_UPDTAN ,
    TCE_UPDDAY                                                              AS  TCB_UPDDAY ,
    TCE_UPDTIM                                                              AS  TCB_UPDTIM
From
    (
        Select
            *
        From
            CHUBU.TCETABL
        Where
            TCE_TOKCOD Not IN (                                             -- ���[�X���͏d�����������邪�A�����Ȃ��ߏ��O����
                '000203',
                '000101',
                '000500',
                '000140',
                '000102',
                '000103',
                '000302',
                '000400',
                '000202',
                '000201',
                '000120',
                '000301',
                '000303',
                '000305',
                '000130',
                '000207',
                '010100',
                '010200'
            )
    )
    Left Outer Join (
        -- ASFTABL��ASN���MID��K�p����
        Select
            ASF_TOKCOD ,
            ASF_ASNSID
        From
            CHUBU.ASFTABL
    )
    On (
        TCE_TOKCOD = ASF_TOKCOD
    )
UNION
-- WEB
Select
    '90000000'                                                     As TCB_TDNPTN , -- WEB�󒍗p�̓`�[�p�^�[���͑S�Ћ��ʂƂ���(��荞�ݎ��̕ϊ��ŋq�悲�Ƃɕϊ�����)
    TCW_STIKCD                                                     As TCB_STIKCD ,
    '00000000' || TCW_STIECO                                       As TCB_STIECO ,
    '0000000000'                                                   As TCB_STIBMN ,
    '0' || Substr(TCW_TOKCOD,1,4) || '0' || Substr(TCW_TOKCOD,5,2) As TCB_TOKCOD ,
    '0' || TCW_TKSCOD                                              As TCB_TKSCOD ,
    '00' || TCW_TKBCOD                                             As TCB_TKBCOD ,
    Nvl2(
		ASF_ASNSID ,
		'0' || SUBSTRB(ASF_ASNSID, 1, 4) || '0' || SUBSTRB(ASF_ASNSID, 5, 3) ,
		'00000000' 
	)   													       As TCB_ASNSID ,
    '0'                                                            As TCB_FILKBN ,
    '0'                                                            As TCB_DELFLG ,
    '999998'                                                       As TCB_ADDTAN ,
    TCW_UPDDAY                                                     As TCB_ADDDAY ,
    TCW_UPDTIM                                                     As TCB_ADDTIM ,
    '999998'                                                       As TCB_UPDTAN ,
    TCW_UPDDAY                                                     As TCB_UPDDAY ,
    TCW_UPDTIM                                                     As TCB_UPDTIM 
From
    CHUBU.TCWTABL
    Left Outer Join (
        -- ASFTABL��ASN���MID��K�p����
        Select
            ASF_TOKCOD ,
            ASF_ASNSID
        From
            CHUBU.ASFTABL
    )
    On (
        TCW_TOKCOD = ASF_TOKCOD
    ) ;
--
-- ̧�ً敪�𓝍�EDI�ɕύX
Update
    TCBTABL
Set
    TCB_FILKBN = '3'
Where
    TCB_FILKBN In ('0','1');
--
-- ����̰��(�H��)��̧�ً敪��JCA�ɕύX
Update
    TCBTABL
Set
    TCB_FILKBN = '1'
Where
    TCB_TOKCOD IN ('00003000','00003010','00016000');
--
--İΰ�ı�q��w���к��ނ�'0000000210101'�ɒu��
Update
    TCBTABL
Set
    TCB_STIKCD = '0000000210101'
Where
    TCB_TOKCOD In ( '00112000', '00112020')
AND TCB_TDNPTN <> '90000000';
--
--�q��x�X���ނ�'09999'����'99999'�ɒu��
Update
    TCBTABL
Set
    TCB_TKSCOD = '99999'
Where
    TCB_TKSCOD = '09999';
--
Commit;
--
/*
Quit ;
*/
--
