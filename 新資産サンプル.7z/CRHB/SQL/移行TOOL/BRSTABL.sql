Truncate Table BRSTABL ;

Insert Into BRSTABL
Select
    '00' || BRS_BRBCOD ,
    '00' || BRS_BRMCOD ,
    '00' || BRS_BRSCOD ,
    BRS_BRSNAM ,
    '0'        ,
    '999998'   ,
    BRS_UPDDAY ,
    BRS_UPDTIM ,
    '999998'   ,
    BRS_UPDDAY ,
    BRS_UPDTIM 
From
    (
        Select
            *
        From
            CHUBU.BRSTABL
    );
--
Commit ;
--
/*
Quit ;
*/
--