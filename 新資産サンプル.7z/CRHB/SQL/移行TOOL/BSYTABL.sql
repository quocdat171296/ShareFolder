Truncate Table BSYTABL ;

Insert Into BSYTABL
Select
    BSY_BSYCOD ,
    Trim(BSY_DSPKNA) As BSY_DSPKNA ,
    Trim(BSY_DSPNAM) As BSY_DSPNAM ,
    Trim(BSY_PRTNAM) As BSY_PRTNAM ,
    BSY_ZIPCOD ,
    Trim(BSY_ADRES1) As BSY_ADRES1 ,
    Trim(BSY_ADRES2) As BSY_ADRES2 ,
    BSY_TELNUM ,
    BSY_FAXNUM ,
    BSY_RECKBN ,
    '999998'   ,
    BSY_ADDDAY ,
    BSY_ADDTIM ,
    '999998'   ,
    BSY_UPDDAY ,
    BSY_UPDTIM 
From
    (
        Select
            *
        From
            CHUBU.BSYTABL
    );
--
Commit ;
--
/*
Quit ;
*/
--
