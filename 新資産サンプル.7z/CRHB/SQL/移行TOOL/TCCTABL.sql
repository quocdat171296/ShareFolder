Truncate Table TCCTABL ;

Insert Into TCCTABL
Select
    '90000000'                                                              AS  TCW_TDNPTN ,
    TCW_STIKCD                                                              AS  TCW_STIKCD ,
    TCW_STIECO                                                              AS  TCW_STIECO ,
    '0' || SUBSTRB(TCW_TOKCOD, 1, 4) || '0' || SUBSTRB(TCW_TOKCOD, 5, 2)    AS  TCW_TOKCOD ,
    '0' || TCW_TKSCOD                                                       AS  TCW_TKSCOD ,
    '00' || TCW_TKBCOD                                                      AS  TCW_TKBCOD ,
    '0' || TCW_SSWCOD                                                       AS  TCW_SSWCOD ,
    '0' || SUBSTRB(TCW_TOKCOD, 1, 4) || '0' || SUBSTRB(TCW_TOKCOD, 5, 2)    AS  TCW_ASNSID ,
    '0'                                                                     AS  TCW_DELFLG ,
    '999998'                                                                AS  TCW_ADDTAN ,
    TCW_UPDDAY                                                              AS  TCW_ADDDAY ,
    TCW_UPDTIM                                                              AS  TCW_ADDTIM ,
    '999998'                                                                AS  TCW_UPDTAN ,
    TCW_UPDDAY                                                              AS  TCW_UPDDAY ,
    TCW_UPDTIM                                                              AS  TCW_UPDTIM
From
    (
        Select
            *
        From
            CHUBU.TCWTABL
    )
Order By
    TCW_TOKCOD ;
--
--�q��x�X���ނ�'09999'����'99999'�ɒu��
Update
    TCCTABL
Set
    TCC_TKSCOD = '99999'
Where
    TCC_TKSCOD = '09999';
--
Commit ;
--
/*
Quit ;
*/
--
