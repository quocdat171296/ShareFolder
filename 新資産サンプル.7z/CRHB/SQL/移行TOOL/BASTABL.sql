Truncate Table BASTABL ;
--
Insert Into BASTABL
Select
    BAS_SHOCOD                                                         As BAS_SHOCOD ,
    BAS_UPDDAY                                                         As BAS_STRDAY ,
    '0' || BAS_ARECOD                                                  As BAS_ARECOD ,
    BAS_DATKBN                                                         As BAS_DATKBN ,
    BAS_SIRCOD                                                         As BAS_SNDCOD ,
    BAS_SIRCOD                                                         As BAS_SIRCOD ,
    BAS_SNTCOD                                                         As BAS_SNTCOD ,
    '0'                                                                As BAS_DELFLG ,
    '999998'                                                           As BAS_ADDTAN ,
    BAS_UPDDAY                                                         As BAS_ADDDAY ,
    BAS_UPDTIM                                                         As BAS_ADDTIM ,
    '999998'                                                           As BAS_UPDTAN ,
    BAS_UPDDAY                                                         As BAS_UPDDAY ,
    BAS_UPDTIM                                                         AS BAS_UPDTIM 
From
	(
        Select
            *
        From
            CHUBU.BASTABL
	)
;
--
Commit ;
--
/*
Quit ;
*/
--