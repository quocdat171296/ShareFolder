Truncate Table KKMTABL ;
--
Insert Into KKMTABL
Select 
    KKM_KKMCOD ,
    Trim(KKM_KKMNAM) As KKM_KKMNAM ,
    KKM_INPKBN ,
    KKM_TAIKBN ,
    KKM_SYKCOD ,
    '0'        ,
    '999998'   ,
    KKM_UPDDAY ,
    KKM_UPDTIM ,
    '999998'   ,
    KKM_UPDDAY ,
    KKM_UPDTIM 
From
    (
        Select
            *
        From
            CHUBU.KKMTABL
    ) ;
--
Commit ;
--
/*
Quit ;
*/
--
