Truncate Table BSTTABL ;

Insert Into BSTTABL
Select
	BST_SNTCOD ,
	Trim(BST_SNTNAM) As BST_SNTNAM ,
	Trim(BST_SNTRYK) As BST_SNTRYK ,
	' '              As BST_SNTKNA ,
	BST_ZIPCOD ,
	Trim(BST_ADRES1) As BST_ADRES1 ,
	Trim(BST_ADRES2) As BST_ADRES2 ,
	BST_TELNUM ,
	BST_FAXNUM ,
	'999'      ,
	BST_NSTKBN ,
	BST_KYUKBN ,
	BST_HATKBN ,
	Case BST_NYCKBN
		WHEN '0' THEN '0'
		         ELSE '1' 
	End As BST_NYCKBN ,
	Case BST_NYCKBN
		WHEN '1' THEN '1'
		         ELSE '0'
	End As BST_NJCKBN ,
	'0000000' || BST_TRICOD ,
	'00'      || BST_STNCOD ,
	BST_TRINAM ,
	BST_BSTCOD ,
	BST_HESCOD ,
	BST_HESNAM ,
	BST_SYCKBN ,
	BST_ZKNKBN ,
	BST_ZKCKBN ,
	BST_SHCKBN ,
	Trim(BST_DATDIR) As BST_DATDIR ,
	BST_DATFMT ,
	BST_TKBKBS ,
	BST_TKBKBB ,
	BST_VEBTRT ,
	BST_VENHCD ,
	BST_RECKBN ,
	'999998'   ,
	BST_ADDDAY ,
	BST_ADDTIM ,
	'999998'   ,
	BST_UPDDAY ,
	BST_UPDTIM 
From
	(
		Select
			*
		From
			CHUBU.BSTTABL
	);
--
Update
    BSTTABL
Set
    BST_DATDIR = Replace(BST_DATDIR,'192.0.2.100','192.168.58.11')
Where
    BST_DATDIR Like '%192.0.2.100%'
And BST_SNTCOD Not In (
		'900015' , -- ���Z����
		'900026' , -- �k�����
		'900028' , -- �����u���
		'900041' , -- ���a
		'900044'   -- �����uDC�i�D���j
	);
--
Commit ;
--
/*
Quit ;
*/
--