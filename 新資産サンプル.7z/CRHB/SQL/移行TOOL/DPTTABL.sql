Truncate Table DPTTABL ;
-- WEB �ȊO
Insert Into DPTTABL
Select
    '0' || DPT_TDNPTN || '000' As DPT_TDNPTN ,
    DPT_TDNNAM                 As DPT_TDNNAM ,
    TKJ_DNETYP ,
    TKJ_DNHTYP ,
    6          ,
    6          ,
    '0'        ,
    '999998'   ,
    DPT_UPDDAY ,
    DPT_UPDTIM ,
    '999998'   ,
    DPT_UPDDAY ,
    DPT_UPDTIM 
From
    (
        Select
            *
        From
            CHUBU.DPTTABL
    )
	Inner Join (
		Select
			TKJ_TDNPTN ,
		    TKJ_DNETYP ,
		    TKJ_DNHTYP 
		From
			CHUBU.TKJTABL
		Where
			TKJ_DNHTYP <> '99'
		Group By
			TKJ_TDNPTN ,
		    TKJ_DNETYP ,
		    TKJ_DNHTYP 
	)
	On (
		TKJ_TDNPTN = DPT_TDNPTN
	);
--
Update DPTTABL Set DPT_DNEGYO = 10 Where DPT_DNETYP ='02';
Update DPTTABL Set DPT_DNEGYO =  9 Where DPT_DNETYP ='06';
Update DPTTABL Set DPT_DNHGYO = 10 Where DPT_DNHTYP ='02';
Update DPTTABL Set DPT_DNHGYO =  9 Where DPT_DNHTYP ='06';
Update DPTTABL Set DPT_DNHGYO =  6 Where DPT_TDNPTN ='00017000';
--
Insert Into DPTTABL
Select
    '99999999' As DPT_TDNPTN ,
    '���Зp'   As DPT_TDNNAM ,
    '02' ,
    '01' ,
    6          ,
    6          ,
    '0'        ,
    '999998'   ,
    Min(DPT_UPDDAY) ,
    Min(DPT_UPDTIM) ,
    '999998'   ,
    Max(DPT_UPDDAY) ,
    Max(DPT_UPDTIM) 
From
    (
        Select
            *
        From
            CHUBU.DPTTABL
        Where
            DPT_TDNPTN = '0001'
    );
--
INSERT INTO DPTTABL (
	DPT_TDNPTN,
	DPT_TDNNAM,
	DPT_DNETYP,
	DPT_DNHTYP,
	DPT_DNEGYO,
	DPT_DNHGYO,
	DPT_DELFLG,
	DPT_ADDTAN,
	DPT_ADDDAY,
	DPT_ADDTIM,
	DPT_UPDTAN,
	DPT_UPDDAY,
	DPT_UPDTIM) 
VALUES (
	'90000000',
	'WEB',
	'04',
	'99',
	6,
	6,
	'0',
	'999998',
	'20090101',
	'000000',
	'999998',
	'20090101',
	'000000'
	);
--
Commit ;
--
/*
Quit ;
*/
--
