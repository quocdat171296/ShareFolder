Truncate Table JRCTABL ;
--
Insert Into JRCTABL
Select 
    JRC_INSNUM  ,
    TO_CHAR(JRC_DSPSEQ  ,'FM00') ,
    JRC_FTOKNM  ,
    JRC_JYUKBN  ,
    JRC_RCVTIM  ,
    JRC_DSPSEQ  ,
    JRC_DSPSEQ  ,
    JRC_DSPSEQ  ,
    JRC_DSPSEQ  ,
    JRC_DSPSEQ  ,
    JRC_DSPSEQ  ,
    JRC_DSPSEQ  ,
    '0' || SubstrB(JRC_TOKCD1,1,4) || '0' || SubstrB(JRC_TOKCD1,5,2) As JRC_TOKCD1 ,
    JRC_CHKTIM  ,
    '0' || SubstrB(JRC_TOKCD1,1,4) || '0' || SubstrB(JRC_TOKCD1,5,2) As JRC_TOKCD1 ,
    Case JRC_TOKCD2
        WHEN '      ' THEN ' '
                      ELSE  '0' || SubstrB(JRC_TOKCD2,1,4) || '0' || SubstrB(JRC_TOKCD2,5,2)
    END As JRC_TOKCD2 ,
    Case JRC_TOKCD3
        WHEN '      ' THEN ' '
                      ELSE  '0' || SubstrB(JRC_TOKCD3,1,4) || '0' || SubstrB(JRC_TOKCD3,5,2)
    END  As JRC_TOKCD3 ,
    Case JRC_TOKCD4
        WHEN '      ' THEN ' '
                      ELSE  '0' || SubstrB(JRC_TOKCD4,1,4) || '0' || SubstrB(JRC_TOKCD4,5,2)
    END  As JRC_TOKCD4 ,
    Case JRC_TOKCD5
        WHEN '      ' THEN ' '
                      ELSE  '0' || SubstrB(JRC_TOKCD5,1,4) || '0' || SubstrB(JRC_TOKCD5,5,2)
    END  As JRC_TOKCD5 ,
    Case JRC_TOKCD6
        WHEN '      ' THEN ' '
                      ELSE  '0' || SubstrB(JRC_TOKCD6,1,4) || '0' || SubstrB(JRC_TOKCD6,5,2)
    END  As JRC_TOKCD6 ,
    Case JRC_TOKCD7
        WHEN '      ' THEN ' '
                      ELSE  '0' || SubstrB(JRC_TOKCD7,1,4) || '0' || SubstrB(JRC_TOKCD7,5,2)
    END  As JRC_TOKCD7 ,
    Case JRC_TOKCD8
        WHEN '      ' THEN ' '
                      ELSE  '0' || SubstrB(JRC_TOKCD8,1,4) || '0' || SubstrB(JRC_TOKCD8,5,2)
    END  As JRC_TOKCD8 ,
    Case JRC_TOKCD9
        WHEN '      ' THEN ' '
                      ELSE  '0' || SubstrB(JRC_TOKCD9,1,4) || '0' || SubstrB(JRC_TOKCD9,5,2)
    END  As JRC_TOKCD9 ,
    Case JRC_TOKCD10
        WHEN '      ' THEN ' '
                      ELSE  '0' || SubstrB(JRC_TOKCD10,1,4) || '0' || SubstrB(JRC_TOKCD10,5,2)
    END  As JRC_TOKCD10 ,
    Case JRC_TOKCD11
        WHEN '      ' THEN ' '
                      ELSE  '0' || SubstrB(JRC_TOKCD11,1,4) || '0' || SubstrB(JRC_TOKCD11,5,2)
    END  As JRC_TOKCD11 ,
    Case JRC_TOKCD12
        WHEN '      ' THEN ' '
                      ELSE  '0' || SubstrB(JRC_TOKCD12,1,4) || '0' || SubstrB(JRC_TOKCD12,5,2)
    END  As JRC_TOKCD12 ,
    Case JRC_TOKCD13
        WHEN '      ' THEN ' '
                      ELSE  '0' || SubstrB(JRC_TOKCD13,1,4) || '0' || SubstrB(JRC_TOKCD13,5,2)
    END  As JRC_TOKCD13 ,
    Case JRC_TOKCD14
    WHEN '      ' THEN ' '
                  ELSE  '0' || SubstrB(JRC_TOKCD14,1,4) || '0' || SubstrB(JRC_TOKCD14,5,2)
    END  As JRC_TOKCD14 ,
    Case JRC_TOKCD15
        WHEN '      ' THEN ' '
                      ELSE  '0' || SubstrB(JRC_TOKCD15,1,4) || '0' || SubstrB(JRC_TOKCD15,5,2)
    END  As JRC_TOKCD15 ,
    Case JRC_TOKCD16
        WHEN '      ' THEN ' '
                      ELSE  '0' || SubstrB(JRC_TOKCD16,1,4) || '0' || SubstrB(JRC_TOKCD16,5,2)
    END  As JRC_TOKCD16 ,
    ' ' As JRC_TOKCD17 ,
    ' ' As JRC_TOKCD18 ,
    ' ' As JRC_TOKCD19 ,
    ' ' As JRC_TOKCD20 ,
    ' ' As JRC_TOKCD21 ,
    ' ' As JRC_TOKCD22 ,
    ' ' As JRC_TOKCD23 ,
    ' ' As JRC_TOKCD24 ,
    ' ' As JRC_TOKCD25 ,
    ' ' As JRC_TOKCD26 ,
    ' ' As JRC_TOKCD27 ,
    ' ' As JRC_TOKCD28 ,
    ' ' As JRC_TOKCD29 ,
    ' ' As JRC_TOKCD30 ,
    ' ' As JRC_TOKCD31 ,
    ' ' As JRC_TOKCD32 ,
    ' ' As JRC_TOKCD33 ,
    ' ' As JRC_TOKCD34 ,
    ' ' As JRC_TOKCD35 ,
    ' ' As JRC_TOKCD36 ,
    ' ' As JRC_TOKCD37 ,
    ' ' As JRC_TOKCD38 ,
    ' ' As JRC_TOKCD39 ,
    ' ' As JRC_TOKCD40 ,
     REPLACE(
         '''' || '0' || SubstrB(JRC_TOKCD1,1,4) || '0' || SubstrB(JRC_TOKCD1,5,2) || '''' || 
        ',''' || '0' || SubstrB(JRC_TOKCD2,1,4) || '0' || SubstrB(JRC_TOKCD2,5,2) || '''' || 
        ',''' || '0' || SubstrB(JRC_TOKCD3,1,4) || '0' || SubstrB(JRC_TOKCD3,5,2) || '''' || 
        ',''' || '0' || SubstrB(JRC_TOKCD4,1,4) || '0' || SubstrB(JRC_TOKCD4,5,2) || '''' || 
        ',''' || '0' || SubstrB(JRC_TOKCD5,1,4) || '0' || SubstrB(JRC_TOKCD5,5,2) || '''' || 
        ',''' || '0' || SubstrB(JRC_TOKCD6,1,4) || '0' || SubstrB(JRC_TOKCD6,5,2) || '''' || 
        ',''' || '0' || SubstrB(JRC_TOKCD7,1,4) || '0' || SubstrB(JRC_TOKCD7,5,2) || '''' || 
        ',''' || '0' || SubstrB(JRC_TOKCD8,1,4) || '0' || SubstrB(JRC_TOKCD8,5,2) || '''' || 
        ',''' || '0' || SubstrB(JRC_TOKCD9,1,4) || '0' || SubstrB(JRC_TOKCD9,5,2) || '''' || 
        ',''' || '0' || SubstrB(JRC_TOKCD10,1,4) || '0' || SubstrB(JRC_TOKCD10,5,2) || '''' || 
        ',''' || '0' || SubstrB(JRC_TOKCD11,1,4) || '0' || SubstrB(JRC_TOKCD11,5,2) || '''' || 
        ',''' || '0' || SubstrB(JRC_TOKCD12,1,4) || '0' || SubstrB(JRC_TOKCD12,5,2) || '''' || 
        ',''' || '0' || SubstrB(JRC_TOKCD13,1,4) || '0' || SubstrB(JRC_TOKCD13,5,2) || '''' || 
        ',''' || '0' || SubstrB(JRC_TOKCD14,1,4) || '0' || SubstrB(JRC_TOKCD14,5,2) || '''' || 
        ',''' || '0' || SubstrB(JRC_TOKCD15,1,4) || '0' || SubstrB(JRC_TOKCD15,5,2) || '''' || 
        ',''' || '0' || SubstrB(JRC_TOKCD16,1,4) || '0' || SubstrB(JRC_TOKCD16,5,2) || ''''   ,
        ',''0    0  ''') As JRC_ITOKCD  ,
    '0' || TOK_TDNPTN || '000' As TOK_TDNPTN ,
    Trim(JRC_COMENT) ,
    '0'         ,
    '999998'    ,
    JRC_ADDDAY  ,
    JRC_ADDTIM  ,
    '999998'    ,
    JRC_UPDDAY  ,
    JRC_UPDTIM  
From
    (
        Select
            *
        From
            CHUBU.JRCTABL
    )
    Inner Join (
        Select
            *
        From
            CHUBU.TOKMAST
    )
    On (
        JRC_TOKCD1 = TOK_TOKCOD
    ) ;
-- WEB�󒍂̓`�[�p�^�[����WEB�ėp�ɕύX
Update
	JRCTABL
Set
	JRC_TDNPTN = '90000000'
Where
	JRC_JYUKBN = '2';
-- �t�[�Y�H��ȊO�͓���EDI�ɕύX
Update
	JRCTABL
Set
	JRC_JYUKBN = '4'
Where
	JRC_INSNUM <> '07';
-- ��۰ΰ��ިݸ޽�̓`�[����݂ɑ΂����߯�
Update
	JRCTABL
Set
	JRC_TDNPTN = '00001000'
Where
	JRC_TDNPTN = '00005000';
--
-- ۯ���o��̓`�[����݂ɑ΂����߯�
Update
	JRCTABL
Set
	JRC_TDNPTN = '00020000'
Where
	JRC_INSNUM = '37';
--
Update
	JRCTABL
Set
	JRC_TDNPTN = '00021000'
Where
	JRC_INSNUM = '38';
--
Update
	JRCTABL
Set
	JRC_TDNPTN = '00022000'
Where
	JRC_INSNUM = '39';
--
Update
	JRCTABL
Set
	JRC_TDNPTN = '00024000'
Where
	JRC_INSNUM = '41';
--
Commit;
--
/*
Quit ;
*/
--
 