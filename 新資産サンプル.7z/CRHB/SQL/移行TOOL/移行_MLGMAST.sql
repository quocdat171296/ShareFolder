/******************************************************************************/
/* �}�X�^�����t�@�C��(CHUBU.MLGFILE)���e�헚���t�@�C���ڍs����              */
/******************************************************************************/

DELETE FROM SHOMAST_LOG ;
DELETE FROM TOKMAST_LOG ;
DELETE FROM SIRMAST_LOG ;
DELETE FROM TSHMAST_LOG ;
DELETE FROM SSHMAST_LOG ;
--
--
DECLARE
    shorow            SHOMAST%ROWTYPE ;                                         --  ���i�}�X�^          �e�[�u����`�ϐ�
    shorowinit        SHOMAST%ROWTYPE ;                                         --  ���i�}�X�^          �e�[�u����`�ϐ�(�������p)
--
    tokrow            TOKMAST%ROWTYPE ;                                         --  �q��}�X�^          �e�[�u����`�ϐ�
    tokrowinit        TOKMAST%ROWTYPE ;                                         --  �q��}�X�^          �e�[�u����`�ϐ�(�������p)
--
    sirrow            SIRMAST%ROWTYPE ;                                         --  �d����}�X�^        �e�[�u����`�ϐ�
    sirrowinit        SIRMAST%ROWTYPE ;                                         --  �d����}�X�^        �e�[�u����`�ϐ�(�������p)
--
    tshrow            TSHMAST%ROWTYPE ;                                         --  �q�揤�i�}�X�^      �e�[�u����`�ϐ�
    tshrowinit        TSHMAST%ROWTYPE ;                                         --  �q�揤�i�}�X�^      �e�[�u����`�ϐ�(�������p)
--
    sshrow            SSHMAST%ROWTYPE ;                                         --  �d���揤�i�}�X�^    �e�[�u����`�ϐ�
    sshrowinit        SSHMAST%ROWTYPE ;                                         --  �d���揤�i�}�X�^    �e�[�u����`�ϐ�(�������p)
--
    CURSOR CReadMlg
    IS
        SELECT
            MLG_PRGNUM
           ,MLG_SHOCOD
           ,MLG_TOKCOD
           ,MLG_SIRCOD
           ,MLG_MEISYO
           ,MLG_UPDKBN
           ,MLG_TANCOD
           ,MLG_UPDDAY
           ,MLG_UPDTIM
           ,MLG_BTTNKB
        FROM
            CHUBU.MLGFILE
        ORDER BY
            MLG_UPDDAY
           ,MLG_UPDTIM
           ,MLG_PRGNUM
           ,MLG_SHOCOD
           ,MLG_TOKCOD
           ,MLG_SIRCOD
           ,MLG_UPDKBN
        ;
BEGIN
    /**************************************************************************/
    /* �e�[�u����`�������p�ϐ�������                                         */
    /**************************************************************************/
    --  ���i�}�X�^
    shorowinit.SHO_SHOCOD := ' ' ;
    shorowinit.SHO_ITFCOD := ' ' ;
    shorowinit.SHO_SHOKNA := ' ' ;
    shorowinit.SHO_SHONAM := ' ' ;
    shorowinit.SHO_MEKCOD := ' ' ;
    shorowinit.SHO_KEBIRI := 0   ;
    shorowinit.SHO_BUKIRI := 0   ;
    shorowinit.SHO_BABIRI := 0   ;
    shorowinit.SHO_BAKIRI := 0   ;
    shorowinit.SHO_SHOWID := 0   ;
    shorowinit.SHO_SHOHIG := 0   ;
    shorowinit.SHO_SHODEM := 0   ;
    shorowinit.SHO_SHOWAT := 0   ;
    shorowinit.SHO_CASWAT := 0   ;
    shorowinit.SHO_BURCOD := ' ' ;
    shorowinit.SHO_ENDDAY := ' ' ;
    shorowinit.SHO_CHGKBN := ' ' ;
    shorowinit.SHO_HYOTNK := 0   ;
    shorowinit.SHO_LSRDAY := ' ' ;
    shorowinit.SHO_LURDAY := ' ' ;
    shorowinit.SHO_SYKDAY := ' ' ;
    shorowinit.SHO_ZAIKBN := ' ' ;
    shorowinit.SHO_BRBCOD := ' ' ;
    shorowinit.SHO_BRMCOD := ' ' ;
    shorowinit.SHO_BRSCOD := ' ' ;
    shorowinit.SHO_CATEGO := ' ' ;
    shorowinit.SHO_GTINCD := ' ' ;
    shorowinit.SHO_SHOKIK := ' ' ;
    shorowinit.SHO_KIKKNA := ' ' ;
    shorowinit.SHO_KATASK := ' ' ;
    shorowinit.SHO_SHOBKO := ' ' ;
    shorowinit.SHO_PBSKBN := ' ' ;
    shorowinit.SHO_UNUKBN := ' ' ;
    shorowinit.SHO_SZIKBN := ' ' ;
    shorowinit.SHO_URIBMN := ' ' ;
    shorowinit.SHO_CASJAN := ' ' ;
    shorowinit.SHO_PRTSUU := 0   ;
    shorowinit.SHO_DOCFIL := ' ' ;
    shorowinit.SHO_IDCKBN := ' ' ;
    shorowinit.SHO_SDCKBN := ' ' ;
    shorowinit.SHO_SYZCOD := ' ' ;
    shorowinit.SHO_SEASON := ' ' ;
    shorowinit.SHO_YTOBKO := ' ' ;
    shorowinit.SHO_USEBMN := ' ' ;
    shorowinit.SHO_OLDSHO := ' ' ;
    shorowinit.SHO_DELFLG := ' ' ;
    shorowinit.SHO_ADDTAN := ' ' ;
    shorowinit.SHO_ADDDAY := ' ' ;
    shorowinit.SHO_ADDTIM := ' ' ;
    shorowinit.SHO_UPDTAN := ' ' ;
    shorowinit.SHO_UPDDAY := ' ' ;
    shorowinit.SHO_UPDTIM := ' ' ;
--
    --  �q��}�X�^
    tokrowinit.TOK_TOKCOD := ' ' ;
    tokrowinit.TOK_TOKKNA := ' ' ;
    tokrowinit.TOK_TOKNAM := ' ' ;
    tokrowinit.TOK_TOKRYK := ' ' ;
    tokrowinit.TOK_ZIPCOD := ' ' ;
    tokrowinit.TOK_ADRES1 := ' ' ;
    tokrowinit.TOK_ADRES2 := ' ' ;
    tokrowinit.TOK_TELNUM := ' ' ;
    tokrowinit.TOK_FAXNUM := ' ' ;
    tokrowinit.TOK_MILADR := ' ' ;
    tokrowinit.TOK_STIKCD := ' ' ;
    tokrowinit.TOK_STIKNM := ' ' ;
    tokrowinit.TOK_TDNPTN := ' ' ;
    tokrowinit.TOK_SIMDAY := ' ' ;
    tokrowinit.TOK_KAICLE := ' ' ;
    tokrowinit.TOK_KAYDAY := ' ' ;
    tokrowinit.TOK_NYUHOU := ' ' ;
    tokrowinit.TOK_SYZKBN := ' ' ;
    tokrowinit.TOK_HASKBN := ' ' ;
    tokrowinit.TOK_URIHAS := ' ' ;
    tokrowinit.TOK_GTIKBN := ' ' ;
    tokrowinit.TOK_HBSKBN := ' ' ;
    tokrowinit.TOK_TOKBKO := ' ' ;
    tokrowinit.TOK_JRYKBN := ' ' ;
    tokrowinit.TOK_SHRKBN := ' ' ;
    tokrowinit.TOK_SEICOD := ' ' ;
    tokrowinit.TOK_KYCYMD := ' ' ;
    tokrowinit.TOK_KYCTYP := ' ' ;
    tokrowinit.TOK_KYCSTR := ' ' ;
    tokrowinit.TOK_KYCEND := ' ' ;
    tokrowinit.TOK_KYCKSN := ' ' ;
    tokrowinit.TOK_ASNBMS := ' ' ;
    tokrowinit.TOK_ASNEOS := ' ' ;
    tokrowinit.TOK_ASNCHF := ' ' ;
    tokrowinit.TOK_ASNMCT := ' ' ;
    tokrowinit.TOK_ASNFAX := ' ' ;
    tokrowinit.TOK_ASNFMT := ' ' ;
    tokrowinit.TOK_ASNFDK := ' ' ;
    tokrowinit.TOK_ASNFDH := ' ' ;
    tokrowinit.TOK_ASNZRO := ' ' ;
    tokrowinit.TOK_ASNSTN := ' ' ;
    tokrowinit.TOK_VTRCG1 := ' ' ;
    tokrowinit.TOK_VSTCG1 := ' ' ;
    tokrowinit.TOK_VTRCG2 := ' ' ;
    tokrowinit.TOK_VSTCG2 := ' ' ;
    tokrowinit.TOK_ASNDFG := ' ' ;
    tokrowinit.TOK_NOUKBN := ' ' ;
    tokrowinit.TOK_UKJKBN := ' ' ;
    tokrowinit.TOK_DELFLG := ' ' ;
    tokrowinit.TOK_ADDTAN := ' ' ;
    tokrowinit.TOK_ADDDAY := ' ' ;
    tokrowinit.TOK_ADDTIM := ' ' ;
    tokrowinit.TOK_UPDTAN := ' ' ;
    tokrowinit.TOK_UPDDAY := ' ' ;
    tokrowinit.TOK_UPDTIM := ' ' ;
--
    --  �d����}�X�^
    sirrowinit.SIR_SIRCOD := ' ' ;
    sirrowinit.SIR_SIRKNA := ' ' ;
    sirrowinit.SIR_SIRNAM := ' ' ;
    sirrowinit.SIR_SIRRYK := ' ' ;
    sirrowinit.SIR_ZIPCOD := ' ' ;
    sirrowinit.SIR_ADRES1 := ' ' ;
    sirrowinit.SIR_ADRES2 := ' ' ;
    sirrowinit.SIR_TELNUM := ' ' ;
    sirrowinit.SIR_FAXNUM := ' ' ;
    sirrowinit.SIR_MILADR := ' ' ;
    sirrowinit.SIR_TUSADR := ' ' ;
    sirrowinit.SIR_SIRTAN := ' ' ;
    sirrowinit.SIR_SIHCOD := ' ' ;
    sirrowinit.SIR_HONKNA := ' ' ;
    sirrowinit.SIR_HONNAM := ' ' ;
    sirrowinit.SIR_HONZIP := ' ' ;
    sirrowinit.SIR_HONAD1 := ' ' ;
    sirrowinit.SIR_HONAD2 := ' ' ;
    sirrowinit.SIR_HONTEL := ' ' ;
    sirrowinit.SIR_HONFAX := ' ' ;
    sirrowinit.SIR_SIMDAY := ' ' ;
    sirrowinit.SIR_KESCLE := ' ' ;
    sirrowinit.SIR_KESDAY := ' ' ;
    sirrowinit.SIR_SIHHOU := ' ' ;
    sirrowinit.SIR_KOUMIG := ' ' ;
    sirrowinit.SIR_KOUMEI := ' ' ;
    sirrowinit.SIR_KOUNUM := ' ' ;
    sirrowinit.SIR_SYZKBN := ' ' ;
    sirrowinit.SIR_HASKBN := ' ' ;
    sirrowinit.SIR_GTIKBN := ' ' ;
    sirrowinit.SIR_SIRBKO := ' ' ;
    sirrowinit.SIR_HONCOD := ' ' ;
    sirrowinit.SIR_GKONAM := ' ' ;
    sirrowinit.SIR_SHNKIN := 0   ;
    sirrowinit.SIR_SUKKBN := ' ' ;
    sirrowinit.SIR_SMSKBN := ' ' ;
    sirrowinit.SIR_EMLADR := ' ' ;
    sirrowinit.SIR_RBTKBN := ' ' ;
    sirrowinit.SIR_HCEKBN := ' ' ;
    sirrowinit.SIR_ASNKBN := ' ' ;
    sirrowinit.SIR_JRYKBN := ' ' ;
    sirrowinit.SIR_SIHKBN := ' ' ;
    sirrowinit.SIR_SIRHAS := ' ' ;
    sirrowinit.SIR_KJOKBN := ' ' ;
    sirrowinit.SIR_TNKKBN := ' ' ;
    sirrowinit.SIR_DELFLG := ' ' ;
    sirrowinit.SIR_JTTKCD := ' ' ;
    sirrowinit.SIR_JTSCCD := ' ' ;
    sirrowinit.SIR_ADDTAN := ' ' ;
    sirrowinit.SIR_ADDDAY := ' ' ;
    sirrowinit.SIR_ADDTIM := ' ' ;
    sirrowinit.SIR_UPDTAN := ' ' ;
    sirrowinit.SIR_UPDDAY := ' ' ;
    sirrowinit.SIR_UPDTIM := ' ' ;
    sirrowinit.SIR_DATKBN := ' ' ;
--
    --�q�揤�i�}�X�^
    tshrowinit.TSH_TOKCOD := ' ' ;
    tshrowinit.TSH_SHOCOD := ' ' ;
    tshrowinit.TSH_TSHNAM := ' ' ;
    tshrowinit.TSH_JYTNKB := ' ' ;
    tshrowinit.TSH_JYTNSU := 0   ;
    tshrowinit.TSH_TNTNKB := ' ' ;
    tshrowinit.TSH_TNTNSU := 0   ;
    tshrowinit.TSH_SYZKBN := ' ' ;
    tshrowinit.TSH_TANNAM := ' ' ;
    tshrowinit.TSH_TABNAM := ' ' ;
    tshrowinit.TSH_SIRCOD := ' ' ;
    tshrowinit.TSH_TRICOD := ' ' ;
    tshrowinit.TSH_STNCOD := ' ' ;
    tshrowinit.TSH_KBNGRP := ' ' ;
    tshrowinit.TSH_KBNCOD := ' ' ;
    tshrowinit.TSH_EJKKBN := ' ' ;
    tshrowinit.TSH_STHSUU := 0   ;
    tshrowinit.TSH_NOUCOD := ' ' ;
    tshrowinit.TSH_TSHBKO := ' ' ;
    tshrowinit.TSH_SNTNKB := ' ' ;
    tshrowinit.TSH_LURDAY := ' ' ;
    tshrowinit.TSH_BTNKBN := ' ' ;
    tshrowinit.TSH_SNDKBN := ' ' ;
    tshrowinit.TSH_DELFLG := ' ' ;
    tshrowinit.TSH_ADDTAN := ' ' ;
    tshrowinit.TSH_ADDDAY := ' ' ;
    tshrowinit.TSH_ADDTIM := ' ' ;
    tshrowinit.TSH_UPDTAN := ' ' ;
    tshrowinit.TSH_UPDDAY := ' ' ;
    tshrowinit.TSH_UPDTIM := ' ' ;
--
    --  �d���揤�i�}�X�^
    sshrowinit.SSH_SIRCOD := ' ' ;
    sshrowinit.SSH_SHOCOD := ' ' ;
    sshrowinit.SSH_SITNKB := ' ' ;
    sshrowinit.SSH_SITNSU := 0   ;
    sshrowinit.SSH_SYZKBN := ' ' ;
    sshrowinit.SSH_TANNAM := ' ' ;
    sshrowinit.SSH_TABNAM := ' ' ;
    sshrowinit.SSH_SYHKBN := ' ' ;
    sshrowinit.SSH_SYHKGN := 0   ;
    sshrowinit.SSH_STNKBN := ' ' ;
    sshrowinit.SSH_HARTIM := 0   ;
    sshrowinit.SSH_KWSRET := 0   ;
    sshrowinit.SSH_KWSDAY := ' ' ;
    sshrowinit.SSH_DELFLG := ' ' ;
    sshrowinit.SSH_ADDTAN := ' ' ;
    sshrowinit.SSH_ADDDAY := ' ' ;
    sshrowinit.SSH_ADDTIM := ' ' ;
    sshrowinit.SSH_UPDTAN := ' ' ;
    sshrowinit.SSH_UPDDAY := ' ' ;
    sshrowinit.SSH_UPDTIM := ' ' ;
--
    /**************************************************************************/
    /* �}�X�^�����t�@�C��(CHUBU.MLGFILE)���[�v���� */
    /**************************************************************************/
    FOR CRecMlg IN CReadMlg
    LOOP
        IF    TRIM(CRecMlg.MLG_PRGNUM) = 'CRJHM020' THEN
            shorow := shorowinit ;
--
            shorow.SHO_SHOCOD := CRecMlg.MLG_SHOCOD ;
            shorow.SHO_SHONAM := RTRIM(CRecMlg.MLG_MEISYO) ;
            shorow.SHO_ADDTAN := CRecMlg.MLG_TANCOD ;
            shorow.SHO_ADDDAY := CRecMlg.MLG_UPDDAY ;
            shorow.SHO_ADDTIM := CRecMlg.MLG_UPDTIM ;
            shorow.SHO_UPDTAN := CRecMlg.MLG_TANCOD ;
            shorow.SHO_UPDDAY := CRecMlg.MLG_UPDDAY ;
            shorow.SHO_UPDTIM := CRecMlg.MLG_UPDTIM ;
--
            IF    CRecMlg.MLG_UPDKBN = 'A' THEN
                shorow.SHO_DELFLG := '0' ;
            ELSIF CRecMlg.MLG_UPDKBN = 'U' THEN
                shorow.SHO_DELFLG := '0' ;
--
                BEGIN
                    SELECT
                        SHO_ADDTAN
                       ,SHO_ADDDAY
                       ,SHO_ADDTIM
                    INTO
                        shorow.SHO_ADDTAN
                       ,shorow.SHO_ADDDAY
                       ,shorow.SHO_ADDTIM
                    FROM
                        SHOMAST
                    WHERE
                        SHO_SHOCOD   =   shorow.SHO_SHOCOD
                    ;
                EXCEPTION
                    WHEN NO_DATA_FOUND THEN                                 --  �Y���f�[�^�Ȃ�
                        shorow.SHO_ADDTAN := CRecMlg.MLG_TANCOD ;
                        shorow.SHO_ADDDAY := CRecMlg.MLG_UPDDAY ;
                        shorow.SHO_ADDTIM := CRecMlg.MLG_UPDTIM ;
                END ;
            ELSIF CRecMlg.MLG_UPDKBN = 'D' THEN
                shorow.SHO_DELFLG := '1' ;
--
                BEGIN
                    SELECT
                        SHO_ADDTAN
                       ,SHO_ADDDAY
                       ,SHO_ADDTIM
                    INTO
                        shorow.SHO_ADDTAN
                       ,shorow.SHO_ADDDAY
                       ,shorow.SHO_ADDTIM
                    FROM
                        SHOMAST
                    WHERE
                        SHO_SHOCOD   =   shorow.SHO_SHOCOD
                    ;
                EXCEPTION
                    WHEN NO_DATA_FOUND THEN                                 --  �Y���f�[�^�Ȃ�
                        shorow.SHO_ADDTAN := CRecMlg.MLG_TANCOD ;
                        shorow.SHO_ADDDAY := CRecMlg.MLG_UPDDAY ;
                        shorow.SHO_ADDTIM := CRecMlg.MLG_UPDTIM ;
                END ;
            END IF ;
--
            BEGIN
                INSERT INTO
                    SHOMAST_LOG
                VALUES
                    shorow
                ;
            EXCEPTION
                WHEN DUP_VAL_ON_INDEX THEN
                    UPDATE
                        SHOMAST_LOG
                    SET
                        SHO_SHONAM = shorow.SHO_SHONAM
                    WHERE
                        SHO_SHOCOD   =   shorow.SHO_SHOCOD
                    ;
            END ;
        ELSIF TRIM(CRecMlg.MLG_PRGNUM) = 'CRJHM02Z' THEN
            shorow := shorowinit ;
--
            shorow.SHO_SHOCOD := CRecMlg.MLG_SHOCOD ;
            shorow.SHO_SHONAM := RTRIM(CRecMlg.MLG_MEISYO) ;
            shorow.SHO_ADDTAN := CRecMlg.MLG_TANCOD ;
            shorow.SHO_ADDDAY := CRecMlg.MLG_UPDDAY ;
            shorow.SHO_ADDTIM := CRecMlg.MLG_UPDTIM ;
            shorow.SHO_UPDTAN := CRecMlg.MLG_TANCOD ;
            shorow.SHO_UPDDAY := CRecMlg.MLG_UPDDAY ;
            shorow.SHO_UPDTIM := CRecMlg.MLG_UPDTIM ;
--
            IF    CRecMlg.MLG_UPDKBN = 'A' THEN
                shorow.SHO_DELFLG := '0' ;
            ELSIF CRecMlg.MLG_UPDKBN = 'U' THEN
                shorow.SHO_DELFLG := '0' ;
--
                BEGIN
                    SELECT
                        SHO_ADDTAN
                       ,SHO_ADDDAY
                       ,SHO_ADDTIM
                    INTO
                        shorow.SHO_ADDTAN
                       ,shorow.SHO_ADDDAY
                       ,shorow.SHO_ADDTIM
                    FROM
                        SHOMAST
                    WHERE
                        SHO_SHOCOD   =   shorow.SHO_SHOCOD
                    ;
                EXCEPTION
                    WHEN NO_DATA_FOUND THEN                                 --  �Y���f�[�^�Ȃ�
                        shorow.SHO_ADDTAN := CRecMlg.MLG_TANCOD ;
                        shorow.SHO_ADDDAY := CRecMlg.MLG_UPDDAY ;
                        shorow.SHO_ADDTIM := CRecMlg.MLG_UPDTIM ;
                END ;
            ELSIF CRecMlg.MLG_UPDKBN = 'D' THEN
                shorow.SHO_DELFLG := '1' ;
--
                BEGIN
                    SELECT
                        SHO_ADDTAN
                       ,SHO_ADDDAY
                       ,SHO_ADDTIM
                    INTO
                        shorow.SHO_ADDTAN
                       ,shorow.SHO_ADDDAY
                       ,shorow.SHO_ADDTIM
                    FROM
                        SHOMAST
                    WHERE
                        SHO_SHOCOD   =   shorow.SHO_SHOCOD
                    ;
                EXCEPTION
                    WHEN NO_DATA_FOUND THEN                                 --  �Y���f�[�^�Ȃ�
                        shorow.SHO_ADDTAN := CRecMlg.MLG_TANCOD ;
                        shorow.SHO_ADDDAY := CRecMlg.MLG_UPDDAY ;
                        shorow.SHO_ADDTIM := CRecMlg.MLG_UPDTIM ;
                END ;
            END IF ;
--
            BEGIN
                INSERT INTO
                    SHOMAST_LOG
                VALUES
                    shorow
                ;
            EXCEPTION
                WHEN DUP_VAL_ON_INDEX THEN
                    UPDATE
                        SHOMAST_LOG
                    SET
                        SHO_SHONAM = shorow.SHO_SHONAM
                    WHERE
                        SHO_SHOCOD   =   shorow.SHO_SHOCOD
                    ;
            END ;
        ELSIF TRIM(CRecMlg.MLG_PRGNUM) = 'CRJHM030' THEN
            tokrow := tokrowinit ;
--
            tokrow.TOK_TOKCOD := '0' || SUBSTRB(CRecMlg.MLG_TOKCOD, 1, 4) || '0' || SUBSTRB(CRecMlg.MLG_TOKCOD, 5, 3) ;
            tokrow.TOK_TOKNAM := RTRIM(CRecMlg.MLG_MEISYO) ;
            tokrow.TOK_ADDTAN := CRecMlg.MLG_TANCOD ;
            tokrow.TOK_ADDDAY := CRecMlg.MLG_UPDDAY ;
            tokrow.TOK_ADDTIM := CRecMlg.MLG_UPDTIM ;
            tokrow.TOK_UPDTAN := CRecMlg.MLG_TANCOD ;
            tokrow.TOK_UPDDAY := CRecMlg.MLG_UPDDAY ;
            tokrow.TOK_UPDTIM := CRecMlg.MLG_UPDTIM ;
--
            IF    CRecMlg.MLG_UPDKBN = 'A' THEN
                tokrow.TOK_DELFLG := '0' ;
            ELSIF CRecMlg.MLG_UPDKBN = 'U' THEN
                tokrow.TOK_DELFLG := '0' ;
--
                BEGIN
                    SELECT
                        TOK_ADDTAN
                       ,TOK_ADDDAY
                       ,TOK_ADDTIM
                    INTO
                        tokrow.TOK_ADDTAN
                       ,tokrow.TOK_ADDDAY
                       ,tokrow.TOK_ADDTIM
                    FROM
                        TOKMAST
                    WHERE
                        TOK_TOKCOD   =   tokrow.TOK_TOKCOD
                    ;
                EXCEPTION
                    WHEN NO_DATA_FOUND THEN                                 --  �Y���f�[�^�Ȃ�
                        tokrow.TOK_ADDTAN := CRecMlg.MLG_TANCOD ;
                        tokrow.TOK_ADDDAY := CRecMlg.MLG_UPDDAY ;
                        tokrow.TOK_ADDTIM := CRecMlg.MLG_UPDTIM ;
                END ;
            ELSIF CRecMlg.MLG_UPDKBN = 'D' THEN
                tokrow.TOK_DELFLG := '1' ;
--
                BEGIN
                    SELECT
                        TOK_ADDTAN
                       ,TOK_ADDDAY
                       ,TOK_ADDTIM
                    INTO
                        tokrow.TOK_ADDTAN
                       ,tokrow.TOK_ADDDAY
                       ,tokrow.TOK_ADDTIM
                    FROM
                        TOKMAST
                    WHERE
                        TOK_TOKCOD   =   tokrow.TOK_TOKCOD
                    ;
                EXCEPTION
                    WHEN NO_DATA_FOUND THEN                                 --  �Y���f�[�^�Ȃ�
                        tokrow.TOK_ADDTAN := CRecMlg.MLG_TANCOD ;
                        tokrow.TOK_ADDDAY := CRecMlg.MLG_UPDDAY ;
                        tokrow.TOK_ADDTIM := CRecMlg.MLG_UPDTIM ;
                END ;
            END IF ;
--
            BEGIN
                INSERT INTO
                    TOKMAST_LOG
                VALUES
                    tokrow
                ;
            EXCEPTION
                WHEN DUP_VAL_ON_INDEX THEN
                    UPDATE
                        TOKMAST_LOG
                    SET
                        TOK_TOKNAM = tokrow.TOK_TOKNAM
                    WHERE
                        TOK_TOKCOD   =   tokrow.TOK_TOKCOD
                    ;
            END ;
        ELSIF TRIM(CRecMlg.MLG_PRGNUM) = 'CRJHM060' THEN
            tshrow := tshrowinit ;
--
            tshrow.TSH_TOKCOD := '0' || SUBSTRB(CRecMlg.MLG_TOKCOD, 1, 4) || '0' || SUBSTRB(CRecMlg.MLG_TOKCOD, 5, 3) ;
            tshrow.TSH_SHOCOD := CRecMlg.MLG_SHOCOD ;
            tshrow.TSH_TSHNAM := SUBSTRB(RTRIM(CRecMlg.MLG_MEISYO), 50) ;
            tshrow.TSH_ADDTAN := CRecMlg.MLG_TANCOD ;
            tshrow.TSH_ADDDAY := CRecMlg.MLG_UPDDAY ;
            tshrow.TSH_ADDTIM := CRecMlg.MLG_UPDTIM ;
            tshrow.TSH_UPDTAN := CRecMlg.MLG_TANCOD ;
            tshrow.TSH_UPDDAY := CRecMlg.MLG_UPDDAY ;
            tshrow.TSH_UPDTIM := CRecMlg.MLG_UPDTIM ;
--
            IF    CRecMlg.MLG_UPDKBN = 'A' THEN
                tshrow.TSH_DELFLG := '0' ;
            ELSIF CRecMlg.MLG_UPDKBN = 'U' THEN
                tshrow.TSH_DELFLG := '0' ;
--
                BEGIN
                    SELECT
                        TSH_ADDTAN
                       ,TSH_ADDDAY
                       ,TSH_ADDTIM
                    INTO
                        tshrow.TSH_ADDTAN
                       ,tshrow.TSH_ADDDAY
                       ,tshrow.TSH_ADDTIM
                    FROM
                        TSHMAST
                    WHERE
                        TSH_TOKCOD   =   tshrow.TSH_TOKCOD
                    AND
                        TSH_SHOCOD   =   tshrow.TSH_SHOCOD
                    ;
                EXCEPTION
                    WHEN NO_DATA_FOUND THEN                                 --  �Y���f�[�^�Ȃ�
                        tshrow.TSH_ADDTAN := CRecMlg.MLG_TANCOD ;
                        tshrow.TSH_ADDDAY := CRecMlg.MLG_UPDDAY ;
                        tshrow.TSH_ADDTIM := CRecMlg.MLG_UPDTIM ;
                END ;
            ELSIF CRecMlg.MLG_UPDKBN = 'D' THEN
                tshrow.TSH_DELFLG := '1' ;
--
                BEGIN
                    SELECT
                        TSH_ADDTAN
                       ,TSH_ADDDAY
                       ,TSH_ADDTIM
                    INTO
                        tshrow.TSH_ADDTAN
                       ,tshrow.TSH_ADDDAY
                       ,tshrow.TSH_ADDTIM
                    FROM
                        TSHMAST
                    WHERE
                        TSH_TOKCOD   =   tshrow.TSH_TOKCOD
                    AND
                        TSH_SHOCOD   =   tshrow.TSH_SHOCOD
                    ;
                EXCEPTION
                    WHEN NO_DATA_FOUND THEN                                 --  �Y���f�[�^�Ȃ�
                        tshrow.TSH_ADDTAN := CRecMlg.MLG_TANCOD ;
                        tshrow.TSH_ADDDAY := CRecMlg.MLG_UPDDAY ;
                        tshrow.TSH_ADDTIM := CRecMlg.MLG_UPDTIM ;
                END ;
            END IF ;
--
            BEGIN
                INSERT INTO
                    TSHMAST_LOG
                VALUES
                    tshrow
                ;
            EXCEPTION
                WHEN DUP_VAL_ON_INDEX THEN
                    UPDATE
                        TSHMAST_LOG
                    SET
                        TSH_TSHNAM = tshrow.TSH_TSHNAM
                    WHERE
                        TSH_TOKCOD   =   tshrow.TSH_TOKCOD
                    AND
                        TSH_SHOCOD   =   tshrow.TSH_SHOCOD
                    ;
            END ;
        ELSIF TRIM(CRecMlg.MLG_PRGNUM) = 'CRJHM070' THEN
            sirrow := sirrowinit ;
--
            sirrow.SIR_SIRCOD := CRecMlg.MLG_SIRCOD ;
            sirrow.SIR_SIRNAM := RTRIM(CRecMlg.MLG_MEISYO) ;
            sirrow.SIR_ADDTAN := CRecMlg.MLG_TANCOD ;
            sirrow.SIR_ADDDAY := CRecMlg.MLG_UPDDAY ;
            sirrow.SIR_ADDTIM := CRecMlg.MLG_UPDTIM ;
            sirrow.SIR_UPDTAN := CRecMlg.MLG_TANCOD ;
            sirrow.SIR_UPDDAY := CRecMlg.MLG_UPDDAY ;
            sirrow.SIR_UPDTIM := CRecMlg.MLG_UPDTIM ;
--
            IF    CRecMlg.MLG_UPDKBN = 'A' THEN
                sirrow.SIR_DELFLG := '0' ;
            ELSIF CRecMlg.MLG_UPDKBN = 'U' THEN
                sirrow.SIR_DELFLG := '0' ;
--
                BEGIN
                    SELECT
                        SIR_ADDTAN
                       ,SIR_ADDDAY
                       ,SIR_ADDTIM
                    INTO
                        sirrow.SIR_ADDTAN
                       ,sirrow.SIR_ADDDAY
                       ,sirrow.SIR_ADDTIM
                    FROM
                        SIRMAST
                    WHERE
                        SIR_SIRCOD   =   sirrow.SIR_SIRCOD
                    ;
                EXCEPTION
                    WHEN NO_DATA_FOUND THEN                                 --  �Y���f�[�^�Ȃ�
                        sirrow.SIR_ADDTAN := CRecMlg.MLG_TANCOD ;
                        sirrow.SIR_ADDDAY := CRecMlg.MLG_UPDDAY ;
                        sirrow.SIR_ADDTIM := CRecMlg.MLG_UPDTIM ;
                END ;
            ELSIF CRecMlg.MLG_UPDKBN = 'D' THEN
                sirrow.SIR_DELFLG := '1' ;
--
                BEGIN
                    SELECT
                        SIR_ADDTAN
                       ,SIR_ADDDAY
                       ,SIR_ADDTIM
                    INTO
                        sirrow.SIR_ADDTAN
                       ,sirrow.SIR_ADDDAY
                       ,sirrow.SIR_ADDTIM
                    FROM
                        SIRMAST
                    WHERE
                        SIR_SIRCOD   =   sirrow.SIR_SIRCOD
                    ;
                EXCEPTION
                    WHEN NO_DATA_FOUND THEN                                 --  �Y���f�[�^�Ȃ�
                        sirrow.SIR_ADDTAN := CRecMlg.MLG_TANCOD ;
                        sirrow.SIR_ADDDAY := CRecMlg.MLG_UPDDAY ;
                        sirrow.SIR_ADDTIM := CRecMlg.MLG_UPDTIM ;
                END ;
            END IF ;
--
            BEGIN
                INSERT INTO
                    SIRMAST_LOG
                VALUES
                    sirrow
                ;
            EXCEPTION
                WHEN DUP_VAL_ON_INDEX THEN
                    UPDATE
                        SIRMAST_LOG
                    SET
                        SIR_SIRNAM = sirrow.SIR_SIRNAM
                    WHERE
                        SIR_SIRCOD   =   sirrow.SIR_SIRCOD
                    ;
            END ;
        ELSIF TRIM(CRecMlg.MLG_PRGNUM) = 'CRJHM080' THEN
            sshrow := sshrowinit ;
--
            sshrow.SSH_SIRCOD := CRecMlg.MLG_SIRCOD ;
            sshrow.SSH_SHOCOD := CRecMlg.MLG_SHOCOD ;
            sshrow.SSH_ADDTAN := CRecMlg.MLG_TANCOD ;
            sshrow.SSH_ADDDAY := CRecMlg.MLG_UPDDAY ;
            sshrow.SSH_ADDTIM := CRecMlg.MLG_UPDTIM ;
            sshrow.SSH_UPDTAN := CRecMlg.MLG_TANCOD ;
            sshrow.SSH_UPDDAY := CRecMlg.MLG_UPDDAY ;
            sshrow.SSH_UPDTIM := CRecMlg.MLG_UPDTIM ;
--
            IF    CRecMlg.MLG_UPDKBN = 'A' THEN
                sshrow.SSH_DELFLG := '0' ;
            ELSIF CRecMlg.MLG_UPDKBN = 'U' THEN
                sshrow.SSH_DELFLG := '0' ;
--
                BEGIN
                    SELECT
                        SSH_ADDTAN
                       ,SSH_ADDDAY
                       ,SSH_ADDTIM
                    INTO
                        sshrow.SSH_ADDTAN
                       ,sshrow.SSH_ADDDAY
                       ,sshrow.SSH_ADDTIM
                    FROM
                        SSHMAST
                    WHERE
                        SSH_SIRCOD   =   sshrow.SSH_SIRCOD
                    AND
                        SSH_SHOCOD   =   sshrow.SSH_SHOCOD
                    ;
                EXCEPTION
                    WHEN NO_DATA_FOUND THEN                                 --  �Y���f�[�^�Ȃ�
                        sshrow.SSH_ADDTAN := CRecMlg.MLG_TANCOD ;
                        sshrow.SSH_ADDDAY := CRecMlg.MLG_UPDDAY ;
                        sshrow.SSH_ADDTIM := CRecMlg.MLG_UPDTIM ;
                END ;
            ELSIF CRecMlg.MLG_UPDKBN = 'D' THEN
                sshrow.SSH_DELFLG := '1' ;
--
                BEGIN
                    SELECT
                        SSH_ADDTAN
                       ,SSH_ADDDAY
                       ,SSH_ADDTIM
                    INTO
                        sshrow.SSH_ADDTAN
                       ,sshrow.SSH_ADDDAY
                       ,sshrow.SSH_ADDTIM
                    FROM
                        SSHMAST
                    WHERE
                        SSH_SIRCOD   =   sshrow.SSH_SIRCOD
                    AND
                        SSH_SHOCOD   =   sshrow.SSH_SHOCOD
                    ;
                EXCEPTION
                    WHEN NO_DATA_FOUND THEN                                 --  �Y���f�[�^�Ȃ�
                        sshrow.SSH_ADDTAN := CRecMlg.MLG_TANCOD ;
                        sshrow.SSH_ADDDAY := CRecMlg.MLG_UPDDAY ;
                        sshrow.SSH_ADDTIM := CRecMlg.MLG_UPDTIM ;
                END ;
            END IF ;
--
            BEGIN
                INSERT INTO
                    SSHMAST_LOG
                VALUES
                    sshrow
                ;
            EXCEPTION
                WHEN DUP_VAL_ON_INDEX THEN
                    NULL ;
            END ;
        ELSIF TRIM(CRecMlg.MLG_PRGNUM) = 'CRJHM500' THEN
            NULL ;
        END IF ;
    END LOOP ;
END ;
/
--
Commit ;
--
/*
Quit ;
*/
--
