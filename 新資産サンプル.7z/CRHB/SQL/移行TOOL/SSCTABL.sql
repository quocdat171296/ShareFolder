Truncate Table SSCTABL ;

Insert Into SSCTABL
Select
    '0' || SUBSTRB(SSC_TOKCOD, 1, 4) || '0' || SUBSTRB(SSC_TOKCOD, 5, 3) AS SSC_TOKCOD,
    SSC_CTKSKB ,
    '0' || SSC_CTKSCD AS SSC_CTKSCD,
    SSC_ADDNOU ,
    '0'        ,
    '999998'   ,
    SSC_UPDDAY ,
    SSC_UPDTIM ,
    '999998'   ,
    SSC_UPDDAY ,
    SSC_UPDTIM
From
    (
        Select
            *
        From
            CHUBU.SSCTABL
    );
--
Commit ;
--
/*
Quit ;
*/
--
