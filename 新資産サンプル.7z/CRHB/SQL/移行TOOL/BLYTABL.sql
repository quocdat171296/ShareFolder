Truncate Table BLYTABL;
--
/*
Quit ;
*/
--
