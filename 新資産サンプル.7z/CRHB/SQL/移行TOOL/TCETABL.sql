Truncate Table TCETABL ;

Insert Into TCETABL
Select
    '0' || TCE_TDNPTN || TKJ_SSWCOD                                         AS  TCE_TDNPTN ,
    TCE_STIKCD                                                              AS  TCE_STIKCD ,
    TCE_STIECO                                                              AS  TCE_STIECO ,
    TCE_STIBMN                                                              AS  TCE_STIBMN ,
    '0' || SUBSTRB(TCE_TOKCOD, 1, 4) || '0' || SUBSTRB(TCE_TOKCOD, 5, 2)    AS  TCE_TOKCOD ,
    '0'        || TCE_TKSCOD                                                AS  TCE_TKSCOD ,
    '00'       || TCE_TKBCOD                                                AS  TCE_TKBCOD ,
    '0' || SUBSTRB(TCE_ASNSID, 1, 4) || '0' || SUBSTRB(TCE_ASNSID, 5, 2)    AS  TCE_ASNSID ,
    '0'                                                                     AS  TCE_DELFLG ,
    '999998'                                                                AS  TCE_ADDTAN ,
    TCE_UPDDAY                                                              AS  TCE_ADDDAY ,
    TCE_UPDTIM                                                              AS  TCE_ADDTIM ,
    '999998'                                                                AS  TCE_UPDTAN ,
    TCE_UPDDAY                                                              AS  TCE_UPDDAY ,
    TCE_UPDTIM                                                              AS  TCE_UPDTIM
From
    (
        Select
            *
        From
            CHUBU.TCETABL
    )
    Inner Join (
        Select
            TKJ_TDNPTN ,
            Trim(To_Char(To_Number(Min(TKJ_SSWCOD)) -1, '000')) AS  TKJ_SSWCOD
        From
            CHUBU.TKJTABL
		Where
			TKJ_SSWCOD <> '6'
        Group By
            TKJ_TDNPTN
    )
    On (
        TCE_TDNPTN = TKJ_TDNPTN
    )
Order By
    TCE_TDNPTN ;
--
--�q��x�X���ނ�'09999'����'99999'�ɒu��
Update
    TCETABL
Set
    TCE_TKSCOD = '99999'
Where
    TCE_TKSCOD = '09999';
--
Commit ;
--
/*
Quit ;
*/
--
