Truncate Table KBMTABL ;
--
Insert Into KBMTABL
Select 
    KBM_KBMCOD ,
    KBM_KBMNAM ,
    KBM_BMNCOD ,
    KBM_KBMSUU ,
    KBM_DSPSEQ ,
    '0'        ,
    '999998'   ,
    KBM_UPDDAY ,
    KBM_UPDTIM ,
    '999998'   ,
    KBM_UPDDAY ,
    KBM_UPDTIM 
From
    (
        Select
            *
        From
            CHUBU.KBMTABL
    ) ;
--
Commit ;
--
/*
Quit ;
*/
--
