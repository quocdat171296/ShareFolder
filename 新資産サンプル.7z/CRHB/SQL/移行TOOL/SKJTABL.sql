Truncate Table SKJTABL;

Insert Into SKJTABL ( 
    SKJ_TOKCOD ,
    SKJ_TKSCOD ,
    SKJ_SSWCOD ,
    SKJ_NHSCOD ,
    SKJ_SEICOD ,
    SKJ_DELFLG ,
    SKJ_ADDTAN ,
    SKJ_ADDDAY ,
    SKJ_ADDTIM ,
    SKJ_UPDTAN ,
    SKJ_UPDDAY ,
    SKJ_UPDTIM 
)
Select
    '0' || SUBSTRB(TOK_TOKCOD, 1, 4) || '0' || SUBSTRB(TOK_TOKCOD, 5, 3)    AS  SKJ_TOKCOD,
    DECODE(TKS_TKSCOD,NULL,'00000','0' || TKS_TKSCOD)                       AS  SKJ_TKSCOD,
    '0' || TKJ_SSWCOD                                                       AS  SKJ_SSWCOD,
    NVL(TKS_HSOTOK, '00000000')                                             AS  SKJ_NHSCOD,
    NVL(TOK_SEICOD, '00000000')                                             AS  SKJ_SEICOD,
    '0'                                                                     AS  SKJ_DELFLG,
    '999998'                                                                AS  SKJ_ADDTAN,
    TKJ_UPDDAY                                                              AS  SKJ_ADDDAY,
    TKJ_UPDTIM                                                              AS  SKJ_ADDTIM,
    '999998'                                                                AS  SKJ_UPDTAN,
    TKJ_UPDDAY                                                              AS  SKJ_UPDDAY,
    TKJ_UPDTIM                                                              AS  SKJ_UPDTIM
From
    (
        Select
            TOK_TOKCOD,
            TOK_TDNPTN,
            '0' || SUBSTRB(TOK_SEICOD, 1, 4) || '0' || SUBSTRB(TOK_SEICOD, 5, 3)  AS  TOK_SEICOD
        From
            CHUBU.TOKMAST
    )
    Inner Join (
        Select
            *
        From
            CHUBU.TKJTABL
    )
    On (
        TOK_TDNPTN  = TKJ_TDNPTN
    )
    Inner Join (
        Select
            TKJ_TDNPTN                                          AS  GRP_TDNPTN,
            Trim(To_Char(To_Number(Min(TKJ_SSWCOD)) -1, '000')) AS  GRP_SSWCOD
        From
            CHUBU.TKJTABL
        Group By
            TKJ_TDNPTN
    )
    On (
        TOK_TDNPTN = GRP_TDNPTN
    )
    Inner Join (
        Select
            TKS_TOKCOD,
            TKS_TKSCOD,
            '0' || SUBSTRB(TKS_HSOTOK, 1, 4) || '0' || SUBSTRB(TKS_HSOTOK, 5, 3)  AS  TKS_HSOTOK,
            '0' || SUBSTRB(TKS_KAITOK, 1, 4) || '0' || SUBSTRB(TKS_KAITOK, 5, 3)  AS  TKS_KAITOK
        From
            CHUBU.TKSMAST
    )
    On (
        TOK_TOKCOD  = TKS_TOKCOD
    )
Order By
    TOK_TOKCOD ,
    TKS_TKSCOD ;
--
/* ���Z�����͎x�X�R�[�h���u9999�v�ō쐬����Ă��邽��            */
/* �x�X�R�[�h���u09999�v�̃��R�[�h�̎x�X�R�[�h���u999990�v�֕ϊ� */
Update SKJTABL
Set SKJ_TKSCOD = '99999'
Where
    SKJ_TKSCOD = '09999';
--
Commit ;
--
/*
Quit ;
*/
--
