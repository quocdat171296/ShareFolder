Truncate Table CNLTABL;
--
Insert Into CNLTABL
Select
    '0' || SubstrB(CNL_TOKCOD,1,4) || '0' || SubstrB(CNL_TOKCOD,5,2) As CNL_TOKCOD ,
    '0' ||CNL_TKSCOD As CNL_TKSCOD ,
    '0000000' || CNL_TRICOD As CNL_TRICOD ,
    '000' || CNL_STNCOD As CNL_STNCOD ,
    CNL_SNTCOD ,
    CNL_JYUKBN ,
    '20010101' ,
    CNL_BTRSWK ,
    CNL_PRTKBN ,
    '0'        ,
    '999998'   ,
    CNL_UPDDAY ,
    CNL_UPDTIM ,
    '999998'   ,
    CNL_UPDDAY ,
    CNL_UPDTIM 
From
    (
        Select
            *
        From
            CHUBU.CNLTABL
    );
--
Commit ;
--
/*
QUIT ;
*/
--
