Truncate Table SSQTABL ;

Insert Into SSQTABL
Select
    SSQ_SHOSTR  AS  SSQ_SHOSTR ,
    SSQ_SHOEND  AS  SSQ_SHOEND ,
    SSQ_SHOSEQ  AS  SSQ_SHOSEQ ,
    SSQ_SHODEF  AS  SSQ_SHODEF ,
    '0'         AS  SSQ_DELFLG ,
    '999998'    AS  SSQ_ADDTAN ,
    SSQ_UPDDAY  AS  SSQ_ADDDAY ,
    SSQ_UPDTIM  AS  SSQ_ADDTIM ,
    '999998'    AS  SSQ_UPDTAN ,
    SSQ_UPDDAY  AS  SSQ_UPDDAY ,
    SSQ_UPDTIM  AS  SSQ_UPDTIM
FROM
    (
        Select
            *
        From
            CHUBU.SSQTABL
    ) ;
--
Commit ;
--
/*
Quit ;
*/
--
