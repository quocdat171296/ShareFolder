-- Truncate Table SRAFILE ;
--
DECLARE
--
    DENNUM SRHFILE.SRH_DENNUM%TYPE ;
    retcod NUMBER;
    retmsg VARCHAR2(256);
    cnt    NUMBER;
    cnt2   NUMBER;
--
    CURSOR CReadSRH IS
        Select
            /*+INDEX (SRHFILE SRHFILE8)*/
            SRH_DENNUM  AS  DENNUM 
        From
            SRHFILE
        Where
            SRH_SIRDAY >= '20200901';
--
BEGIN
--
    cnt := 0;
    cnt2 := 0;
--
    FOR CRecSRH IN CReadSRH LOOP
--
        DENNUM  := CRecSRH.DENNUM ;
--
        cnt  := cnt  + 1 ;
        cnt2 := cnt2 + 1 ;
--
        CRCO000S.TBLCALC(
            CRCO000S.SIR_TBLKBN ,
            DENNUM ,
            retcod ,
            retmsg
        );
        IF cnt > 10000 then
            COMMIT ;
            cnt := 0 ;
        END IF;

    END LOOP;

END ;
/
--
Commit ;
--
--Quit ;
--
