-- Truncate Table URAFILE ;
--
DECLARE
--
    DENNUM URHFILE.URH_DENNUM%TYPE ;
    retcod NUMBER;
    retmsg VARCHAR2(256);
    cnt    NUMBER;
    cnt2   NUMBER;
--
    CURSOR CReadURH IS
        Select
            /*+ INDEX (URHFILE URHFILE6) */
            URH_DENNUM  AS  DENNUM 
        From
            URHFILE
        Where
            URH_URIDAY >= '20200901';
--
BEGIN
--
    cnt := 0;
    cnt2 := 0;
--
    FOR CRecURH IN CReadURH LOOP
--
        DENNUM  := CRecURH.DENNUM ;
--
        cnt  := cnt  + 1 ;
        cnt2 := cnt2 + 1 ;
--
        CRCO000S.TBLCALC(
            CRCO000S.URI_TBLKBN ,
            DENNUM ,
            retcod ,
            retmsg
        );
        IF cnt > 10000 then
            COMMIT ;
            cnt := 0 ;
        END IF;

    END LOOP;

END ;
/
--
Commit ;
--
--Quit ;
--
