-- Truncate Table BASTABL ;
-- �K�{�FJYH�����JYB�̈ڍs�������������Ă��邱��
--       BASTABL��BASTABL�͋�����DB���ڍs
--
-- 2020/03/27 ���s�V�X�e���Ɠ��l�̎�z���@�ɕύX�ɔ���
--            CHUBU.BASTABL �ˁ@�VDB.BASTABL �݂̂̈ڍs�Ƃ���
-- 2020/06/01 BASTABL�̍\�������s�ʂ�ƂȂ�������
--            CHUBU.BASTABL �ˁ@�VDB.BASTABL �̒P���ڍs�Ƃ��ABASTABL2��p�~
/*
DECLARE
--
    retcod NUMBER;
    retmsg VARCHAR2(256);
--
    cnt    NUMBER;
    cnt2   NUMBER;
    cnt3   NUMBER;
--
    TOKCOD BASTABL.BAS_TOKCOD%TYPE ;
    ARECOD BASTABL.BAS_ARECOD%TYPE ;
    SHOCOD BASTABL.BAS_SHOCOD%TYPE ;
    DATKBN BASTABL.BAS_DATKBN%TYPE ;
    SNDCOD BASTABL.BAS_SNDCOD%TYPE ;
    SIRCOD BASTABL.BAS_SIRCOD%TYPE ;
    SNTCOD BASTABL.BAS_SNTCOD%TYPE ;
    ADDDAY BASTABL.BAS_ADDDAY%TYPE ;
    ADDTIM BASTABL.BAS_ADDTIM%TYPE ;
--
---------------------------------------------------------------------
--         STEP1   EOS�������̎�z����쐬����
---------------------------------------------------------------------
--
--    CURSOR CReadJYFILE1 IS
--        Select
--            JYH_NOUCOD As TOKCOD ,
--            JYH_ARECOD As ARECOD ,
--            JYB_SHOCOD As SHOCOD ,
--            JYH_DATKBN As DATKBN ,
--            JYH_SNDCOD As SNDCOD ,
--            JYH_SIRCOD As SIRCOD,
--            JYH_SNTCOD As SNTCOD
--        From
--            (
--                Select
--                    JYH_DENNUM ,
--                    JYH_NOUCOD ,
--                    JYH_ARECOD ,
--                    JYH_NOUDAY ,
--                    JYH_DATKBN ,
--                    JYH_SNDCOD ,
--                    JYH_SIRCOD ,
--                    JYH_SNTCOD
--                From
--                    JYHFILE
--                Where
--                --  JYH_DATKBN <> '3'
--                    JYH_JYUKBN =  '1'
--            )
--            Inner Join (
--                Select
--                    JYB_DENNUM ,
--                    JYB_SHOCOD
--                From
--                    JYBFILE
--                Where
--                    JYB_TJYUSU <> 0
--            )
--            On (
--                JYH_DENNUM = JYB_DENNUM
--            )
--        Order By
--            JYH_NOUCOD ,
--            JYH_ARECOD ,
--            JYB_SHOCOD ,
--            JYH_NOUDAY ,
--            JYH_DENNUM;
--
---------------------------------------------------------------------
--         STEP2   WEB/FAX�󒍕��̎�z����쐬����
---------------------------------------------------------------------
--
    CURSOR CReadJYFILE2 IS
        Select
            '0' || SubstrB(TSH_TOKCOD,1,4) || '0' || SubstrB(TSH_TOKCOD,5,2) As TOKCOD ,
            BAG_ARECOD                                                       As ARECOD ,
            TSH_SHOCOD                                                       As SHOCOD ,
            NVL(TSH_ADDDAY,'00000000')                                       As STRDAY ,
            BAS_DATKBN                                                       AS DATKBN ,
            BAS_SIRCOD                                                       AS SNDCOD ,
            BAS_SIRCOD                                                       AS SIRCOD ,
            BAS_SNTCOD                                                       AS SNTCOD
        From
            (
                Select
                    *
                From
                    CHUBU.TSHMAST
                Where
                    TSH_RECKBN = '0'
                And TSH_TRICOD = '000000'
            )
            Inner Join (
                Select DISTINCT
                    BAG_TOKCOD ,
                    BAG_ARECOD
                From
                    CHUBU.BAGTABL
                Where
                    BAG_ARECOD <> '99'
                Group By
                    BAG_TOKCOD ,
                    BAG_ARECOD
            ) On ( TSH_TOKCOD = BAG_TOKCOD )
            Inner Join (
                    Select
                        *
                    From
                    CHUBU.BASTABL
            ) On ( BAG_ARECOD = BAS_ARECOD
               And TSH_SHOCOD = BAS_SHOCOD )
        ;
--
---------------------------------------------------------------------
--         STEP3   FAX�󒍕��̎�z����쐬����
---------------------------------------------------------------------
--
--    CURSOR CReadJYFILE3 IS
--        Select
--            JYH_NOUCOD As TOKCOD ,
--            JYH_ARECOD As ARECOD ,
--            JYB_SHOCOD As SHOCOD ,
--            JYH_DATKBN As DATKBN ,
--            JYH_SNDCOD As SNDCOD ,
--            JYH_SIRCOD As SIRCOD,
--            JYH_SNTCOD As SNTCOD
--        From
--            (
--                Select
--                    JYH_DENNUM ,
--                    JYH_NOUCOD ,
--                    JYH_ARECOD ,
--                    JYH_NOUDAY ,
--                    JYH_DATKBN ,
--                    JYH_SNDCOD ,
--                    JYH_SIRCOD ,
--                    JYH_SNTCOD
--                From
--                    JYHFILE
--                Where
--                --  JYH_DATKBN = '3'
--                    JYH_JYUKBN = '3'
--                And JYH_TRICOD<> '0000000000000'
--            )
--            Inner Join (
--                Select
--                    JYB_DENNUM ,
--                    JYB_SHOCOD
--                From
--                    JYBFILE
--                Where
--                    JYB_TJYUSU <> 0
--            )
--            On (
--                JYH_DENNUM = JYB_DENNUM
--            )
--        Order By
--            JYH_NOUCOD ,
--            JYH_ARECOD ,
--            JYB_SHOCOD ,
--            JYH_NOUDAY ,
--            JYH_DENNUM;
--
BEGIN
--
    cnt  := 0;
    cnt2 := 0;
    cnt3 := 0;
--
    ADDDAY := TO_CHAR(SYSDATE, 'YYYYMMDD') ;
    ADDTIM := TO_CHAR(SYSDATE, 'HH24MISS') ;
--
---------------------------------------------------------------------
--         STEP1   EOS�������̎�z����쐬����(�ڍs�ςݎ󒍂��쐬)
---------------------------------------------------------------------
--
--  FOR CRecJYFILE IN CReadJYFILE1 LOOP
--
--        IF cnt2 = 0 THEN
--            TOKCOD := CRecJYFILE.TOKCOD ;
--            ARECOD := CRecJYFILE.ARECOD ;
--            SHOCOD := CRecJYFILE.SHOCOD ;
--            DATKBN := CRecJYFILE.DATKBN ;
--            SNDCOD := CRecJYFILE.SNDCOD ;
--            SIRCOD := CRecJYFILE.SIRCOD ;
--            SNTCOD := CRecJYFILE.SNTCOD ;
--        END IF;
--
--        cnt2 := cnt2 + 1 ;
--
--        IF TOKCOD = CRecJYFILE.TOKCOD AND
--           ARECOD = CRecJYFILE.ARECOD AND
--           SHOCOD = CRecJYFILE.SHOCOD THEN
--            NULL ;
--        ELSE
--            Insert Into BASTABL (
--                BAS_SHOCOD ,
--                BAS_STRDAY ,
--                BAS_TOKCOD ,
--                BAS_ARECOD ,
--                BAS_DATKBN ,
--                BAS_SNDCOD ,
--                BAS_SIRCOD ,
--                BAS_SNTCOD ,
--                BAS_DELFLG ,
--                BAS_ADDTAN ,
--                BAS_ADDDAY ,
--                BAS_ADDTIM ,
--                BAS_UPDTAN ,
--                BAS_UPDDAY ,
--                BAS_UPDTIM
--            )
--            Values (
--                SHOCOD     ,
--                '20010101' ,
--                TOKCOD     ,
--                ARECOD     ,
--                DATKBN     ,
--                SNDCOD     ,
--                SIRCOD     ,
--                SNTCOD     ,
--                '0'        ,
--                '999998'   ,
--                ADDDAY     ,
--                ADDTIM     ,
--                '999998'   ,
--                ADDDAY     ,
--                ADDTIM
--            ) ;
--
--            cnt  := cnt  + 1 ;
--
--        END IF ;
--
--        IF cnt > 10000 THEN
--            COMMIT ;
--            cnt := 0 ;
--        END IF;
--
--        TOKCOD := CRecJYFILE.TOKCOD ;
--        ARECOD := CRecJYFILE.ARECOD ;
--        SHOCOD := CRecJYFILE.SHOCOD ;
--        DATKBN := CRecJYFILE.DATKBN ;
--        SNDCOD := CRecJYFILE.SNDCOD ;
--        SIRCOD := CRecJYFILE.SIRCOD ;
--        SNTCOD := CRecJYFILE.SNTCOD ;
----
--    END LOOP;
--
--    IF cnt2 > 0 THEN
--        Insert Into BASTABL (
--            BAS_SHOCOD ,
--            BAS_STRDAY ,
--            BAS_TOKCOD ,
--            BAS_ARECOD ,
--            BAS_DATKBN ,
--            BAS_SNDCOD ,
--            BAS_SIRCOD ,
--            BAS_SNTCOD ,
--            BAS_DELFLG ,
--            BAS_ADDTAN ,
--            BAS_ADDDAY ,
--            BAS_ADDTIM ,
--            BAS_UPDTAN ,
--            BAS_UPDDAY ,
--            BAS_UPDTIM
--        )
--        Values (
--            SHOCOD     ,
--            '20010101' ,
--            TOKCOD     ,
--            ARECOD     ,
--            DATKBN     ,
--            SNDCOD     ,
--            SIRCOD     ,
--            SNTCOD     ,
--            '0'        ,
--            '999998'   ,
--            ADDDAY     ,
--            ADDTIM     ,
--            '999998'   ,
--            ADDDAY     ,
--            ADDTIM
--        ) ;
--    END IF ;
--
---------------------------------------------------------------------
--         STEP2   WEB/FAX�󒍕��̎�z����쐬����(�ڍs��DB���쐬)
---------------------------------------------------------------------
--
    FOR CRecJYFILE2 IN CReadJYFILE2 LOOP
            TOKCOD := CRecJYFILE2.TOKCOD ;
            ARECOD := CRecJYFILE2.ARECOD ;
            SHOCOD := CRecJYFILE2.SHOCOD ;
            DATKBN := CRecJYFILE2.DATKBN ;
            SNDCOD := CRecJYFILE2.SNDCOD ;
            SIRCOD := CRecJYFILE2.SIRCOD ;
            SNTCOD := CRecJYFILE2.SNTCOD ;
--
            BEGIN
                Insert Into BASTABL (
                    BAS_SHOCOD ,
                    BAS_STRDAY ,
                    BAS_TOKCOD ,
                    BAS_ARECOD ,
                    BAS_DATKBN ,
                    BAS_SNDCOD ,
                    BAS_SIRCOD ,
                    BAS_SNTCOD ,
                    BAS_DELFLG ,
                    BAS_ADDTAN ,
                    BAS_ADDDAY ,
                    BAS_ADDTIM ,
                    BAS_UPDTAN ,
                    BAS_UPDDAY ,
                    BAS_UPDTIM
                )
                Values (
                    SHOCOD     ,
                    '20010101' ,
                    TOKCOD     ,
                    ARECOD     ,
                    DATKBN     ,
                    SNDCOD     ,
                    SIRCOD     ,
                    SNTCOD     ,
                    '0'        ,
                    '999998'   ,
                    ADDDAY     ,
                    ADDTIM     ,
                    '999998'   ,
                    ADDDAY     ,
                    ADDTIM
                ) ;
--
                cnt  := cnt  + 1 ;
--
            EXCEPTION
                WHEN DUP_VAL_ON_INDEX THEN
--
                    NULL ;
--
                WHEN OTHERS THEN
--
                    RAISE ;                                                             --  �G���[����
--
            END ;
--
    END LOOP;
--
---------------------------------------------------------------------
--         STEP3   FAX�󒍕��̎�z����쐬����(�ڍs�ςݎ󒍂��쐬)
---------------------------------------------------------------------
--
--    cnt := 0 ;
--
--    FOR CRecJYFILE3 IN CReadJYFILE3 LOOP
--
--        IF cnt3 = 0 THEN
--            TOKCOD := CRecJYFILE3.TOKCOD ;
--            ARECOD := CRecJYFILE3.ARECOD ;
--            SHOCOD := CRecJYFILE3.SHOCOD ;
--            DATKBN := CRecJYFILE3.DATKBN ;
--            SNDCOD := CRecJYFILE3.SNDCOD ;
--            SIRCOD := CRecJYFILE3.SIRCOD ;
--            SNTCOD := CRecJYFILE3.SNTCOD ;
--        END IF;
--
--        cnt3 := cnt3 + 1 ;
--
--        IF TOKCOD = CRecJYFILE3.TOKCOD AND
--           ARECOD = CRecJYFILE3.ARECOD AND
--           SHOCOD = CRecJYFILE3.SHOCOD THEN
--            NULL ;
--        ELSE
--            BEGIN
--                Insert Into BASTABL (
--                    BAS_SHOCOD ,
--                    BAS_STRDAY ,
--                    BAS_TOKCOD ,
--                    BAS_ARECOD ,
--                    BAS_DATKBN ,
--                    BAS_SNDCOD ,
--                    BAS_SIRCOD ,
--                    BAS_SNTCOD ,
--                    BAS_DELFLG ,
--                    BAS_ADDTAN ,
--                    BAS_ADDDAY ,
--                    BAS_ADDTIM ,
--                    BAS_UPDTAN ,
--                    BAS_UPDDAY ,
--                    BAS_UPDTIM
--                )
--                Values (
--                    SHOCOD     ,
--                    '20010101' ,
--                    TOKCOD     ,
--                    ARECOD     ,
--                    DATKBN     ,
--                    SNDCOD     ,
--                    SIRCOD     ,
--                    SNTCOD     ,
--                    '0'        ,
--                    '999998'   ,
--                    ADDDAY     ,
--                    ADDTIM     ,
--                    '999998'   ,
--                    ADDDAY     ,
--                    ADDTIM
--                ) ;
--
--                cnt  := cnt  + 1 ;
--
--            EXCEPTION
--                WHEN DUP_VAL_ON_INDEX THEN
--
--                    NULL ;
--
--                WHEN OTHERS THEN
--
--                    RAISE ;                                                             --  �G���[����
--
--            END ;
--
--        END IF ;
--
--        IF cnt > 10000 THEN
--            COMMIT ;
--
--            cnt := 0 ;
--        END IF;
--
--        TOKCOD := CRecJYFILE3.TOKCOD ;
--        ARECOD := CRecJYFILE3.ARECOD ;
--        SHOCOD := CRecJYFILE3.SHOCOD ;
--        DATKBN := CRecJYFILE3.DATKBN ;
--        SNDCOD := CRecJYFILE3.SNDCOD ;
--        SIRCOD := CRecJYFILE3.SIRCOD ;
--        SNTCOD := CRecJYFILE3.SNTCOD ;
--
--    END LOOP;
--
--    IF cnt3 > 0 THEN
--        BEGIN
--            Insert Into BASTABL (
--                BAS_SHOCOD ,
--                BAS_STRDAY ,
--                BAS_TOKCOD ,
--                BAS_ARECOD ,
--                BAS_DATKBN ,
--                BAS_SNDCOD ,
--                BAS_SIRCOD ,
--                BAS_SNTCOD ,
--                BAS_DELFLG ,
--                BAS_ADDTAN ,
--                BAS_ADDDAY ,
--                BAS_ADDTIM ,
--                BAS_UPDTAN ,
--                BAS_UPDDAY ,
--                BAS_UPDTIM
--            )
--            Values (
--                SHOCOD     ,
--                '20010101' ,
--                TOKCOD     ,
--                ARECOD     ,
--                DATKBN     ,
--                SNDCOD     ,
--                SIRCOD     ,
--                SNTCOD     ,
--                '0'        ,
--                '999998'   ,
--                ADDDAY     ,
--                ADDTIM     ,
--                '999998'   ,
--                ADDDAY     ,
--                ADDTIM
--            ) ;
--        EXCEPTION
--            WHEN DUP_VAL_ON_INDEX THEN
--
--                NULL ;
--
--            WHEN OTHERS THEN
--
--                RAISE ;                                                             --  �G���[����
--
--        END ;
--
--    END IF ;
--
    COMMIT;
--
END ;
/
*/
--
Commit ;
--
--Quit ;
--
