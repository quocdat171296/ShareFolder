Truncate Table WCSTABL ;

Insert Into WCSTABL
Select
    '0000000' || WCS_WTRICD AS  WCS_WTRICD ,
    WCS_SIRCOD              AS  WCS_SIRCOD ,
    WCS_SHOCOD              AS  WCS_SHOCOD ,
    WCS_TRIKBN              AS  WCS_TRIKBN ,
    '0'                     AS  WCS_DELFLG ,
    '999998'                AS  WCS_ADDTAN ,
    WCS_UPDDAY              AS  WCS_ADDDAY ,
    WCS_UPDTIM              AS  WCS_ADDTIM ,
    '999998'                AS  WCS_UPDTAN ,
    WCS_UPDDAY              AS  WCS_UPDDAY ,
    WCS_UPDTIM              AS  WCS_UPDTIM
From
    (
        Select
            *
        From
            CHUBU.WCSTABL
    ) ;
--
Commit ;
--
/*
Quit ;
*/
--
