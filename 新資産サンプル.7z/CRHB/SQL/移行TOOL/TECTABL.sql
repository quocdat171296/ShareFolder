Truncate Table TECTABL ;

Insert Into TECTABL
Select
    TEC_TEIKEY  AS  TEC_TEIKEY ,
    TEC_TEINUM  AS  TEC_TEINUM ,
    TEC_TEISTR  AS  TEC_TEISTR ,
    '0'         AS  TEC_DELFLG ,
    '999998'    AS  TEC_ADDTAN ,
    TEC_UPDDAY  AS  TEC_ADDDAY ,
    TEC_UPDTIM  AS  TEC_ADDTIM ,
    '999998'    AS  TEC_UPDTAN ,
    TEC_UPDDAY  AS  TEC_UPDDAY ,
    TEC_UPDTIM  AS  TEC_UPDTIM
From
    (
        Select
            *
        From
            CHUBU.TECTABL
    ) ;
--
Commit ;
--
/*
Quit ;
*/
--
