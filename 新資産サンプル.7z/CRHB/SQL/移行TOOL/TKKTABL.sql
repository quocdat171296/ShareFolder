Truncate Table TKKTABL ;
--
/*
Quit ;
*/
--
