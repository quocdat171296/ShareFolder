Truncate Table TYSTABL;

Insert Into TYSTABL
Select
    TYS_YNENDO                                                              AS  TYS_YNENDO ,
    TYS_TANCOD                                                              AS  TYS_TANCOD ,
    '0' || SUBSTRB(TYS_TOKCOD, 1, 4) || '0' || SUBSTRB(TYS_TOKCOD, 5, 3)    AS  TYS_TOKCOD ,
    '0'  || TYS_TKSCOD                                                      AS  TYS_TKSCOD ,
    '00' || TYS_TKBCOD                                                      AS  TYS_TKBCOD ,
    '0'  || TYS_SSWCOD                                                      AS  TYS_SSWCOD ,
    TYS_YSN004                                                              AS  TYS_YSN004 ,
    TYS_YSN005                                                              AS  TYS_YSN005 ,
    TYS_YSN006                                                              AS  TYS_YSN006 ,
    TYS_YSN007                                                              AS  TYS_YSN007 ,
    TYS_YSN008                                                              AS  TYS_YSN008 ,
    TYS_YSN009                                                              AS  TYS_YSN009 ,
    TYS_YSN010                                                              AS  TYS_YSN010 ,
    TYS_YSN011                                                              AS  TYS_YSN011 ,
    TYS_YSN012                                                              AS  TYS_YSN012 ,
    TYS_YSN001                                                              AS  TYS_YSN001 ,
    TYS_YSN002                                                              AS  TYS_YSN002 ,
    TYS_YSN003                                                              AS  TYS_YSN003 ,
    '0'                                                                     AS  TYS_DELFLG ,
    '999998'                                                                AS  TYS_ADDTAN ,
    TYS_ADDDAY                                                              AS  TYS_ADDDAY ,
    TYS_ADDTIM                                                              AS  TYS_ADDTIM ,
    '999998'                                                                AS  TYS_UPDTAN ,
    TYS_UPDDAY                                                              AS  TYS_UPDDAY ,
    TYS_UPDTIM                                                              AS  TYS_UPDTIM
From
    (
        Select
            *
        From
            CHUBU.TYSTABL
    ) ;
--
Update
	TYSTABL
Set
	TYS_TKSCOD = '99999'
Where
	TYS_TKSCOD = '09999';
--
Commit ;
--
/*
Quit ;
*/
--
