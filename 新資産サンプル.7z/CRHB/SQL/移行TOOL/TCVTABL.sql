Truncate Table TCVTABL ;

Insert Into TCVTABL
Select
    '0' || TCV_TDNPTN || TKJ_SSWCOD                                         AS  TCV_TDNPTN ,
    TCV_STIKCD                                                              AS  TCV_STIKCD ,
    TCV_STIECO                                                              AS  TCV_STIECO ,
    TCV_STIBMN                                                              AS  TCV_STIBMN ,
    '0' || SUBSTRB(TCV_TOKCOD, 1, 4) || '0' || SUBSTRB(TCV_TOKCOD, 5, 2)    AS  TCV_TOKCOD ,
    '0'        || TCV_TKSCOD                                                AS  TCV_TKSCOD ,
    '00'       || TCV_TKBCOD                                                AS  TCV_TKBCOD ,
    '0' || SUBSTRB(TCV_ASNSID, 1, 4) || '0' || SUBSTRB(TCV_ASNSID, 5, 2)    AS  TCV_ASNSID ,
    TCV_FILKBN                                                              AS  TCV_FILKBN ,
    '0'                                                                     AS  TCV_DELFLG ,
    '999998'                                                                AS  TCV_ADDTAN ,
    TCV_UPDDAY                                                              AS  TCV_ADDDAY ,
    TCV_UPDTIM                                                              AS  TCV_ADDTIM ,
    '999998'                                                                AS  TCV_UPDTAN ,
    TCV_UPDDAY                                                              AS  TCV_UPDDAY ,
    TCV_UPDTIM                                                              AS  TCV_UPDTIM
From
    (
        Select
            *
        From
            CHUBU.TCVTABL
    )
    Inner Join (
        Select
            TKJ_TDNPTN ,
            Trim(To_Char(To_Number(Min(TKJ_SSWCOD)) -1, '000')) AS  TKJ_SSWCOD
        From
            CHUBU.TKJTABL
        Where
            TKJ_SSWCOD <> '6'
        Group By
            TKJ_TDNPTN
    )
    On (
        TCV_TDNPTN = TKJ_TDNPTN
    )
Order By
    TCV_TDNPTN ;
--
Commit ;
--
/*
Quit ;
*/
--
