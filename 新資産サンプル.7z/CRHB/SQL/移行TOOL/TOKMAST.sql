Truncate Table TOKMAST ;

Insert Into TOKMAST
Select
    '0' || SUBSTRB(TOK_TOKCOD, 1, 4) || '0' || SUBSTRB(TOK_TOKCOD, 5, 3)    AS  TOK_TOKCOD ,
    Trim(TOK_TOKKNA)                                                        AS  TOK_TOKKNA ,
    Trim(TOK_TOKNAM)                                                        AS  TOK_TOKNAM ,
    Trim(TOK_TOKRYK)                                                        AS  TOK_TOKRYK ,
    TOK_ZIPCOD                                                              AS  TOK_ZIPCOD ,
    Trim(TOK_ADRES1)                                                        AS  TOK_ADRES1 ,
    Trim(TOK_ADRES2)                                                        AS  TOK_ADRES2 ,
    Trim(TOK_TELNUM)                                                        AS  TOK_TELNUM ,
    Trim(TOK_FAXNUM)                                                        AS  TOK_FAXNUM ,
    Trim(TOK_MILADR)                                                        AS  TOK_MILADR ,
    '000000000' || TOK_STIKCD                                               AS  TOK_STIKCD ,
    Trim(TOK_STIKNM)                                                        AS  TOK_STIKNM ,
    '0' || TOK_TDNPTN || '000'                                              AS  TOK_TDNPTN ,
    TOK_SIMDAY                                                              AS  TOK_SIMDAY ,
    TOK_KAICLE                                                              AS  TOK_KAICLE ,
    TOK_KAYDAY                                                              AS  TOK_KAYDAY ,
    TOK_NYUHOU                                                              AS  TOK_NYUHOU ,
    TOK_SYZKBN                                                              AS  TOK_SYZKBN ,
    TOK_HASKBN                                                              AS  TOK_HASKBN ,
    CASE SYS_URIHAS
		WHEN '1' THEN '0'
		WHEN '2' THEN '1'
		WHEN '3' THEN '2'
 		ELSE SYS_URIHAS
	END                                                                     AS  TOK_URIHAS ,
    TOK_GTIKBN                                                              AS  TOK_GTIKBN ,
    TOK_HBSKBN                                                              AS  TOK_HBSKBN ,
    Trim(TOK_TOKBKO)                                                        AS  TOK_TOKBKO ,
    '0'                                                                     AS  TOK_JRYKBN ,        /* Todo �b��� '0' ���Z�b�g */
    '0'                                                                     AS  TOK_SHRKBN ,        /* Todo �b��� '0' ���Z�b�g */
    '0' || SUBSTRB(TOK_SEICOD, 1, 4) || '0' || SUBSTRB(TOK_SEICOD, 5, 3)    AS  TOK_SEICOD ,
    TOK_KYCYMD                                                              AS  TOK_KYCYMD ,
    TOK_KYCTYP                                                              AS  TOK_KYCTYP ,
    TOK_KYCSTR                                                              AS  TOK_KYCSTR ,
    TOK_KYCEND                                                              AS  TOK_KYCEND ,
    TOK_KYCKSN                                                              AS  TOK_KYCKSN ,
    CASE WHEN TOK_ASNEDI != '0' THEN CASE TOK_ASNEDI WHEN '2' THEN '3' ELSE TOK_ASNEDI END
         WHEN TOK_ASNBMS != '0' THEN CASE TOK_ASNBMS WHEN '2' THEN '3' ELSE TOK_ASNBMS END
         WHEN TOK_ASNEOS != '0' THEN TOK_ASNEOS
         ELSE '0'
    END                                                                     AS  TOK_ASNBMS ,
    '0'                                                                     AS  TOK_ASNEOS ,
    '0'                                                                     AS  TOK_ASNCHF ,        /* Todo �b��� '0' ���Z�b�g */
    '0'                                                                     AS  TOK_ASNMCT ,        /* Todo �b��� '0' ���Z�b�g */
	TOK_ASNFAX                                                              AS  TOK_ASNFAX ,
    CASE WHEN TOK_ASNEDI != '0' THEN '1'
         WHEN TOK_ASNBMS != '0' THEN '1'
         WHEN TOK_ASNEOS != '0' THEN '1'
         ELSE '0'
    END                                                                     AS  TOK_ASNFMT ,
    TOK_ASNFDK                                                              AS  TOK_ASNFDK ,
    TOK_ASNFDH                                                              AS  TOK_ASNFDH ,
    TOK_ASNZRO                                                              AS  TOK_ASNZRO ,
    '000'     || TOK_ASNSTN                                                 AS  TOK_ASNSTN ,
    '0000000' || TOK_VTRCG1                                                 AS  TOK_VTRCG1 ,
    '000'     || TOK_VSTCG1                                                 AS  TOK_VSTCG1 ,
    '0000000' || TOK_VTRCG2                                                 AS  TOK_VTRCG2 ,
    '000'     || TOK_VSTCG2                                                 AS  TOK_VSTCG2 ,
    TOK_ASNDFG                                                              AS  TOK_ASNDFG ,
    '0'                                                                     AS  TOK_ASNDTR ,
    '0'                                                                     AS  TOK_NOUKBN ,        /* Todo �b��� '0' ���Z�b�g */
    '0'                                                                     AS  TOK_UKJKBN ,        /* Todo �b��� '0' ���Z�b�g */
    TOK_RECKBN                                                              AS  TOK_DELFLG ,
    '999998'                                                                AS  TOK_ADDTAN ,
    TOK_ADDDAY                                                              AS  TOK_ADDDAY ,
    TOK_ADDTIM                                                              AS  TOK_ADDTIM ,
    '999998'                                                                AS  TOK_UPDTAN ,
    TOK_UPDDAY                                                              AS  TOK_UPDDAY ,
    TOK_UPDTIM                                                              AS  TOK_UPDTIM
From
    (
        Select
            *
        From
            CHUBU.TOKMAST
    )
    Inner Join (
        Select
            SYS_KAICOD,
            SYS_URIHAS
        From
            CHUBU.SYSMAST
    )
    On (
        '000000' = SYS_KAICOD
    ) ;
--
-- �����t�[�Y�H��̂�JCA
Update
	TOKMAST
SET
    TOK_ASNEOS = TOK_ASNBMS ,
    TOK_ASNBMS = '0'        ,
    TOK_ASNFMT = '2'
Where
	TOK_TOKCOD In ('00003000','00003010','00016000');
--
-- VEDI�q��(�o�׎w������敪���ݒ�)
Update TOKMAST
SET
       TOK_ASNDTR = '1'
WHERE  TOK_TOKCOD IN (SELECT '0' || SUBSTR(TOK_TOKCOD,1,4)  || '0' || SUBSTR(TOK_TOKCOD,5,2) FROM CHUBU.TOKMAST WHERE TOK_ASNEDI <> '0');
--
-- �É�TC�Ή�
UPDATE TOKMAST SET TOK_ASNFAX = '4' WHERE TOK_TOKCOD IN ('00001001','00003001');
--
Commit ;
--
/*
Quit ;
*/
--
