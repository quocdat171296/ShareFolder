Truncate Table SSHMAST ;

Insert Into SSHMAST
Select
    SSH_SIRCOD  AS  SSH_SIRCOD ,
    SSH_SHOCOD  AS  SSH_SHOCOD ,
    SSH_SITNKB  AS  SSH_SITNKB ,
    SSH_SITNSU  AS  SSH_SITNSU ,
    SSH_SYZKBN  AS  SSH_SYZKBN ,
    SSH_TANNAM  AS  SSH_TANNAM ,
    SSH_TABNAM  AS  SSH_TABNAM ,
    SSH_SYHKBN  AS  SSH_SYHKBN ,
    SSH_SYHKGN  AS  SSH_SYHKGN ,
    SSH_STNKBN  AS  SSH_STNKBN ,
    SSH_HARTIM  AS  SSH_HARTIM ,
    SSH_KWSRET  AS  SSH_KWSRET ,
    SSH_KWSDAY  AS  SSH_KWSDAY ,
    SSH_RECKBN  AS  SSH_DELFLG ,
    '999998'    AS  SSH_ADDTAN ,
    SSH_ADDDAY  AS  SSH_ADDDAY ,
    SSH_ADDTIM  AS  SSH_ADDTIM ,
    '999998'    AS  SSH_UPDTAN ,
    SSH_UPDDAY  AS  SSH_UPDDAY ,
    SSH_UPDTIM  AS  SSH_UPDTIM
From
    (
        Select
            *
        From
            CHUBU.SSHMAST
    ) ;
--
Commit ;
--
/*
Quit ;
*/
--
