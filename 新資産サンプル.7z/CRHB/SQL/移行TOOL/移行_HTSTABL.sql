Truncate Table HTSTABL ;
--
DECLARE
    WRK_SHOCOD        HTSTABL.HTS_SHOCOD%TYPE ;
    WRK_SYKKBN        HTSTABL.HTS_SYKKBN%TYPE ;
    WRK_NOUKBN        HTSTABL.HTS_NOUKBN%TYPE ;
    WRK_NOUCD1        HTSTABL.HTS_NOUCD1%TYPE ;
    WRK_NOUCD2        HTSTABL.HTS_NOUCD2%TYPE ;
    WRK_BMNCOD        HTSTABL.HTS_BMNCOD%TYPE ;
    WRK_SSWCOD        HTSTABL.HTS_SSWCOD%TYPE ;
    WRK_STRDAY        HTSTABL.HTS_STRDAY%TYPE ;
    WRK_ENDDAY        HTSTABL.HTS_ENDDAY%TYPE ;
    WRK_KKKNUM        HTSTABL.HTS_KKKNUM%TYPE ;
    WRK_MINSUU        HTSTABL.HTS_MINSUU%TYPE ;
    WRK_MAXSUU        HTSTABL.HTS_MAXSUU%TYPE ;
    WRK_HANTNK        HTSTABL.HTS_HANTNK%TYPE ;
    WRK_TENTNK        HTSTABL.HTS_TENTNK%TYPE ;
    WRK_DELFLG        HTSTABL.HTS_DELFLG%TYPE ;
    WRK_ADDTAN        HTSTABL.HTS_ADDTAN%TYPE ;
    WRK_ADDDAY        HTSTABL.HTS_ADDDAY%TYPE ;
    WRK_ADDTIM        HTSTABL.HTS_ADDTIM%TYPE ;
    WRK_UPDTAN        HTSTABL.HTS_UPDTAN%TYPE ;
    WRK_UPDDAY        HTSTABL.HTS_UPDDAY%TYPE ;
    WRK_UPDTIM        HTSTABL.HTS_UPDTIM%TYPE ;
--
    WRK_BSHCNT        NUMBER ;
--
    TOKCOD      CHUBU.TSHMAST.TSH_TOKCOD%TYPE ;
    SHOCOD      CHUBU.TSHMAST.TSH_SHOCOD%TYPE ;
--
    ARECOD      CHUBU.BAGTABL.BAG_ARECOD%TYPE ;
--
    TLTFLG      CHAR(1)                       ;
--
    TTKFLG      CHAR(1)                       ;
--
    CURSOR CReadTSH IS
        Select
            TSH_SHOCOD  AS  SHOCOD ,
            TSH_TOKCOD  AS  TOKCOD ,
            '20000101'  AS  SETYMD ,
            TSH_GENTNK  AS  GNBTNK ,
            TSH_HANTNK  AS  HNBTNK ,
            TSH_RECKBN  AS  RECKBN  
        From
            CHUBU.TSHMAST
        Where
            TSH_TOKCOD  IS NOT NULL
        UNION ALL 
        Select
            TTK_SHOCOD AS  SHOCOD ,
            TTK_TOKCOD AS  TOKCOD ,
            TTK_SETYMD AS  SETYMD ,
            TTK_GENTNN AS  GNBTNK ,
            TTK_HANTNN AS  HNBTNK ,
            '0'        AS  RECKBN
        From
            CHUBU.TTKTABL
        Where
            TTK_RENKBN   = '0'
        Order by
            TOKCOD , SHOCOD , SETYMD  DESC ;
--
    CURSOR CReadTLT IS
        Select
            TLT_TOKCOD              AS  TOKCOD ,
            TLT_SHOCOD              AS  SHOCOD ,
            TLT_SETYMD              AS  SETYMD ,
            TLT_LOTSU1              AS  MINSUU ,
            DECODE(TLT_LOTSU2,0,9999999.999, TLT_LOTSU2 - 0.001)  AS  MAXSUU ,
            TLT_HNBTK1              AS  HNBTNK
        From
            CHUBU.TLTTABL
        Where
            TLT_RECKBN   = '0'
        And
            TLT_LOTSU1   > 0
        UNION
        Select
            TLT_TOKCOD              AS  TOKCOD ,
            TLT_SHOCOD              AS  SHOCOD ,
            TLT_SETYMD              AS  SETYMD ,
            TLT_LOTSU2              AS  MINSUU ,
            DECODE(TLT_LOTSU3,0,9999999.999, TLT_LOTSU3 - 0.001)  AS  MAXSUU ,
            TLT_HNBTK2              AS  HNBTNK
        From
            CHUBU.TLTTABL
        Where
            TLT_RECKBN   = '0'
        And
            TLT_LOTSU2   > 0
        UNION
        Select
            TLT_TOKCOD              AS  TOKCOD ,
            TLT_SHOCOD              AS  SHOCOD ,
            TLT_SETYMD              AS  SETYMD ,
            TLT_LOTSU3              AS  MINSUU ,
            DECODE(TLT_LOTSU4,0,9999999.999, TLT_LOTSU4 - 0.001)  AS  MAXSUU ,
            TLT_HNBTK3              AS  HNBTNK
        From
            CHUBU.TLTTABL
        Where
            TLT_RECKBN   = '0'
        And
            TLT_LOTSU3   > 0
        UNION
        Select
            TLT_TOKCOD              AS  TOKCOD ,
            TLT_SHOCOD              AS  SHOCOD ,
            TLT_SETYMD              AS  SETYMD ,
            TLT_LOTSU4              AS  MINSUU ,
            DECODE(TLT_LOTSU5,0,9999999.999, TLT_LOTSU5 - 0.001)  AS  MAXSUU ,
            TLT_HNBTK4              AS  HNBTNK
        From
            CHUBU.TLTTABL
        Where
            TLT_RECKBN   = '0'
        And
            TLT_LOTSU4   > 0
        UNION
        Select
            TLT_TOKCOD              AS  TOKCOD ,
            TLT_SHOCOD              AS  SHOCOD ,
            TLT_SETYMD              AS  SETYMD ,
            TLT_LOTSU5              AS  MINSUU ,
            DECODE(TLT_LOTSU6,0,9999999.999, TLT_LOTSU6 - 0.001)  AS  MAXSUU ,
            TLT_HNBTK5              AS  HNBTNK
        From
            CHUBU.TLTTABL
        Where
            TLT_RECKBN   = '0'
        And
            TLT_LOTSU5   > 0
        UNION
        Select
            TLT_TOKCOD              AS  TOKCOD ,
            TLT_SHOCOD              AS  SHOCOD ,
            TLT_SETYMD              AS  SETYMD ,
            TLT_LOTSU6              AS  MINSUU ,
            9999999.999             AS  MAXSUU ,
            TLT_HNBTK6              AS  HNBTNK
        From
            CHUBU.TLTTABL
        Where
            TLT_RECKBN   = '0'
        And
            TLT_LOTSU6   > 0
        Order By
            SHOCOD       ,
            TOKCOD       ,
            SETYMD  DESC ,
            MINSUU       ;
--
BEGIN
-----------------------------------------------------------
--   ���ʒP��
-----------------------------------------------------------
--
    WRK_SHOCOD := '0000000000000'              ;
    WRK_NOUCD1 := '00000000'                   ;
    WRK_NOUKBN := '0'                          ;
    WRK_BMNCOD := '0000'                       ;
    WRK_SSWCOD := '00'                         ;
    WRK_KKKNUM := '     '                      ;
    WRK_DELFLG := '0'                          ;
    WRK_ADDTAN := '999998'                     ;
    WRK_ADDDAY := TO_CHAR(SYSDATE, 'YYYYMMDD') ;
    WRK_ADDTIM := TO_CHAR(SYSDATE, 'HH24MISS') ;
    WRK_UPDTAN := '999998'                     ;
    WRK_UPDDAY := TO_CHAR(SYSDATE, 'YYYYMMDD') ;
    WRK_UPDTIM := TO_CHAR(SYSDATE, 'HH24MISS') ;
--
    FOR CRecTSH IN CReadTSH LOOP
        IF '0' || SUBSTR(CRecTSH.TOKCOD,1,4) || '0' || SUBSTR(CRecTSH.TOKCOD,5,2) || CRecTSH.SHOCOD  <> WRK_NOUCD1 || WRK_SHOCOD THEN
            WRK_ENDDAY  := '21001231' ;
        ELSE
            IF WRK_STRDAY <> CRecTSH.SETYMD THEN
                WRK_ENDDAY  := TO_CHAR(TO_DATE(WRK_STRDAY, 'YYYYMMDD') - 1, 'YYYYMMDD') ;
            END IF;
        END IF ;
--
        TOKCOD  := CRecTSH.TOKCOD     ;
        SHOCOD  := CRecTSH.SHOCOD     ;
--
        WRK_SHOCOD  := SHOCOD         ;
        WRK_SYKKBN  := '9'            ;
        WRK_NOUKBN  := '0'            ;
        WRK_NOUCD1  := '0' || SUBSTRB(TOKCOD, 1, 4) || '0' || SUBSTRB(TOKCOD, 5, 2) ;
        WRK_NOUCD2  := '00000'        ;
        WRK_STRDAY  := CRecTSH.SETYMD ;
        WRK_MINSUU  := 0              ;
        WRK_MAXSUU  := 9999999.999    ;
        WRK_HANTNK  := 0              ;
        WRK_HANTNK  := CRecTSH.GNBTNK ;
        WRK_TENTNK  := CRecTSH.HNBTNK ;


        WRK_DELFLG  := CRecTSH.RECKBN ;
--
       Insert Into HTSTABL (
           HTS_SHOCOD ,
           HTS_SYKKBN ,
           HTS_NOUKBN ,
           HTS_NOUCD1 ,
           HTS_NOUCD2 ,
           HTS_BMNCOD ,
           HTS_SSWCOD ,
           HTS_STRDAY ,
           HTS_ENDDAY ,
           HTS_KKKNUM ,
           HTS_MINSUU ,
           HTS_MAXSUU ,
           HTS_HANTNK ,
           HTS_TENTNK ,
           HTS_HNBTNK ,
           HTS_TNBTNK ,
           HTS_DELFLG ,
           HTS_ADDTAN ,
           HTS_ADDDAY ,
           HTS_ADDTIM ,
           HTS_UPDTAN ,
           HTS_UPDDAY ,
           HTS_UPDTIM
       )
       Values (
           WRK_SHOCOD ,
           WRK_SYKKBN ,
           WRK_NOUKBN ,
           WRK_NOUCD1 ,
           WRK_NOUCD2 ,
           WRK_BMNCOD ,
           WRK_SSWCOD ,
           WRK_STRDAY ,
           WRK_ENDDAY ,
           WRK_KKKNUM ,
           WRK_MINSUU ,
           WRK_MAXSUU ,
           WRK_HANTNK ,
           WRK_TENTNK ,
           0          ,
           0          ,
           WRK_DELFLG ,
           WRK_ADDTAN ,
           WRK_ADDDAY ,
           WRK_ADDTIM ,
           WRK_UPDTAN ,
           WRK_UPDDAY ,
           WRK_UPDTIM
       ) ;
    END LOOP ;
--
-----------------------------------------------------------
--   ���b�g�P��
-----------------------------------------------------------
--
    WRK_SHOCOD := '0000000000000'              ;
    WRK_NOUCD1 := '00000000'                   ;
    WRK_NOUCD2 := '00000'                      ;
    WRK_STRDAY := '00000000'                   ;
    WRK_BMNCOD := '0000'                       ;
    WRK_SSWCOD := '00'                         ;
    WRK_KKKNUM := '     '                      ;
    WRK_DELFLG := '0'                          ;
    WRK_ADDTAN := '999998'                     ;
    WRK_ADDDAY := TO_CHAR(SYSDATE, 'YYYYMMDD') ;
    WRK_ADDTIM := TO_CHAR(SYSDATE, 'HH24MISS') ;
    WRK_UPDTAN := '999998'                     ;
    WRK_UPDDAY := TO_CHAR(SYSDATE, 'YYYYMMDD') ;
    WRK_UPDTIM := TO_CHAR(SYSDATE, 'HH24MISS') ;
--
    FOR CRecTLT IN CReadTLT LOOP
        IF CRecTLT.SHOCOD || '0' || SUBSTR(CRecTLT.TOKCOD,1,4) ||  '0' || SUBSTR(CRecTLT.TOKCOD,5,2) <> WRK_SHOCOD || WRK_NOUCD1 THEN
            WRK_ENDDAY  := '21001231' ;
        ELSE
            IF CRecTLT.SETYMD <> WRK_STRDAY THEN
                WRK_ENDDAY  := TO_CHAR(TO_DATE(WRK_STRDAY, 'YYYYMMDD') - 1, 'YYYYMMDD') ;
            END IF ;
        END IF ;
--
        WRK_SHOCOD  := CRecTLT.SHOCOD ;
        WRK_SYKKBN  := '9'            ;
        WRK_NOUKBN  := '0'            ;
        WRK_NOUCD1  := '0' || SUBSTR(CRecTLT.TOKCOD,1,4) ||  '0' || SUBSTR(CRecTLT.TOKCOD,5,2);
        WRK_NOUCD2  := '00000'        ;
        WRK_STRDAY  := CRecTLT.SETYMD ;
        WRK_MINSUU  := CRecTLT.MINSUU ;
        WRK_MAXSUU  := CRecTLT.MAXSUU ;
        WRK_HANTNK  := CRecTLT.HNBTNK ;
        WRK_TENTNK  := 0              ;
--
       Insert Into HTSTABL (
           HTS_SHOCOD ,
           HTS_SYKKBN ,
           HTS_NOUKBN ,
           HTS_NOUCD1 ,
           HTS_NOUCD2 ,
           HTS_BMNCOD ,
           HTS_SSWCOD ,
           HTS_STRDAY ,
           HTS_ENDDAY ,
           HTS_KKKNUM ,
           HTS_MINSUU ,
           HTS_MAXSUU ,
           HTS_HANTNK ,
           HTS_TENTNK ,
           HTS_HNBTNK ,
           HTS_TNBTNK ,
           HTS_DELFLG ,
           HTS_ADDTAN ,
           HTS_ADDDAY ,
           HTS_ADDTIM ,
           HTS_UPDTAN ,
           HTS_UPDDAY ,
           HTS_UPDTIM
       )
       Values (
           WRK_SHOCOD ,
           WRK_SYKKBN ,
           WRK_NOUKBN ,
           WRK_NOUCD1 ,
           WRK_NOUCD2 ,
           WRK_BMNCOD ,
           WRK_SSWCOD ,
           WRK_STRDAY ,
           WRK_ENDDAY ,
           WRK_KKKNUM ,
           WRK_MINSUU ,
           WRK_MAXSUU ,
           WRK_HANTNK ,
           WRK_TENTNK ,
           0          ,
           0          ,
           WRK_DELFLG ,
           WRK_ADDTAN ,
           WRK_ADDDAY ,
           WRK_ADDTIM ,
           WRK_UPDTAN ,
           WRK_UPDDAY ,
           WRK_UPDTIM
       ) ;
    END LOOP ;
END ;
/
--
Commit ;
--
--Rollback ;
--
/*
Quit ;
*/
--
