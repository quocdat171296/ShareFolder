Truncate Table TTCTABL;

Insert Into TTCTABL
Select
    '0' || TTC_ARECOD                                                              AS  TTC_ARECOD ,
    '0000000' || TTC_TRICOD                                                 AS  TTC_TRICOD ,
    '0000000' || TTC_TRISET                                                 AS  TTC_TRISET ,
    '0'                                                                     AS  TTC_DELFLG ,
    '999998'                                                                AS  TTC_ADDTAN ,
    TTC_UPDDAY                                                              AS  TTC_ADDDAY ,
    TTC_UPDTIM                                                              AS  TTC_ADDTIM ,
    '999998'                                                                AS  TTC_UPDTAN ,
    TTC_UPDDAY                                                              AS  TTC_UPDDAY ,
    TTC_UPDTIM                                                              AS  TTC_UPDTIM
From
    (
        Select
            *
        From
            CHUBU.TTCTABL
    ) ;
--
Commit ;
--
/*
Quit ;
*/
--
