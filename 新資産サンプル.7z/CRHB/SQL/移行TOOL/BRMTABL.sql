Truncate Table BRMTABL ;

Insert Into BRMTABL
Select
    '00' || BRM_BRBCOD ,
    '00' || BRM_BRMCOD ,
    BRM_BRMNAM ,
    '0'        ,
    '999998'   ,
    BRM_UPDDAY ,
    BRM_UPDTIM ,
    '999998'   ,
    BRM_UPDDAY ,
    BRM_UPDTIM 
From
    (
        Select
            *
        From
            CHUBU.BRMTABL
    );
--
Commit ;
--
/*
Quit ;
*/
--