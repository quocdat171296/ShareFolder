Truncate Table FATTABL ;
--
Insert Into FATTABL
Select
    '0' || SUBSTR(FAT_TOKCOD,1,4) || '0' || SUBSTR(FAT_TOKCOD,5,2)     As FAT_TOKCOD ,
    '0000000' || FAT_TRICOD                                            As FAT_TRICOD ,
    '000'     || FAT_STNCOD                                            As FAT_STNCOD ,
    '0'                                                                As FAT_DELFLG ,
    '999998'                                                           As FAT_ADDTAN ,
    FAT_UPDDAY                                                         As FAT_ADDDAY ,
    FAT_UPDTIM                                                         As FAT_ADDTIM ,
    '999998'                                                           As FAT_UPDTAN ,
    FAT_UPDDAY                                                         As FAT_UPDDAY ,
    FAT_UPDTIM                                                         AS FAT_UPDTIM 
From
	(
        Select
            *
        From
            CHUBU.FATTABL
	)
;
--
Commit ;
--
/*
Quit ;
*/
--