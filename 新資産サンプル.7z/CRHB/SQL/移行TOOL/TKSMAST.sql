Truncate Table TKSMAST;

Insert Into TKSMAST
Select
    '0' || SUBSTRB(TKS_TOKCOD, 1, 4) || '0' || SUBSTRB(TKS_TOKCOD, 5, 2)    AS  TKS_TOKCOD ,
    '0' || TKS_TKSCOD                                                       AS  TKS_TKSCOD ,
    Trim(TKS_TKSKNA)                                                        AS  TKS_TKSKNA ,
    Trim(TKS_TKSNAM)                                                        AS  TKS_TKSNAM ,
    Trim(TKS_TKSRYK)                                                        AS  TKS_TKSRYK ,
    TKS_ZIPCOD                                                              AS  TKS_ZIPCOD ,
    Trim(TKS_ADRES1)                                                        AS  TKS_ADRES1 ,
    Trim(TKS_ADRES2)                                                        AS  TKS_ADRES2 ,
    TKS_TELNUM                                                              AS  TKS_TELNUM ,
    TKS_FAXNUM                                                              AS  TKS_FAXNUM ,
    Trim(TKS_MILADR)                                                        AS  TKS_MILADR ,
    '999'                                                                   AS  TKS_STTCOD ,        /* Todo �b��� ���e�[�u����[999:���{��ǉ�]�������l�Ƃ��� */
    '00000000' || TKS_STIECO                                                AS  TKS_STIECO ,
    Trim(TKS_STIENM)                                                        AS  TKS_STIENM ,
    '0' || SUBSTRB(TKS_KAITOK, 1, 4) || '0' || SUBSTRB(TKS_KAITOK, 5, 2)    AS  TKS_KAITOK ,
    '0' || TKS_KAITKS                                                       AS  TKS_KAITKS ,
    '0' || SUBSTRB(TKS_KAISEG, 1, 4) || '0' || SUBSTRB(TKS_KAISEG, 5, 2)    AS  TKS_KAISEG ,
    TKS_TOKKBN                                                              AS  TKS_TOKKBN ,
    TKS_NOSSET                                                              AS  TKS_NOSSET ,
    '0' || SUBSTRB(TKS_HSOTOK, 1, 4) || '0' || SUBSTRB(TKS_HSOTOK, 5, 2)    AS  TKS_NHSCOD ,
    TKS_RECKBN                                                              AS  TKS_DELFLG ,
    '999998'                                                                AS  TKS_ADDTAN ,
    TKS_ADDDAY                                                              AS  TKS_ADDDAY ,
    TKS_ADDTIM                                                              AS  TKS_ADDTIM ,
    '999998'                                                                AS  TKS_UPDTAN ,
    TKS_UPDDAY                                                              AS  TKS_UPDDAY ,
    TKS_UPDTIM                                                              AS  TKS_UPDTIM
From
    (
        Select
            *
        From
            CHUBU.TKSMAST
            Where
                TKS_TOKCOD IS NOT NULL
    ) ;
--
/* ���Z�����͎x�X�R�[�h���u9999�v�ō쐬����Ă��邽��            */
/* �x�X�R�[�h���u09999�v�̃��R�[�h�̎x�X�R�[�h���u999990�v�֕ϊ� */
Update TKSMAST
Set TKS_TKSCOD = '99999'
Where
    TKS_TKSCOD = '09999';
--
Update TKSMAST
Set TKS_KAITKS = '99999'
Where
    TKS_KAITKS = '09999';
--
/* ************************************************************************************** */
/* ���������͂��܂��̏���                                                               */
/* �Z���P���s���{���e�[�u���́y�s���{�����z�Ƀq�b�g������y�s���{���R�[�h�z���Z�b�g���܂� */
/* ************************************************************************************** */
/*
DECLARE
    kennam KENTABL.KEN_KENNAM%TYPE ;
--
    CURSOR CReadKenTabl IS
        SELECT * FROM KENTABL ;
--
BEGIN
    FOR CRecKen IN CReadKenTabl LOOP
        DBMS_OUTPUT.PUT_LINE(CRecKen.KEN_KENCOD || ' ' || CRecKen.KEN_KENNAM) ;
--
        kennam := Trim(CRecKen.KEN_KENNAM) || '%' ;
--
        UPDATE
            TKSMAST
        SET
            TKS_STTCOD  = CRecKen.KEN_KENCOD
        WHERE
            TKS_ADRES1   LIKE kennam ;
    END LOOP ;
END ;
/
*/
--
Commit ;
--
/*
Quit ;
*/
--
