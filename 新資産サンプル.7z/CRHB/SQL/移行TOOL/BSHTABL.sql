Truncate Table BSHTABL ;

Insert Into BSHTABL
Select
    BSH_SNTCOD ,
    BSH_SHOCOD ,
    BSH_SIRCOD ,
    BSH_SYKDAY ,
    BSH_ENDDAY ,
    BSH_LSRDAY ,
    BSH_LSYDAY ,
    BSH_HYOTNK ,
    '00' ||BSH_BMNCOD As BSH_BMNCOD ,
    BSH_CHGKBN ,
    '00000000' ,
    BSH_RECKBN ,
    '999998'   ,
    BSH_ADDDAY ,
    BSH_ADDTIM ,
    '999998'   ,
    BSH_UPDDAY ,
    BSH_UPDTIM 
From
    (
        Select
            *
        From
            CHUBU.BSHTABL
    )
--
--Commit ;
--
/*
Quit ;
*/
--
