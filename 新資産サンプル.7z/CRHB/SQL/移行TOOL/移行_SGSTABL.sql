Truncate Table SGSTABL ;
--
DECLARE
    WRK_SHOCOD        SGSTABL.SGS_SHOCOD%TYPE ;
    WRK_SIRCOD        SGSTABL.SGS_SIRCOD%TYPE ;
    WRK_NOUKBN        SGSTABL.SGS_NOUKBN%TYPE ;
    WRK_NOUCD1        SGSTABL.SGS_NOUCD1%TYPE ;
    WRK_NOUCD2        SGSTABL.SGS_NOUCD2%TYPE ;
    WRK_BMNCOD        SGSTABL.SGS_BMNCOD%TYPE ;
    WRK_SSWCOD        SGSTABL.SGS_SSWCOD%TYPE ;
    WRK_STRDAY        SGSTABL.SGS_STRDAY%TYPE ;
    WRK_ENDDAY        SGSTABL.SGS_ENDDAY%TYPE ;
    WRK_KKKNUM        SGSTABL.SGS_KKKNUM%TYPE ;
    WRK_MINSUU        SGSTABL.SGS_MINSUU%TYPE ;
    WRK_MAXSUU        SGSTABL.SGS_MAXSUU%TYPE ;
    WRK_SIRTNK        SGSTABL.SGS_SIRTNK%TYPE ;
    WRK_SIBTNK        SGSTABL.SGS_SIBTNK%TYPE ;
    WRK_DELFLG        SGSTABL.SGS_DELFLG%TYPE ;
    WRK_ADDTAN        SGSTABL.SGS_ADDTAN%TYPE ;
    WRK_ADDDAY        SGSTABL.SGS_ADDDAY%TYPE ;
    WRK_ADDTIM        SGSTABL.SGS_ADDTIM%TYPE ;
    WRK_UPDTAN        SGSTABL.SGS_UPDTAN%TYPE ;
    WRK_UPDDAY        SGSTABL.SGS_UPDDAY%TYPE ;
    WRK_UPDTIM        SGSTABL.SGS_UPDTIM%TYPE ;
--
    SHOCOD      CHUBU.SSHMAST.SSH_SHOCOD%TYPE ;
    SIRCOD      CHUBU.SSHMAST.SSH_SIRCOD%TYPE ;
--
    TOKCOD      CHUBU.TSHMAST.TSH_TOKCOD%TYPE ;
--
    SNTCOD      CHUBU.BSHTABL.BSH_SNTCOD%TYPE ;
--
    TLTFLG      CHAR(1)                       ;
--
    STKFLG      CHAR(1)                       ;
--
    BSHFLG      CHAR(1)                       ;
--
    CURSOR CReadSSH IS
        Select
            SSH_SIRCOD  AS  SIRCOD ,
            SSH_SHOCOD  AS  SHOCOD ,
            '20000101'  AS  SETYMD ,
            SSH_SIRTNK  AS  SIRTNK ,
            SSH_RECKBN  AS  RECKBN
        From
            CHUBU.SSHMAST
        UNION ALL 
        Select
            STK_SIRCOD AS SIRCOD ,
            STK_SHOCOD AS SHOCOD ,
            STK_SETYMD AS SETYMD ,
            STK_SIRTNN AS SIRTNN ,
            '0'        AS RECKBN 
        From
            CHUBU.STKTABL
        Where
            STK_RENKBN   = '0'
        Order by
            SIRCOD , SHOCOD ,SETYMD  DESC ;
--
    CURSOR CReadTLT IS
	SELECT 
	   SSH_SIRCOD AS SIRCOD ,
           LOT.SHOCOD AS SHOCOD ,
           LOT.TOKCOD AS TOKCOD ,
	   LOT.SETYMD AS SETYMD ,
	   LOT.MINSUU AS MINSUU ,
	   LOT.MAXSUU AS MAXSUU ,
	   LOT.GNBTNK AS GNBTNK 
	FROM  (
        Select
            TLT_TOKCOD              AS  TOKCOD ,
            TLT_SHOCOD              AS  SHOCOD ,
            TLT_SETYMD              AS  SETYMD ,
            TLT_LOTSU1              AS  MINSUU ,
            DECODE(TLT_LOTSU2,0,9999999.999, TLT_LOTSU2 - 0.001)  AS  MAXSUU ,
            TLT_GNBTK1              AS  GNBTNK
        From
            CHUBU.TLTTABL
        Where
            TLT_RECKBN   = '0'
        And
            TLT_LOTSU1   > 0
        UNION
        Select
            TLT_TOKCOD              AS  TOKCOD ,
            TLT_SHOCOD              AS  SHOCOD ,
            TLT_SETYMD              AS  SETYMD ,
            TLT_LOTSU2              AS  MINSUU ,
            DECODE(TLT_LOTSU3,0,9999999.999, TLT_LOTSU3 - 0.001) AS  MAXSUU ,
            TLT_GNBTK2              AS  GNBTNK
        From
            CHUBU.TLTTABL
        Where
            TLT_RECKBN   = '0'
        And
            TLT_LOTSU2   > 0
        UNION
        Select
            TLT_TOKCOD              AS  TOKCOD ,
            TLT_SHOCOD              AS  SHOCOD ,
            TLT_SETYMD              AS  SETYMD ,
            TLT_LOTSU3              AS  MINSUU ,
            DECODE(TLT_LOTSU4,0,9999999.999, TLT_LOTSU4 - 0.001) AS  MAXSUU ,
            TLT_GNBTK3              AS  GNBTNK
        From
            CHUBU.TLTTABL
        Where
            TLT_RECKBN   = '0'
        And
            TLT_LOTSU3  > 0
        UNION
        Select
            TLT_TOKCOD              AS  TOKCOD ,
            TLT_SHOCOD              AS  SHOCOD ,
            TLT_SETYMD              AS  SETYMD ,
            TLT_LOTSU4              AS  MINSUU ,
            DECODE(TLT_LOTSU5,0,9999999.999, TLT_LOTSU5 - 0.001) AS  MAXSUU ,
            TLT_GNBTK4              AS  GNBTNK
        From
            CHUBU.TLTTABL
        Where
            TLT_RECKBN   = '0'
        And
            TLT_LOTSU4   > 0
        UNION
        Select
            TLT_TOKCOD              AS  TOKCOD ,
            TLT_SHOCOD              AS  SHOCOD ,
            TLT_SETYMD              AS  SETYMD ,
            TLT_LOTSU5              AS  MINSUU ,
            DECODE(TLT_LOTSU6,0,9999999.999, TLT_LOTSU6 - 0.001) AS  MAXSUU ,
            TLT_GNBTK5              AS  GNBTNK
        From
            CHUBU.TLTTABL
        Where
            TLT_RECKBN   = '0'
        And
            TLT_LOTSU5   > 0
        UNION
        Select
            TLT_TOKCOD              AS  TOKCOD ,
            TLT_SHOCOD              AS  SHOCOD ,
            TLT_SETYMD              AS  SETYMD ,
            TLT_LOTSU6              AS  MINSUU ,
            9999999.999             AS  MAXSUU ,
            TLT_GNBTK6              AS  GNBTNK
        From
            CHUBU.TLTTABL
        Where
            TLT_RECKBN   = '0'
        And
            TLT_LOTSU6   > 0 ) LOT
    INNER JOIN CHUBU.SSHMAST ON LOT.SHOCOD = SSH_SHOCOD AND SSH_RECKBN = '0'
    Order By
            SSH_SIRCOD ,
            SHOCOD ,
            TOKCOD ,
            SETYMD  DESC ,
            MINSUU ;
--
    CURSOR CReadSTK IS 
        Select
            STK_SIRCOD AS SIRCOD ,
            STK_SHOCOD AS SHOCOD ,
            STK_SETYMD AS SETYMD ,
            STK_SIRTNN AS SIRTNN
        From
            CHUBU.STKTABL
        Where
            STK_RENKBN   = '0'
        Order by
            STK_SIRCOD , STK_SHOCOD ,STK_SETYMD  DESC ;
--
--
BEGIN
-----------------------------------------------------------
--   ���ʒP��
-----------------------------------------------------------
--
    WRK_SIRCOD := '0000000'                    ;
    WRK_SHOCOD := '0000000000000'              ;
    WRK_STRDAY := '00000000'                   ;
    WRK_BMNCOD := '0000'                       ;
    WRK_SSWCOD := '00'                         ;
    WRK_KKKNUM := '     '                      ;
    WRK_ADDTAN := '999998'                     ;
    WRK_ADDDAY := TO_CHAR(SYSDATE, 'YYYYMMDD') ;
    WRK_ADDTIM := TO_CHAR(SYSDATE, 'HH24MISS') ;
    WRK_UPDTAN := '999998'                     ;
    WRK_UPDDAY := TO_CHAR(SYSDATE, 'YYYYMMDD') ;
    WRK_UPDTIM := TO_CHAR(SYSDATE, 'HH24MISS') ;
--
    FOR CRecSSH IN CReadSSH LOOP
        IF CRecSSH.SIRCOD || CRecSSH.SHOCOD  <> WRK_SIRCOD || WRK_SHOCOD THEN
            WRK_ENDDAY  := '21001231' ;
        ELSE
            IF WRK_STRDAY <> CRecSSH.SETYMD THEN
                WRK_ENDDAY  := TO_CHAR(TO_DATE(WRK_STRDAY, 'YYYYMMDD') - 1, 'YYYYMMDD') ;
            END IF;
        END IF ;
--
        SHOCOD  := CRecSSH.SHOCOD     ;
        SIRCOD  := CRecSSH.SIRCOD     ;
--
        WRK_SHOCOD  := SHOCOD         ;
        WRK_SIRCOD  := SIRCOD         ;
        WRK_NOUKBN  := '9'            ;
        WRK_NOUCD1  := '00000000'     ;
        WRK_NOUCD2  := '00000'        ;
        WRK_STRDAY  := CRecSSH.SETYMD ;
        WRK_MINSUU  := 0              ;
        WRK_MAXSUU  := 9999999.999    ;
        WRK_MINSUU  := 0              ;
        WRK_MAXSUU  := 9999999.999    ;
        WRK_SIRTNK  := CRecSSH.SIRTNK ;
        WRK_SIBTNK  := 0              ;
        WRK_DELFLG  := CRecSSH.RECKBN ;
--
        Insert Into SGSTABL (
            SGS_SHOCOD ,
            SGS_SIRCOD ,
            SGS_NOUKBN ,
            SGS_NOUCD1 ,
            SGS_NOUCD2 ,
            SGS_BMNCOD ,
            SGS_SSWCOD ,
            SGS_STRDAY ,
            SGS_ENDDAY ,
            SGS_KKKNUM ,
            SGS_MINSUU ,
            SGS_MAXSUU ,
            SGS_SIRTNK ,
            SGS_SIBTNK ,
            SGS_DELFLG ,
            SGS_ADDTAN ,
            SGS_ADDDAY ,
            SGS_ADDTIM ,
            SGS_UPDTAN ,
            SGS_UPDDAY ,
            SGS_UPDTIM
        )
        Values (
            WRK_SHOCOD ,
            WRK_SIRCOD ,
            WRK_NOUKBN ,
            WRK_NOUCD1 ,
            WRK_NOUCD2 ,
            WRK_BMNCOD ,
            WRK_SSWCOD ,
            WRK_STRDAY ,
            WRK_ENDDAY ,
            WRK_KKKNUM ,
            WRK_MINSUU ,
            WRK_MAXSUU ,
            WRK_SIRTNK ,
            WRK_SIBTNK ,
            WRK_DELFLG ,
            WRK_ADDTAN ,
            WRK_ADDDAY ,
            WRK_ADDTIM ,
            WRK_UPDTAN ,
            WRK_UPDDAY ,
            WRK_UPDTIM
        ) ;
    END LOOP;
--
-----------------------------------------------------------
--   ���b�g�P��
-----------------------------------------------------------
--
    WRK_SIRCOD := '0000000'                    ;
    WRK_SHOCOD := '0000000000000'              ;
    WRK_NOUCD1 := '00000000'                   ;
    WRK_NOUCD2 := '00000'                      ;
    WRK_STRDAY := '00000000'                   ;
    WRK_BMNCOD := '0000'                       ;
    WRK_SSWCOD := '00'                         ;
    WRK_KKKNUM := '     '                      ;
    WRK_DELFLG := '0'                          ;
    WRK_ADDTAN := '999998'                     ;
    WRK_ADDDAY := TO_CHAR(SYSDATE, 'YYYYMMDD') ;
    WRK_ADDTIM := TO_CHAR(SYSDATE, 'HH24MISS') ;
    WRK_UPDTAN := '999998'                     ;
    WRK_UPDDAY := TO_CHAR(SYSDATE, 'YYYYMMDD') ;
    WRK_UPDTIM := TO_CHAR(SYSDATE, 'HH24MISS') ;
--
    FOR CRecTLT IN CReadTLT LOOP
        IF CRecTLT.SIRCOD || CRecTLT.SHOCOD || '0' || SUBSTR(CRecTLT.TOKCOD,1,4) ||  '0' || SUBSTR(CRecTLT.TOKCOD,5,2) <> WRK_SIRCOD || WRK_SHOCOD || WRK_NOUCD1 THEN
            WRK_ENDDAY  := '21001231' ;
        ELSE
            IF CRecTLT.SETYMD <> WRK_STRDAY THEN
                WRK_ENDDAY  := TO_CHAR(TO_DATE(WRK_STRDAY, 'YYYYMMDD') - 1, 'YYYYMMDD') ;
            END IF ;
        END IF ;
--
        WRK_SIRCOD  := CRecTLT.SIRCOD ;
        WRK_SHOCOD  := CRecTLT.SHOCOD ;
        WRK_NOUKBN  := '0' ;
        WRK_NOUCD1  := '0' || SUBSTR(CRecTLT.TOKCOD,1,4) ||  '0' || SUBSTR(CRecTLT.TOKCOD,5,2);
        WRK_NOUCD2  := '00000' ;
        WRK_STRDAY  := CRecTLT.SETYMD ;
        WRK_MINSUU  := CRecTLT.MINSUU ;
        WRK_MAXSUU  := CRecTLT.MAXSUU ;
        WRK_SIRTNK  := CRecTLT.GNBTNK ;
        WRK_SIBTNK  := 0              ;
--
        Insert Into SGSTABL (
            SGS_SHOCOD ,
            SGS_SIRCOD ,
            SGS_NOUKBN ,
            SGS_NOUCD1 ,
            SGS_NOUCD2 ,
            SGS_BMNCOD ,
            SGS_SSWCOD ,
            SGS_STRDAY ,
            SGS_ENDDAY ,
            SGS_KKKNUM ,
            SGS_MINSUU ,
            SGS_MAXSUU ,
            SGS_SIRTNK ,
            SGS_SIBTNK ,
            SGS_DELFLG ,
            SGS_ADDTAN ,
            SGS_ADDDAY ,
            SGS_ADDTIM ,
            SGS_UPDTAN ,
            SGS_UPDDAY ,
            SGS_UPDTIM
        )
        Values (
            WRK_SHOCOD ,
            WRK_SIRCOD ,
            WRK_NOUKBN ,
            WRK_NOUCD1 ,
            WRK_NOUCD2 ,
            WRK_BMNCOD ,
            WRK_SSWCOD ,
            WRK_STRDAY ,
            WRK_ENDDAY ,
            WRK_KKKNUM ,
            WRK_MINSUU ,
            WRK_MAXSUU ,
            WRK_SIRTNK ,
            WRK_SIBTNK ,
            WRK_DELFLG ,
            WRK_ADDTAN ,
            WRK_ADDDAY ,
            WRK_ADDTIM ,
            WRK_UPDTAN ,
            WRK_UPDDAY ,
            WRK_UPDTIM
        ) ;
    END LOOP ;
--
END ;
/
--
Commit ;
--
/*
Quit ;
*/
--
