-- �V�K�e�[�u���̂��߈ڍs�����Ȃ� --
Truncate Table NHSTABL;
--
Insert
Into
	NHSTABL(
		NHS_NHSCOD ,
		NHS_TKSKNA ,
		NHS_TKSNAM ,
		NHS_TKSRYK ,
		NHS_ZIPCOD ,
		NHS_ADRES1 ,
		NHS_ADRES2 ,
		NHS_TELNUM ,
		NHS_FAXNUM ,
		NHS_DELFLG ,
		NHS_ADDTAN ,
		NHS_ADDDAY ,
		NHS_ADDTIM ,
		NHS_UPDTAN ,
		NHS_UPDDAY ,
		NHS_UPDTIM 
	)
Select
    '0' || SUBSTRB(TKS2.TKS_TOKCOD, 1, 4) || '0' || SUBSTRB(TKS2.TKS_TOKCOD, 5, 2) AS  NHS_NHSCOD ,
	Trim(TKS2.TKS_TKSKNA)                                                          AS  NHS_TKSKNA ,
	Trim(TKS2.TKS_TKSNAM)                                                          AS  NHS_TKSNAM ,
	Trim(TKS2.TKS_TKSRYK)                                                          AS  NHS_TKSRYK ,
	TKS2.TKS_ZIPCOD                                                                AS  NHS_ZIPCOD ,
	Trim(TKS2.TKS_ADRES1)                                                          AS  NHS_ADRES1 ,
	Trim(TKS2.TKS_ADRES2)                                                          AS  NHS_ADRES2 ,
	TKS2.TKS_TELNUM                                                                AS  NHS_TELNUM ,
	TKS2.TKS_FAXNUM                                                                AS  NHS_FAXNUM ,
	'0'                                                                            AS  NHS_DELFLG ,
    '999998'                                                                       AS  NHS_ADDTAN ,
    TKS2.TKS_ADDDAY                                                                AS  NHS_ADDDAY ,
    TKS2.TKS_ADDTIM                                                                AS  NHS_ADDTIM ,
    '999998'                                                                       AS  NHS_UPDTAN ,
    TKS2.TKS_UPDDAY                                                                AS  NHS_UPDDAY ,
    TKS2.TKS_UPDTIM                                                                AS  NHS_UPDTIM
From
	(
		Select
			TKS_HSOTOK ,
			TKS_HSOTKS
		From
			CHUBU.TKSMAST
		Where
			TKS_NOSSET = '2'
		Group By
			TKS_HSOTOK ,
			TKS_HSOTKS
	) TKS1
	Inner Join (
		Select
			*
		From
			CHUBU.TKSMAST
	) TKS2
	On (
		TKS1.TKS_HSOTOK = TKS2.TKS_TOKCOD
	And TKS1.TKS_HSOTKS = TKS2.TKS_TKSCOD
	);
--
Commit;
--
/*
Quit
*/
--
