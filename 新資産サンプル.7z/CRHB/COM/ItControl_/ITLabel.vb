Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.Drawing.Drawing2D
Imports System.Windows.Forms

Public Class ITLabel
    Inherits System.Windows.Forms.Label

#Region " �R���|�[�l���g �f�U�C�i�Ő������ꂽ�R�[�h "

    Public Sub New()
        MyBase.New()

        ' ���̌Ăяo���́A�R���|�[�l���g �f�U�C�i�ŕK�v�ł��B
        InitializeComponent()

        ' InitializeComponent() �Ăяo���̌�ɏ�������ǉ����܂��B

        MyBase.BackColor = Color.Transparent
        MyBase.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._BorderColor = Color.Black
        Me._BorderStyle = Windows.Forms.BorderStyle.None
        Me._BorderWidth = 1
    End Sub

    'Control �́A�R���|�[�l���g�ꗗ�Ɍ㏈�������s���邽�߂ɁAdispose �����s���܂��B
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    '�R���g���[�� �f�U�C�i�ŕK�v�ł��B
    Private components As System.ComponentModel.IContainer

    ' ���� : �ȉ��̃v���V�[�W���̓R���|�[�l���g �f�U�C�i�ŕK�v�ł��B
    ' �R���|�[�l���g �f�U�C�i���g���ĕύX�ł��܂��B�R�[�h �G�f�B�^��
    ' �g���ĕύX���Ȃ��ł��������B
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        components = New System.ComponentModel.Container()
    End Sub

#End Region

    Protected Overrides Sub OnPaintBackground(ByVal e As System.Windows.Forms.PaintEventArgs)
        MyBase.OnPaintBackground(e)
    End Sub

    Protected Overrides Sub OnPaint(ByVal e As System.Windows.Forms.PaintEventArgs)
        Dim ar As Rectangle = Me.ClientRectangle
        ar.X += ar.X + Convert.ToInt32(Math.Floor(Me.BorderWidth / 2))
        ar.Y += ar.Y + Convert.ToInt32(Math.Floor(Me.BorderWidth / 2))
        ar.Width -= (Me.BorderWidth + 1)
        ar.Height -= (Me.BorderWidth + 1)
        Dim lr As Rectangle = Me.ClientRectangle
        Dim canArc As Boolean = (ar.Width > 0 AndAlso ar.Height > 0)

        Using gp As New GraphicsPath
            gp.StartFigure()
            If Me.RadiusTopRight > 0 AndAlso canArc = True Then
                Dim w As Integer = If(Me.RadiusTopRight > ar.Width, ar.Width, Me.RadiusTopRight)
                Dim h As Integer = If(Me.RadiusTopRight > ar.Height, ar.Height, Me.RadiusTopRight)
                gp.AddArc(ar.Right - w, ar.Top, w, h, 270, 90)
            Else
                gp.AddLine(lr.Right - 1, lr.Top, lr.Right - 1, lr.Top)
            End If
            If Me.RadiusBottomRight > 0 AndAlso canArc = True Then
                Dim w As Integer = If(Me.RadiusBottomRight > ar.Width, ar.Width, Me.RadiusBottomRight)
                Dim h As Integer = If(Me.RadiusBottomRight > ar.Height, ar.Height, Me.RadiusBottomRight)
                gp.AddArc(ar.Right - w, ar.Bottom - h, w, h, 0, 90)
            Else
                gp.AddLine(lr.Right - 1, lr.Bottom - 1, lr.Right - 1, lr.Bottom - 1)
            End If
            If Me.RadiusBottomLeft > 0 AndAlso canArc = True Then
                Dim w As Integer = If(Me.RadiusBottomLeft > ar.Width, ar.Width, Me.RadiusBottomLeft)
                Dim h As Integer = If(Me.RadiusBottomLeft > ar.Height, ar.Height, Me.RadiusBottomLeft)
                gp.AddArc(ar.Left, ar.Bottom - h, w, h, 90, 90)
            Else
                gp.AddLine(lr.Left, lr.Bottom - 1, lr.Left, lr.Bottom - 1)
            End If

            If Me.RadiusTopLeft > 0 AndAlso canArc = True Then
                Dim w As Integer = If(Me.RadiusTopLeft > ar.Width, ar.Width, Me.RadiusTopLeft)
                Dim h As Integer = If(Me.RadiusTopLeft > ar.Height, ar.Height, Me.RadiusTopLeft)
                gp.AddArc(ar.Left, ar.Top, w, h, 180, 90)
            Else
                gp.AddLine(lr.Left, lr.Top, lr.Left, lr.Top)
            End If
            gp.CloseFigure()

            If canArc = True Then
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias
            End If
            ' �w�i��`��
            Using sb As New SolidBrush(Me.BackColor)
                e.Graphics.FillPath(sb, gp)
            End Using
            ' ���E����`��
            If Me.BorderStyle <> Windows.Forms.BorderStyle.None Then
                Using p As New Pen(Me.BorderColor, Me.BorderWidth)
                    'p.DashStyle = CType(Me.BorderStyle, DashStyle)
                    e.Graphics.DrawPath(p, gp)
                End Using
            End If
            If canArc = True Then
                e.Graphics.SmoothingMode = SmoothingMode.Default
            End If

        End Using

        MyBase.OnPaint(e)
    End Sub

    Private P_Index As Integer = 0
    Private P_Name As String = ""
    Private P_SubName As String = ""

    Public Shadows Property Name() As String
        Get
            Return P_Name
        End Get
        Set(ByVal Value As String)
            P_Name = Value
            Init()
        End Set
    End Property

    Public Function Index() As Integer
        Return P_Index
    End Function

    Public Function SubName() As String
        Return P_SubName
    End Function

    Public Sub Init()
        P_Index = 0
        P_SubName = P_Name

        If InStr(P_Name, "_") > 0 Then
            If IsNumeric(Mid$(P_Name, InStr(P_Name, "_") + 1)) Then
                P_Index = CInt(Mid$(P_Name, InStr(P_Name, "_") + 1))
                P_SubName = Mid$(P_Name, 1, InStr(P_Name, "_") - 1)
            End If
        End If
    End Sub

#Region " BackColor "

    Private _BackColor As Color
    Public Shadows Property BackColor() As Color
        Get
            If Me._BackColor <> Color.Empty Then
                Return Me._BackColor
            End If
            If Me.Parent IsNot Nothing Then
                Return Me.Parent.BackColor
            End If

            Return Control.DefaultBackColor
        End Get
        Set(ByVal value As Color)
            Me._BackColor = value
            Me.Invalidate()
        End Set
    End Property

    Public Overrides Sub ResetBackColor()
        Me.BackColor = Color.Empty
    End Sub

    Private Function ShouldSerializeBackColor() As Boolean
        Return Me._BackColor <> Color.Empty
    End Function

#End Region

    Private _BorderColor As Color
    <Category("�\��")> _
    <DefaultValue(GetType(Color), "Black")> _
    <Description("�R���g���[���̋��E���F���擾�܂��͐ݒ肵�܂��B")> _
    Public Property BorderColor() As Color
        Get
            Return Me._BorderColor
        End Get
        Set(ByVal value As Color)
            Me._BorderColor = value
            Me.Invalidate()
        End Set
    End Property

    Private _BorderStyle As BorderStyle
    <Category("�\��")> _
    <DefaultValue(GetType(BorderStyle), "None")> _
    <Description("�R���g���[���̋��E���X�^�C�����擾�܂��͐ݒ肵�܂��B")> _
    Public Shadows Property BorderStyle() As BorderStyle
        Get
            Return Me._BorderStyle
        End Get
        Set(ByVal value As BorderStyle)
            Me._BorderStyle = value
            Me.Invalidate()
        End Set
    End Property

    Private _BorderWidth As Integer
    <Category("�\��")> _
    <DefaultValue(1)> _
    <Description("�R���g���[���̋��E���̕����擾�܂��͐ݒ肵�܂��B")> _
    Public Property BorderWidth() As Integer
        Get
            Return Me._BorderWidth
        End Get
        Set(ByVal value As Integer)
            Me._BorderWidth = value
            Me.Invalidate()
        End Set
    End Property

    Private _RadiusTopLeft As Integer
    <Category("�\��")> _
    <DefaultValue(0)> _
    <Description("�R���g���[���̍���̊p�̔��a���擾�܂��͐ݒ肵�܂��B")> _
    Public Property RadiusTopLeft() As Integer
        Get
            Return Me._RadiusTopLeft
        End Get
        Set(ByVal value As Integer)
            Me._RadiusTopLeft = value
            Me.Invalidate()
        End Set
    End Property

    Private _RadiusTopRight As Integer
    <Category("�\��")> _
    <DefaultValue(0)> _
    <Description("�R���g���[���̉E��̊p�̔��a���擾�܂��͐ݒ肵�܂��B")> _
    Public Property RadiusTopRight() As Integer
        Get
            Return Me._RadiusTopRight
        End Get
        Set(ByVal value As Integer)
            Me._RadiusTopRight = value
            Me.Invalidate()
        End Set
    End Property

    Private _RadiusBottomLeft As Integer
    <Category("�\��")> _
    <DefaultValue(0)> _
    <Description("�R���g���[���̍����̊p�̔��a���擾�܂��͐ݒ肵�܂��B")> _
    Public Property RadiusBottomLeft() As Integer
        Get
            Return Me._RadiusBottomLeft
        End Get
        Set(ByVal value As Integer)
            Me._RadiusBottomLeft = value
            Me.Invalidate()
        End Set
    End Property

    Private _RadiusBottomRight As Integer
    <Category("�\��")> _
    <DefaultValue(0)> _
    <Description("�R���g���[���̉E���̊p�̔��a���擾�܂��͐ݒ肵�܂��B")> _
    Public Property RadiusBottomRight() As Integer
        Get
            Return Me._RadiusBottomRight
        End Get
        Set(ByVal value As Integer)
            Me._RadiusBottomRight = value
            Me.Invalidate()
        End Set
    End Property
End Class
