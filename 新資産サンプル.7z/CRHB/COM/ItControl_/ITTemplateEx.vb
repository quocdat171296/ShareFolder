﻿Imports System.ComponentModel
Imports System.Collections.Generic
Imports System.Drawing

''' <summary>
''' MultiRow拡張クラス
''' </summary>
''' <remarks></remarks>
Public Class ITTemplateEx
    Inherits GrapeCity.Win.MultiRow.Template
    Protected _IsAutoRowReNumber As Boolean = False

    <Browsable(True)>
    Public Property IsAutoRowReNumber As Boolean
        Get
            Return _IsAutoRowReNumber
        End Get
        Set(value As Boolean)
            _IsAutoRowReNumber = value
        End Set
    End Property

    Protected _DefaultRowSequenceFormat As String = ""

    <Browsable(True)>
    Public Property DefaultRowSequenceFormat As String
        Get
            Return _DefaultRowSequenceFormat
        End Get
        Set(value As String)
            _DefaultRowSequenceFormat = value
        End Set
    End Property

    Private P_Index As Integer = 0
    Private P_Name As String = ""
    Private P_SubName As String = ""
    Private P_Search As Boolean = False
    Private P_Ank As String = ""

    Public Shadows Property CellName() As String
        Get
            Return P_Name
        End Get
        Set(ByVal Value As String)
            P_Name = Value
            Init()
        End Set
    End Property

    Public Property CellSearch() As Boolean
        Get
            Return P_Search
        End Get
        Set(ByVal Value As Boolean)
            P_Search = Value
        End Set
    End Property

    Public Property CellAnk() As String
        Get
            Return P_Ank
        End Get
        Set(ByVal Value As String)
            P_Ank = Value
        End Set
    End Property

    Public Function CellIndex() As Integer
        Return P_Index
    End Function

    Public Function CellSubName() As String
        Return P_SubName
    End Function

    Public Sub Init()
        P_Index = 0
        P_SubName = P_Name

        If InStr(P_Name, "_") > 0 Then
            If IsNumeric(Mid$(P_Name, InStr(P_Name, "_") + 1)) Then
                P_Index = CInt(Mid$(P_Name, InStr(P_Name, "_") + 1))
                P_SubName = Mid$(P_Name, 1, InStr(P_Name, "_") - 1)
            End If
        End If

    End Sub

    '[OK]
    ''' <summary>
    ''' ヘッダ列追加（1列）
    ''' </summary>
    ''' <param name="CellControl"></param>
    ''' <param name="Header"></param>
    ''' <remarks></remarks>
    Public Sub ColumnAddOfHeader(ByVal CellControl As GrapeCity.Win.MultiRow.Cell, ByRef Header As GrapeCity.Win.MultiRow.ColumnHeaderSection)
        Try

            ' -------------------------
            ' ヘッダ描画領域を設定
            Header.Width += CellControl.Width

            ' -------------------------
            ' 生成座標を取得
            Dim MostRight As Integer = 0

            ' -------------------------
            ' TabIndexを取得
            Dim MaxTabIndex As Integer = 0

            ' 既存のセル情報を取得
            For Each Cell As GrapeCity.Win.MultiRow.Cell In Header.Cells
                ' 座標
                If MostRight < (Cell.Location.X + Cell.Width) Then
                    MostRight = Cell.Location.X + Cell.Width
                End If

                ' TabIndex
                If MaxTabIndex < Cell.TabIndex Then
                    MaxTabIndex = Cell.TabIndex
                End If
            Next

            ' -------------------------
            ' 座標を設定
            CellControl.Location = New Point(MostRight, 0)

            ' -------------------------
            ' TabIndex設定
            CellControl.TabIndex = MaxTabIndex + 1

            ' -------------------------
            ' アイテムを追加
            Header.Cells.Add(CellControl)

        Catch ex As Exception
            Throw ex
        End Try

    End Sub

    '[OK]
    ''' <summary>
    ''' 明細列追加（1列）
    ''' </summary>
    ''' <param name="CellControl"></param>
    ''' <param name="Details"></param>
    ''' <remarks></remarks>
    Public Sub ColumnAddOfDetail(ByVal CellControl As GrapeCity.Win.MultiRow.Cell, ByRef Details As GrapeCity.Win.MultiRow.Row)
        Try
            ' -------------------------
            ' 明細描画領域を設定
            ' 　※明細だけ追加する場合はないとする
            ' 　　→必ずヘッダがある
            ' Details.Width += CellControl.Width

            ' -------------------------
            ' 生成座標を取得
            Dim MostRight As Integer = 0

            ' -------------------------
            ' TabIndexを取得
            Dim MaxTabIndex As Integer = 0

            ' 既存のセル情報を取得
            For Each Cell As GrapeCity.Win.MultiRow.Cell In Details.Cells

                ' 座標
                If MostRight < (Cell.Location.X + Cell.Width) Then
                    MostRight = Cell.Location.X + Cell.Width
                End If

                ' TabIndex
                If MaxTabIndex < Cell.TabIndex Then
                    MaxTabIndex = Cell.TabIndex
                End If
            Next

            ' -------------------------
            ' 座標を設定
            CellControl.Location = New Point(MostRight, 0)

            ' -------------------------
            ' TabIndex設定
            CellControl.TabIndex = MaxTabIndex + 1

            ' -------------------------
            ' アイテムを追加
            Details.Cells.Add(CellControl)

        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    '[OK]
    ''' <summary>
    ''' ヘッダ列挿入（1列）
    ''' </summary>
    ''' <param name="CellControl"></param>
    ''' <param name="Header"></param>
    ''' <remarks></remarks>
    Public Sub ColumnInsertOfHeader(ByVal CellControl As GrapeCity.Win.MultiRow.Cell, ByVal InsertIndexName As String, ByRef Header As GrapeCity.Win.MultiRow.ColumnHeaderSection)
        Try

            ' -------------------------
            ' ヘッダ描画領域を設定
            Header.Width += CellControl.Width

            ' -------------------------
            ' TabIndexの設定
            CellControl.TabIndex = Header.Cells(InsertIndexName).TabIndex

            ' -------------------------
            ' 挿入先の座標を取得
            Dim PosIns As Point = Header.Cells(InsertIndexName).Location

            ' -------------------------
            ' 既存セルの設定
            For Each Cell As GrapeCity.Win.MultiRow.Cell In Header.Cells
                If PosIns.X <= Cell.Location.X Then
                    ' 位置をずらす
                    Cell.Location = New Point(Cell.Location.X + CellControl.Width, Cell.Location.Y)

                    ' TabIndex
                    Cell.TabIndex += 1

                End If
            Next

            ' -------------------------
            ' 座標を設定
            CellControl.Location = PosIns

            ' -------------------------
            ' アイテムを追加
            Header.Cells.Add(CellControl)

        Catch ex As Exception
            Throw ex
        End Try

    End Sub

    '[OK]
    ''' <summary>
    ''' 明細列挿入（1列）
    ''' </summary>
    ''' <param name="CellControl"></param>
    ''' <param name="Detail"></param>
    ''' <remarks></remarks>
    Public Sub ColumnInsertOfDetail(ByVal CellControl As GrapeCity.Win.MultiRow.Cell, ByVal InsertIndexName As String, ByRef Detail As GrapeCity.Win.MultiRow.Row)
        Try
            ' -------------------------
            ' 明細描画領域を設定
            ' 　※明細だけ追加する場合はないとする
            ' 　　→必ずヘッダがある
            ' Details.Width += CellControl.Width

            ' -------------------------
            ' TabIndexの設定
            CellControl.TabIndex = Detail.Cells(InsertIndexName).TabIndex

            ' -------------------------
            ' 挿入先の座標を取得
            Dim PosIns As Point = Detail.Cells(InsertIndexName).Location

            ' -------------------------
            ' 既存セルの設定
            For Each Cell As GrapeCity.Win.MultiRow.Cell In Detail.Cells
                If PosIns.X <= Cell.Location.X Then
                    ' 位置をずらす
                    Cell.Location = New Point(Cell.Location.X + CellControl.Width, Cell.Location.Y)

                    ' TabIndex
                    Cell.TabIndex += 1

                End If
            Next

            ' -------------------------
            ' 座標を設定
            CellControl.Location = PosIns

            ' -------------------------
            ' アイテムを追加
            Detail.Cells.Add(CellControl)

        Catch ex As Exception
            Throw ex
        End Try

    End Sub

    '[OK]
    ''' <summary>
    ''' ヘッダ列追加（複数段対応）
    ''' </summary>
    ''' <param name="CellControls"></param>
    ''' <param name="Header"></param>
    ''' <remarks></remarks>
    Public Sub ColumnsAddOfHeader(ByVal CellControls() As CellPlusPosition, ByRef Header As GrapeCity.Win.MultiRow.ColumnHeaderSection)
        Try
            ' 以下の行パターンに対応
            ' パターン１
            ' |￣￣￣￣￣￣￣￣￣|
            ' |                  |
            '  ￣￣￣￣￣￣￣￣￣
            '
            ' パターン２
            ' |￣￣￣￣￣￣￣￣￣|
            ' |￣￣￣￣￣￣￣￣￣|
            '  ￣￣￣￣￣￣￣￣￣
            '
            ' パターン３
            ' |￣￣￣￣￣￣￣￣￣|
            ' |￣￣￣￣│￣￣￣￣|
            '  ￣￣￣￣￣￣￣￣￣
            '
            ' パターン４
            ' |￣￣￣￣│￣￣￣￣|
            ' |￣￣￣￣  ￣￣￣￣|
            '  ￣￣￣￣￣￣￣￣￣
            '
            ' パターン５
            ' |￣￣￣│￣￣￣￣￣|
            ' |￣￣￣￣￣│￣￣￣|
            '  ￣￣￣￣￣￣￣￣￣
            '
            ' パターン６
            ' |￣￣￣￣│￣￣￣￣| → 可能だが2回に分けて1列ずつAddするべき
            ' |　　　　│　　　　|
            '  ￣￣￣￣￣￣￣￣￣

            ' -------------------------
            ' 生成座標を取得
            Dim MostRight As Integer = 0

            ' -------------------------
            ' TabIndexを取得
            Dim MaxTabIndexTop As Integer = 0
            Dim MaxTabIndexBottom As Integer = 0

            ' 既存のセル情報を取得
            For Each Cell As GrapeCity.Win.MultiRow.Cell In Header.Cells

                ' 座標
                If MostRight < (Cell.Location.X + Cell.Width) Then
                    MostRight = Cell.Location.X + Cell.Width
                End If

                ' TabIndex
                If Cell.Location.Y = 0 Then
                    ' 上段
                    If MaxTabIndexTop < Cell.TabIndex Then
                        MaxTabIndexTop = Cell.TabIndex
                    End If
                Else
                    ' 下段

                    ' 下段のTabIndexを強制的に2増やす
                    ' TabIndex 1,2,3,4...が
                    '          1,2,5,6...となっても問題ないため
                    Cell.TabIndex += 2

                    If MaxTabIndexBottom < Cell.TabIndex Then
                        MaxTabIndexBottom = Cell.TabIndex
                    End If
                End If

            Next

            ' 左上セル
            Dim TopLeftCell As GrapeCity.Win.MultiRow.Cell = Nothing
            ' 右上セル
            Dim TopRightCell As GrapeCity.Win.MultiRow.Cell = Nothing
            ' 左下セル
            Dim BottomLeftCell As GrapeCity.Win.MultiRow.Cell = Nothing
            ' 右下セル
            Dim BottomRightCell As GrapeCity.Win.MultiRow.Cell = Nothing

            ' 追加するセル情報取得
            For Each CellPos As CellPlusPosition In CellControls
                Select Case (CType(CellPos.VerticalPosition, Integer) + CType(CellPos.HorizontalPosition, Integer))
                    Case (CType(eVerticalPosition.Top, Integer) + CType(eHorizontalPosition.Left, Integer))
                        TopLeftCell = CellPos.Cell
                    Case (CType(eVerticalPosition.Top, Integer) + CType(eHorizontalPosition.Right, Integer))
                        TopRightCell = CellPos.Cell
                    Case (CType(eVerticalPosition.Bottom, Integer) + CType(eHorizontalPosition.Left, Integer))
                        BottomLeftCell = CellPos.Cell
                    Case (CType(eVerticalPosition.Bottom, Integer) + CType(eHorizontalPosition.Right, Integer))
                        BottomRightCell = CellPos.Cell
                End Select
            Next

            ' -----------------------------
            ' 描画位置を取得
            Dim PosTL As Point = New Point(MostRight, 0)
            Dim PosTR As Point = New Point(MostRight, 0)
            Dim PosBL As Point = New Point(MostRight, 0)
            Dim PosBR As Point = New Point(MostRight, 0)

            ' -----------------------------
            ' サイズを取得
            Dim SizTL As Size = New Size(0, 0)
            Dim SizTR As Size = New Size(0, 0)
            Dim SizBL As Size = New Size(0, 0)
            Dim SizBR As Size = New Size(0, 0)

            ' 左上から順番にリストを生成する
            Dim CellList As List(Of GrapeCity.Win.MultiRow.Cell) = New List(Of GrapeCity.Win.MultiRow.Cell)()

            ' 左上セル
            If Not TopLeftCell Is Nothing Then
                ' サイズ取得
                SizTL = TopLeftCell.Size

                ' 描画位置設定
                TopLeftCell.Location = PosTL

                ' TabIndex設定
                TopLeftCell.TabIndex = MaxTabIndexTop + 1

                ' セルリスト追加
                CellList.Add(TopLeftCell)
            End If
            ' 右上セル
            If Not TopRightCell Is Nothing Then
                ' サイズ取得
                SizTR = TopRightCell.Size

                ' 描画位置設定
                ' 左上セル分右にスライド
                PosTR.X += SizTL.Width
                TopRightCell.Location = PosTR

                ' TabIndex設定
                TopRightCell.TabIndex = MaxTabIndexTop + 2

                ' セルリスト追加
                CellList.Add(TopRightCell)
            End If
            ' 左下セル
            If Not BottomLeftCell Is Nothing Then
                ' サイズ取得
                SizBL = BottomLeftCell.Size

                ' 描画位置設定
                ' 上段セル分下にスライド
                PosBL.Y += CInt(IIf(SizTL.Height >= SizTR.Height, SizTL.Height, SizTR.Height))
                BottomLeftCell.Location = PosBL

                ' TabIndex設定
                BottomLeftCell.TabIndex = MaxTabIndexBottom + 1

                ' セルリスト追加
                CellList.Add(BottomLeftCell)
            End If
            ' 右下セル
            If Not BottomRightCell Is Nothing Then
                ' サイズ取得
                SizBR = BottomRightCell.Size    ' 不要だが他のセルと同様に取得しておく

                ' 描画位置設定
                ' 左下セル分右にスライド
                PosBR.X += SizBL.Width
                ' 上段セル分下にスライド
                PosBR.Y += CInt(IIf(SizTL.Height >= SizTR.Height, SizTL.Height, SizTR.Height))

                ' TabIndex設定
                BottomRightCell.TabIndex = MaxTabIndexBottom + 2

                ' セルリスト追加
                CellList.Add(BottomRightCell)
            End If

            ' ヘッダ描画幅を設定する
            Header.Width += CInt(IIf((SizTL.Width + SizTR.Width) >= (SizBL.Width + SizBR.Width), (SizTL.Width + SizTR.Width), (SizBL.Width + SizBR.Width)))

            ' アイテムを追加する
            For i As Integer = 0 To CellList.Count - 1 Step 1
                Header.Cells.Add(CellList(i))
            Next
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    '[OK]
    ''' <summary>
    ''' 明細列追加（複数段対応）
    ''' </summary>
    ''' <param name="CellControls"></param>
    ''' <param name="Detail"></param>
    ''' <remarks></remarks>
    Public Sub ColumnsAddOfDetail(ByVal CellControls() As CellPlusPosition, ByRef Detail As GrapeCity.Win.MultiRow.Row)
        Try
            ' 以下の行パターンに対応
            ' パターン１
            ' |￣￣￣￣￣￣￣￣￣|
            ' |                  |
            '  ￣￣￣￣￣￣￣￣￣
            '
            ' パターン２
            ' |￣￣￣￣￣￣￣￣￣|
            ' |￣￣￣￣￣￣￣￣￣|
            '  ￣￣￣￣￣￣￣￣￣
            '
            ' パターン３
            ' |￣￣￣￣￣￣￣￣￣|
            ' |￣￣￣￣│￣￣￣￣|
            '  ￣￣￣￣￣￣￣￣￣
            '
            ' パターン４
            ' |￣￣￣￣│￣￣￣￣|
            ' |￣￣￣￣  ￣￣￣￣|
            '  ￣￣￣￣￣￣￣￣￣
            '            
            ' パターン５
            ' |￣￣￣│￣￣￣￣￣|
            ' |￣￣￣￣￣│￣￣￣|
            '  ￣￣￣￣￣￣￣￣￣
            '
            ' パターン６
            ' |￣￣￣￣│￣￣￣￣| → 可能だが2回に分けて1列ずつAddするべき
            ' |　　　　│　　　　|
            '  ￣￣￣￣￣￣￣￣￣

            ' -------------------------
            ' 生成座標を取得
            Dim MostRight As Integer = 0

            ' -------------------------
            ' TabIndexを取得
            Dim MaxTabIndexTop As Integer = 0
            Dim MaxTabIndexBottom As Integer = 0

            ' 既存のセル情報を取得
            For Each Cell As GrapeCity.Win.MultiRow.Cell In Detail.Cells

                ' 座標
                If MostRight < (Cell.Location.X + Cell.Width) Then
                    MostRight = Cell.Location.X + Cell.Width
                End If

                ' TabIndex
                If Cell.Location.Y = 0 Then
                    ' 上段
                    If MaxTabIndexTop < Cell.TabIndex Then
                        MaxTabIndexTop = Cell.TabIndex
                    End If
                Else
                    ' 下段

                    ' 下段のTabIndexを強制的に2増やす
                    ' TabIndex 1,2,3,4...が
                    '          1,2,5,6...となっても問題ないため
                    Cell.TabIndex += 2

                    If MaxTabIndexBottom < Cell.TabIndex Then
                        MaxTabIndexBottom = Cell.TabIndex
                    End If
                End If

            Next

            ' 左上セル
            Dim TopLeftCell As GrapeCity.Win.MultiRow.Cell = Nothing
            ' 右上セル
            Dim TopRightCell As GrapeCity.Win.MultiRow.Cell = Nothing
            ' 左下セル
            Dim BottomLeftCell As GrapeCity.Win.MultiRow.Cell = Nothing
            ' 右下セル
            Dim BottomRightCell As GrapeCity.Win.MultiRow.Cell = Nothing

            ' 追加するセル情報取得
            For Each CellPos As CellPlusPosition In CellControls
                Select Case (CType(CellPos.VerticalPosition, Integer) + CType(CellPos.HorizontalPosition, Integer))
                    Case (CType(eVerticalPosition.Top, Integer) + CType(eHorizontalPosition.Left, Integer))
                        TopLeftCell = CellPos.Cell
                    Case (CType(eVerticalPosition.Top, Integer) + CType(eHorizontalPosition.Right, Integer))
                        TopRightCell = CellPos.Cell
                    Case (CType(eVerticalPosition.Bottom, Integer) + CType(eHorizontalPosition.Left, Integer))
                        BottomLeftCell = CellPos.Cell
                    Case (CType(eVerticalPosition.Bottom, Integer) + CType(eHorizontalPosition.Right, Integer))
                        BottomRightCell = CellPos.Cell
                End Select
            Next

            ' -----------------------------
            ' 描画位置を取得
            Dim PosTL As Point = New Point(MostRight, 0)
            Dim PosTR As Point = New Point(MostRight, 0)
            Dim PosBL As Point = New Point(MostRight, 0)
            Dim PosBR As Point = New Point(MostRight, 0)

            ' -----------------------------
            ' サイズを取得
            Dim SizTL As Size = New Size(0, 0)
            Dim SizTR As Size = New Size(0, 0)
            Dim SizBL As Size = New Size(0, 0)
            Dim SizBR As Size = New Size(0, 0)

            ' 左上から順番にリストを生成する
            Dim CellList As List(Of GrapeCity.Win.MultiRow.Cell) = New List(Of GrapeCity.Win.MultiRow.Cell)()

            ' 左上セル
            If Not TopLeftCell Is Nothing Then
                ' サイズ取得
                SizTL = TopLeftCell.Size

                ' 描画位置設定
                TopLeftCell.Location = PosTL

                ' TabIndex設定
                TopLeftCell.TabIndex = MaxTabIndexTop + 1

                ' セルリスト追加
                CellList.Add(TopLeftCell)
            End If
            ' 右上セル
            If Not TopRightCell Is Nothing Then
                ' サイズ取得
                SizTR = TopRightCell.Size

                ' 描画位置設定
                ' 左上セル分右にスライド
                PosTR.X += SizTL.Width
                TopRightCell.Location = PosTR

                ' TabIndex設定
                TopRightCell.TabIndex = MaxTabIndexTop + 2

                ' セルリスト追加
                CellList.Add(TopRightCell)
            End If
            ' 左下セル
            If Not BottomLeftCell Is Nothing Then
                ' サイズ取得
                SizBL = BottomLeftCell.Size

                ' 描画位置設定
                ' 上段セル分下にスライド
                PosBL.Y += CInt(IIf(SizTL.Height >= SizTR.Height, SizTL.Height, SizTR.Height))
                BottomLeftCell.Location = PosBL

                ' TabIndex設定
                BottomLeftCell.TabIndex = MaxTabIndexBottom + 1

                ' セルリスト追加
                CellList.Add(BottomLeftCell)
            End If
            ' 右下セル
            If Not BottomRightCell Is Nothing Then
                ' サイズ取得
                SizBR = BottomRightCell.Size    ' 不要だが他のセルと同様に取得しておく

                ' 描画位置設定
                ' 左下セル分右にスライド
                PosBR.X += SizBL.Width
                ' 上段セル分下にスライド
                PosBR.Y += CInt(IIf(SizTL.Height >= SizTR.Height, SizTL.Height, SizTR.Height))

                ' TabIndex設定
                BottomRightCell.TabIndex = MaxTabIndexBottom + 2

                ' セルリスト追加
                CellList.Add(BottomRightCell)
            End If

            ' ※ヘッダ描画幅を設定するためここでは処理を行わない
            ' 明細描画幅を設定する
            ' Detail.Width += IIf((SizTL.Width + SizTR.Width) >= (SizBL.Width + SizBR.Width), (SizTL.Width + SizTR.Width), (SizBL.Width + SizBR.Width))

            ' アイテムを追加する
            For i As Integer = 0 To CellList.Count - 1 Step 1
                Detail.Cells.Add(CellList(i))
            Next
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    '[OK]
    ''' <summary>
    ''' ヘッダ列挿入（複数段対応）
    ''' </summary>
    ''' <param name="CellControls"></param>
    ''' <param name="Header"></param>
    ''' <remarks></remarks>
    Public Sub ColumnsInsertOfHeader(ByVal CellControls() As CellPlusPosition, ByVal InsertIndexName As String, ByRef Header As GrapeCity.Win.MultiRow.ColumnHeaderSection)
        Try
            ' 以下の行パターンに対応
            ' パターン１
            ' |￣￣￣￣￣￣￣￣￣|
            ' |                  |
            '  ￣￣￣￣￣￣￣￣￣
            '
            ' パターン２
            ' |￣￣￣￣￣￣￣￣￣|
            ' |￣￣￣￣￣￣￣￣￣|
            '  ￣￣￣￣￣￣￣￣￣
            '
            ' パターン３
            ' |￣￣￣￣￣￣￣￣￣|
            ' |￣￣￣￣│￣￣￣￣|
            '  ￣￣￣￣￣￣￣￣￣
            '
            ' パターン４
            ' |￣￣￣￣│￣￣￣￣|
            ' |￣￣￣￣  ￣￣￣￣|
            '  ￣￣￣￣￣￣￣￣￣
            '
            ' パターン５
            ' |￣￣￣│￣￣￣￣￣|
            ' |￣￣￣￣￣│￣￣￣|
            '  ￣￣￣￣￣￣￣￣￣
            '
            ' パターン６
            ' |￣￣￣￣│￣￣￣￣| → 可能だが2回に分けて1列ずつInsertするべき
            ' |　　　　│　　　　|
            '  ￣￣￣￣￣￣￣￣￣

            ' -------------------------
            ' 挿入先の座標を取得
            Dim PosIns As Point = Header.Cells(InsertIndexName).Location

            ' -------------------------
            ' 挿入セルの設定
            ' 左上セル
            Dim TopLeftCell As GrapeCity.Win.MultiRow.Cell = Nothing
            ' 右上セル
            Dim TopRightCell As GrapeCity.Win.MultiRow.Cell = Nothing
            ' 左下セル
            Dim BottomLeftCell As GrapeCity.Win.MultiRow.Cell = Nothing
            ' 右下セル
            Dim BottomRightCell As GrapeCity.Win.MultiRow.Cell = Nothing

            ' 追加するセル情報取得
            For Each CellPos As CellPlusPosition In CellControls
                Select Case (CType(CellPos.VerticalPosition, Integer) + CType(CellPos.HorizontalPosition, Integer))
                    Case (CType(eVerticalPosition.Top, Integer) + CType(eHorizontalPosition.Left, Integer))
                        TopLeftCell = CellPos.Cell
                    Case (CType(eVerticalPosition.Top, Integer) + CType(eHorizontalPosition.Right, Integer))
                        TopRightCell = CellPos.Cell
                    Case (CType(eVerticalPosition.Bottom, Integer) + CType(eHorizontalPosition.Left, Integer))
                        BottomLeftCell = CellPos.Cell
                    Case (CType(eVerticalPosition.Bottom, Integer) + CType(eHorizontalPosition.Right, Integer))
                        BottomRightCell = CellPos.Cell
                End Select
            Next

            ' -----------------------------
            ' 描画位置を取得
            Dim PosTL As Point = New Point(PosIns.X, 0)
            Dim PosTR As Point = New Point(PosIns.X, 0)
            Dim PosBL As Point = New Point(PosIns.X, 0)
            Dim PosBR As Point = New Point(PosIns.X, 0)

            ' -----------------------------
            ' サイズを取得
            Dim SizTL As Size = New Size(0, 0)
            Dim SizTR As Size = New Size(0, 0)
            Dim SizBL As Size = New Size(0, 0)
            Dim SizBR As Size = New Size(0, 0)

            ' 左上セル
            If Not TopLeftCell Is Nothing Then
                ' サイズ取得
                SizTL = TopLeftCell.Size

                ' 描画位置設定
                TopLeftCell.Location = PosTL
            End If
            ' 右上セル
            If Not TopRightCell Is Nothing Then
                ' サイズ取得
                SizTR = TopRightCell.Size

                ' 描画位置設定
                ' 左上セル分右にスライド
                PosTR.X += SizTL.Width
                TopRightCell.Location = PosTR
            End If
            ' 左下セル
            If Not BottomLeftCell Is Nothing Then
                ' サイズ取得
                SizBL = BottomLeftCell.Size

                ' 描画位置設定
                ' 上段セル分下にスライド
                PosBL.Y += CInt(IIf(SizTL.Height >= SizTR.Height, SizTL.Height, SizTR.Height))
                BottomLeftCell.Location = PosBL
            End If
            ' 右下セル
            If Not BottomRightCell Is Nothing Then
                ' サイズ取得
                SizBR = BottomRightCell.Size    ' 不要だが他のセルと同様に取得しておく

                ' 描画位置設定
                ' 左下セル分右にスライド
                PosBR.X += SizBL.Width
                ' 上段セル分下にスライド
                PosBR.Y += CInt(IIf(SizTL.Height >= SizTR.Height, SizTL.Height, SizTR.Height))
                BottomRightCell.Location = PosBR
            End If

            ' 移動幅設定
            Dim SlideWidth As Integer = CInt(IIf((SizTL.Width + SizTR.Width) >= (SizBL.Width + SizBR.Width), (SizTL.Width + SizTR.Width), (SizBL.Width + SizBR.Width)))

            ' ヘッダ描画幅を設定する
            Header.Width += SlideWidth

            ' -------------------------
            ' TabIndexを取得
            Dim TopTabIndex As Integer = 0
            Dim BottomTabIndex As Integer = 0

            ' -------------------------
            ' 挿入先１つ左のセル（上段/下段）
            Dim TopBeforeCell As GrapeCity.Win.MultiRow.Cell = Nothing
            Dim BottomBeforeCell As GrapeCity.Win.MultiRow.Cell = Nothing

            ' -------------------------
            ' 既存のセル情報の取得／設定
            For Each Cell As GrapeCity.Win.MultiRow.Cell In Header.Cells

                If PosIns.X <= Cell.Location.X Then
                    ' 挿入先より右に当たるセル

                    If Cell.Location.Y = 0 Then
                        ' 上段

                        ' TabIndex2増やす
                        Cell.TabIndex += 2

                    Else
                        ' 下段

                        ' TabIndex4増やす
                        Cell.TabIndex += 4

                    End If

                    ' 描画位置設定
                    Cell.Location = New Point(Cell.Location.X + SlideWidth, Cell.Location.Y)

                Else
                    ' 挿入先より左に当たるセル
                    If Cell.Location.Y = 0 Then
                        ' 上段

                        ' TabIndexを増やさない
                        '

                        If TopBeforeCell Is Nothing OrElse TopBeforeCell.Location.X < Cell.Location.X Then
                            ' 挿入セルの１つ左にあたるセルを取得（上段）
                            TopBeforeCell = Cell
                        End If
                    Else
                        ' 下段

                        ' TabIndex2増やす
                        Cell.TabIndex += 2

                        If BottomBeforeCell Is Nothing OrElse BottomBeforeCell.Location.X < Cell.Location.X Then
                            ' 挿入セルの１つ左にあたるセルを取得（下段）
                            BottomBeforeCell = Cell
                        End If
                    End If
                End If

            Next

            ' 左上から順番にリストを生成する
            Dim CellList As List(Of GrapeCity.Win.MultiRow.Cell) = New List(Of GrapeCity.Win.MultiRow.Cell)()

            ' 左上セル
            If Not TopLeftCell Is Nothing Then
                ' TabIndex設定
                TopLeftCell.TabIndex = TopBeforeCell.TabIndex + 1

                ' セルリスト追加
                CellList.Add(TopLeftCell)
            End If
            ' 右上セル
            If Not TopRightCell Is Nothing Then
                ' TabIndex設定
                TopRightCell.TabIndex = TopBeforeCell.TabIndex + 2

                ' セルリスト追加
                CellList.Add(TopRightCell)
            End If
            ' 左下セル
            If Not BottomLeftCell Is Nothing Then
                ' TabIndex設定
                BottomLeftCell.TabIndex = BottomBeforeCell.TabIndex + 1

                ' セルリスト追加
                CellList.Add(BottomLeftCell)
            End If
            ' 右下セル
            If Not BottomRightCell Is Nothing Then
                ' TabIndex設定
                BottomRightCell.TabIndex = BottomBeforeCell.TabIndex + 2

                ' セルリスト追加
                CellList.Add(BottomRightCell)
            End If

            ' アイテムを追加する
            For i As Integer = 0 To CellList.Count - 1 Step 1
                Header.Cells.Add(CellList(i))
            Next
        Catch ex As Exception
            Throw ex
        End Try
    End Sub


    '[OK]
    ''' <summary>
    ''' 明細列挿入（複数段対応）
    ''' </summary>
    ''' <param name="CellControls"></param>
    ''' <param name="Detail"></param>
    ''' <remarks></remarks>
    Public Sub ColumnsInsertOfDetail(ByVal CellControls() As CellPlusPosition, ByVal InsertIndexName As String, ByRef Detail As GrapeCity.Win.MultiRow.Row)
        Try
            ' 以下の行パターンに対応
            ' パターン１
            ' |￣￣￣￣￣￣￣￣￣|
            ' |                  |
            '  ￣￣￣￣￣￣￣￣￣
            '
            ' パターン２
            ' |￣￣￣￣￣￣￣￣￣|
            ' |￣￣￣￣￣￣￣￣￣|
            '  ￣￣￣￣￣￣￣￣￣
            '
            ' パターン３
            ' |￣￣￣￣￣￣￣￣￣|
            ' |￣￣￣￣│￣￣￣￣|
            '  ￣￣￣￣￣￣￣￣￣
            '
            ' パターン４
            ' |￣￣￣￣│￣￣￣￣|
            ' |￣￣￣￣  ￣￣￣￣|
            '  ￣￣￣￣￣￣￣￣￣
            '
            ' パターン５
            ' |￣￣￣│￣￣￣￣￣|
            ' |￣￣￣￣￣│￣￣￣|
            '  ￣￣￣￣￣￣￣￣￣
            '
            ' パターン６
            ' |￣￣￣￣│￣￣￣￣| → 可能だが2回に分けて1列ずつInsertするべき
            ' |　　　　│　　　　|
            '  ￣￣￣￣￣￣￣￣￣

            ' -------------------------
            ' 挿入先の座標を取得
            Dim PosIns As Point = Detail.Cells(InsertIndexName).Location

            ' -------------------------
            ' 挿入セルの設定
            ' 左上セル
            Dim TopLeftCell As GrapeCity.Win.MultiRow.Cell = Nothing
            ' 右上セル
            Dim TopRightCell As GrapeCity.Win.MultiRow.Cell = Nothing
            ' 左下セル
            Dim BottomLeftCell As GrapeCity.Win.MultiRow.Cell = Nothing
            ' 右下セル
            Dim BottomRightCell As GrapeCity.Win.MultiRow.Cell = Nothing

            ' 追加するセル情報取得
            For Each CellPos As CellPlusPosition In CellControls
                Select Case (CType(CellPos.VerticalPosition, Integer) + CType(CellPos.HorizontalPosition, Integer))
                    Case (CType(eVerticalPosition.Top, Integer) + CType(eHorizontalPosition.Left, Integer))
                        TopLeftCell = CellPos.Cell
                    Case (CType(eVerticalPosition.Top, Integer) + CType(eHorizontalPosition.Right, Integer))
                        TopRightCell = CellPos.Cell
                    Case (CType(eVerticalPosition.Bottom, Integer) + CType(eHorizontalPosition.Left, Integer))
                        BottomLeftCell = CellPos.Cell
                    Case (CType(eVerticalPosition.Bottom, Integer) + CType(eHorizontalPosition.Right, Integer))
                        BottomRightCell = CellPos.Cell
                End Select
            Next

            ' -----------------------------
            ' 描画位置を取得
            Dim PosTL As Point = New Point(PosIns.X, 0)
            Dim PosTR As Point = New Point(PosIns.X, 0)
            Dim PosBL As Point = New Point(PosIns.X, 0)
            Dim PosBR As Point = New Point(PosIns.X, 0)

            ' -----------------------------
            ' サイズを取得
            Dim SizTL As Size = New Size(0, 0)
            Dim SizTR As Size = New Size(0, 0)
            Dim SizBL As Size = New Size(0, 0)
            Dim SizBR As Size = New Size(0, 0)

            ' 左上セル
            If Not TopLeftCell Is Nothing Then
                ' サイズ取得
                SizTL = TopLeftCell.Size

                ' 描画位置設定
                TopLeftCell.Location = PosTL
            End If
            ' 右上セル
            If Not TopRightCell Is Nothing Then
                ' サイズ取得
                SizTR = TopRightCell.Size

                ' 描画位置設定
                ' 左上セル分右にスライド
                PosTR.X += SizTL.Width
                TopRightCell.Location = PosTR
            End If
            ' 左下セル
            If Not BottomLeftCell Is Nothing Then
                ' サイズ取得
                SizBL = BottomLeftCell.Size

                ' 描画位置設定
                ' 上段セル分下にスライド
                PosBL.Y += CInt(IIf(SizTL.Height >= SizTR.Height, SizTL.Height, SizTR.Height))
                BottomLeftCell.Location = PosBL
            End If
            ' 右下セル
            If Not BottomRightCell Is Nothing Then
                ' サイズ取得
                SizBR = BottomRightCell.Size    ' 不要だが他のセルと同様に取得しておく

                ' 描画位置設定
                ' 左下セル分右にスライド
                PosBR.X += SizBL.Width
                ' 上段セル分下にスライド
                PosBR.Y += CInt(IIf(SizTL.Height >= SizTR.Height, SizTL.Height, SizTR.Height))
                BottomRightCell.Location = PosBR
            End If

            ' 移動幅設定
            Dim SlideWidth As Integer = CInt(IIf((SizTL.Width + SizTR.Width) >= (SizBL.Width + SizBR.Width), (SizTL.Width + SizTR.Width), (SizBL.Width + SizBR.Width))
)
            ' ※ヘッダ描画幅を設定するためここでは処理を行わない
            ' 明細描画幅を設定する
            ' Detail.Width += SlideWidth

            ' -------------------------
            ' TabIndexを取得
            Dim TopTabIndex As Integer = 0
            Dim BottomTabIndex As Integer = 0

            ' -------------------------
            ' 挿入先１つ左のセル（上段/下段）
            Dim TopBeforeCell As GrapeCity.Win.MultiRow.Cell = Nothing
            Dim BottomBeforeCell As GrapeCity.Win.MultiRow.Cell = Nothing

            ' -------------------------
            ' 既存のセル情報の取得／設定
            For Each Cell As GrapeCity.Win.MultiRow.Cell In Detail.Cells

                If PosIns.X <= Cell.Location.X Then
                    ' 挿入先より右に当たるセル

                    If Cell.Location.Y = 0 Then
                        ' 上段

                        ' TabIndex2増やす
                        Cell.TabIndex += 2

                    Else
                        ' 下段

                        ' TabIndex4増やす
                        Cell.TabIndex += 4

                    End If

                    ' 描画位置設定
                    Cell.Location = New Point(Cell.Location.X + SlideWidth, Cell.Location.Y)

                Else
                    ' 挿入先より左に当たるセル
                    If Cell.Location.Y = 0 Then
                        ' 上段

                        ' TabIndexを増やさない
                        '

                        If TopBeforeCell Is Nothing OrElse TopBeforeCell.Location.X < Cell.Location.X Then
                            ' 挿入セルの１つ左にあたるセルを取得（上段）
                            TopBeforeCell = Cell
                        End If
                    Else
                        ' 下段

                        ' TabIndex2増やす
                        Cell.TabIndex += 2

                        If BottomBeforeCell Is Nothing OrElse BottomBeforeCell.Location.X < Cell.Location.X Then
                            ' 挿入セルの１つ左にあたるセルを取得（下段）
                            BottomBeforeCell = Cell
                        End If
                    End If
                End If

            Next

            ' 左上から順番にリストを生成する
            Dim CellList As List(Of GrapeCity.Win.MultiRow.Cell) = New List(Of GrapeCity.Win.MultiRow.Cell)()

            ' 左上セル
            If Not TopLeftCell Is Nothing Then
                ' TabIndex設定
                TopLeftCell.TabIndex = TopBeforeCell.TabIndex + 1

                ' セルリスト追加
                CellList.Add(TopLeftCell)
            End If
            ' 右上セル
            If Not TopRightCell Is Nothing Then
                ' TabIndex設定
                TopRightCell.TabIndex = TopBeforeCell.TabIndex + 2

                ' セルリスト追加
                CellList.Add(TopRightCell)
            End If
            ' 左下セル
            If Not BottomLeftCell Is Nothing Then
                ' TabIndex設定
                BottomLeftCell.TabIndex = BottomBeforeCell.TabIndex + 1

                ' セルリスト追加
                CellList.Add(BottomLeftCell)
            End If
            ' 右下セル
            If Not BottomRightCell Is Nothing Then
                ' TabIndex設定
                BottomRightCell.TabIndex = BottomBeforeCell.TabIndex + 2

                ' セルリスト追加
                CellList.Add(BottomRightCell)
            End If

            ' アイテムを追加する
            For i As Integer = 0 To CellList.Count - 1 Step 1
                Detail.Cells.Add(CellList(i))
            Next
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    ' -------------------------------------------------------------------------
    ' オーバーライドメソッド
    ' -------------------------------------------------------------------------

    ' -------------------------------------------------------------------------
    ' カプセル化メソッド
    ' -------------------------------------------------------------------------

    ''' <summary>
    ''' セルのキープレス
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Cell_KeyPress(sender As Object, e As KeyPressEventArgs)
        Try
            ' バックスペースキーまたはLength = 0のキーは
            ' 判定処理しない
            If e.KeyChar = ControlChars.Back Or e.KeyChar.ToString().Length = 0 Then
                Return
            End If

            Select Case GetInputTypeFormat(Me.DefaultCellStyle).InputType
                Case eInputType.None



                Case eInputType.Alphabet




                Case eInputType.Number
                    If e.KeyChar = "." Then
                        Dim editcell As GrapeCity.Win.MultiRow.TextBoxEditingControl = CType(sender, GrapeCity.Win.MultiRow.TextBoxEditingControl)
                        If editcell.Text.Contains(".") = True Then
                            e.Handled = True
                        End If
                    ElseIf e.KeyChar < "0"c OrElse "9"c < e.KeyChar Then
                        e.Handled = True
                    End If
                Case eInputType.DateTime
                    If e.KeyChar < "0"c OrElse "9"c < e.KeyChar Then
                        e.Handled = True
                    End If
                Case Else
                    ' 処理なし
            End Select
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Private Sub Cell_Enter(sender As Object, e As EventArgs)
        Try
            Dim textCell As GrapeCity.Win.MultiRow.TextBoxEditingControl = CType(sender, GrapeCity.Win.MultiRow.TextBoxEditingControl)

            textCell.SelectAll()

        Catch ex As Exception
            Throw ex
        End Try
    End Sub


    ''' <summary>
    ''' 入力形式・フォーマット取得
    ''' </summary>
    ''' <param name="Tag"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetInputTypeFormat(ByVal Tag As Object) As InputTypeFormat

        Dim InpFmt As InputTypeFormat = New InputTypeFormat()

        If Tag Is Nothing Then
            Return InpFmt
        End If

        Dim strTags() As String = Tag.ToString().Split(CChar("|"))

        Dim strInputType As String = ""
        Dim strFormat As String = ""

        ' 入力形式
        If strTags.Length >= 1 Then
            strInputType = strTags(0)
        End If

        ' フォーマット
        If strTags.Length >= 2 Then
            strFormat = strTags(1)
        End If

        Select Case strInputType
            Case "A"
                InpFmt.InputType = eInputType.Alphabet
            Case "9"
                InpFmt.InputType = eInputType.Number
            Case "D"
                InpFmt.InputType = eInputType.DateTime
            Case Else
                InpFmt.InputType = eInputType.None
        End Select

        InpFmt.Format = strFormat

        Return InpFmt

    End Function

End Class

''' <summary>
''' 複数行追加/挿入のセル情報クラス
''' </summary>
''' <remarks></remarks>
Public Class CellPlusPosition2

    ''' <summary>
    ''' 追加するセル
    ''' </summary>
    ''' <remarks></remarks>
    Public Cell As GrapeCity.Win.MultiRow.Cell

    ''' <summary>
    ''' 垂直位置
    ''' </summary>
    ''' <remarks></remarks>
    Public VerticalPosition As eVerticalPosition = eVerticalPosition.Top

    ''' <summary>
    ''' 水平位置
    ''' </summary>
    ''' <remarks></remarks>
    Public HorizontalPosition As eHorizontalPosition = eHorizontalPosition.Left

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="_Cell"></param>
    ''' <remarks></remarks>
    Sub New(ByVal _Cell As GrapeCity.Win.MultiRow.Cell)
        Cell = _Cell
    End Sub

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="_Cell"></param>
    ''' <param name="_VerticalPosition"></param>
    ''' <remarks></remarks>
    Sub New(ByVal _Cell As GrapeCity.Win.MultiRow.Cell, ByVal _VerticalPosition As eVerticalPosition)
        Cell = _Cell
        VerticalPosition = _VerticalPosition
    End Sub

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="_Cell"></param>
    ''' <param name="_VerticalPosition"></param>
    ''' <param name="_HorizontalPosition"></param>
    ''' <remarks></remarks>
    Sub New(ByVal _Cell As GrapeCity.Win.MultiRow.Cell, ByVal _VerticalPosition As eVerticalPosition, ByVal _HorizontalPosition As eHorizontalPosition)
        Cell = _Cell
        VerticalPosition = _VerticalPosition
        HorizontalPosition = _HorizontalPosition
    End Sub

End Class

''' <summary>
''' 垂直位置
''' </summary>
''' <remarks></remarks>
Public Enum eVerticalPosition2
    ''' <summary>
    ''' 上段
    ''' </summary>
    ''' <remarks></remarks>
    Top = 0
    ''' <summary>
    ''' 下段
    ''' </summary>
    ''' <remarks></remarks>
    Bottom = 1
End Enum

''' <summary>
''' 水平位置
''' </summary>
''' <remarks></remarks>
Public Enum eHorizontalPosition2
    ''' <summary>
    ''' 左
    ''' </summary>
    ''' <remarks></remarks>
    Left = 2
    ''' <summary>
    ''' 右
    ''' </summary>
    ''' <remarks></remarks>
    Right = 4
End Enum

''' <summary>
''' 入力タイプ・フォーマット
''' </summary>
''' <remarks></remarks>
Public Class InputTypeFormat2
    ''' <summary>
    ''' 入力タイプ
    ''' </summary>
    ''' <remarks></remarks>
    Public InputType As eInputType = eInputType.None
    ''' <summary>
    ''' フォーマット
    ''' </summary>
    ''' <remarks></remarks>
    Public Format As String = ""

End Class

''' <summary>
''' 入力タイプ
''' </summary>
''' <remarks></remarks>
Public Enum eInputType2
    ''' <summary>
    ''' 制限なし
    ''' </summary>
    ''' <remarks></remarks>
    [None]
    ''' <summary>
    ''' 英数
    ''' </summary>
    ''' <remarks></remarks>
    Alphabet
    ''' <summary>
    ''' 数値
    ''' </summary>
    ''' <remarks></remarks>
    Number
    ''' <summary>
    ''' 日付
    ''' </summary>
    ''' <remarks></remarks>
    DateTime
End Enum