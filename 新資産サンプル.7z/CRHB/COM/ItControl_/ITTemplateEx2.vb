﻿Imports System.ComponentModel
Imports System.Collections.Generic
Imports System.Drawing

''' <summary>
''' MultiRow拡張クラス
''' </summary>
''' <remarks></remarks>
Public Class ITTemplateEx2
    Inherits GrapeCity.Win.MultiRow.Template

    Private P_Index As Integer = 0
    Private P_Name As String = ""
    Private P_SubName As String = ""
    Private P_Search As Boolean = False
    Private P_Ank As String = ""

    Public Shadows Property CellName() As String
        Get
            Return P_Name
        End Get
        Set(ByVal Value As String)
            P_Name = Value
            Init()
        End Set
    End Property

    Public Property CellSearch() As Boolean
        Get
            Return P_Search
        End Get
        Set(ByVal Value As Boolean)
            P_Search = Value
        End Set
    End Property

    Public Property CellAnk() As String
        Get
            Return P_Ank
        End Get
        Set(ByVal Value As String)
            P_Ank = Value
        End Set
    End Property

    Public Function CellIndex() As Integer
        Return P_Index
    End Function

    Public Function CellSubName() As String
        Return P_SubName
    End Function

    Public Sub Init()
        P_Index = 0
        P_SubName = P_Name

        If InStr(P_Name, "_") > 0 Then
            If IsNumeric(Mid$(P_Name, InStr(P_Name, "_") + 1)) Then
                P_Index = CInt(Mid$(P_Name, InStr(P_Name, "_") + 1))
                P_SubName = Mid$(P_Name, 1, InStr(P_Name, "_") - 1)
            End If
        End If

    End Sub
End Class