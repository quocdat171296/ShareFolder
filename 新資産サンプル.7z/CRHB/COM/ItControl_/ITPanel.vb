﻿Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.Drawing.Drawing2D
Imports System.Windows.Forms

Public Class ITPanel
    Inherits System.Windows.Forms.Panel

    Public Sub New()
        MyBase.BackColor = Color.Transparent
        MyBase.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._BorderColor = Color.Black
        Me._BorderStyle = Windows.Forms.BorderStyle.None
        Me._BorderWidth = 1
    End Sub

    Protected Overrides Sub OnPaintBackground(ByVal e As System.Windows.Forms.PaintEventArgs)
        MyBase.OnPaintBackground(e)
    End Sub

    Protected Overrides Sub OnPaint(ByVal e As PaintEventArgs)
        Dim ar As Rectangle = Me.ClientRectangle
        ar.X += ar.X + Convert.ToInt32(Math.Floor(Me.BorderWidth / 2))
        ar.Y += ar.Y + Convert.ToInt32(Math.Floor(Me.BorderWidth / 2))
        ar.Width -= (Me.BorderWidth + 1)
        ar.Height -= (Me.BorderWidth + 1)
        Dim lr As Rectangle = Me.ClientRectangle
        Dim canArc As Boolean = (ar.Width > 0 AndAlso ar.Height > 0)

        Using gp As New GraphicsPath
            gp.StartFigure()
            If Me.RadiusTopRight > 0 AndAlso canArc = True Then
                Dim w As Integer = If(Me.RadiusTopRight > ar.Width, ar.Width, Me.RadiusTopRight)
                Dim h As Integer = If(Me.RadiusTopRight > ar.Height, ar.Height, Me.RadiusTopRight)
                gp.AddArc(ar.Right - w, ar.Top, w, h, 270, 90)
            Else
                gp.AddLine(lr.Right, lr.Top, lr.Right, lr.Top)
            End If
            If Me.RadiusBottomRight > 0 AndAlso canArc = True Then
                Dim w As Integer = If(Me.RadiusBottomRight > ar.Width, ar.Width, Me.RadiusBottomRight)
                Dim h As Integer = If(Me.RadiusBottomRight > ar.Height, ar.Height, Me.RadiusBottomRight)
                gp.AddArc(ar.Right - w, ar.Bottom - h, w, h, 0, 90)
            Else
                gp.AddLine(lr.Right, lr.Bottom, lr.Right, lr.Bottom)
            End If
            If Me.RadiusBottomLeft > 0 AndAlso canArc = True Then
                Dim w As Integer = If(Me.RadiusBottomLeft > ar.Width, ar.Width, Me.RadiusBottomLeft)
                Dim h As Integer = If(Me.RadiusBottomLeft > ar.Height, ar.Height, Me.RadiusBottomLeft)
                gp.AddArc(ar.Left, ar.Bottom - h, w, h, 90, 90)
            Else
                gp.AddLine(lr.Left, lr.Bottom, lr.Left, lr.Bottom)
            End If

            If Me.RadiusTopLeft > 0 AndAlso canArc = True Then
                Dim w As Integer = If(Me.RadiusTopLeft > ar.Width, ar.Width, Me.RadiusTopLeft)
                Dim h As Integer = If(Me.RadiusTopLeft > ar.Height, ar.Height, Me.RadiusTopLeft)
                gp.AddArc(ar.Left, ar.Top, w, h, 180, 90)
            Else
                gp.AddLine(lr.Left, lr.Top, lr.Left, lr.Top)
            End If
            gp.CloseFigure()

            If canArc = True Then
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias
            End If
            ' 背景を描画
            Using sb As New SolidBrush(Me.BackColor)
                e.Graphics.FillPath(sb, gp)
            End Using
            ' 境界線を描画
            If Me.BorderStyle <> Windows.Forms.BorderStyle.None Then
                Using p As New Pen(Me.BorderColor, Me.BorderWidth)
                    'p.DashStyle = CType(Me.BorderStyle, DashStyle)
                    e.Graphics.DrawPath(p, gp)
                End Using
            End If
            If canArc = True Then
                e.Graphics.SmoothingMode = SmoothingMode.Default
            End If

        End Using

        MyBase.OnPaint(e)
    End Sub

#Region " BackColor "

    Private _BackColor As Color
    Public Shadows Property BackColor() As Color
        Get
            If Me._BackColor <> Color.Empty Then
                Return Me._BackColor
            End If
            If Me.Parent IsNot Nothing Then
                Return Me.Parent.BackColor
            End If

            Return Control.DefaultBackColor
        End Get
        Set(ByVal value As Color)
            Me._BackColor = value
            Me.Invalidate()
        End Set
    End Property

    Public Overrides Sub ResetBackColor()
        Me.BackColor = Color.Empty
    End Sub

    Private Function ShouldSerializeBackColor() As Boolean
        Return Me._BackColor <> Color.Empty
    End Function

#End Region

    Private _BorderColor As Color
    <Category("表示")> _
    <DefaultValue(GetType(Color), "Black")> _
    <Description("コントロールの境界線色を取得または設定します。")> _
    Public Property BorderColor() As Color
        Get
            Return Me._BorderColor
        End Get
        Set(ByVal value As Color)
            Me._BorderColor = value
            Me.Invalidate()
        End Set
    End Property

    Private _BorderStyle As BorderStyle
    <Category("表示")> _
    <DefaultValue(GetType(BorderStyle), "None")> _
    <Description("コントロールの境界線スタイルを取得または設定します。")> _
    Public Shadows Property BorderStyle() As BorderStyle
        Get
            Return Me._BorderStyle
        End Get
        Set(ByVal value As BorderStyle)
            Me._BorderStyle = value
            Me.Invalidate()
        End Set
    End Property

    Private _BorderWidth As Integer
    <Category("表示")> _
    <DefaultValue(1)> _
    <Description("コントロールの境界線の幅を取得または設定します。")> _
    Public Property BorderWidth() As Integer
        Get
            Return Me._BorderWidth
        End Get
        Set(ByVal value As Integer)
            Me._BorderWidth = value
            Me.Invalidate()
        End Set
    End Property

    Private _RadiusTopLeft As Integer
    <Category("表示")> _
    <DefaultValue(0)> _
    <Description("コントロールの左上の角の半径を取得または設定します。")> _
    Public Property RadiusTopLeft() As Integer
        Get
            Return Me._RadiusTopLeft
        End Get
        Set(ByVal value As Integer)
            Me._RadiusTopLeft = value
            Me.Invalidate()
        End Set
    End Property

    Private _RadiusTopRight As Integer
    <Category("表示")> _
    <DefaultValue(0)> _
    <Description("コントロールの右上の角の半径を取得または設定します。")> _
    Public Property RadiusTopRight() As Integer
        Get
            Return Me._RadiusTopRight
        End Get
        Set(ByVal value As Integer)
            Me._RadiusTopRight = value
            Me.Invalidate()
        End Set
    End Property

    Private _RadiusBottomLeft As Integer
    <Category("表示")> _
    <DefaultValue(0)> _
    <Description("コントロールの左下の角の半径を取得または設定します。")> _
    Public Property RadiusBottomLeft() As Integer
        Get
            Return Me._RadiusBottomLeft
        End Get
        Set(ByVal value As Integer)
            Me._RadiusBottomLeft = value
            Me.Invalidate()
        End Set
    End Property

    Private _RadiusBottomRight As Integer
    <Category("表示")> _
    <DefaultValue(0)> _
    <Description("コントロールの右下の角の半径を取得または設定します。")> _
    Public Property RadiusBottomRight() As Integer
        Get
            Return Me._RadiusBottomRight
        End Get
        Set(ByVal value As Integer)
            Me._RadiusBottomRight = value
            Me.Invalidate()
        End Set
    End Property

End Class
