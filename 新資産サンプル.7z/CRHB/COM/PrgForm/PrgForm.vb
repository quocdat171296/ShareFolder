'*****************************************************************************************
'*                                                                                       *
'*  �V�X�e��      ����  �F  �`���~�[�g�Z���^�������Y�Ǘ��V�X�e��                         *
'*  �T�u�V�X�e��  ����  �F  �v���W�F�N�g����                                             *
'*  �v���O����    ����  �F  �i���\�����                                                 *
'*  �v���O����    �h�c  �F  �o�����e�������D����       �@                                *
'*  �@�\�T�v            �F  �������̃��b�Z�[�W��\������                                 *
'*  �쐬���t            �F  �����Q�W�N�@�P���@�U��                                       *
'*  �쐬�Җ�            �F  �V��@��                                                     *
'*  �ύX����            �F  ����    �N    ��    ��                                       *
'*  �ύX�Җ�            �F                                                               *
'*  �ύX���e            �F                                                               *
'*                                                                                       *
'*  All Rights Reserved,Copyright(C) (��)�C�V�_�e�N�m                                    *
'*****************************************************************************************
Imports System

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows �t�H�[�� �f�U�C�i�Ő������ꂽ�R�[�h "

    Public Sub New()
        MyBase.New()

        ' ���̌Ăяo���� Windows �t�H�[�� �f�U�C�i�ŕK�v�ł��B
        InitializeComponent()
    End Sub

    ' Form �� dispose ���I�[�o�[���C�h���ăR���|�[�l���g�ꗗ���������܂��B
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Friend WithEvents pgbr As System.Windows.Forms.ProgressBar
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents lblNowCnt As System.Windows.Forms.Label
    Friend WithEvents lblMaxCnt As System.Windows.Forms.Label
    Friend WithEvents lblPer As System.Windows.Forms.Label
    Friend WithEvents lbl2 As System.Windows.Forms.Label
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents timVis As System.Windows.Forms.Timer

    ' Windows �t�H�[�� �f�U�C�i�ŕK�v�ł��B
    Private components As System.ComponentModel.IContainer

    ' ���� : �ȉ��̃v���V�[�W���́AWindows �t�H�[�� �f�U�C�i�ŕK�v�ł��B
    ' Windows �t�H�[�� �f�U�C�i���g���ĕύX���Ă��������B  
    ' �R�[�h �G�f�B�^�͎g�p���Ȃ��ł��������B
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.pgbr = New System.Windows.Forms.ProgressBar()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.lblNowCnt = New System.Windows.Forms.Label()
        Me.lblMaxCnt = New System.Windows.Forms.Label()
        Me.lblPer = New System.Windows.Forms.Label()
        Me.lbl2 = New System.Windows.Forms.Label()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.timVis = New System.Windows.Forms.Timer(Me.components)
        Me.SuspendLayout()
        '
        'ImageList1
        '
        Me.ImageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.ImageList1.ImageSize = New System.Drawing.Size(16, 16)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        '
        'pgbr
        '
        Me.pgbr.Location = New System.Drawing.Point(11, 80)
        Me.pgbr.Name = "pgbr"
        Me.pgbr.Size = New System.Drawing.Size(305, 23)
        Me.pgbr.TabIndex = 0
        '
        'lblTitle
        '
        Me.lblTitle.Font = New System.Drawing.Font("�l�r �S�V�b�N", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblTitle.Location = New System.Drawing.Point(10, 9)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(305, 22)
        Me.lblTitle.TabIndex = 1
        Me.lblTitle.Text = "�w�w�w�w�w�w"
        '
        'lblNowCnt
        '
        Me.lblNowCnt.Font = New System.Drawing.Font("�l�r �S�V�b�N", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblNowCnt.Location = New System.Drawing.Point(95, 112)
        Me.lblNowCnt.Name = "lblNowCnt"
        Me.lblNowCnt.Size = New System.Drawing.Size(56, 13)
        Me.lblNowCnt.TabIndex = 2
        Me.lblNowCnt.Text = "999,999"
        Me.lblNowCnt.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblNowCnt.Visible = False
        '
        'lblMaxCnt
        '
        Me.lblMaxCnt.Font = New System.Drawing.Font("�l�r �S�V�b�N", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblMaxCnt.Location = New System.Drawing.Point(179, 112)
        Me.lblMaxCnt.Name = "lblMaxCnt"
        Me.lblMaxCnt.Size = New System.Drawing.Size(56, 13)
        Me.lblMaxCnt.TabIndex = 3
        Me.lblMaxCnt.Text = "999,999"
        Me.lblMaxCnt.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblMaxCnt.Visible = False
        '
        'lblPer
        '
        Me.lblPer.AutoSize = True
        Me.lblPer.Font = New System.Drawing.Font("�l�r �S�V�b�N", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblPer.Location = New System.Drawing.Point(158, 112)
        Me.lblPer.Name = "lblPer"
        Me.lblPer.Size = New System.Drawing.Size(14, 13)
        Me.lblPer.TabIndex = 4
        Me.lblPer.Text = "/"
        Me.lblPer.Visible = False
        '
        'lbl2
        '
        Me.lbl2.Font = New System.Drawing.Font("�l�r �S�V�b�N", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lbl2.ForeColor = System.Drawing.Color.Blue
        Me.lbl2.Location = New System.Drawing.Point(12, 44)
        Me.lbl2.Name = "lbl2"
        Me.lbl2.Size = New System.Drawing.Size(305, 22)
        Me.lbl2.TabIndex = 5
        Me.lbl2.Text = "�E�E�E�o�@�́@���E�E�E"
        Me.lbl2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(126, 140)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(71, 26)
        Me.btnCancel.TabIndex = 6
        Me.btnCancel.TabStop = False
        Me.btnCancel.Text = "�L�����Z��"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'timVis
        '
        Me.timVis.Interval = 1000
        '
        'Form1
        '
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(329, 172)
        Me.ControlBox = False
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.lbl2)
        Me.Controls.Add(Me.lblPer)
        Me.Controls.Add(Me.lblMaxCnt)
        Me.Controls.Add(Me.lblNowCnt)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.pgbr)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(1024, 768)
        Me.MinimizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

#End Region
    Dim canflg As Boolean = False
    Dim outkbn As Integer

    ''' <summary>
    ''' �i���\���ݒ�
    ''' </summary>
    ''' <value></value>
    ''' <remarks></remarks>
    Public WriteOnly Property outflg() As Integer
        Set(ByVal outflg As Integer)
            outkbn = outflg

            Select Case outkbn
                Case OUT_GRID
                    lbl2.Text = "�E�E�E�ꗗ�쐬���E�E�E"

                    pgbr.Visible = True
                    lblMaxCnt.Visible = False
                    lblNowCnt.Visible = False
                    lblPer.Visible = False

                    btnCancel.Visible = True
                Case OUT_EXCEL
                    lbl2.Text = "�E�E�EEXCEL�o�͒��E�E�E"

                    pgbr.Visible = False
                    lblMaxCnt.Visible = False
                    lblNowCnt.Visible = False
                    lblPer.Visible = False

                    btnCancel.Visible = False
                Case OUT_PREV
                    lbl2.Text = "�E�E�E����ޭ��o�͒��E�E�E"

                    pgbr.Visible = False
                    lblMaxCnt.Visible = False
                    lblNowCnt.Visible = False
                    lblPer.Visible = False

                    btnCancel.Visible = False
                Case OUT_CSV
                    lbl2.Text = "�E�E�ECSV�o�͒��E�E�E"

                    pgbr.Visible = False
                    lblMaxCnt.Visible = False
                    lblNowCnt.Visible = False
                    lblPer.Visible = False

                    btnCancel.Visible = False
                Case OUT_PRINT
                    lbl2.Text = "�E�E�E������E�E�E"

                    pgbr.Visible = False
                    lblMaxCnt.Visible = False
                    lblNowCnt.Visible = False
                    lblPer.Visible = False

                    btnCancel.Visible = False

                Case Else
                    lbl2.Text = "�E�E�E�������E�E�E"

                    pgbr.Visible = False
                    lblMaxCnt.Visible = False
                    lblNowCnt.Visible = False
                    lblPer.Visible = False

                    btnCancel.Visible = False
            End Select

            Application.DoEvents()
        End Set
    End Property

    ''' <summary>
    ''' �\���^�C�g���ݒ�
    ''' </summary>
    ''' <value></value>
    ''' <remarks></remarks>
    Public WriteOnly Property title() As String
        Set(ByVal ttlnam As String)
            lblTitle.Text = ttlnam
        End Set
    End Property
    ''' <summary>
    ''' �i�����ݒ�/�v���O���X�o�[�X�V����
    ''' </summary>
    ''' <value></value>
    ''' <remarks></remarks>
    Public WriteOnly Property nowcnt() As Integer
        Set(ByVal cnt As Integer)
            lblNowCnt.Text = cnt.ToString("#,0")
            'pgbr.Value = cnt

            With pgbr
                If .Value < cnt Then
                    '�l�𑝂₷��
                    If cnt < .Maximum Then
                        '�ړI�̒l����傫�����Ă���A�ړI�̒l�ɂ���
                        .Value = cnt + 1
                        .Value = cnt
                    Else
                        '�ő�l�ɂ��鎞
                        '�ő�l��1���₵�Ă���A���ɖ߂�
                        .Maximum += 1
                        .Value = cnt + 1
                        .Value = cnt
                        .Maximum -= 1
                    End If
                Else
                    '�l�����炷���́A���̂܂�
                    .Value = cnt
                End If
            End With

            'Application.DoEvents()
        End Set
    End Property

    ''' <summary>
    ''' ������ݒ�
    ''' </summary>
    ''' <value></value>
    ''' <remarks></remarks>
    Public WriteOnly Property maxcnt() As Integer
        Set(ByVal cnt As Integer)
            lblMaxCnt.Text = cnt.ToString("#,0")

            pgbr.Maximum = cnt

            pgbr.Visible = True
        End Set
    End Property
    ''' <summary>
    ''' 
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property cancel() As Boolean
        Get
            Return canflg
        End Get
    End Property

    ''' <summary>
    ''' �N����Load����
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            Me.Enabled = True                                                   '   �t�H�[���g�p��

            Application.DoEvents()

            'Me.TopMost = True
            Me.Show()                                                           '   �t�H�[���̕\�����s��

            timVis.Enabled = True

            'btnCancel.Focus()

            Application.DoEvents()
        Catch ex As Exception

        End Try
    End Sub
    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        canflg = True
    End Sub
    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub timVis_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles timVis.Tick
        If lbl2.Visible = True Then
            lbl2.Visible = False
        Else
            lbl2.Visible = True
        End If

        Application.DoEvents()
    End Sub
End Class
