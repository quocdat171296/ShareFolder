﻿'*****************************************************************************************
'*                                                                                       *
'*  システム      名称  ：  販売管理システム                                             *
'*  サブシステム  名称  ：  システム共通                                                 *
'*  プログラム    名称  ：  システム共通定義ファイル                                     *
'*  モジュール    ＩＤ  ：  ＦＴＰＣ０１０Ｓ．ＶＢ                                       *
'*  機能概要            ：  ＦＴＰ接続用共通モジュール                                   *
'*  作成日付            ：  平成３０年１２月１７日                                       *
'*  作成者名            ：  西野  宏                                                     *
'*  変更履歴            ：  平成    年    月    日                                       *
'*                                                                                       *
'*  All Rights Reserved,Copyright(C) (株)イシダテクノ                                    *
'*****************************************************************************************

Public Module CRCOFTPS
    'Private Declare Function GetProp Lib "user32" Alias "GetPropA" (ByVal hwnd As Long, ByVal lpString As String) As Long
    ''   指定されたメモリブロックの内容をコピーするAPI関数
    'Private Declare Sub CopyMemory Lib "Kernel32" Alias "RtlMoveMemory" (ByRef pDest As Byte, pSource As IntPtr, ByVal ByteLen As Integer)

    'Public FtpSsn As FtpClient                                                          '   FTPセッション情報

    'Public Const FTP_ERR_LOGOUT As Integer = -7000                                                 '   切断エラー


    'Public Sub GPrcInternetStatusCallBack(ByVal hInternet As Long, ByVal dwContext As Long, _
    '    ByVal dwInternetStatus As Long, ByVal lpvStatusInformation As Long, _
    '    ByVal dwStatusInformationLength As Long)

    '    Dim clsFtp As FtpClient
    '    Dim lngBytes As Long
    '    '   コンテキストよりオブジェクトのアドレス取得
    '    Call CopyMemory(clsFtp, dwContext, 4)

    '    If Not clsFtp Is Nothing Then
    '        Call clsFtp.InternetStatusCallBack(hInternet, dwContext, dwInternetStatus, lpvStatusInformation, dwStatusInformationLength)
    '    End If

    '    Call CopyMemory(clsFtp, 0&, 4)
    'End Sub

    ''*****************************************************************************************
    ''*                                                                                       *
    ''*    プロシジャー 名称    ：  FTPサーバ接続サブルーチン                                 *
    ''*    プロシジャー ＩＤ    ：  Ftp_Connect                                               *
    ''*                                                                                       *
    ''*    機能概要             ：  FTPサーバに接続をする                                     *
    ''*                                                                                       *
    ''*    パラメータ   説明    ：  I_ServerNM    サーバー名又はサーバIPｱﾄﾞﾚｽ                 *
    ''*                             I_UserID      ログインユーザ名                            *
    ''*                             I_Passward    ログインパスワード                          *
    ''*                                                                                       *
    ''*    戻り値       説明    ：  処理結果                                                  *
    ''*                                                                                       *
    ''*  All Rights Reserved,Copyright(C) トリオシステムプランズ(株)                          *
    ''*****************************************************************************************
    ''
    'Public Function Ftp_Connect(I_ServerNM As String, I_UserID As String, I_Passward As String, Optional I_lopcnt As Long = 0) As Long
    '    Dim ret As Boolean                                                              '   リターンコード

    '    FtpSsn = New FtpClient

    '    If I_lopcnt = 0 Then
    '        I_lopcnt = 7
    '    End If

    '    ret = True                                                                      '   変数初期化

    '    Do While ret = True                                                             '   制御用ループ
    '        ret = FtpSsn.Connect(I_ServerNM, I_UserID, I_Passward)                      '   FTPサーバーへ接続

    '        If ret = False And I_lopcnt <= 0 Then                                       '   リトライを繰返しても接続を確立できない時
    '            If SysDebug = "DEBUG" Then                                              '   デバッグモード時
    '                '   メッセージを表示
    '                Call MsgBox("接続を確立できません" & vbCrLf & FtpSsn.Response, vbExclamation, "警告")
    '            End If

    '            MsgDat = "接続を確立できません. "

    '            Exit Do                                                                 '   制御ループを抜ける
    '        End If

    '        MsgDat = FtpSsn.Response

    '        If ret = True Then                                                          '   正常取得時
    '            Exit Do                                                                 '   制御用ループを抜ける
    '        End If

    '        I_lopcnt = I_lopcnt - 1                                                     '   リトライカウンタを減らす

    '        ret = True
    '    Loop

    '    If ret = True Then                                                              '   結果が正常時
    '        Ftp_Connect = SUCCESS
    '    Else                                                                            '   結果が異常時
    '        Ftp_Connect = NG
    '    End If
    'End Function

    ''*****************************************************************************************
    ''*                                                                                       *
    ''*    プロシジャー 名称    ：  FTPサーバ切断サブルーチン                                 *
    ''*    プロシジャー ＩＤ    ：  Ftp_DisConnect                                            *
    ''*                                                                                       *
    ''*    機能概要             ：  FTPサーバ接続の切断をする                                 *
    ''*                                                                                       *
    ''*    パラメータ   説明    ：  なし                                                      *
    ''*                                                                                       *
    ''*    戻り値       説明    ：  なし                                                      *
    ''*                                                                                       *
    ''*  All Rights Reserved,Copyright(C) トリオシステムプランズ(株)                          *
    ''*****************************************************************************************
    ''
    'Public Sub Ftp_DisConnect()
    '    FtpSsn.DisConnect()                                                               '   FTPサーバーの切断
    'End Sub
    ''*****************************************************************************************
    ''*                                                                                       *
    ''*    プロシジャー 名称    ：  FTPサーバ内のファイル受信サブルーチン                     *
    ''*    プロシジャー ＩＤ    ：  Ftp_GetFile                                               *
    ''*                                                                                       *
    ''*    機能概要             ：  FTPサーバ内のファイルを受信する(上書き取得）              *
    ''*                                                                                       *
    ''*    パラメータ   説明    ：  I_GetFileName ：FTPｻｰﾊﾞ側取得ファイル名                   *
    ''*                             I_DownFileName：ｸﾗｲｱﾝﾄ側ﾀﾞｳﾝﾛｰﾄﾞﾌｧｲﾙ名                    *
    ''*                                                                                       *
    ''*    戻り値       説明    ：  処理結果                                                  *
    ''*                                                                                       *
    ''*  All Rights Reserved,Copyright(C) トリオシステムプランズ(株)                          *
    ''*****************************************************************************************
    ''
    'Public Function Ftp_GetFile(I_GetFileName As String, I_DownFileName As String) As Long
    '    Dim ret As Boolean                                                          '   リターンコード

    '    ret = True                                                                      '   変数初期化

    '    Do While ret = True                                                             '   制御用ループ

    '        ret = FtpSsn.getfile(I_GetFileName, I_DownFileName)                         '   ファイル取得処理

    '        If ret = False Then                                                         '   処理異常時
    '            If SysDebug = "DEBUG" Then                                              '   デバッグモード時
    '                Call MsgBox(FtpSsn.Response & vbCrLf & "受信ﾌｧｲﾙ：" & I_GetFileName, vbExclamation, "警告")
    '            End If

    '            MsgDat = "ファイル受信エラーです。（受信ﾌｧｲﾙ：" & I_GetFileName & "）"  '   処理結果メッセージセット

    '            Exit Do
    '        End If

    '        MsgDat = FtpSsn.Response                                                    '   処理結果メッセージセット

    '        Exit Do                                                                     '   制御用ループを抜ける
    '    Loop

    '    If ret = True Then                                                              '   結果が正常時
    '        Ftp_GetFile = SUCCESS
    '    Else                                                                            '   結果が異常時
    '        If FtpSsn.IsConnect = True Then                                             '   接続状態を確認（接続中の時）
    '            Ftp_GetFile = NG
    '        Else
    '            Ftp_GetFile = FTP_ERR_LOGOUT                                            '   切断エラーセット
    '        End If
    '    End If
    'End Function

    ''*****************************************************************************************
    ''*                                                                                       *
    ''*    プロシジャー 名称    ：  FTPサーバ内のファイル検索サブルーチン                     *
    ''*    プロシジャー ＩＤ    ：  Ftp_SerFile                                               *
    ''*                                                                                       *
    ''*    機能概要             ：  FTPサーバ内のファイルを検索する                           *
    ''*                                                                                       *
    ''*    パラメータ   説明    ：  I_SerFileName：検索ファイル名                             *
    ''*                             O_GetFileName：該当ファイル名                             *
    ''*                                                                                       *
    ''*    戻り値       説明    ：  検索ヒット件数                                            *
    ''*                                                                                       *
    ''*  All Rights Reserved,Copyright(C) トリオシステムプランズ(株)                          *
    ''*****************************************************************************************
    ''
    'Public Function Ftp_SerFile(I_SerFileName As String, O_GetFileName() As String) As Long
    '    Dim getcnt As Long                                                             '   件数

    '    getcnt = FtpSsn.SearchFile(O_GetFileName, I_SerFileName)                        '   ファイル検索

    '    Ftp_SerFile = getcnt
    'End Function

    ''*****************************************************************************************
    ''*                                                                                       *
    ''*    プロシジャー 名称    ：  FTPサーバ内にファイル転送サブルーチン                     *
    ''*    プロシジャー ＩＤ    ：  Ftp_PutFile                                               *
    ''*                                                                                       *
    ''*    機能概要             ：  FTPサーバ内にファイルを転送する(上書き転送）              *
    ''*                                                                                       *
    ''*    パラメータ   説明    ：  I_PutFileName：ｸﾗｲｱﾝﾄ側転送元ファイル名                   *
    ''*                             I_UpdFileName：FTPｻｰﾊﾞ側転送先ファイル名                  *
    ''*                                                                                       *
    ''*    戻り値       説明    ：  処理結果                                                  *
    ''*                                                                                       *
    ''*  All Rights Reserved,Copyright(C) トリオシステムプランズ(株)                          *
    ''*****************************************************************************************
    ''
    'Public Function Ftp_PutFile(I_PutFileName As String, I_UpdFileName As String) As Long
    '    Dim ret As Boolean                                                          '   リターンコード

    '    ret = True                                                                      '   変数初期化

    '    Do While ret = True                                                             '   制御用ループ
    '        ret = FtpSsn.PutFile(I_PutFileName, I_UpdFileName)                          '   ファイル転送処理

    '        If ret = False Then                                                         '   処理異常時
    '            If SysDebug = "DEBUG" Then                                              '   デバッグモード時
    '                Call MsgBox(FtpSsn.Response & vbCrLf & "転送ﾌｧｲﾙ：" & I_PutFileName, vbExclamation, "警告")
    '            End If

    '            MsgDat = "ファイル送信エラーです。（送信ﾌｧｲﾙ：" & I_PutFileName & "）"  '   処理結果メッセージセット

    '            Exit Do
    '        End If

    '        MsgDat = FtpSsn.Response                                                    '   処理結果メッセージセット

    '        Exit Do                                                                     '   制御用ループを抜ける
    '    Loop

    '    If ret = True Then                                                              '   結果が正常時
    '        Ftp_PutFile = SUCCESS
    '    Else                                                                            '   結果が異常時
    '        If FtpSsn.IsConnect = True Then                                             '   接続状態を確認（接続中の時）
    '            Ftp_PutFile = NG
    '        Else
    '            Ftp_PutFile = FTP_ERR_LOGOUT                                            '   切断エラーセット
    '        End If
    '    End If
    'End Function

    ''*****************************************************************************************
    ''*                                                                                       *
    ''*    プロシジャー 名称    ：  FTPサーバ内ファイル削除サブルーチン                       *
    ''*    プロシジャー ＩＤ    ：  Ftp_DeleteFile                                            *
    ''*                                                                                       *
    ''*    機能概要             ：  FTPサーバ内のファイルを削除                               *
    ''*                                                                                       *
    ''*    パラメータ   説明    ：  I_DelFileName：FTPｻｰﾊﾞ側削除ファイル名                    *
    ''*                                                                                       *
    ''*    戻り値       説明    ：  処理結果                                                  *
    ''*                                                                                       *
    ''*  All Rights Reserved,Copyright(C) トリオシステムプランズ(株)                          *
    ''*****************************************************************************************
    ''
    'Public Function Ftp_DeleteFile(I_DelFileName As String) As Long
    '    Dim ret As Boolean                                                          '   リターンコード

    '    ret = True                                                                      '   変数初期化

    '    Do While ret = True                                                             '   制御用ループ
    '        ret = FtpSsn.DeleteFile(I_DelFileName)                                      '   ファイル削除処理

    '        If ret = False Then                                                         '   処理異常時
    '            If SysDebug = "DEBUG" Then                                              '   デバッグモード時
    '                Call MsgBox(FtpSsn.Response & vbCrLf & "削除ﾌｧｲﾙ：" & I_DelFileName, vbExclamation, "警告")
    '            End If

    '            MsgDat = "ファイル削除エラーです。（転送ﾌｧｲﾙ：" & I_DelFileName & "）"  '   処理結果メッセージセット

    '            Exit Do
    '        End If

    '        MsgDat = FtpSsn.Response                                                    '   処理結果メッセージセット

    '        Exit Do                                                                     '   制御用ループを抜ける
    '    Loop

    '    If ret = True Then                                                              '   結果が正常時
    '        Ftp_DeleteFile = SUCCESS
    '    Else                                                                            '   結果が異常時
    '        If FtpSsn.IsConnect = True Then                                             '   接続状態を確認（接続中の時）
    '            Ftp_DeleteFile = NG
    '        Else
    '            Ftp_DeleteFile = FTP_ERR_LOGOUT                                         '   切断エラーセット
    '        End If
    '    End If
    'End Function

    ''*****************************************************************************************
    ''*                                                                                       *
    ''*    プロシジャー 名称    ：  FTPサーバ内ファイル名変更サブルーチン                     *
    ''*    プロシジャー ＩＤ    ：  Ftp_RenameFile                                            *
    ''*                                                                                       *
    ''*    機能概要             ：  FTPサーバ内のファイル名を変更する                         *
    ''*                                                                                       *
    ''*    パラメータ   説明    ：  I_BeforeFileName：FTPｻｰﾊﾞ側変更前ファイル名               *
    ''*                             I_AfterFileName ：FTPｻｰﾊﾞ側変更後ファイル名               *
    ''*                                                                                       *
    ''*    戻り値       説明    ：  処理結果                                                  *
    ''*                                                                                       *
    ''*  All Rights Reserved,Copyright(C) トリオシステムプランズ(株)                          *
    ''*****************************************************************************************
    ''
    'Public Function Ftp_RenameFile(I_BeforeFileName As String, I_AfterFileName As String) As Long
    '    Dim ret As Boolean                                                          '   リターンコード

    '    ret = True                                                                      '   変数初期化

    '    Do While ret = True                                                             '   制御用ループ
    '        ret = FtpSsn.RenameFile(I_BeforeFileName, I_AfterFileName)                  '   ファイル名変更処理

    '        If ret = False Then                                                         '   処理異常時
    '            If SysDebug = "DEBUG" Then                                              '   デバッグモード時
    '                Call MsgBox(FtpSsn.Response & vbCrLf & "変更前ﾌｧｲﾙ：" & I_BeforeFileName, vbExclamation, "警告")
    '            End If

    '            MsgDat = "ファイル名変更エラーです。（変更前ﾌｧｲﾙ：" & I_BeforeFileName & "）"  '   処理結果メッセージセット

    '            Exit Do
    '        End If

    '        MsgDat = FtpSsn.Response                                                    '   処理結果メッセージセット

    '        Exit Do                                                                     '   制御用ループを抜ける
    '    Loop

    '    If ret = True Then                                                              '   結果が正常時
    '        Ftp_RenameFile = SUCCESS
    '    Else                                                                            '   結果が異常時
    '        If FtpSsn.IsConnect = True Then                                             '   接続状態を確認（接続中の時）
    '            Ftp_RenameFile = NG
    '        Else
    '            Ftp_RenameFile = FTP_ERR_LOGOUT                                         '   切断エラーセット
    '        End If
    '    End If
    'End Function

    ''*****************************************************************************************
    ''*                                                                                       *
    ''*    プロシジャー 名称    ：  FTPサーバ内カレントディレクトリ設定                       *
    ''*    プロシジャー ＩＤ    ：  Ftp_CurrentDir                                            *
    ''*                                                                                       *
    ''*    機能概要             ：  FTPサーバ内のカレントディレクトリを変更する               *
    ''*                                                                                       *
    ''*    パラメータ   説明    ：  I_NewDir：FTPｻｰﾊﾞ側ｶﾚﾝﾄﾃﾞｨﾚｸﾄﾘ                            *
    ''*                                                                                       *
    ''*    戻り値       説明    ：  処理結果                                                  *
    ''*                                                                                       *
    ''*  All Rights Reserved,Copyright(C) トリオシステムプランズ(株)                          *
    ''*****************************************************************************************
    ''
    'Public Function Ftp_CurrentDir(I_NewDir As String) As Long
    '    Dim ret As Boolean                                                          '   リターンコード

    '    ret = True                                                                      '   変数初期化

    '    Do While ret = True                                                             '   制御用ループ
    '        ret = FtpSsn.CurrentDir(I_NewDir)                                           '   カレントディレクトリ変更処理

    '        If ret = False Then                                                         '   処理異常時
    '            If SysDebug = "DEBUG" Then                                              '   デバッグモード時
    '                Call MsgBox(FtpSsn.Response & vbCrLf & "変更ﾃﾞｨﾚｸﾄﾘ：" & I_NewDir, vbExclamation, "警告")
    '            End If

    '            MsgDat = "カレントﾃﾞｨﾚｸﾄﾘ変更エラーです。（変更ﾃﾞｨﾚｸﾄﾘ：" & I_NewDir & "）"  '   処理結果メッセージセット

    '            Exit Do
    '        End If

    '        MsgDat = FtpSsn.Response                                                    '   処理結果メッセージセット

    '        Exit Do                                                                     '   制御用ループを抜ける
    '    Loop

    '    If ret = True Then                                                              '   結果が正常時
    '        Ftp_CurrentDir = SUCCESS
    '    Else                                                                            '   結果が異常時
    '        If FtpSsn.IsConnect = True Then                                             '   接続状態を確認（接続中の時）
    '            Ftp_CurrentDir = NG
    '        Else
    '            Ftp_CurrentDir = FTP_ERR_LOGOUT                                         '   切断エラーセット
    '        End If
    '    End If
    'End Function

End Module
