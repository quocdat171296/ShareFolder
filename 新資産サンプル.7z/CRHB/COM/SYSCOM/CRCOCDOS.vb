﻿'*****************************************************************************************
'*                                                                                       *
'*  システム      名称  ：  販売管理システム                                             *
'*  サブシステム  名称  ：  システム共通                                                 *
'*  プログラム    名称  ：  システム共通定義ファイル                                     *
'*  モジュール    ＩＤ  ：  ＣＲＣＯＣＤＯ．ＶＢ                                         *
'*  機能概要            ：  メール送信用共通モジュール                                   *
'*  作成日付            ：  平成３０年１２月１７日                                       *
'*  作成者名            ：  西野  宏                                                     *
'*  変更履歴            ：  平成    年    月    日                                       *
'*  変更者名            ：                                                               *
'*  変更内容            ：                                                               *
'*  変更履歴            ：                                                               *
'*                                                                                       *
'*  All Rights Reserved,Copyright(C) (株)イシダテクノ                                    *
'*****************************************************************************************

Public Module CRCOCDOS

    ''' <summary>
    ''' E-Mail送信
    ''' </summary>
    ''' <param name="I_ServerNM"></param>
    ''' <param name="I_ServerPort"></param>
    ''' <param name="I_LoginKbn"></param>
    ''' <param name="I_UserID"></param>
    ''' <param name="I_Passward"></param>
    ''' <param name="I_From"></param>
    ''' <param name="I_To"></param>
    ''' <param name="I_CC"></param>
    ''' <param name="I_BCC"></param>
    ''' <param name="I_Subject"></param>
    ''' <param name="I_TextBody"></param>
    ''' <param name="I_Attachment"></param>
    ''' <param name="O_ErrMsg"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function Mail_Send(ByVal I_ServerNM As String, _
                              ByVal I_ServerPort As String, _
                              ByVal I_LoginKbn As String, _
                              ByVal I_UserID As String, _
                              ByVal I_Passward As String, _
                              ByVal I_From As String, _
                              ByVal I_To As String, _
                              ByVal I_CC As String, _
                              ByVal I_BCC As String, _
                              ByVal I_Subject As String, _
                              ByVal I_TextBody As String, _
                              ByVal I_Attachment As String, _
                              ByRef O_ErrMsg As String) As Long

        Dim ret As Long
        Dim sSMTPServer As String
        Dim bSMTP_Flg As Boolean
        Dim sUserName As String
        Dim sPassWord As String
        Dim sFrom As String
        Dim sTO As String
        Dim sCC As String
        Dim sBCC As String
        Dim sSubject As String
        Dim sTextBody As String
        Dim sErrMsg As String

        Dim ipos As Integer

        O_ErrMsg = ""

        ret = 0

        '---メール送信情報取得
        sSMTPServer = I_ServerNM                                                    '   SMTPサーバ

        If I_LoginKbn = "1" Then
            bSMTP_Flg = True
        Else
            bSMTP_Flg = False
        End If

        sUserName = I_UserID                                                        '   SMTPサーバ：認証用ユーザ名
        sPassWord = I_Passward                                                      '   SMTPサーバ：認証用パスワード

        '---メール送信内容取得
        sFrom = I_From                                                              '   差出人
        sTO = I_To                                                                  '   宛先
        sCC = I_CC                                                                  '   CC
        sBCC = I_BCC                                                                '   BCC
        sSubject = I_Subject                                                        '   件名
        sTextBody = I_TextBody                                                      '   本文

        Try
            'JISコード
            Dim enc As System.Text.Encoding = System.Text.Encoding.GetEncoding(932)

            'メッセージの作成
            Dim msg As New System.Net.Mail.MailMessage()
            '件名と本文の文字コードを指定する
            msg.SubjectEncoding = enc
            msg.BodyEncoding = enc

            If Trim(sFrom) <> "" Then
                msg.From = New System.Net.Mail.MailAddress(sFrom)                   '   送信者
            Else
                ret = -1

                O_ErrMsg = "送信者未設定"

                Exit Try
            End If

            If Trim(sTO) <> "" Then
                msg.To.Add(New System.Net.Mail.MailAddress(sTO))                    '   宛先
            End If
            If Trim(sCC) <> "" Then
                msg.CC.Add(New System.Net.Mail.MailAddress(sCC))                    '   CC
            End If
            If Trim(sBCC) <> "" Then
                msg.Bcc.Add(New System.Net.Mail.MailAddress(sBCC))                  '   BCC
            End If

            If Trim(sTO) = "" And Trim(sCC) = "" And Trim(sBCC) = "" Then
                ret = -1

                O_ErrMsg = "送信先未設定"

                Exit Try
            End If

            msg.Subject = sSubject                                                  '   件名
            msg.Body = sTextBody                                                    '   本文

            If I_Attachment <> "" Then
                msg.Attachments.Add(New System.Net.Mail.Attachment(I_Attachment))
            End If

            Dim sc As New System.Net.Mail.SmtpClient()
            'SMTPサーバーなどを設定する
            If Trim(sSMTPServer) <> "" Then
                sc.Host = sSMTPServer
            Else
                ret = -1

                O_ErrMsg = "メールサーバ未設定"

                Exit Try
            End If

            If Trim(I_ServerPort) <> "" Then
                sc.Port = CInt(Val(I_ServerPort))
            Else
                ret = -1

                O_ErrMsg = "サーバポート未設定"

                Exit Try
            End If

            sc.DeliveryMethod = System.Net.Mail.SmtpDeliveryMethod.Network
            'sc.EnableSsl = True
            sc.UseDefaultCredentials = bSMTP_Flg
            If bSMTP_Flg = True Then
                If Trim(sUserName) = "" Then
                    ret = -1

                    O_ErrMsg = "認証用ユーザ未設定"

                    Exit Try
                End If

                If Trim(sPassWord) = "" Then
                    ret = -1

                    O_ErrMsg = "認証用パスワード未設定"

                    Exit Try
                End If

                sc.Credentials = New System.Net.NetworkCredential(sUserName, sPassWord)
            End If

            sc.Send(msg)                                                            '   メッセージを送信する

        Catch
            sErrMsg = Err.Description

            ipos = InStr(sErrMsg, sTO) - 1

            If ipos < 1 Then
                ipos = 1
            End If

            O_ErrMsg = "メール送信でエラーが発生しました。 ｴﾗｰ:" & Mid(sErrMsg, ipos)

            ret = Err.Number

        Finally
        End Try

        Mail_Send = ret
    End Function
End Module
