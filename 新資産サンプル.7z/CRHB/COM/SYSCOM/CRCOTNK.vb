﻿Imports System.Text

Public Module CRCOTNK

    '出荷区分
    Public Const SYKKBN_CKS As String = "0"                                     '   直送
    Public Const SYKKBN_CNT As String = "1"                                     '   センター
    '単価基準日区分
    Public Const TNKKBN_NOU As String = "0"                                     '   納品日
    Public Const TNKKBN_HAT As String = "1"                                     '   発注日


    Public Structure sshtnk
        Private sitnkb As String
        Private sitnsu As Decimal
        Private syzkbn As String
        Private sirtnk As Decimal
        Private sibtnk As Decimal
        Private tannam As String
        Private tabnam As String
        Private syhkbn As String
        Private syhkgn As Decimal
        Private hartim As Decimal
        Private kkknum As String

        Public Property sitnkbDat As String
            Get
                Return sitnkb
            End Get
            Set(value As String)
                sitnkb = value
            End Set
        End Property

        Public Property sitnsuDat As Decimal
            Get
                Return sitnsu
            End Get
            Set(value As Decimal)
                sitnsu = value
            End Set
        End Property

        Public Property syzkbnDat As String
            Get
                Return syzkbn
            End Get
            Set(value As String)
                syzkbn = value
            End Set
        End Property

        Public Property sirtnkDat As Decimal
            Get
                Return sirtnk
            End Get
            Set(value As Decimal)
                sirtnk = value
            End Set
        End Property

        Public Property sibtnkDat As Decimal
            Get
                Return sibtnk
            End Get
            Set(value As Decimal)
                sibtnk = value
            End Set
        End Property

        Public Property tannamDat As String
            Get
                Return tannam
            End Get
            Set(value As String)
                tannam = value
            End Set
        End Property

        Public Property tabnamDat As String
            Get
                Return tabnam
            End Get
            Set(value As String)
                tabnam = value
            End Set
        End Property

        Public Property syhkbnDat As String
            Get
                Return syhkbn
            End Get
            Set(value As String)
                syhkbn = value
            End Set
        End Property

        Public Property syhkgnDat As Decimal
            Get
                Return syhkgn
            End Get
            Set(value As Decimal)
                syhkgn = value
            End Set
        End Property

        Public Property hartimDat As Decimal
            Get
                Return hartim
            End Get
            Set(value As Decimal)
                hartim = value
            End Set
        End Property

        Public Property kkknumDat As String
            Get
                Return kkknum
            End Get
            Set(value As String)
                kkknum = value
            End Set
        End Property

    End Structure

    Public Structure tshtnk
        Private tshnam As String
        Private jytnkb As String
        Private jytnsu As Decimal
        Private syzkbn As String
        Private hantnk As Decimal
        Private habtnk As Decimal
        Private tentnk As Decimal
        Private tebtnk As Decimal
        Private tannam As String
        Private tabnam As String
        Private sircod As String
        Private tricod As String
        Private stncod As String
        Private kbngrp As String
        Private kbncod As String
        Private kkknum As String

        Public Property tshnamDat As String
            Get
                Return tshnam
            End Get
            Set(value As String)
                tshnam = value
            End Set
        End Property

        Public Property jytnkbDat As String
            Get
                Return jytnkb
            End Get
            Set(value As String)
                jytnkb = value
            End Set
        End Property

        Public Property jytnsuDat As Decimal
            Get
                Return jytnsu
            End Get
            Set(value As Decimal)
                jytnsu = value
            End Set
        End Property

        Public Property syzkbnDat As String
            Get
                Return syzkbn
            End Get
            Set(value As String)
                syzkbn = value
            End Set
        End Property

        Public Property hantnkDat As Decimal
            Get
                Return hantnk
            End Get
            Set(value As Decimal)
                hantnk = value
            End Set
        End Property

        Public Property habtnkDat As Decimal
            Get
                Return habtnk
            End Get
            Set(value As Decimal)
                habtnk = value
            End Set
        End Property

        Public Property tentnkDat As Decimal
            Get
                Return tentnk
            End Get
            Set(value As Decimal)
                tentnk = value
            End Set
        End Property

        Public Property tebtnkDat As Decimal
            Get
                Return tebtnk
            End Get
            Set(value As Decimal)
                tebtnk = value
            End Set
        End Property

        Public Property tannamDat As String
            Get
                Return tannam
            End Get
            Set(value As String)
                tannam = value
            End Set
        End Property

        Public Property tabnamDat As String
            Get
                Return tabnam
            End Get
            Set(value As String)
                tabnam = value
            End Set
        End Property

        Public Property sircodDat As String
            Get
                Return sircod
            End Get
            Set(value As String)
                sircod = value
            End Set
        End Property

        Public Property tricodDat As String
            Get
                Return tricod
            End Get
            Set(value As String)
                tricod = value
            End Set
        End Property

        Public Property stncodDat As String
            Get
                Return stncod
            End Get
            Set(value As String)
                stncod = value
            End Set
        End Property

        Public Property kbngrpDat As String
            Get
                Return kbngrp
            End Get
            Set(value As String)
                kbngrp = value
            End Set
        End Property

        Public Property kbncodDat As String
            Get
                Return kbncod
            End Get
            Set(value As String)
                kbncod = value
            End Set
        End Property

        Public Property kkknumDat As String
            Get
                Return kkknum
            End Get
            Set(value As String)
                kkknum = value
            End Set
        End Property

    End Structure


    '---------------------------------------------------------------------------------------------------------
    '単価取得処理改定＆共有版
    '---------------------------------------------------------------------------------------------------------

    ''' <summary>
    ''' 販売単価取得処理
    ''' </summary>
    ''' <param name="I_TokCod">客先コード</param>
    ''' <param name="I_ShoCod">商品コード</param>
    ''' <param name="I_Jyuday">受注日</param>
    ''' <param name="I_Nouday">納品日</param>
    ''' <param name="I_BraSuu">バラ数</param>
    ''' <param name="I_BmnCod">部門コード</param>
    ''' <param name="I_SswCod">勘定科目コード</param>
    ''' <param name="I_TksCod">客先支店コード</param>
    ''' <param name="I_DatKbn">受注区分</param>
    ''' <param name="O_TnkCnt">単価件数</param>
    ''' <param name="O_TshTnk">販売単価</param>
    ''' <returns>実行結果区分</returns>
    ''' <remarks>販売単価テーブルから単価情報を取得する</remarks>
    Public Function Com_DbGetHtk(ByVal I_TokCod As String, ByVal I_ShoCod As String, ByVal I_Jyuday As String, _
                                  ByVal I_Nouday As String, ByVal I_BraSuu As Decimal, ByVal I_BmnCod As String, _
                                  ByVal I_SswCod As String, ByVal I_TksCod As String, ByVal I_DatKbn As String, _
                                  ByRef O_TnkCnt As Integer, ByRef O_TshTnk As tshtnk) As Long

        Dim _ret As Long                                                              '   リターンコード
        Dim cnt As Integer
        Dim sykkbn As String
        Dim nouday As String
        Dim oradyn As System.Data.Common.DbDataReader = Nothing
        Dim blnFound As Boolean

        Dim Com_AreCod As String = vbNullString
        Dim Com_SttCod As String = vbNullString
        Dim Com_TnkKbn As String = vbNullString

        O_TnkCnt = 0
        O_TshTnk = New tshtnk
        blnFound = False

        Try

            cnt = 0

            '客先マスタより単価基準日区分を取得
            SqlBuf = New StringBuilder
            SqlBuf.Append("SELECT                                           " & vbCrLf)     ' 
            SqlBuf.Append("    TOK_NOUKBN                                   " & vbCrLf)     '
            SqlBuf.Append("FROM                                             " & vbCrLf)     '
            SqlBuf.Append("    TOKMAST                                      " & vbCrLf)     '
            SqlBuf.Append("WHERE                                            " & vbCrLf)     '
            SqlBuf.Append("    TOK_TOKCOD = :tokcod                         " & vbCrLf)     '

            ' パラメータ組立
            ' --------------------------------------------------
            Call Ora_ParmRemAll()

            Call Ora_CreateParmString("tokcod", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成

            Call Ora_SetParmTable("tokcod", 0, I_TokCod)                              '   キーセット

            _ret = Ora_DbOneReadSqlEx(oradyn, SqlBuf.ToString)                        '   ＳＱＬ発行

            Select Case _ret                                                          '   ＳＱＬ発行チェック
                Case ORA_FOUNDREC                                                     '   ＳＱＬ正常発行の場合

                    Do While oradyn.Read = True
                        Com_TnkKbn = Trim(Com_NulCut(oradyn("TOK_NOUKBN")))
                    Loop

                    ' パラメータ消去
                    ' --------------------------------------------------
                    Call Ora_ParmRemAll()

                    ' リーダークローズ
                    ' --------------------------------------------------
                    oradyn.Close()

                Case ORA_NOTFOUND                                                     '   取得データなしの場合
                    ' パラメータ消去
                    ' --------------------------------------------------
                    Call Ora_ParmRemAll()

                    Com_TnkKbn = TNKKBN_HAT

                    oradyn.Close()
                    oradyn.Dispose()
                    oradyn = Nothing
            End Select

            '客先支店マスタより都道府県を取得
            SqlBuf = New StringBuilder
            SqlBuf.Append("SELECT                                           " & vbCrLf)     ' 
            SqlBuf.Append("    TKS_STTCOD                                   " & vbCrLf)     '
            SqlBuf.Append("FROM                                             " & vbCrLf)     '
            SqlBuf.Append("    TKSMAST                                      " & vbCrLf)     '
            SqlBuf.Append("WHERE                                            " & vbCrLf)     '
            SqlBuf.Append("    TKS_TOKCOD = :tokcod                         " & vbCrLf)     '
            SqlBuf.Append("AND TKS_TKSCOD = :tkscod                         " & vbCrLf)     '

            ' パラメータ組立
            ' --------------------------------------------------
            Call Ora_ParmRemAll()

            Call Ora_CreateParmString("tokcod", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
            Call Ora_CreateParmString("tkscod", ORAPARM_INPUT, 1, 5, ORA_EXEC_NORMAL) '   データ取得パラメータ作成

            Call Ora_SetParmTable("tokcod", 0, I_TokCod)                              '   キーセット
            Call Ora_SetParmTable("tkscod", 0, I_TksCod)                              '   キーセット

            _ret = Ora_DbOneReadSqlEx(oradyn, SqlBuf.ToString)                        '   ＳＱＬ発行

            Select Case _ret                                                          '   ＳＱＬ発行チェック
                Case ORA_FOUNDREC                                                     '   ＳＱＬ正常発行の場合

                    Do While oradyn.Read = True
                        Com_SttCod = Trim(Com_NulCut(oradyn("TKS_STTCOD")))
                    Loop

                    ' パラメータ消去
                    ' --------------------------------------------------
                    Call Ora_ParmRemAll()

                    ' リーダークローズ
                    ' --------------------------------------------------
                    oradyn.Close()

                Case ORA_NOTFOUND                                                     '   取得データなしの場合
                    ' パラメータ消去
                    ' --------------------------------------------------
                    Call Ora_ParmRemAll()

                    Com_SttCod = "000"

                    oradyn.Close()
                    oradyn.Dispose()
                    oradyn = Nothing
            End Select

            '物流エリアテーブルより物流エリアを取得
            SqlBuf = New StringBuilder
            SqlBuf.Append("SELECT                                           " & vbCrLf)     ' 
            SqlBuf.Append("    BAG_ARECOD                                   " & vbCrLf)     '
            SqlBuf.Append("FROM                                             " & vbCrLf)     '
            SqlBuf.Append("    BAGTABL                                      " & vbCrLf)     '
            SqlBuf.Append("WHERE                                            " & vbCrLf)     '
            SqlBuf.Append("    BAG_TOKCOD = :tokcod1                        " & vbCrLf)     '
            SqlBuf.Append("AND BAG_TKSCOD = :tkscod1                        " & vbCrLf)     '
            SqlBuf.Append("AND BAG_STRDAY In (                              " & vbCrLf)     '
            SqlBuf.Append("        SELECT                                   " & vbCrLf)     ' 
            SqlBuf.Append("            MAX(BAG_STRDAY)                      " & vbCrLf)     '
            SqlBuf.Append("        FROM                                     " & vbCrLf)     '
            SqlBuf.Append("            BAGTABL                              " & vbCrLf)     '
            SqlBuf.Append("        WHERE                                    " & vbCrLf)     '
            SqlBuf.Append("            BAG_TOKCOD  = :tokcod2                " & vbCrLf)     '
            SqlBuf.Append("        AND BAG_TKSCOD  = :tkscod2                " & vbCrLf)     '
            SqlBuf.Append("        AND BAG_STRDAY <= :nouday                " & vbCrLf)     '
            SqlBuf.Append("    )                                            " & vbCrLf)     '

            ' パラメータ組立
            ' --------------------------------------------------
            Call Ora_ParmRemAll()

            Call Ora_CreateParmString("tokcod1", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
            Call Ora_CreateParmString("tkscod1", ORAPARM_INPUT, 1, 5, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
            Call Ora_CreateParmString("tokcod2", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
            Call Ora_CreateParmString("tkscod2", ORAPARM_INPUT, 1, 5, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
            Call Ora_CreateParmString("nouday", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成

            Call Ora_SetParmTable("tokcod1", 0, I_TokCod)                              '   キーセット
            Call Ora_SetParmTable("tkscod1", 0, I_TksCod)                              '   キーセット
            Call Ora_SetParmTable("tokcod2", 0, I_TokCod)                              '   キーセット
            Call Ora_SetParmTable("tkscod2", 0, I_TksCod)                              '   キーセット
            Call Ora_SetParmTable("nouday", 0, I_Nouday)                               '   キーセット

            _ret = Ora_DbOneReadSqlEx(oradyn, SqlBuf.ToString)                        '   ＳＱＬ発行

            Select Case _ret                                                          '   ＳＱＬ発行チェック
                Case ORA_FOUNDREC                                                     '   ＳＱＬ正常発行の場合

                    Do While oradyn.Read = True
                        Com_AreCod = Trim(Com_NulCut(oradyn("BAG_ARECOD")))
                    Loop

                    ' パラメータ消去
                    ' --------------------------------------------------
                    Call Ora_ParmRemAll()

                    ' リーダークローズ
                    ' --------------------------------------------------
                    oradyn.Close()

                Case ORA_NOTFOUND                                                     '   取得データなしの場合
                    ' パラメータ消去
                    ' --------------------------------------------------
                    Call Ora_ParmRemAll()

                    Com_AreCod = "000"

                    oradyn.Close()
                    oradyn.Dispose()
                    oradyn = Nothing
            End Select

            If I_DatKbn = DATKBN_EOS Or _
               I_DatKbn = DATKBN_FAX Then
                sykkbn = SYKKBN_CKS
            ElseIf I_DatKbn = DATKBN_SYU Then
                sykkbn = SYKKBN_CNT
            Else
                sykkbn = SYKKBN_CKS
            End If

            If Com_TnkKbn = TNKKBN_HAT Then
                nouday = I_Jyuday
            Else
                nouday = I_Nouday
            End If


            If blnFound = False Then
                SqlBuf = New StringBuilder
                SqlBuf.Append("SELECT                                           " & vbCrLf)     '
                SqlBuf.Append("    WRK_PRIORY ,                                 " & vbCrLf)     '
                SqlBuf.Append("    HTS_HANTNK ,                                 " & vbCrLf)     '
                SqlBuf.Append("    HTS_TENTNK ,                                 " & vbCrLf)     '
                SqlBuf.Append("    HTS_HNBTNK ,                                 " & vbCrLf)     '
                SqlBuf.Append("    HTS_TNBTNK ,                                 " & vbCrLf)     '
                SqlBuf.Append("    HTS_KKKNUM                                   " & vbCrLf)     '
                SqlBuf.Append("FROM                                             " & vbCrLf)     '
                '(3)客先店舗一致・勘定科目一致・客先部門一致
                SqlBuf.Append("    (                                            " & vbCrLf)     '
                SqlBuf.Append("        SELECT                                   " & vbCrLf)     '
                SqlBuf.Append("            1 As WRK_PRIORY ,                    " & vbCrLf)     '
                SqlBuf.Append("            HTS_HANTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TENTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_HNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_KKKNUM                           " & vbCrLf)     '
                SqlBuf.Append("        FROM                                     " & vbCrLf)     '
                SqlBuf.Append("            (                                    " & vbCrLf)     '
                SqlBuf.Append("                SELECT                           " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HANTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TENTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_KKKNUM                   " & vbCrLf)     '
                SqlBuf.Append("                FROM                             " & vbCrLf)     '
                SqlBuf.Append("                    HTSTABL                      " & vbCrLf)     '
                SqlBuf.Append("                WHERE                            " & vbCrLf)     '
                SqlBuf.Append("                    HTS_SYKKBN = :sykKbn_1       " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SHOCOD = :shocod_1       " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUKBN = '3'             " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD1 = :tokcod_1       " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD2 = :tkscod_1       " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_BMNCOD IN (:bmncod_1)    " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SSWCOD IN (:sswcod_1)    " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_STRDAY <= :strday_1      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_ENDDAY >= :endday_1      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MINSUU <= :minsuu_1      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MAXSUU >= :maxsuu_1      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_DELFLG = '" & DELFLG_NOT & "' " & vbCrLf) '
                SqlBuf.Append("            )                                    " & vbCrLf)     '
                SqlBuf.Append("    )                                            " & vbCrLf)     '
                '(3)客先店舗一致・勘定科目一致・客先部門ALL
                SqlBuf.Append("    UNION ALL (                                  " & vbCrLf)     '
                SqlBuf.Append("        SELECT                                   " & vbCrLf)     '
                SqlBuf.Append("            2 As WRK_PRIORY ,                    " & vbCrLf)     '
                SqlBuf.Append("            HTS_HANTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TENTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_HNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_KKKNUM                           " & vbCrLf)     '
                SqlBuf.Append("        FROM                                     " & vbCrLf)     '
                SqlBuf.Append("            (                                    " & vbCrLf)     '
                SqlBuf.Append("                SELECT                           " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HANTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TENTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_KKKNUM                   " & vbCrLf)     '
                SqlBuf.Append("                FROM                             " & vbCrLf)     '
                SqlBuf.Append("                    HTSTABL                      " & vbCrLf)     '
                SqlBuf.Append("                WHERE                            " & vbCrLf)     '
                SqlBuf.Append("                    HTS_SYKKBN = :sykKbn_2       " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SHOCOD = :shocod_2       " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUKBN = '3'             " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD1 = :tokcod_2       " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD2 = :tkscod_2       " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_BMNCOD IN ('0000')       " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SSWCOD IN (:sswcod_2)    " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_STRDAY <= :strday_2      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_ENDDAY >= :endday_2      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MINSUU <= :minsuu_2      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MAXSUU >= :maxsuu_2      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_DELFLG = '" & DELFLG_NOT & "' " & vbCrLf) '
                SqlBuf.Append("            )                                    " & vbCrLf)     '
                SqlBuf.Append("    )                                            " & vbCrLf)     '
                '(3)客先店舗一致・勘定科目ALL・客先部門一致
                SqlBuf.Append("    UNION ALL (                                  " & vbCrLf)     '
                SqlBuf.Append("        SELECT                                   " & vbCrLf)     '
                SqlBuf.Append("            3 As WRK_PRIORY ,                    " & vbCrLf)     '
                SqlBuf.Append("            HTS_HANTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TENTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_HNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_KKKNUM                           " & vbCrLf)     '
                SqlBuf.Append("        FROM                                     " & vbCrLf)     '
                SqlBuf.Append("            (                                    " & vbCrLf)     '
                SqlBuf.Append("                SELECT                           " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HANTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TENTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_KKKNUM                   " & vbCrLf)     '
                SqlBuf.Append("                FROM                             " & vbCrLf)     '
                SqlBuf.Append("                    HTSTABL                      " & vbCrLf)     '
                SqlBuf.Append("                WHERE                            " & vbCrLf)     '
                SqlBuf.Append("                    HTS_SYKKBN = :sykKbn_3       " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SHOCOD = :shocod_3       " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUKBN = '3'             " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD1 = :tokcod_3       " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD2 = :tkscod_3       " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_BMNCOD IN (:bmncod_3)    " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SSWCOD IN ('00')         " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_STRDAY <= :strday_3      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_ENDDAY >= :endday_3      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MINSUU <= :minsuu_3      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MAXSUU >= :maxsuu_3      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_DELFLG = '" & DELFLG_NOT & "' " & vbCrLf) '
                SqlBuf.Append("            )                                    " & vbCrLf)     '
                SqlBuf.Append("    )                                            " & vbCrLf)     '
                '(3)客先店舗一致・勘定科目ALL・客先部門ALL
                SqlBuf.Append("    UNION ALL (                                  " & vbCrLf)     '
                SqlBuf.Append("        SELECT                                   " & vbCrLf)     '
                SqlBuf.Append("            4 As WRK_PRIORY ,                    " & vbCrLf)     '
                SqlBuf.Append("            HTS_HANTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TENTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_HNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_KKKNUM                           " & vbCrLf)     '
                SqlBuf.Append("        FROM                                     " & vbCrLf)     '
                SqlBuf.Append("            (                                    " & vbCrLf)     '
                SqlBuf.Append("                SELECT                           " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HANTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TENTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_KKKNUM                   " & vbCrLf)     '
                SqlBuf.Append("                FROM                             " & vbCrLf)     '
                SqlBuf.Append("                    HTSTABL                      " & vbCrLf)     '
                SqlBuf.Append("                WHERE                            " & vbCrLf)     '
                SqlBuf.Append("                    HTS_SYKKBN = :sykKbn_4       " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SHOCOD = :shocod_4       " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUKBN = '3'             " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD1 = :tokcod_4       " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD2 = :tkscod_4       " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_BMNCOD IN ('0000')       " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SSWCOD IN ('00')         " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_STRDAY <= :strday_4      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_ENDDAY >= :endday_4      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MINSUU <= :minsuu_4      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MAXSUU >= :maxsuu_4      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_DELFLG = '" & DELFLG_NOT & "' " & vbCrLf) '
                SqlBuf.Append("            )                                    " & vbCrLf)     '
                SqlBuf.Append("    )                                            " & vbCrLf)     '
                '(0)客先一致・勘定科目一致・客先部門一致
                SqlBuf.Append("    UNION ALL (                                  " & vbCrLf)     '
                SqlBuf.Append("        SELECT                                   " & vbCrLf)     '
                SqlBuf.Append("            5 As WRK_PRIORY ,                    " & vbCrLf)     '
                SqlBuf.Append("            HTS_HANTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TENTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_HNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_KKKNUM                           " & vbCrLf)     '
                SqlBuf.Append("        FROM                                     " & vbCrLf)     '
                SqlBuf.Append("            (                                    " & vbCrLf)     '
                SqlBuf.Append("                SELECT                           " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HANTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TENTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_KKKNUM                   " & vbCrLf)     '
                SqlBuf.Append("                FROM                             " & vbCrLf)     '
                SqlBuf.Append("                    HTSTABL                      " & vbCrLf)     '
                SqlBuf.Append("                WHERE                            " & vbCrLf)     '
                SqlBuf.Append("                    HTS_SYKKBN = :sykKbn_5       " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SHOCOD = :shocod_5       " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUKBN = '0'             " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD1 = :tokcod_5       " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD2 = '00000'         " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_BMNCOD IN (:bmncod_5)    " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SSWCOD IN (:sswcod_5)    " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_STRDAY <= :strday_5      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_ENDDAY >= :endday_5      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MINSUU <= :minsuu_5      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MAXSUU >= :maxsuu_5      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_DELFLG = '" & DELFLG_NOT & "' " & vbCrLf) '
                SqlBuf.Append("            )                                    " & vbCrLf)     '
                SqlBuf.Append("    )                                            " & vbCrLf)     '
                '(0)客先一致・勘定科目一致・客先部門ALL
                SqlBuf.Append("    UNION ALL (                                  " & vbCrLf)     '
                SqlBuf.Append("        SELECT                                   " & vbCrLf)     '
                SqlBuf.Append("            6 As WRK_PRIORY ,                    " & vbCrLf)     '
                SqlBuf.Append("            HTS_HANTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TENTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_HNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_KKKNUM                           " & vbCrLf)     '
                SqlBuf.Append("        FROM                                     " & vbCrLf)     '
                SqlBuf.Append("            (                                    " & vbCrLf)     '
                SqlBuf.Append("                SELECT                           " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HANTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TENTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_KKKNUM                   " & vbCrLf)     '
                SqlBuf.Append("                FROM                             " & vbCrLf)     '
                SqlBuf.Append("                    HTSTABL                      " & vbCrLf)     '
                SqlBuf.Append("                WHERE                            " & vbCrLf)     '
                SqlBuf.Append("                    HTS_SYKKBN = :sykKbn_6       " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SHOCOD = :shocod_6       " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUKBN = '0'             " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD1 = :tokcod_6       " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD2 = '00000'         " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_BMNCOD IN ('0000')       " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SSWCOD IN (:sswcod_6)    " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_STRDAY <= :strday_6      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_ENDDAY >= :endday_6      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MINSUU <= :minsuu_6      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MAXSUU >= :maxsuu_6      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_DELFLG = '" & DELFLG_NOT & "' " & vbCrLf) '
                SqlBuf.Append("            )                                    " & vbCrLf)     '
                SqlBuf.Append("    )                                            " & vbCrLf)     '
                '(0)客先一致・勘定科目ALL・客先部門一致
                SqlBuf.Append("    UNION ALL (                                  " & vbCrLf)     '
                SqlBuf.Append("        SELECT                                   " & vbCrLf)     ' 
                SqlBuf.Append("            7 As WRK_PRIORY ,                    " & vbCrLf)     '
                SqlBuf.Append("            HTS_HANTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TENTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_HNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_KKKNUM                           " & vbCrLf)     '
                SqlBuf.Append("        FROM                                     " & vbCrLf)     '
                SqlBuf.Append("            (                                    " & vbCrLf)     '
                SqlBuf.Append("                SELECT                           " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HANTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TENTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_KKKNUM                   " & vbCrLf)     '
                SqlBuf.Append("                FROM                             " & vbCrLf)     '
                SqlBuf.Append("                    HTSTABL                      " & vbCrLf)     '
                SqlBuf.Append("                WHERE                            " & vbCrLf)     '
                SqlBuf.Append("                    HTS_SYKKBN = :sykKbn_7       " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SHOCOD = :shocod_7       " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUKBN = '0'             " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD1 = :tokcod_7       " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD2 = '00000'         " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_BMNCOD IN (:bmncod_7)    " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SSWCOD IN ('00')         " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_STRDAY <= :strday_7      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_ENDDAY >= :endday_7      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MINSUU <= :minsuu_7      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MAXSUU >= :maxsuu_7      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_DELFLG = '" & DELFLG_NOT & "' " & vbCrLf) '
                SqlBuf.Append("            )                                    " & vbCrLf)     '
                SqlBuf.Append("    )                                            " & vbCrLf)     '
                '(0)客先一致・勘定科目ALL・客先部門ALL
                SqlBuf.Append("    UNION ALL (                                  " & vbCrLf)     '
                SqlBuf.Append("        SELECT                                   " & vbCrLf)     ' 
                SqlBuf.Append("            8 As WRK_PRIORY ,                    " & vbCrLf)     '
                SqlBuf.Append("            HTS_HANTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TENTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_HNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_KKKNUM                           " & vbCrLf)     '
                SqlBuf.Append("        FROM                                     " & vbCrLf)     '
                SqlBuf.Append("            (                                    " & vbCrLf)     '
                SqlBuf.Append("                SELECT                           " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HANTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TENTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_KKKNUM                   " & vbCrLf)     '
                SqlBuf.Append("                FROM                             " & vbCrLf)     '
                SqlBuf.Append("                    HTSTABL                      " & vbCrLf)     '
                SqlBuf.Append("                WHERE                            " & vbCrLf)     '
                SqlBuf.Append("                    HTS_SYKKBN = :sykKbn_8       " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SHOCOD = :shocod_8       " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUKBN = '0'             " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD1 = :tokcod_8       " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD2 = '00000'         " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_BMNCOD IN ('0000')       " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SSWCOD IN ('00')         " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_STRDAY <= :strday_8      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_ENDDAY >= :endday_8      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MINSUU <= :minsuu_8      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MAXSUU >= :maxsuu_8      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_DELFLG = '" & DELFLG_NOT & "' " & vbCrLf) '
                SqlBuf.Append("            )                                    " & vbCrLf)     '
                SqlBuf.Append("    )                                            " & vbCrLf)     '
                '(2)客先エリア一致・勘定科目一致・客先部門一致
                SqlBuf.Append("    UNION ALL (                                  " & vbCrLf)     '
                SqlBuf.Append("        SELECT                                   " & vbCrLf)     '
                SqlBuf.Append("            9 As WRK_PRIORY ,                    " & vbCrLf)     '
                SqlBuf.Append("            HTS_HANTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TENTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_HNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_KKKNUM                           " & vbCrLf)     '
                SqlBuf.Append("        FROM                                     " & vbCrLf)     '
                SqlBuf.Append("            (                                    " & vbCrLf)     '
                SqlBuf.Append("                SELECT                           " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HANTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TENTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_KKKNUM                   " & vbCrLf)     '
                SqlBuf.Append("                FROM                             " & vbCrLf)     '
                SqlBuf.Append("                    HTSTABL                      " & vbCrLf)     '
                SqlBuf.Append("                WHERE                            " & vbCrLf)     '
                SqlBuf.Append("                    HTS_SYKKBN = :sykKbn2_9      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SHOCOD = :shocod2_9      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUKBN = '2'             " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD1 = :tokcod2_9      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD2 = '00' || :arecod_9 " & vbCrLf)  '
                SqlBuf.Append("                AND HTS_BMNCOD IN (:bmncod2_9)   " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SSWCOD IN (:sswcod2_9)   " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_STRDAY <= :strday2_9     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_ENDDAY >= :endday2_9     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MINSUU <= :minsuu2_9     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MAXSUU >= :maxsuu2_9     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_DELFLG = '" & DELFLG_NOT & "' " & vbCrLf) '
                SqlBuf.Append("            )                                    " & vbCrLf)     '
                SqlBuf.Append("    )                                            " & vbCrLf)     '
                '(2)客先エリア一致・勘定科目一致・客先部門ALL
                SqlBuf.Append("    UNION ALL (                                  " & vbCrLf)     '
                SqlBuf.Append("        SELECT                                   " & vbCrLf)     '
                SqlBuf.Append("            10 As WRK_PRIORY ,                   " & vbCrLf)     '
                SqlBuf.Append("            HTS_HANTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TENTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_HNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_KKKNUM                           " & vbCrLf)     '
                SqlBuf.Append("        FROM                                     " & vbCrLf)     '
                SqlBuf.Append("            (                                    " & vbCrLf)     '
                SqlBuf.Append("                SELECT                           " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HANTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TENTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_KKKNUM                   " & vbCrLf)     '
                SqlBuf.Append("                FROM                             " & vbCrLf)     '
                SqlBuf.Append("                    HTSTABL                      " & vbCrLf)     '
                SqlBuf.Append("                WHERE                            " & vbCrLf)     '
                SqlBuf.Append("                    HTS_SYKKBN = :sykKbn2_10     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SHOCOD = :shocod2_10     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUKBN = '2'             " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD1 = :tokcod2_10     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD2 = '00' || :arecod_10 " & vbCrLf) '
                SqlBuf.Append("                AND HTS_BMNCOD IN ('0000')       " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SSWCOD IN (:sswcod2_10)  " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_STRDAY <= :strday2_10    " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_ENDDAY >= :endday2_10    " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MINSUU <= :minsuu2_10    " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MAXSUU >= :maxsuu2_10    " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_DELFLG = '" & DELFLG_NOT & "' " & vbCrLf) '
                SqlBuf.Append("            )                                    " & vbCrLf)     '
                SqlBuf.Append("    )                                            " & vbCrLf)     '
                '(2)客先エリア一致・勘定科目ALL・客先部門一致
                SqlBuf.Append("    UNION ALL (                                  " & vbCrLf)     '
                SqlBuf.Append("        SELECT                                   " & vbCrLf)     ' 
                SqlBuf.Append("            11 As WRK_PRIORY ,                   " & vbCrLf)     '
                SqlBuf.Append("            HTS_HANTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TENTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_HNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_KKKNUM                           " & vbCrLf)     '
                SqlBuf.Append("        FROM                                     " & vbCrLf)     '
                SqlBuf.Append("            (                                    " & vbCrLf)     '
                SqlBuf.Append("                SELECT                           " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HANTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TENTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_KKKNUM                   " & vbCrLf)     '
                SqlBuf.Append("                FROM                             " & vbCrLf)     '
                SqlBuf.Append("                    HTSTABL                      " & vbCrLf)     '
                SqlBuf.Append("                WHERE                            " & vbCrLf)     '
                SqlBuf.Append("                    HTS_SYKKBN = :sykKbn2_11     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SHOCOD = :shocod2_11     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUKBN = '2'             " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD1 = :tokcod2_11     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD2 = '00' || :arecod_11 " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_BMNCOD IN (:bmncod2_11)  " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SSWCOD IN ('00')         " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_STRDAY <= :strday2_11    " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_ENDDAY >= :endday2_11    " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MINSUU <= :minsuu2_11    " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MAXSUU >= :maxsuu2_11    " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_DELFLG = '" & DELFLG_NOT & "' " & vbCrLf)     '
                SqlBuf.Append("            )                                    " & vbCrLf)     '
                SqlBuf.Append("    )                                            " & vbCrLf)     '
                '(2)客先エリア一致・勘定科目ALL・客先部門ALL
                SqlBuf.Append("    UNION ALL (                                  " & vbCrLf)     '
                SqlBuf.Append("        SELECT                                   " & vbCrLf)     ' 
                SqlBuf.Append("            12 As WRK_PRIORY ,                   " & vbCrLf)     '
                SqlBuf.Append("            HTS_HANTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TENTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_HNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_KKKNUM                           " & vbCrLf)     '
                SqlBuf.Append("        FROM                                     " & vbCrLf)     '
                SqlBuf.Append("            (                                    " & vbCrLf)     '
                SqlBuf.Append("                SELECT                           " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HANTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TENTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_KKKNUM                   " & vbCrLf)     '
                SqlBuf.Append("                FROM                             " & vbCrLf)     '
                SqlBuf.Append("                    HTSTABL                      " & vbCrLf)     '
                SqlBuf.Append("                WHERE                            " & vbCrLf)     '
                SqlBuf.Append("                    HTS_SYKKBN = :sykKbn2_12     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SHOCOD = :shocod2_12     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUKBN = '2'             " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD1 = :tokcod2_12     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD2 = '00' || :arecod_12 " & vbCrLf) '
                SqlBuf.Append("                AND HTS_BMNCOD IN ('0000')       " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SSWCOD IN ('00'  )       " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_STRDAY <= :strday2_12    " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_ENDDAY >= :endday2_12    " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MINSUU <= :minsuu2_12    " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MAXSUU >= :maxsuu2_12    " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_DELFLG = '" & DELFLG_NOT & "' " & vbCrLf) '
                SqlBuf.Append("            )                                    " & vbCrLf)     '
                SqlBuf.Append("    )                                            " & vbCrLf)     '
                '(4)都道府県一致
                SqlBuf.Append("    UNION ALL (                                  " & vbCrLf)     '
                SqlBuf.Append("        SELECT                                   " & vbCrLf)     '
                SqlBuf.Append("            13 As WRK_PRIORY ,                   " & vbCrLf)     '
                SqlBuf.Append("            HTS_HANTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TENTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_HNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_KKKNUM                           " & vbCrLf)     '
                SqlBuf.Append("        FROM                                     " & vbCrLf)     '
                SqlBuf.Append("            (                                    " & vbCrLf)     '
                SqlBuf.Append("                SELECT                           " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HANTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TENTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_KKKNUM                   " & vbCrLf)     '
                SqlBuf.Append("                FROM                             " & vbCrLf)     '
                SqlBuf.Append("                    HTSTABL                      " & vbCrLf)     '
                SqlBuf.Append("                WHERE                            " & vbCrLf)     '
                SqlBuf.Append("                    HTS_SYKKBN = :sykKbn3_13     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SHOCOD = :shocod3_13     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUKBN = '4'             " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD1 = '00000' || :sttcod_13 " & vbCrLf) '
                SqlBuf.Append("                AND HTS_NOUCD2 = '00000'         " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_BMNCOD IN ('0000',:bmncod3_13) " & vbCrLf) '
                SqlBuf.Append("                AND HTS_SSWCOD IN ('00'  ,:sswcod3_13) " & vbCrLf) '
                SqlBuf.Append("                AND HTS_STRDAY <= :strday3_13    " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_ENDDAY >= :endday3_13    " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MINSUU <= :minsuu3_13    " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MAXSUU >= :maxsuu3_13    " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_DELFLG = '" & DELFLG_NOT & "' " & vbCrLf) '
                SqlBuf.Append("            )                                    " & vbCrLf)     '
                SqlBuf.Append("    )                                            " & vbCrLf)     '

                '出荷元(9:共通)
                '(3)客先店舗一致・勘定科目一致・客先部門一致
                SqlBuf.Append("    UNION ALL (                                  " & vbCrLf)     '
                SqlBuf.Append("        SELECT                                   " & vbCrLf)     '
                SqlBuf.Append("            21 As WRK_PRIORY ,                   " & vbCrLf)     '
                SqlBuf.Append("            HTS_HANTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TENTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_HNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_KKKNUM                           " & vbCrLf)     '
                SqlBuf.Append("        FROM                                     " & vbCrLf)     '
                SqlBuf.Append("            (                                    " & vbCrLf)     '
                SqlBuf.Append("                SELECT                           " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HANTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TENTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_KKKNUM                   " & vbCrLf)     '
                SqlBuf.Append("                FROM                             " & vbCrLf)     '
                SqlBuf.Append("                    HTSTABL                      " & vbCrLf)     '
                SqlBuf.Append("                WHERE                            " & vbCrLf)     '
                SqlBuf.Append("                    HTS_SYKKBN = :sykKbn_21      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SHOCOD = :shocod_21      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUKBN = '3'             " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD1 = :tokcod_21      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD2 = :tkscod_21      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_BMNCOD IN (:bmncod_21)   " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SSWCOD IN (:sswcod_21)   " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_STRDAY <= :strday_21     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_ENDDAY >= :endday_21     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MINSUU <= :minsuu_21     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MAXSUU >= :maxsuu_21     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_DELFLG = '" & DELFLG_NOT & "' " & vbCrLf) '
                SqlBuf.Append("            )                                    " & vbCrLf)     '
                SqlBuf.Append("    )                                            " & vbCrLf)     '
                '(3)客先店舗一致・勘定科目一致・客先部門ALL
                SqlBuf.Append("    UNION ALL (                                  " & vbCrLf)     '
                SqlBuf.Append("        SELECT                                   " & vbCrLf)     '
                SqlBuf.Append("            22 As WRK_PRIORY ,                   " & vbCrLf)     '
                SqlBuf.Append("            HTS_HANTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TENTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_HNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_KKKNUM                           " & vbCrLf)     '
                SqlBuf.Append("        FROM                                     " & vbCrLf)     '
                SqlBuf.Append("            (                                    " & vbCrLf)     '
                SqlBuf.Append("                SELECT                           " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HANTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TENTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_KKKNUM                   " & vbCrLf)     '
                SqlBuf.Append("                FROM                             " & vbCrLf)     '
                SqlBuf.Append("                    HTSTABL                      " & vbCrLf)     '
                SqlBuf.Append("                WHERE                            " & vbCrLf)     '
                SqlBuf.Append("                    HTS_SYKKBN = :sykKbn_22      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SHOCOD = :shocod_22      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUKBN = '3'             " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD1 = :tokcod_22      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD2 = :tkscod_22      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_BMNCOD IN ('0000')       " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SSWCOD IN (:sswcod_22)   " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_STRDAY <= :strday_22     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_ENDDAY >= :endday_22     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MINSUU <= :minsuu_22     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MAXSUU >= :maxsuu_22     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_DELFLG = '" & DELFLG_NOT & "' " & vbCrLf) '
                SqlBuf.Append("            )                                    " & vbCrLf)     '
                SqlBuf.Append("    )                                            " & vbCrLf)     '
                '(3)客先店舗一致・勘定科目ALL・客先部門一致
                SqlBuf.Append("    UNION ALL (                                  " & vbCrLf)     '
                SqlBuf.Append("        SELECT                                   " & vbCrLf)     '
                SqlBuf.Append("            23 As WRK_PRIORY ,                   " & vbCrLf)     '
                SqlBuf.Append("            HTS_HANTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TENTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_HNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_KKKNUM                           " & vbCrLf)     '
                SqlBuf.Append("        FROM                                     " & vbCrLf)     '
                SqlBuf.Append("            (                                    " & vbCrLf)     '
                SqlBuf.Append("                SELECT                           " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HANTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TENTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_KKKNUM                   " & vbCrLf)     '
                SqlBuf.Append("                FROM                             " & vbCrLf)     '
                SqlBuf.Append("                    HTSTABL                      " & vbCrLf)     '
                SqlBuf.Append("                WHERE                            " & vbCrLf)     '
                SqlBuf.Append("                    HTS_SYKKBN = :sykKbn_23      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SHOCOD = :shocod_23      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUKBN = '3'             " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD1 = :tokcod_23      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD2 = :tkscod_23      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_BMNCOD IN (:bmncod_23)   " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SSWCOD IN ('00')         " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_STRDAY <= :strday_23     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_ENDDAY >= :endday_23     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MINSUU <= :minsuu_23     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MAXSUU >= :maxsuu_23     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_DELFLG = '" & DELFLG_NOT & "' " & vbCrLf) '
                SqlBuf.Append("            )                                    " & vbCrLf)     '
                SqlBuf.Append("    )                                            " & vbCrLf)     '
                '(3)客先店舗一致・勘定科目ALL・客先部門ALL
                SqlBuf.Append("    UNION ALL (                                  " & vbCrLf)     '
                SqlBuf.Append("        SELECT                                   " & vbCrLf)     '
                SqlBuf.Append("            24 As WRK_PRIORY ,                   " & vbCrLf)     '
                SqlBuf.Append("            HTS_HANTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TENTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_HNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_KKKNUM                           " & vbCrLf)     '
                SqlBuf.Append("        FROM                                     " & vbCrLf)     '
                SqlBuf.Append("            (                                    " & vbCrLf)     '
                SqlBuf.Append("                SELECT                           " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HANTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TENTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_KKKNUM                   " & vbCrLf)     '
                SqlBuf.Append("                FROM                             " & vbCrLf)     '
                SqlBuf.Append("                    HTSTABL                      " & vbCrLf)     '
                SqlBuf.Append("                WHERE                            " & vbCrLf)     '
                SqlBuf.Append("                    HTS_SYKKBN = :sykKbn_24      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SHOCOD = :shocod_24      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUKBN = '3'             " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD1 = :tokcod_24      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD2 = :tkscod_24      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_BMNCOD IN ('0000')       " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SSWCOD IN ('00')         " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_STRDAY <= :strday_24     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_ENDDAY >= :endday_24     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MINSUU <= :minsuu_24     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MAXSUU >= :maxsuu_24     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_DELFLG = '" & DELFLG_NOT & "' " & vbCrLf) '
                SqlBuf.Append("            )                                    " & vbCrLf)     '
                SqlBuf.Append("    )                                            " & vbCrLf)     '
                '(0)客先一致・勘定科目一致・客先部門一致
                SqlBuf.Append("    UNION ALL (                                  " & vbCrLf)     '
                SqlBuf.Append("        SELECT                                   " & vbCrLf)     '
                SqlBuf.Append("            25 As WRK_PRIORY ,                   " & vbCrLf)     '
                SqlBuf.Append("            HTS_HANTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TENTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_HNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_KKKNUM                           " & vbCrLf)     '
                SqlBuf.Append("        FROM                                     " & vbCrLf)     '
                SqlBuf.Append("            (                                    " & vbCrLf)     '
                SqlBuf.Append("                SELECT                           " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HANTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TENTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_KKKNUM                   " & vbCrLf)     '
                SqlBuf.Append("                FROM                             " & vbCrLf)     '
                SqlBuf.Append("                    HTSTABL                      " & vbCrLf)     '
                SqlBuf.Append("                WHERE                            " & vbCrLf)     '
                SqlBuf.Append("                    HTS_SYKKBN = :sykKbn_25       " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SHOCOD = :shocod_25       " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUKBN = '0'             " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD1 = :tokcod_25      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD2 = '00000'         " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_BMNCOD IN (:bmncod_25)   " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SSWCOD IN (:sswcod_25)   " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_STRDAY <= :strday_25     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_ENDDAY >= :endday_25     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MINSUU <= :minsuu_25     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MAXSUU >= :maxsuu_25     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_DELFLG = '" & DELFLG_NOT & "' " & vbCrLf) '
                SqlBuf.Append("            )                                    " & vbCrLf)     '
                SqlBuf.Append("    )                                            " & vbCrLf)     '
                '(0)客先一致・勘定科目一致・客先部門ALL
                SqlBuf.Append("    UNION ALL (                                  " & vbCrLf)     '
                SqlBuf.Append("        SELECT                                   " & vbCrLf)     '
                SqlBuf.Append("            26 As WRK_PRIORY ,                   " & vbCrLf)     '
                SqlBuf.Append("            HTS_HANTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TENTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_HNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_KKKNUM                           " & vbCrLf)     '
                SqlBuf.Append("        FROM                                     " & vbCrLf)     '
                SqlBuf.Append("            (                                    " & vbCrLf)     '
                SqlBuf.Append("                SELECT                           " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HANTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TENTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_KKKNUM                   " & vbCrLf)     '
                SqlBuf.Append("                FROM                             " & vbCrLf)     '
                SqlBuf.Append("                    HTSTABL                      " & vbCrLf)     '
                SqlBuf.Append("                WHERE                            " & vbCrLf)     '
                SqlBuf.Append("                    HTS_SYKKBN = :sykKbn_26      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SHOCOD = :shocod_26      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUKBN = '0'             " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD1 = :tokcod_26      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD2 = '00000'         " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_BMNCOD IN ('0000')       " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SSWCOD IN (:sswcod_26)   " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_STRDAY <= :strday_26     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_ENDDAY >= :endday_26     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MINSUU <= :minsuu_26     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MAXSUU >= :maxsuu_26     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_DELFLG = '" & DELFLG_NOT & "' " & vbCrLf) '
                SqlBuf.Append("            )                                    " & vbCrLf)     '
                SqlBuf.Append("    )                                            " & vbCrLf)     '
                '(0)客先一致・勘定科目ALL・客先部門一致
                SqlBuf.Append("    UNION ALL (                                  " & vbCrLf)     '
                SqlBuf.Append("        SELECT                                   " & vbCrLf)     ' 
                SqlBuf.Append("            27 As WRK_PRIORY ,                   " & vbCrLf)     '
                SqlBuf.Append("            HTS_HANTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TENTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_HNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_KKKNUM                           " & vbCrLf)     '
                SqlBuf.Append("        FROM                                     " & vbCrLf)     '
                SqlBuf.Append("            (                                    " & vbCrLf)     '
                SqlBuf.Append("                SELECT                           " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HANTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TENTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_KKKNUM                   " & vbCrLf)     '
                SqlBuf.Append("                FROM                             " & vbCrLf)     '
                SqlBuf.Append("                    HTSTABL                      " & vbCrLf)     '
                SqlBuf.Append("                WHERE                            " & vbCrLf)     '
                SqlBuf.Append("                    HTS_SYKKBN = :sykKbn_27      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SHOCOD = :shocod_27      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUKBN = '0'             " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD1 = :tokcod_27      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD2 = '00000'         " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_BMNCOD IN (:bmncod_27)   " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SSWCOD IN ('00')         " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_STRDAY <= :strday_27     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_ENDDAY >= :endday_27     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MINSUU <= :minsuu_27     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MAXSUU >= :maxsuu_27     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_DELFLG = '" & DELFLG_NOT & "' " & vbCrLf) '
                SqlBuf.Append("            )                                    " & vbCrLf)     '
                SqlBuf.Append("    )                                            " & vbCrLf)     '
                '(0)客先一致・勘定科目ALL・客先部門ALL
                SqlBuf.Append("    UNION ALL (                                  " & vbCrLf)     '
                SqlBuf.Append("        SELECT                                   " & vbCrLf)     ' 
                SqlBuf.Append("            28 As WRK_PRIORY ,                   " & vbCrLf)     '
                SqlBuf.Append("            HTS_HANTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TENTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_HNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_KKKNUM                           " & vbCrLf)     '
                SqlBuf.Append("        FROM                                     " & vbCrLf)     '
                SqlBuf.Append("            (                                    " & vbCrLf)     '
                SqlBuf.Append("                SELECT                           " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HANTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TENTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_KKKNUM                   " & vbCrLf)     '
                SqlBuf.Append("                FROM                             " & vbCrLf)     '
                SqlBuf.Append("                    HTSTABL                      " & vbCrLf)     '
                SqlBuf.Append("                WHERE                            " & vbCrLf)     '
                SqlBuf.Append("                    HTS_SYKKBN = :sykKbn_28      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SHOCOD = :shocod_28      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUKBN = '0'             " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD1 = :tokcod_28      " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD2 = '00000'         " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_BMNCOD IN ('0000')       " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SSWCOD IN ('00')         " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_STRDAY <= :strday_28     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_ENDDAY >= :endday_28     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MINSUU <= :minsuu_28     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MAXSUU >= :maxsuu_28     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_DELFLG = '" & DELFLG_NOT & "' " & vbCrLf) '
                SqlBuf.Append("            )                                    " & vbCrLf)     '
                SqlBuf.Append("    )                                            " & vbCrLf)     '
                '(2)客先エリア一致・勘定科目一致・客先部門一致
                SqlBuf.Append("    UNION ALL (                                  " & vbCrLf)     '
                SqlBuf.Append("        SELECT                                   " & vbCrLf)     '
                SqlBuf.Append("            29 As WRK_PRIORY ,                   " & vbCrLf)     '
                SqlBuf.Append("            HTS_HANTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TENTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_HNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_KKKNUM                           " & vbCrLf)     '
                SqlBuf.Append("        FROM                                     " & vbCrLf)     '
                SqlBuf.Append("            (                                    " & vbCrLf)     '
                SqlBuf.Append("                SELECT                           " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HANTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TENTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_KKKNUM                   " & vbCrLf)     '
                SqlBuf.Append("                FROM                             " & vbCrLf)     '
                SqlBuf.Append("                    HTSTABL                      " & vbCrLf)     '
                SqlBuf.Append("                WHERE                            " & vbCrLf)     '
                SqlBuf.Append("                    HTS_SYKKBN = :sykKbn2_29     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SHOCOD = :shocod2_29     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUKBN = '2'             " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD1 = :tokcod2_29     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD2 = '00' || :arecod_29 " & vbCrLf)  '
                SqlBuf.Append("                AND HTS_BMNCOD IN (:bmncod2_29)  " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SSWCOD IN (:sswcod2_29)  " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_STRDAY <= :strday2_29    " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_ENDDAY >= :endday2_29    " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MINSUU <= :minsuu2_29    " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MAXSUU >= :maxsuu2_29    " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_DELFLG = '" & DELFLG_NOT & "' " & vbCrLf) '
                SqlBuf.Append("            )                                    " & vbCrLf)     '
                SqlBuf.Append("    )                                            " & vbCrLf)     '
                '(2)客先エリア一致・勘定科目一致・客先部門ALL
                SqlBuf.Append("    UNION ALL (                                  " & vbCrLf)     '
                SqlBuf.Append("        SELECT                                   " & vbCrLf)     '
                SqlBuf.Append("            30 As WRK_PRIORY ,                   " & vbCrLf)     '
                SqlBuf.Append("            HTS_HANTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TENTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_HNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_KKKNUM                           " & vbCrLf)     '
                SqlBuf.Append("        FROM                                     " & vbCrLf)     '
                SqlBuf.Append("            (                                    " & vbCrLf)     '
                SqlBuf.Append("                SELECT                           " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HANTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TENTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_KKKNUM                   " & vbCrLf)     '
                SqlBuf.Append("                FROM                             " & vbCrLf)     '
                SqlBuf.Append("                    HTSTABL                      " & vbCrLf)     '
                SqlBuf.Append("                WHERE                            " & vbCrLf)     '
                SqlBuf.Append("                    HTS_SYKKBN = :sykKbn2_30     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SHOCOD = :shocod2_30     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUKBN = '2'             " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD1 = :tokcod2_30     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD2 = '00' || :arecod_30 " & vbCrLf) '
                SqlBuf.Append("                AND HTS_BMNCOD IN ('0000')       " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SSWCOD IN (:sswcod2_30)  " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_STRDAY <= :strday2_30    " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_ENDDAY >= :endday2_30    " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MINSUU <= :minsuu2_30    " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MAXSUU >= :maxsuu2_30    " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_DELFLG = '" & DELFLG_NOT & "' " & vbCrLf) '
                SqlBuf.Append("            )                                    " & vbCrLf)     '
                SqlBuf.Append("    )                                            " & vbCrLf)     '
                '(2)客先エリア一致・勘定科目ALL・客先部門一致
                SqlBuf.Append("    UNION ALL (                                  " & vbCrLf)     '
                SqlBuf.Append("        SELECT                                   " & vbCrLf)     ' 
                SqlBuf.Append("            31 As WRK_PRIORY ,                   " & vbCrLf)     '
                SqlBuf.Append("            HTS_HANTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TENTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_HNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_KKKNUM                           " & vbCrLf)     '
                SqlBuf.Append("        FROM                                     " & vbCrLf)     '
                SqlBuf.Append("            (                                    " & vbCrLf)     '
                SqlBuf.Append("                SELECT                           " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HANTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TENTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_KKKNUM                   " & vbCrLf)     '
                SqlBuf.Append("                FROM                             " & vbCrLf)     '
                SqlBuf.Append("                    HTSTABL                      " & vbCrLf)     '
                SqlBuf.Append("                WHERE                            " & vbCrLf)     '
                SqlBuf.Append("                    HTS_SYKKBN = :sykKbn2_31     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SHOCOD = :shocod2_31     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUKBN = '2'             " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD1 = :tokcod2_31     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD2 = '00' || :arecod_31 " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_BMNCOD IN (:bmncod2_31)  " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SSWCOD IN ('00')         " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_STRDAY <= :strday2_31    " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_ENDDAY >= :endday2_31    " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MINSUU <= :minsuu2_31    " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MAXSUU >= :maxsuu2_31    " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_DELFLG = '" & DELFLG_NOT & "' " & vbCrLf)     '
                SqlBuf.Append("            )                                    " & vbCrLf)     '
                SqlBuf.Append("    )                                            " & vbCrLf)     '
                '(2)客先エリア一致・勘定科目ALL・客先部門ALL
                SqlBuf.Append("    UNION ALL (                                  " & vbCrLf)     '
                SqlBuf.Append("        SELECT                                   " & vbCrLf)     ' 
                SqlBuf.Append("            32 As WRK_PRIORY ,                   " & vbCrLf)     '
                SqlBuf.Append("            HTS_HANTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TENTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_HNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_KKKNUM                           " & vbCrLf)     '
                SqlBuf.Append("        FROM                                     " & vbCrLf)     '
                SqlBuf.Append("            (                                    " & vbCrLf)     '
                SqlBuf.Append("                SELECT                           " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HANTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TENTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_KKKNUM                   " & vbCrLf)     '
                SqlBuf.Append("                FROM                             " & vbCrLf)     '
                SqlBuf.Append("                    HTSTABL                      " & vbCrLf)     '
                SqlBuf.Append("                WHERE                            " & vbCrLf)     '
                SqlBuf.Append("                    HTS_SYKKBN = :sykKbn2_32     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SHOCOD = :shocod2_32     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUKBN = '2'             " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD1 = :tokcod2_32     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD2 = '00' || :arecod_32 " & vbCrLf) '
                SqlBuf.Append("                AND HTS_BMNCOD IN ('0000')       " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SSWCOD IN ('00'  )       " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_STRDAY <= :strday2_32    " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_ENDDAY >= :endday2_32    " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MINSUU <= :minsuu2_32    " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MAXSUU >= :maxsuu2_32    " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_DELFLG = '" & DELFLG_NOT & "' " & vbCrLf) '
                SqlBuf.Append("            )                                    " & vbCrLf)     '
                SqlBuf.Append("    )                                            " & vbCrLf)     '
                '(4)都道府県一致
                SqlBuf.Append("    UNION ALL (                                  " & vbCrLf)     '
                SqlBuf.Append("        SELECT                                   " & vbCrLf)     '
                SqlBuf.Append("            33 As WRK_PRIORY ,                   " & vbCrLf)     '
                SqlBuf.Append("            HTS_HANTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TENTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_HNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_TNBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            HTS_KKKNUM                           " & vbCrLf)     '
                SqlBuf.Append("        FROM                                     " & vbCrLf)     '
                SqlBuf.Append("            (                                    " & vbCrLf)     '
                SqlBuf.Append("                SELECT                           " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HANTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TENTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_HNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_TNBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    HTS_KKKNUM                   " & vbCrLf)     '
                SqlBuf.Append("                FROM                             " & vbCrLf)     '
                SqlBuf.Append("                    HTSTABL                      " & vbCrLf)     '
                SqlBuf.Append("                WHERE                            " & vbCrLf)     '
                SqlBuf.Append("                    HTS_SYKKBN = :sykKbn3_33     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_SHOCOD = :shocod3_33     " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUKBN = '4'             " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_NOUCD1 = '00000' || :sttcod_33 " & vbCrLf) '
                SqlBuf.Append("                AND HTS_NOUCD2 = '00000'         " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_BMNCOD IN ('0000',:bmncod3_33) " & vbCrLf) '
                SqlBuf.Append("                AND HTS_SSWCOD IN ('00'  ,:sswcod3_33) " & vbCrLf) '
                SqlBuf.Append("                AND HTS_STRDAY <= :strday3_33    " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_ENDDAY >= :endday3_33    " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MINSUU <= :minsuu3_33    " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_MAXSUU >= :maxsuu3_33    " & vbCrLf)     '
                SqlBuf.Append("                AND HTS_DELFLG = '" & DELFLG_NOT & "' " & vbCrLf) '
                SqlBuf.Append("            )                                    " & vbCrLf)     '
                SqlBuf.Append("    )                                            " & vbCrLf)     '

                SqlBuf.Append("ORDER BY                                         " & vbCrLf)     '
                SqlBuf.Append("    WRK_PRIORY DESC ,                            " & vbCrLf)     '
                SqlBuf.Append("    HTS_HNBTNK DESC                              " & vbCrLf)     '

                ' パラメータ組立
                ' --------------------------------------------------
                Call Ora_ParmRemAll()

                Call Ora_CreateParmString("sykKbn_1", ORAPARM_INPUT, 1, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("shocod_1", ORAPARM_INPUT, 1, 13, ORA_EXEC_NORMAL)   '   データ取得パラメータ作成
                Call Ora_CreateParmString("tokcod_1", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("tkscod_1", ORAPARM_INPUT, 1, 5, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("bmncod_1", ORAPARM_INPUT, 1, 4, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("sswcod_1", ORAPARM_INPUT, 1, 2, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("strday_1", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("endday_1", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("minsuu_1", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)       '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("maxsuu_1", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)       '   データ取得パラメータ作成

                Call Ora_CreateParmString("sykKbn_2", ORAPARM_INPUT, 1, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("shocod_2", ORAPARM_INPUT, 1, 13, ORA_EXEC_NORMAL)   '   データ取得パラメータ作成
                Call Ora_CreateParmString("tokcod_2", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("tkscod_2", ORAPARM_INPUT, 1, 5, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("sswcod_2", ORAPARM_INPUT, 1, 2, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("strday_2", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("endday_2", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("minsuu_2", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)       '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("maxsuu_2", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)       '   データ取得パラメータ作成

                Call Ora_CreateParmString("sykKbn_3", ORAPARM_INPUT, 1, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("shocod_3", ORAPARM_INPUT, 1, 13, ORA_EXEC_NORMAL)   '   データ取得パラメータ作成
                Call Ora_CreateParmString("tokcod_3", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("tkscod_3", ORAPARM_INPUT, 1, 5, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("bmncod_3", ORAPARM_INPUT, 1, 4, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("strday_3", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("endday_3", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("minsuu_3", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)       '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("maxsuu_3", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)       '   データ取得パラメータ作成

                Call Ora_CreateParmString("sykKbn_4", ORAPARM_INPUT, 1, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("shocod_4", ORAPARM_INPUT, 1, 13, ORA_EXEC_NORMAL)   '   データ取得パラメータ作成
                Call Ora_CreateParmString("tokcod_4", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("tkscod_4", ORAPARM_INPUT, 1, 5, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("strday_4", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("endday_4", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("minsuu_4", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)       '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("maxsuu_4", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)       '   データ取得パラメータ作成

                Call Ora_CreateParmString("sykKbn_5", ORAPARM_INPUT, 1, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("shocod_5", ORAPARM_INPUT, 1, 13, ORA_EXEC_NORMAL)   '   データ取得パラメータ作成
                Call Ora_CreateParmString("tokcod_5", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("bmncod_5", ORAPARM_INPUT, 1, 4, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("sswcod_5", ORAPARM_INPUT, 1, 2, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("strday_5", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("endday_5", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("minsuu_5", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)       '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("maxsuu_5", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)       '   データ取得パラメータ作成

                Call Ora_CreateParmString("sykKbn_6", ORAPARM_INPUT, 1, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("shocod_6", ORAPARM_INPUT, 1, 13, ORA_EXEC_NORMAL)   '   データ取得パラメータ作成
                Call Ora_CreateParmString("tokcod_6", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("sswcod_6", ORAPARM_INPUT, 1, 2, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("strday_6", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("endday_6", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("minsuu_6", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)       '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("maxsuu_6", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)       '   データ取得パラメータ作成

                Call Ora_CreateParmString("sykKbn_7", ORAPARM_INPUT, 1, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("shocod_7", ORAPARM_INPUT, 1, 13, ORA_EXEC_NORMAL)   '   データ取得パラメータ作成
                Call Ora_CreateParmString("tokcod_7", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("bmncod_7", ORAPARM_INPUT, 1, 4, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("strday_7", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("endday_7", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("minsuu_7", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)       '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("maxsuu_7", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)       '   データ取得パラメータ作成

                Call Ora_CreateParmString("sykKbn_8", ORAPARM_INPUT, 1, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("shocod_8", ORAPARM_INPUT, 1, 13, ORA_EXEC_NORMAL)   '   データ取得パラメータ作成
                Call Ora_CreateParmString("tokcod_8", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("strday_8", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("endday_8", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("minsuu_8", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)       '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("maxsuu_8", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)       '   データ取得パラメータ作成

                Call Ora_CreateParmString("sykKbn2_9", ORAPARM_INPUT, 1, 1, ORA_EXEC_NORMAL)   '   データ取得パラメータ作成
                Call Ora_CreateParmString("shocod2_9", ORAPARM_INPUT, 1, 13, ORA_EXEC_NORMAL)  '   データ取得パラメータ作成
                Call Ora_CreateParmString("tokcod2_9", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)   '   データ取得パラメータ作成
                Call Ora_CreateParmString("arecod_9", ORAPARM_INPUT, 1, 3, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("bmncod2_9", ORAPARM_INPUT, 1, 4, ORA_EXEC_NORMAL)   '   データ取得パラメータ作成
                Call Ora_CreateParmString("sswcod2_9", ORAPARM_INPUT, 1, 2, ORA_EXEC_NORMAL)   '   データ取得パラメータ作成
                Call Ora_CreateParmString("strday2_9", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)   '   データ取得パラメータ作成
                Call Ora_CreateParmString("endday2_9", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)   '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("minsuu2_9", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)      '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("maxsuu2_9", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)      '   データ取得パラメータ作成

                Call Ora_CreateParmString("sykKbn2_10", ORAPARM_INPUT, 1, 1, ORA_EXEC_NORMAL)  '   データ取得パラメータ作成
                Call Ora_CreateParmString("shocod2_10", ORAPARM_INPUT, 1, 13, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("tokcod2_10", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)  '   データ取得パラメータ作成
                Call Ora_CreateParmString("arecod_10", ORAPARM_INPUT, 1, 3, ORA_EXEC_NORMAL)   '   データ取得パラメータ作成
                Call Ora_CreateParmString("sswcod2_10", ORAPARM_INPUT, 1, 2, ORA_EXEC_NORMAL)  '   データ取得パラメータ作成
                Call Ora_CreateParmString("strday2_10", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)  '   データ取得パラメータ作成
                Call Ora_CreateParmString("endday2_10", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)  '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("minsuu2_10", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)     '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("maxsuu2_10", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)     '   データ取得パラメータ作成

                Call Ora_CreateParmString("sykKbn2_11", ORAPARM_INPUT, 1, 1, ORA_EXEC_NORMAL)  '   データ取得パラメータ作成
                Call Ora_CreateParmString("shocod2_11", ORAPARM_INPUT, 1, 13, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("tokcod2_11", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)  '   データ取得パラメータ作成
                Call Ora_CreateParmString("arecod_11", ORAPARM_INPUT, 1, 3, ORA_EXEC_NORMAL)   '   データ取得パラメータ作成
                Call Ora_CreateParmString("bmncod2_11", ORAPARM_INPUT, 1, 4, ORA_EXEC_NORMAL)  '   データ取得パラメータ作成
                Call Ora_CreateParmString("strday2_11", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)  '   データ取得パラメータ作成
                Call Ora_CreateParmString("endday2_11", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)  '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("minsuu2_11", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)     '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("maxsuu2_11", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)     '   データ取得パラメータ作成

                Call Ora_CreateParmString("sykKbn2_12", ORAPARM_INPUT, 1, 1, ORA_EXEC_NORMAL)  '   データ取得パラメータ作成
                Call Ora_CreateParmString("shocod2_12", ORAPARM_INPUT, 1, 13, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("tokcod2_12", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)  '   データ取得パラメータ作成
                Call Ora_CreateParmString("arecod_12", ORAPARM_INPUT, 1, 3, ORA_EXEC_NORMAL)   '   データ取得パラメータ作成
                Call Ora_CreateParmString("strday2_12", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)  '   データ取得パラメータ作成
                Call Ora_CreateParmString("endday2_12", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)  '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("minsuu2_12", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)     '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("maxsuu2_12", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)     '   データ取得パラメータ作成

                Call Ora_CreateParmString("sykKbn3_13", ORAPARM_INPUT, 1, 1, ORA_EXEC_NORMAL) '  データ取得パラメータ作成
                Call Ora_CreateParmString("shocod3_13", ORAPARM_INPUT, 1, 13, ORA_EXEC_NORMAL) '  データ取得パラメータ作成
                Call Ora_CreateParmString("sttcod_13", ORAPARM_INPUT, 1, 3, ORA_EXEC_NORMAL)  '   データ取得パラメータ作成
                Call Ora_CreateParmString("bmncod3_13", ORAPARM_INPUT, 1, 4, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("sswcod3_13", ORAPARM_INPUT, 1, 2, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("strday3_13", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("endday3_13", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("minsuu3_13", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("maxsuu3_13", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成

                Call Ora_CreateParmString("sykKbn_21", ORAPARM_INPUT, 1, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("shocod_21", ORAPARM_INPUT, 1, 13, ORA_EXEC_NORMAL)   '   データ取得パラメータ作成
                Call Ora_CreateParmString("tokcod_21", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("tkscod_21", ORAPARM_INPUT, 1, 5, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("bmncod_21", ORAPARM_INPUT, 1, 4, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("sswcod_21", ORAPARM_INPUT, 1, 2, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("strday_21", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("endday_21", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("minsuu_21", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)       '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("maxsuu_21", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)       '   データ取得パラメータ作成

                Call Ora_CreateParmString("sykKbn_22", ORAPARM_INPUT, 1, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("shocod_22", ORAPARM_INPUT, 1, 13, ORA_EXEC_NORMAL)   '   データ取得パラメータ作成
                Call Ora_CreateParmString("tokcod_22", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("tkscod_22", ORAPARM_INPUT, 1, 5, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("sswcod_22", ORAPARM_INPUT, 1, 2, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("strday_22", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("endday_22", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("minsuu_22", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)       '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("maxsuu_22", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)       '   データ取得パラメータ作成

                Call Ora_CreateParmString("sykKbn_23", ORAPARM_INPUT, 1, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("shocod_23", ORAPARM_INPUT, 1, 13, ORA_EXEC_NORMAL)   '   データ取得パラメータ作成
                Call Ora_CreateParmString("tokcod_23", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("tkscod_23", ORAPARM_INPUT, 1, 5, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("bmncod_23", ORAPARM_INPUT, 1, 4, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("strday_23", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("endday_23", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("minsuu_23", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)       '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("maxsuu_23", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)       '   データ取得パラメータ作成

                Call Ora_CreateParmString("sykKbn_24", ORAPARM_INPUT, 1, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("shocod_24", ORAPARM_INPUT, 1, 13, ORA_EXEC_NORMAL)   '   データ取得パラメータ作成
                Call Ora_CreateParmString("tokcod_24", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("tkscod_24", ORAPARM_INPUT, 1, 5, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("strday_24", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("endday_24", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("minsuu_24", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)       '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("maxsuu_24", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)       '   データ取得パラメータ作成

                Call Ora_CreateParmString("sykKbn_25", ORAPARM_INPUT, 1, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("shocod_25", ORAPARM_INPUT, 1, 13, ORA_EXEC_NORMAL)   '   データ取得パラメータ作成
                Call Ora_CreateParmString("tokcod_25", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("bmncod_25", ORAPARM_INPUT, 1, 4, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("sswcod_25", ORAPARM_INPUT, 1, 2, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("strday_25", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("endday_25", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("minsuu_25", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)       '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("maxsuu_25", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)       '   データ取得パラメータ作成

                Call Ora_CreateParmString("sykKbn_26", ORAPARM_INPUT, 1, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("shocod_26", ORAPARM_INPUT, 1, 13, ORA_EXEC_NORMAL)   '   データ取得パラメータ作成
                Call Ora_CreateParmString("tokcod_26", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("sswcod_26", ORAPARM_INPUT, 1, 2, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("strday_26", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("endday_26", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("minsuu_26", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)       '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("maxsuu_26", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)       '   データ取得パラメータ作成

                Call Ora_CreateParmString("sykKbn_27", ORAPARM_INPUT, 1, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("shocod_27", ORAPARM_INPUT, 1, 13, ORA_EXEC_NORMAL)   '   データ取得パラメータ作成
                Call Ora_CreateParmString("tokcod_27", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("bmncod_27", ORAPARM_INPUT, 1, 4, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("strday_27", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("endday_27", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("minsuu_27", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)       '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("maxsuu_27", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)       '   データ取得パラメータ作成

                Call Ora_CreateParmString("sykKbn_28", ORAPARM_INPUT, 1, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("shocod_28", ORAPARM_INPUT, 1, 13, ORA_EXEC_NORMAL)   '   データ取得パラメータ作成
                Call Ora_CreateParmString("tokcod_28", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("strday_28", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("endday_28", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("minsuu_28", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)       '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("maxsuu_28", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)       '   データ取得パラメータ作成

                Call Ora_CreateParmString("sykKbn2_29", ORAPARM_INPUT, 1, 1, ORA_EXEC_NORMAL)   '   データ取得パラメータ作成
                Call Ora_CreateParmString("shocod2_29", ORAPARM_INPUT, 1, 13, ORA_EXEC_NORMAL)  '   データ取得パラメータ作成
                Call Ora_CreateParmString("tokcod2_29", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)   '   データ取得パラメータ作成
                Call Ora_CreateParmString("arecod_29", ORAPARM_INPUT, 1, 3, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmString("bmncod2_29", ORAPARM_INPUT, 1, 4, ORA_EXEC_NORMAL)   '   データ取得パラメータ作成
                Call Ora_CreateParmString("sswcod2_29", ORAPARM_INPUT, 1, 2, ORA_EXEC_NORMAL)   '   データ取得パラメータ作成
                Call Ora_CreateParmString("strday2_29", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)   '   データ取得パラメータ作成
                Call Ora_CreateParmString("endday2_29", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)   '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("minsuu2_29", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)      '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("maxsuu2_29", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)      '   データ取得パラメータ作成

                Call Ora_CreateParmString("sykKbn2_30", ORAPARM_INPUT, 1, 1, ORA_EXEC_NORMAL)  '   データ取得パラメータ作成
                Call Ora_CreateParmString("shocod2_30", ORAPARM_INPUT, 1, 13, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("tokcod2_30", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)  '   データ取得パラメータ作成
                Call Ora_CreateParmString("arecod_30", ORAPARM_INPUT, 1, 3, ORA_EXEC_NORMAL)   '   データ取得パラメータ作成
                Call Ora_CreateParmString("sswcod2_30", ORAPARM_INPUT, 1, 2, ORA_EXEC_NORMAL)  '   データ取得パラメータ作成
                Call Ora_CreateParmString("strday2_30", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)  '   データ取得パラメータ作成
                Call Ora_CreateParmString("endday2_30", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)  '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("minsuu2_30", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)     '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("maxsuu2_30", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)     '   データ取得パラメータ作成

                Call Ora_CreateParmString("sykKbn2_31", ORAPARM_INPUT, 1, 1, ORA_EXEC_NORMAL)  '   データ取得パラメータ作成
                Call Ora_CreateParmString("shocod2_31", ORAPARM_INPUT, 1, 13, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("tokcod2_31", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)  '   データ取得パラメータ作成
                Call Ora_CreateParmString("arecod_31", ORAPARM_INPUT, 1, 3, ORA_EXEC_NORMAL)   '   データ取得パラメータ作成
                Call Ora_CreateParmString("bmncod2_31", ORAPARM_INPUT, 1, 4, ORA_EXEC_NORMAL)  '   データ取得パラメータ作成
                Call Ora_CreateParmString("strday2_31", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)  '   データ取得パラメータ作成
                Call Ora_CreateParmString("endday2_31", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)  '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("minsuu2_31", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)     '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("maxsuu2_31", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)     '   データ取得パラメータ作成

                Call Ora_CreateParmString("sykKbn2_32", ORAPARM_INPUT, 1, 1, ORA_EXEC_NORMAL)  '   データ取得パラメータ作成
                Call Ora_CreateParmString("shocod2_32", ORAPARM_INPUT, 1, 13, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("tokcod2_32", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)  '   データ取得パラメータ作成
                Call Ora_CreateParmString("arecod_32", ORAPARM_INPUT, 1, 3, ORA_EXEC_NORMAL)   '   データ取得パラメータ作成
                Call Ora_CreateParmString("strday2_32", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)  '   データ取得パラメータ作成
                Call Ora_CreateParmString("endday2_32", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL)  '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("minsuu2_32", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)     '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("maxsuu2_32", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)     '   データ取得パラメータ作成

                Call Ora_CreateParmString("sykKbn3_33", ORAPARM_INPUT, 1, 1, ORA_EXEC_NORMAL) '  データ取得パラメータ作成
                Call Ora_CreateParmString("shocod3_33", ORAPARM_INPUT, 1, 13, ORA_EXEC_NORMAL) '  データ取得パラメータ作成
                Call Ora_CreateParmString("sttcod_33", ORAPARM_INPUT, 1, 3, ORA_EXEC_NORMAL)  '   データ取得パラメータ作成
                Call Ora_CreateParmString("bmncod3_33", ORAPARM_INPUT, 1, 4, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("sswcod3_33", ORAPARM_INPUT, 1, 2, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("strday3_33", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("endday3_33", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("minsuu3_33", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("maxsuu3_33", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成

                Call Ora_SetParmTable("sykKbn_1", 0, sykkbn)                                '   キーセット
                Call Ora_SetParmTable("shocod_1", 0, I_ShoCod)                              '   キーセット
                Call Ora_SetParmTable("tokcod_1", 0, I_TokCod)                              '   キーセット
                Call Ora_SetParmTable("tkscod_1", 0, I_TksCod)                              '   キーセット
                Call Ora_SetParmTable("bmncod_1", 0, I_BmnCod)                              '   キーセット
                Call Ora_SetParmTable("sswcod_1", 0, I_SswCod)                              '   キーセット
                Call Ora_SetParmTable("strday_1", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("endday_1", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("minsuu_1", 0, I_BraSuu)                              '   キーセット
                Call Ora_SetParmTable("maxsuu_1", 0, I_BraSuu)                              '   キーセット

                Call Ora_SetParmTable("sykKbn_2", 0, sykkbn)                                '   キーセット
                Call Ora_SetParmTable("shocod_2", 0, I_ShoCod)                              '   キーセット
                Call Ora_SetParmTable("tokcod_2", 0, I_TokCod)                              '   キーセット
                Call Ora_SetParmTable("tkscod_2", 0, I_TksCod)                              '   キーセット
                Call Ora_SetParmTable("sswcod_2", 0, I_SswCod)                              '   キーセット
                Call Ora_SetParmTable("strday_2", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("endday_2", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("minsuu_2", 0, I_BraSuu)                              '   キーセット
                Call Ora_SetParmTable("maxsuu_2", 0, I_BraSuu)                              '   キーセット

                Call Ora_SetParmTable("sykKbn_3", 0, sykkbn)                                '   キーセット
                Call Ora_SetParmTable("shocod_3", 0, I_ShoCod)                              '   キーセット
                Call Ora_SetParmTable("tokcod_3", 0, I_TokCod)                              '   キーセット
                Call Ora_SetParmTable("tkscod_3", 0, I_TksCod)                              '   キーセット
                Call Ora_SetParmTable("bmncod_3", 0, I_BmnCod)                              '   キーセット
                Call Ora_SetParmTable("strday_3", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("endday_3", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("minsuu_3", 0, I_BraSuu)                              '   キーセット
                Call Ora_SetParmTable("maxsuu_3", 0, I_BraSuu)                              '   キーセット

                Call Ora_SetParmTable("sykKbn_4", 0, sykkbn)                                '   キーセット
                Call Ora_SetParmTable("shocod_4", 0, I_ShoCod)                              '   キーセット
                Call Ora_SetParmTable("tokcod_4", 0, I_TokCod)                              '   キーセット
                Call Ora_SetParmTable("tkscod_4", 0, I_TksCod)                              '   キーセット
                Call Ora_SetParmTable("strday_4", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("endday_4", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("minsuu_4", 0, I_BraSuu)                              '   キーセット
                Call Ora_SetParmTable("maxsuu_4", 0, I_BraSuu)                              '   キーセット

                Call Ora_SetParmTable("sykKbn_5", 0, sykkbn)                                '   キーセット
                Call Ora_SetParmTable("shocod_5", 0, I_ShoCod)                              '   キーセット
                Call Ora_SetParmTable("tokcod_5", 0, I_TokCod)                              '   キーセット
                Call Ora_SetParmTable("bmncod_5", 0, I_BmnCod)                              '   キーセット
                Call Ora_SetParmTable("sswcod_5", 0, I_SswCod)                              '   キーセット
                Call Ora_SetParmTable("strday_5", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("endday_5", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("minsuu_5", 0, I_BraSuu)                              '   キーセット
                Call Ora_SetParmTable("maxsuu_5", 0, I_BraSuu)                              '   キーセット

                Call Ora_SetParmTable("sykKbn_6", 0, sykkbn)                                '   キーセット
                Call Ora_SetParmTable("shocod_6", 0, I_ShoCod)                              '   キーセット
                Call Ora_SetParmTable("tokcod_6", 0, I_TokCod)                              '   キーセット
                Call Ora_SetParmTable("sswcod_6", 0, I_SswCod)                              '   キーセット
                Call Ora_SetParmTable("strday_6", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("endday_6", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("minsuu_6", 0, I_BraSuu)                              '   キーセット
                Call Ora_SetParmTable("maxsuu_6", 0, I_BraSuu)                              '   キーセット

                Call Ora_SetParmTable("sykKbn_7", 0, sykkbn)                                '   キーセット
                Call Ora_SetParmTable("shocod_7", 0, I_ShoCod)                              '   キーセット
                Call Ora_SetParmTable("tokcod_7", 0, I_TokCod)                              '   キーセット
                Call Ora_SetParmTable("bmncod_7", 0, I_BmnCod)                              '   キーセット
                Call Ora_SetParmTable("strday_7", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("endday_7", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("minsuu_7", 0, I_BraSuu)                              '   キーセット
                Call Ora_SetParmTable("maxsuu_7", 0, I_BraSuu)                              '   キーセット

                Call Ora_SetParmTable("sykKbn_8", 0, sykkbn)                                '   キーセット
                Call Ora_SetParmTable("shocod_8", 0, I_ShoCod)                              '   キーセット
                Call Ora_SetParmTable("tokcod_8", 0, I_TokCod)                              '   キーセット
                Call Ora_SetParmTable("strday_8", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("endday_8", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("minsuu_8", 0, I_BraSuu)                              '   キーセット
                Call Ora_SetParmTable("maxsuu_8", 0, I_BraSuu)                              '   キーセット

                Call Ora_SetParmTable("sykKbn2_9", 0, sykkbn)                               '   キーセット
                Call Ora_SetParmTable("shocod2_9", 0, I_ShoCod)                             '   キーセット
                Call Ora_SetParmTable("tokcod2_9", 0, I_TokCod)                             '   キーセット
                Call Ora_SetParmTable("arecod_9", 0, Com_AreCod)                            '   キーセット
                Call Ora_SetParmTable("bmncod2_9", 0, I_BmnCod)                             '   キーセット
                Call Ora_SetParmTable("sswcod2_9", 0, I_SswCod)                             '   キーセット
                Call Ora_SetParmTable("strday2_9", 0, nouday)                               '   キーセット
                Call Ora_SetParmTable("endday2_9", 0, nouday)                               '   キーセット
                Call Ora_SetParmTable("minsuu2_9", 0, I_BraSuu)                             '   キーセット
                Call Ora_SetParmTable("maxsuu2_9", 0, I_BraSuu)                             '   キーセット

                Call Ora_SetParmTable("sykKbn2_10", 0, sykkbn)                              '   キーセット
                Call Ora_SetParmTable("shocod2_10", 0, I_ShoCod)                            '   キーセット
                Call Ora_SetParmTable("tokcod2_10", 0, I_TokCod)                            '   キーセット
                Call Ora_SetParmTable("arecod_10", 0, Com_AreCod)                           '   キーセット
                Call Ora_SetParmTable("sswcod2_10", 0, I_SswCod)                            '   キーセット
                Call Ora_SetParmTable("strday2_10", 0, nouday)                              '   キーセット
                Call Ora_SetParmTable("endday2_10", 0, nouday)                              '   キーセット
                Call Ora_SetParmTable("minsuu2_10", 0, I_BraSuu)                            '   キーセット
                Call Ora_SetParmTable("maxsuu2_10", 0, I_BraSuu)                            '   キーセット

                Call Ora_SetParmTable("sykKbn2_11", 0, sykkbn)                              '   キーセット
                Call Ora_SetParmTable("shocod2_11", 0, I_ShoCod)                            '   キーセット
                Call Ora_SetParmTable("tokcod2_11", 0, I_TokCod)                            '   キーセット
                Call Ora_SetParmTable("arecod_11", 0, Com_AreCod)                           '   キーセット
                Call Ora_SetParmTable("bmncod2_11", 0, I_BmnCod)                            '   キーセット
                Call Ora_SetParmTable("strday2_11", 0, nouday)                              '   キーセット
                Call Ora_SetParmTable("endday2_11", 0, nouday)                              '   キーセット
                Call Ora_SetParmTable("minsuu2_11", 0, I_BraSuu)                            '   キーセット
                Call Ora_SetParmTable("maxsuu2_11", 0, I_BraSuu)                            '   キーセット

                Call Ora_SetParmTable("sykKbn2_12", 0, sykkbn)                              '   キーセット
                Call Ora_SetParmTable("shocod2_12", 0, I_ShoCod)                            '   キーセット
                Call Ora_SetParmTable("tokcod2_12", 0, I_TokCod)                            '   キーセット
                Call Ora_SetParmTable("arecod_12", 0, Com_AreCod)                           '   キーセット
                Call Ora_SetParmTable("strday2_12", 0, nouday)                              '   キーセット
                Call Ora_SetParmTable("endday2_12", 0, nouday)                              '   キーセット
                Call Ora_SetParmTable("minsuu2_12", 0, I_BraSuu)                            '   キーセット
                Call Ora_SetParmTable("maxsuu2_12", 0, I_BraSuu)                            '   キーセット

                Call Ora_SetParmTable("sykKbn3_13", 0, sykkbn)                                '   キーセット
                Call Ora_SetParmTable("shocod3_13", 0, I_ShoCod)                              '   キーセット
                Call Ora_SetParmTable("sttcod_13", 0, Com_SttCod)                                 '   キーセット
                Call Ora_SetParmTable("bmncod3_13", 0, I_BmnCod)                              '   キーセット
                Call Ora_SetParmTable("sswcod3_13", 0, I_SswCod)                              '   キーセット
                Call Ora_SetParmTable("strday3_13", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("endday3_13", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("minsuu3_13", 0, I_BraSuu)                              '   キーセット
                Call Ora_SetParmTable("maxsuu3_13", 0, I_BraSuu)                              '   キーセット

                Call Ora_SetParmTable("sykKbn_21", 0, "9")                                   '   キーセット
                Call Ora_SetParmTable("shocod_21", 0, I_ShoCod)                              '   キーセット
                Call Ora_SetParmTable("tokcod_21", 0, I_TokCod)                              '   キーセット
                Call Ora_SetParmTable("tkscod_21", 0, I_TksCod)                              '   キーセット
                Call Ora_SetParmTable("bmncod_21", 0, I_BmnCod)                              '   キーセット
                Call Ora_SetParmTable("sswcod_21", 0, I_SswCod)                              '   キーセット
                Call Ora_SetParmTable("strday_21", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("endday_21", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("minsuu_21", 0, I_BraSuu)                              '   キーセット
                Call Ora_SetParmTable("maxsuu_21", 0, I_BraSuu)                              '   キーセット

                Call Ora_SetParmTable("sykKbn_22", 0, "9")                                   '   キーセット
                Call Ora_SetParmTable("shocod_22", 0, I_ShoCod)                              '   キーセット
                Call Ora_SetParmTable("tokcod_22", 0, I_TokCod)                              '   キーセット
                Call Ora_SetParmTable("tkscod_22", 0, I_TksCod)                              '   キーセット
                Call Ora_SetParmTable("sswcod_22", 0, I_SswCod)                              '   キーセット
                Call Ora_SetParmTable("strday_22", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("endday_22", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("minsuu_22", 0, I_BraSuu)                              '   キーセット
                Call Ora_SetParmTable("maxsuu_22", 0, I_BraSuu)                              '   キーセット

                Call Ora_SetParmTable("sykKbn_23", 0, "9")                                   '   キーセット
                Call Ora_SetParmTable("shocod_23", 0, I_ShoCod)                              '   キーセット
                Call Ora_SetParmTable("tokcod_23", 0, I_TokCod)                              '   キーセット
                Call Ora_SetParmTable("tkscod_23", 0, I_TksCod)                              '   キーセット
                Call Ora_SetParmTable("bmncod_23", 0, I_BmnCod)                              '   キーセット
                Call Ora_SetParmTable("strday_23", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("endday_23", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("minsuu_23", 0, I_BraSuu)                              '   キーセット
                Call Ora_SetParmTable("maxsuu_23", 0, I_BraSuu)                              '   キーセット

                Call Ora_SetParmTable("sykKbn_24", 0, "9")                                   '   キーセット
                Call Ora_SetParmTable("shocod_24", 0, I_ShoCod)                              '   キーセット
                Call Ora_SetParmTable("tokcod_24", 0, I_TokCod)                              '   キーセット
                Call Ora_SetParmTable("tkscod_24", 0, I_TksCod)                              '   キーセット
                Call Ora_SetParmTable("strday_24", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("endday_24", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("minsuu_24", 0, I_BraSuu)                              '   キーセット
                Call Ora_SetParmTable("maxsuu_24", 0, I_BraSuu)                              '   キーセット

                Call Ora_SetParmTable("sykKbn_25", 0, "9")                                   '   キーセット
                Call Ora_SetParmTable("shocod_25", 0, I_ShoCod)                              '   キーセット
                Call Ora_SetParmTable("tokcod_25", 0, I_TokCod)                              '   キーセット
                Call Ora_SetParmTable("bmncod_25", 0, I_BmnCod)                              '   キーセット
                Call Ora_SetParmTable("sswcod_25", 0, I_SswCod)                              '   キーセット
                Call Ora_SetParmTable("strday_25", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("endday_25", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("minsuu_25", 0, I_BraSuu)                              '   キーセット
                Call Ora_SetParmTable("maxsuu_25", 0, I_BraSuu)                              '   キーセット

                Call Ora_SetParmTable("sykKbn_26", 0, "9")                                   '   キーセット
                Call Ora_SetParmTable("shocod_26", 0, I_ShoCod)                              '   キーセット
                Call Ora_SetParmTable("tokcod_26", 0, I_TokCod)                              '   キーセット
                Call Ora_SetParmTable("sswcod_26", 0, I_SswCod)                              '   キーセット
                Call Ora_SetParmTable("strday_26", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("endday_26", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("minsuu_26", 0, I_BraSuu)                              '   キーセット
                Call Ora_SetParmTable("maxsuu_26", 0, I_BraSuu)                              '   キーセット

                Call Ora_SetParmTable("sykKbn_27", 0, "9")                                   '   キーセット
                Call Ora_SetParmTable("shocod_27", 0, I_ShoCod)                              '   キーセット
                Call Ora_SetParmTable("tokcod_27", 0, I_TokCod)                              '   キーセット
                Call Ora_SetParmTable("bmncod_27", 0, I_BmnCod)                              '   キーセット
                Call Ora_SetParmTable("strday_27", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("endday_27", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("minsuu_27", 0, I_BraSuu)                              '   キーセット
                Call Ora_SetParmTable("maxsuu_27", 0, I_BraSuu)                              '   キーセット

                Call Ora_SetParmTable("sykKbn_28", 0, "9")                                   '   キーセット
                Call Ora_SetParmTable("shocod_28", 0, I_ShoCod)                              '   キーセット
                Call Ora_SetParmTable("tokcod_28", 0, I_TokCod)                              '   キーセット
                Call Ora_SetParmTable("strday_28", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("endday_28", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("minsuu_28", 0, I_BraSuu)                              '   キーセット
                Call Ora_SetParmTable("maxsuu_28", 0, I_BraSuu)                              '   キーセット

                Call Ora_SetParmTable("sykKbn2_29", 0, "9")                                  '   キーセット
                Call Ora_SetParmTable("shocod2_29", 0, I_ShoCod)                             '   キーセット
                Call Ora_SetParmTable("tokcod2_29", 0, I_TokCod)                             '   キーセット
                Call Ora_SetParmTable("arecod_29", 0, Com_AreCod)                            '   キーセット
                Call Ora_SetParmTable("bmncod2_29", 0, I_BmnCod)                             '   キーセット
                Call Ora_SetParmTable("sswcod2_29", 0, I_SswCod)                             '   キーセット
                Call Ora_SetParmTable("strday2_29", 0, nouday)                               '   キーセット
                Call Ora_SetParmTable("endday2_29", 0, nouday)                               '   キーセット
                Call Ora_SetParmTable("minsuu2_29", 0, I_BraSuu)                             '   キーセット
                Call Ora_SetParmTable("maxsuu2_29", 0, I_BraSuu)                             '   キーセット

                Call Ora_SetParmTable("sykKbn2_30", 0, "9")                                 '   キーセット
                Call Ora_SetParmTable("shocod2_30", 0, I_ShoCod)                            '   キーセット
                Call Ora_SetParmTable("tokcod2_30", 0, I_TokCod)                            '   キーセット
                Call Ora_SetParmTable("arecod_30", 0, Com_AreCod)                           '   キーセット
                Call Ora_SetParmTable("sswcod2_30", 0, I_SswCod)                            '   キーセット
                Call Ora_SetParmTable("strday2_30", 0, nouday)                              '   キーセット
                Call Ora_SetParmTable("endday2_30", 0, nouday)                              '   キーセット
                Call Ora_SetParmTable("minsuu2_30", 0, I_BraSuu)                            '   キーセット
                Call Ora_SetParmTable("maxsuu2_30", 0, I_BraSuu)                            '   キーセット

                Call Ora_SetParmTable("sykKbn2_31", 0, "9")                                 '   キーセット
                Call Ora_SetParmTable("shocod2_31", 0, I_ShoCod)                            '   キーセット
                Call Ora_SetParmTable("tokcod2_31", 0, I_TokCod)                            '   キーセット
                Call Ora_SetParmTable("arecod_31", 0, Com_AreCod)                           '   キーセット
                Call Ora_SetParmTable("bmncod2_31", 0, I_BmnCod)                            '   キーセット
                Call Ora_SetParmTable("strday2_31", 0, nouday)                              '   キーセット
                Call Ora_SetParmTable("endday2_31", 0, nouday)                              '   キーセット
                Call Ora_SetParmTable("minsuu2_31", 0, I_BraSuu)                            '   キーセット
                Call Ora_SetParmTable("maxsuu2_31", 0, I_BraSuu)                            '   キーセット

                Call Ora_SetParmTable("sykKbn2_32", 0, "9")                                 '   キーセット
                Call Ora_SetParmTable("shocod2_32", 0, I_ShoCod)                            '   キーセット
                Call Ora_SetParmTable("tokcod2_32", 0, I_TokCod)                            '   キーセット
                Call Ora_SetParmTable("arecod_32", 0, Com_AreCod)                           '   キーセット
                Call Ora_SetParmTable("strday2_32", 0, nouday)                              '   キーセット
                Call Ora_SetParmTable("endday2_32", 0, nouday)                              '   キーセット
                Call Ora_SetParmTable("minsuu2_32", 0, I_BraSuu)                            '   キーセット
                Call Ora_SetParmTable("maxsuu2_32", 0, I_BraSuu)                            '   キーセット

                Call Ora_SetParmTable("sykKbn3_33", 0, "9")                                 '   キーセット
                Call Ora_SetParmTable("shocod3_33", 0, I_ShoCod)                            '   キーセット
                Call Ora_SetParmTable("sttcod_33", 0, Com_SttCod)                           '   キーセット
                Call Ora_SetParmTable("bmncod3_33", 0, I_BmnCod)                            '   キーセット
                Call Ora_SetParmTable("sswcod3_33", 0, I_SswCod)                            '   キーセット
                Call Ora_SetParmTable("strday3_33", 0, nouday)                              '   キーセット
                Call Ora_SetParmTable("endday3_33", 0, nouday)                              '   キーセット
                Call Ora_SetParmTable("minsuu3_33", 0, I_BraSuu)                            '   キーセット
                Call Ora_SetParmTable("maxsuu3_33", 0, I_BraSuu)                            '   キーセット

                _ret = Ora_DbOneReadSqlEx(oradyn, SqlBuf.ToString)                        '   ＳＱＬ発行

                Select Case _ret                                                          '   ＳＱＬ発行チェック
                    Case ORA_FOUNDREC                                                     '   ＳＱＬ正常発行の場合

                        Do While oradyn.Read = True
                            O_TshTnk.hantnkDat = CDec(Trim(Com_NulCut(oradyn("HTS_HANTNK"))))
                            O_TshTnk.tentnkDat = CDec(Trim(Com_NulCut(oradyn("HTS_TENTNK"))))
                            O_TshTnk.habtnkDat = CDec(Trim(Com_NulCut(oradyn("HTS_HNBTNK"))))
                            O_TshTnk.tebtnkDat = CDec(Trim(Com_NulCut(oradyn("HTS_TNBTNK"))))
                            O_TshTnk.kkknumDat = Trim(Com_NulCut(oradyn("HTS_KKKNUM")))
                            cnt += 1
                        Loop

                        ' リーダークローズ
                        ' --------------------------------------------------
                        oradyn.Close()

                        ' パラメータ消去
                        ' --------------------------------------------------
                        Call Ora_ParmRemAll()

                        blnFound = True

                    Case ORA_NOTFOUND                                                     '   取得データなしの場合
                        ' パラメータ消去
                        ' --------------------------------------------------
                        Call Ora_ParmRemAll()

                        oradyn.Close()
                        oradyn.Dispose()
                        oradyn = Nothing
                    Case Else
                        ' パラメータ消去
                        ' --------------------------------------------------
                        Call Ora_ParmRemAll()

                        blnFound = True

                        O_TshTnk.hantnkDat = 0
                        O_TshTnk.tentnkDat = 0
                        O_TshTnk.habtnkDat = 0
                        O_TshTnk.tebtnkDat = 0
                        O_TshTnk.kkknumDat = "     "

                        MsgDat = MSG_E115 & " ERR:" & CStr(_ret)
                End Select
            End If


            If blnFound = False Then
                O_TshTnk.hantnkDat = 0
                O_TshTnk.tentnkDat = 0
                O_TshTnk.habtnkDat = 0
                O_TshTnk.tebtnkDat = 0
                O_TshTnk.kkknumDat = "     "

                _ret = SUCCESS
            End If
        Catch ex As Exception
            MsgDat = ex.ToString
            _ret = NG
        Finally
            O_TnkCnt = cnt
            If Not oradyn Is Nothing Then                                             '   オブジェクト使用時
                oradyn.Dispose()
            End If
        End Try

        oradyn = Nothing                                                              '   オブジェクトを空にする

        Com_DbGetHtk = _ret                                                           '   関数内戻り値セット
    End Function


    ''' <summary>
    '''　仕入原価取得処理  
    ''' </summary>
    ''' <param name="I_TokCod">客先コード</param>
    ''' <param name="I_ShoCod">商品コード</param>
    ''' <param name="I_Nouday">納品日付</param>
    ''' <param name="I_BraSuu">バラ数</param>
    ''' <param name="I_BmnCod">部門コード</param>
    ''' <param name="I_SswCod">勘定科目コード</param>
    ''' <param name="I_TksCod">客先支店コード</param>
    ''' <param name="I_SirCod">仕入先コード</param>
    ''' <param name="I_BstCod">納品先コード</param>
    ''' <param name="O_TnkCnt">単価件数</param>
    ''' <param name="O_SshTnk">単価情報</param>
    ''' <returns>処理結果</returns>
    ''' <remarks>仕入原価テーブルから単価情報を取得する</remarks>
    Public Function Com_DbGetSgn(ByVal I_TokCod As String, ByVal I_ShoCod As String, ByVal I_Jyuday As String, _
                                  ByVal I_Nouday As String, ByVal I_BraSuu As Decimal, ByVal I_BmnCod As String, _
                                  ByVal I_SswCod As String, ByVal I_TksCod As String, ByVal I_SirCod As String, _
                                  ByVal I_BstCod As String, ByVal I_TnkKbn As String, _
                                  ByRef O_TnkCnt As Integer, ByRef O_SshTnk As sshtnk) As Long

        Dim _ret As Long                                                                    '   リターンコード
        Dim cnt As Integer
        Dim nouday As String
        Dim oradyn As System.Data.Common.DbDataReader = Nothing
        Dim blnFound As Boolean
        Dim Com_AreCod As String = vbNullString
        Dim Com_SttCod As String = vbNullString

        O_TnkCnt = 0
        O_SshTnk = New sshtnk
        blnFound = False

        Try
            cnt = 0

            If Val(I_BstCod) = 0 Then

                '客先支店マスタより都道府県を取得
                SqlBuf = New StringBuilder
                SqlBuf.Append("SELECT                                           " & vbCrLf)     ' 
                SqlBuf.Append("    TKS_STTCOD                                   " & vbCrLf)     '
                SqlBuf.Append("FROM                                             " & vbCrLf)     '
                SqlBuf.Append("    TKSMAST                                      " & vbCrLf)     '
                SqlBuf.Append("WHERE                                            " & vbCrLf)     '
                SqlBuf.Append("    TKS_TOKCOD = :tokcod                         " & vbCrLf)     '
                SqlBuf.Append("AND TKS_TKSCOD = :tkscod                         " & vbCrLf)     '

                ' パラメータ組立
                ' --------------------------------------------------
                Call Ora_ParmRemAll()

                Call Ora_CreateParmString("tokcod", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("tkscod", ORAPARM_INPUT, 1, 5, ORA_EXEC_NORMAL) '   データ取得パラメータ作成

                Call Ora_SetParmTable("tokcod", 0, I_TokCod)                              '   キーセット
                Call Ora_SetParmTable("tkscod", 0, I_TksCod)                              '   キーセット

                _ret = Ora_DbOneReadSqlEx(oradyn, SqlBuf.ToString)                        '   ＳＱＬ発行

                Select Case _ret                                                          '   ＳＱＬ発行チェック
                    Case ORA_FOUNDREC                                                     '   ＳＱＬ正常発行の場合

                        Do While oradyn.Read = True
                            Com_SttCod = Trim(Com_NulCut(oradyn("TKS_STTCOD")))
                        Loop

                        ' パラメータ消去
                        ' --------------------------------------------------
                        Call Ora_ParmRemAll()

                        ' リーダークローズ
                        ' --------------------------------------------------
                        oradyn.Close()

                    Case ORA_NOTFOUND                                                     '   取得データなしの場合
                        ' パラメータ消去
                        ' --------------------------------------------------
                        Call Ora_ParmRemAll()

                        Com_SttCod = "000"

                        oradyn.Close()
                        oradyn.Dispose()
                        oradyn = Nothing
                End Select

                '物流エリアテーブルより物流エリアを取得
                SqlBuf = New StringBuilder
                SqlBuf.Append("SELECT                                           " & vbCrLf)     ' 
                SqlBuf.Append("    BAG_ARECOD                                   " & vbCrLf)     '
                SqlBuf.Append("FROM                                             " & vbCrLf)     '
                SqlBuf.Append("    BAGTABL                                      " & vbCrLf)     '
                SqlBuf.Append("WHERE                                            " & vbCrLf)     '
                SqlBuf.Append("    BAG_TOKCOD = :tokcod1                        " & vbCrLf)     '
                SqlBuf.Append("AND BAG_TKSCOD = :tkscod1                        " & vbCrLf)     '
                SqlBuf.Append("AND BAG_STRDAY In (                              " & vbCrLf)     '
                SqlBuf.Append("        SELECT                                   " & vbCrLf)     ' 
                SqlBuf.Append("            MAX(BAG_STRDAY)                      " & vbCrLf)     '
                SqlBuf.Append("        FROM                                     " & vbCrLf)     '
                SqlBuf.Append("            BAGTABL                              " & vbCrLf)     '
                SqlBuf.Append("        WHERE                                    " & vbCrLf)     '
                SqlBuf.Append("            BAG_TOKCOD = :tokcod2                " & vbCrLf)     '
                SqlBuf.Append("        AND BAG_TKSCOD = :tkscod2                " & vbCrLf)     '
                SqlBuf.Append("        AND BAG_STRDAY <= :nouday                " & vbCrLf)     '
                SqlBuf.Append("    )                                            " & vbCrLf)     '

                ' パラメータ組立
                ' --------------------------------------------------
                Call Ora_ParmRemAll()

                Call Ora_CreateParmString("tokcod1", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("tkscod1", ORAPARM_INPUT, 1, 5, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("tokcod2", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("tkscod2", ORAPARM_INPUT, 1, 5, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("nouday", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成

                Call Ora_SetParmTable("tokcod1", 0, I_TokCod)                              '   キーセット
                Call Ora_SetParmTable("tkscod1", 0, I_TksCod)                              '   キーセット
                Call Ora_SetParmTable("tokcod2", 0, I_TokCod)                              '   キーセット
                Call Ora_SetParmTable("tkscod2", 0, I_TksCod)                              '   キーセット
                Call Ora_SetParmTable("nouday", 0, I_Nouday)                               '   キーセット

                _ret = Ora_DbOneReadSqlEx(oradyn, SqlBuf.ToString)                        '   ＳＱＬ発行

                Select Case _ret                                                          '   ＳＱＬ発行チェック
                    Case ORA_FOUNDREC                                                     '   ＳＱＬ正常発行の場合

                        Do While oradyn.Read = True
                            Com_AreCod = Trim(Com_NulCut(oradyn("BAG_ARECOD")))
                        Loop

                        ' パラメータ消去
                        ' --------------------------------------------------
                        Call Ora_ParmRemAll()

                        ' リーダークローズ
                        ' --------------------------------------------------
                        oradyn.Close()

                    Case ORA_NOTFOUND                                                     '   取得データなしの場合
                        ' パラメータ消去
                        ' --------------------------------------------------
                        Call Ora_ParmRemAll()

                        Com_AreCod = "000"

                        oradyn.Close()
                        oradyn.Dispose()
                        oradyn = Nothing
                End Select

            Else
                Com_AreCod = "000"

                '物流センターテーブルより都道府県を取得
                SqlBuf = New StringBuilder
                SqlBuf.Append("SELECT                                           " & vbCrLf)     ' 
                SqlBuf.Append("    BST_STTCOD                                   " & vbCrLf)     '
                SqlBuf.Append("FROM                                             " & vbCrLf)     '
                SqlBuf.Append("    BSTTABL                                      " & vbCrLf)     '
                SqlBuf.Append("WHERE                                            " & vbCrLf)     '
                SqlBuf.Append("    BST_SNTCOD = :sntcod                         " & vbCrLf)     '

                ' パラメータ組立
                ' --------------------------------------------------
                Call Ora_ParmRemAll()

                Call Ora_CreateParmString("sntcod", ORAPARM_INPUT, 1, 6, ORA_EXEC_NORMAL) '   データ取得パラメータ作成

                Call Ora_SetParmTable("sntcod", 0, I_BstCod)                              '   キーセット

                _ret = Ora_DbOneReadSqlEx(oradyn, SqlBuf.ToString)                        '   ＳＱＬ発行

                Select Case _ret                                                          '   ＳＱＬ発行チェック
                    Case ORA_FOUNDREC                                                     '   ＳＱＬ正常発行の場合

                        Do While oradyn.Read = True
                            Com_SttCod = Trim(Com_NulCut(oradyn("BST_STTCOD")))
                        Loop

                        ' パラメータ消去
                        ' --------------------------------------------------
                        Call Ora_ParmRemAll()

                        ' リーダークローズ
                        ' --------------------------------------------------
                        oradyn.Close()

                    Case ORA_NOTFOUND                                                     '   取得データなしの場合
                        ' パラメータ消去
                        ' --------------------------------------------------
                        Call Ora_ParmRemAll()

                        Com_SttCod = "000"

                        oradyn.Close()
                        oradyn.Dispose()
                        oradyn = Nothing
                End Select

            End If

            If I_TnkKbn = TNKKBN_HAT Then
                nouday = I_Jyuday
            Else
                nouday = I_Nouday
            End If

            If blnFound = False Then
                SqlBuf = New StringBuilder
                SqlBuf.Append("SELECT                                           " & vbCrLf)     ' 
                SqlBuf.Append("    WRK_PRIORY ,                                 " & vbCrLf)     '
                SqlBuf.Append("    SGS_SIRTNK ,                                 " & vbCrLf)     '
                SqlBuf.Append("    SGS_SIBTNK ,                                 " & vbCrLf)     '
                SqlBuf.Append("    SGS_KKKNUM                                   " & vbCrLf)     '
                SqlBuf.Append("FROM                                             " & vbCrLf)     '
                '(1)物流センター
                SqlBuf.Append("    (                                            " & vbCrLf)     '
                SqlBuf.Append("        SELECT                                   " & vbCrLf)     ' 
                SqlBuf.Append("            1 As WRK_PRIORY ,                    " & vbCrLf)     '
                SqlBuf.Append("            SGS_SIRTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            SGS_SIBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            SGS_KKKNUM                           " & vbCrLf)     '
                SqlBuf.Append("        FROM                                     " & vbCrLf)     '
                SqlBuf.Append("            (                                    " & vbCrLf)     '
                SqlBuf.Append("                SELECT                           " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIRTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    SGS_KKKNUM                   " & vbCrLf)     '
                SqlBuf.Append("                FROM                             " & vbCrLf)     '
                SqlBuf.Append("                    SGSTABL                      " & vbCrLf)     '
                SqlBuf.Append("                WHERE                            " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIRCOD = :sircod_1       " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_SHOCOD = :shocod_1       " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_NOUKBN = '1'             " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_NOUCD1 = '00' || :bstcod_1 " & vbCrLf)   '
                SqlBuf.Append("                AND SGS_NOUCD2 = '00000'         " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_BMNCOD IN ('0000')       " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_SSWCOD IN ('00')         " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_STRDAY <= :strday_1      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_ENDDAY >= :endday_1      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_MINSUU <= :minsuu_1      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_MAXSUU >= :maxsuu_1      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_DELFLG = '" & DELFLG_NOT & "' " & vbCrLf) '
                SqlBuf.Append("            )                                    " & vbCrLf)     '
                SqlBuf.Append("    )                                            " & vbCrLf)     '
                '(3)客先店舗一致・勘定科目一致・客先部門一致
                SqlBuf.Append("    UNION ALL (                                  " & vbCrLf)     '
                SqlBuf.Append("        SELECT                                   " & vbCrLf)     ' 
                SqlBuf.Append("            2 As WRK_PRIORY ,                    " & vbCrLf)     '
                SqlBuf.Append("            SGS_SIRTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            SGS_SIBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            SGS_KKKNUM                           " & vbCrLf)     '
                SqlBuf.Append("        FROM                                     " & vbCrLf)     '
                SqlBuf.Append("            (                                    " & vbCrLf)     '
                SqlBuf.Append("                SELECT                           " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIRTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    SGS_KKKNUM                   " & vbCrLf)     '
                SqlBuf.Append("                FROM                             " & vbCrLf)     '
                SqlBuf.Append("                    SGSTABL                      " & vbCrLf)     '
                SqlBuf.Append("                WHERE                            " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIRCOD = :sircod_2       " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_SHOCOD = :shocod_2       " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_NOUKBN = '3'             " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_NOUCD1 = :tokcod_2       " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_NOUCD2 = :tkscod_2       " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_BMNCOD IN (:bmncod_2)    " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_SSWCOD IN (:sswcod_2)    " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_STRDAY <= :strday_2      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_ENDDAY >= :endday_2      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_MINSUU <= :minsuu_2      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_MAXSUU >= :maxsuu_2      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_DELFLG = '" & DELFLG_NOT & "' " & vbCrLf)     '
                SqlBuf.Append("            )                                    " & vbCrLf)     '
                SqlBuf.Append("    )                                            " & vbCrLf)     '
                '(3)客先店舗一致・勘定科目一致・客先部門ALL
                SqlBuf.Append("    UNION ALL (                                  " & vbCrLf)     '
                SqlBuf.Append("        SELECT                                   " & vbCrLf)     ' 
                SqlBuf.Append("            3 As WRK_PRIORY ,                    " & vbCrLf)     '
                SqlBuf.Append("            SGS_SIRTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            SGS_SIBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            SGS_KKKNUM                           " & vbCrLf)     '
                SqlBuf.Append("        FROM                                     " & vbCrLf)     '
                SqlBuf.Append("            (                                    " & vbCrLf)     '
                SqlBuf.Append("                SELECT                           " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIRTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    SGS_KKKNUM                   " & vbCrLf)     '
                SqlBuf.Append("                FROM                             " & vbCrLf)     '
                SqlBuf.Append("                    SGSTABL                      " & vbCrLf)     '
                SqlBuf.Append("                WHERE                            " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIRCOD = :sircod_3       " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_SHOCOD = :shocod_3       " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_NOUKBN = '3'             " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_NOUCD1 = :tokcod_3       " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_NOUCD2 = :tkscod_3       " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_BMNCOD IN ('0000')       " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_SSWCOD IN (:sswcod_3)    " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_STRDAY <= :strday_3      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_ENDDAY >= :endday_3      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_MINSUU <= :minsuu_3      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_MAXSUU >= :maxsuu_3      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_DELFLG = '" & DELFLG_NOT & "' " & vbCrLf)     '
                SqlBuf.Append("            )                                    " & vbCrLf)     '
                SqlBuf.Append("    )                                            " & vbCrLf)     '
                '(3)客先店舗一致・勘定科目ALL・客先部門一致
                SqlBuf.Append("    UNION ALL (                                  " & vbCrLf)     '
                SqlBuf.Append("        SELECT                                   " & vbCrLf)     ' 
                SqlBuf.Append("            4 As WRK_PRIORY ,                    " & vbCrLf)     '
                SqlBuf.Append("            SGS_SIRTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            SGS_SIBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            SGS_KKKNUM                           " & vbCrLf)     '
                SqlBuf.Append("        FROM                                     " & vbCrLf)     '
                SqlBuf.Append("            (                                    " & vbCrLf)     '
                SqlBuf.Append("                SELECT                           " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIRTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    SGS_KKKNUM                   " & vbCrLf)     '
                SqlBuf.Append("                FROM                             " & vbCrLf)     '
                SqlBuf.Append("                    SGSTABL                      " & vbCrLf)     '
                SqlBuf.Append("                WHERE                            " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIRCOD = :sircod_4       " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_SHOCOD = :shocod_4       " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_NOUKBN = '3'             " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_NOUCD1 = :tokcod_4       " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_NOUCD2 = :tkscod_4       " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_BMNCOD IN (:bmncod_4)    " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_SSWCOD IN ('00')         " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_STRDAY <= :strday_4      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_ENDDAY >= :endday_4      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_MINSUU <= :minsuu_4      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_MAXSUU >= :maxsuu_4      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_DELFLG = '" & DELFLG_NOT & "' " & vbCrLf)     '
                SqlBuf.Append("            )                                    " & vbCrLf)     '
                SqlBuf.Append("    )                                            " & vbCrLf)     '
                '(3)客先店舗一致・勘定科目ALL・客先部門ALL
                SqlBuf.Append("    UNION ALL (                                  " & vbCrLf)     '
                SqlBuf.Append("        SELECT                                   " & vbCrLf)     ' 
                SqlBuf.Append("            5 As WRK_PRIORY ,                    " & vbCrLf)     '
                SqlBuf.Append("            SGS_SIRTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            SGS_SIBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            SGS_KKKNUM                           " & vbCrLf)     '
                SqlBuf.Append("        FROM                                     " & vbCrLf)     '
                SqlBuf.Append("            (                                    " & vbCrLf)     '
                SqlBuf.Append("                SELECT                           " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIRTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    SGS_KKKNUM                   " & vbCrLf)     '
                SqlBuf.Append("                FROM                             " & vbCrLf)     '
                SqlBuf.Append("                    SGSTABL                      " & vbCrLf)     '
                SqlBuf.Append("                WHERE                            " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIRCOD = :sircod_5       " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_SHOCOD = :shocod_5       " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_NOUKBN = '3'             " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_NOUCD1 = :tokcod_5       " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_NOUCD2 = :tkscod_5       " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_BMNCOD IN ('0000')       " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_SSWCOD IN ('00')         " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_STRDAY <= :strday_5      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_ENDDAY >= :endday_5      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_MINSUU <= :minsuu_5      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_MAXSUU >= :maxsuu_5      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_DELFLG = '" & DELFLG_NOT & "' " & vbCrLf)     '
                SqlBuf.Append("            )                                    " & vbCrLf)     '
                SqlBuf.Append("    )                                            " & vbCrLf)     '
                '(0)客先一致・勘定科目一致・客先部門一致
                SqlBuf.Append("    UNION ALL (                                  " & vbCrLf)     '
                SqlBuf.Append("        SELECT                                   " & vbCrLf)     ' 
                SqlBuf.Append("            6 As WRK_PRIORY ,                    " & vbCrLf)     '
                SqlBuf.Append("            SGS_SIRTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            SGS_SIBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            SGS_KKKNUM                           " & vbCrLf)     '
                SqlBuf.Append("        FROM                                     " & vbCrLf)     '
                SqlBuf.Append("            (                                    " & vbCrLf)     '
                SqlBuf.Append("                SELECT                           " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIRTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    SGS_KKKNUM                   " & vbCrLf)     '
                SqlBuf.Append("                FROM                             " & vbCrLf)     '
                SqlBuf.Append("                    SGSTABL                      " & vbCrLf)     '
                SqlBuf.Append("                WHERE                            " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIRCOD = :sircod_6       " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_SHOCOD = :shocod_6       " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_NOUKBN = '0'             " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_NOUCD1 = :tokcod_6       " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_NOUCD2 = '00000'         " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_BMNCOD IN (:bmncod_6)    " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_SSWCOD IN (:sswcod_6)    " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_STRDAY <= :strday_6      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_ENDDAY >= :endday_6      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_MINSUU <= :minsuu_6      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_MAXSUU >= :maxsuu_6      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_DELFLG = '" & DELFLG_NOT & "' " & vbCrLf)     '
                SqlBuf.Append("            )                                    " & vbCrLf)     '
                SqlBuf.Append("    )                                            " & vbCrLf)     '
                '(0)客先一致・勘定科目一致・客先部門ALL
                SqlBuf.Append("    UNION ALL (                                  " & vbCrLf)     '
                SqlBuf.Append("        SELECT                                   " & vbCrLf)     ' 
                SqlBuf.Append("            7 As WRK_PRIORY ,                    " & vbCrLf)     '
                SqlBuf.Append("            SGS_SIRTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            SGS_SIBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            SGS_KKKNUM                           " & vbCrLf)     '
                SqlBuf.Append("        FROM                                     " & vbCrLf)     '
                SqlBuf.Append("            (                                    " & vbCrLf)     '
                SqlBuf.Append("                SELECT                           " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIRTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    SGS_KKKNUM                   " & vbCrLf)     '
                SqlBuf.Append("                FROM                             " & vbCrLf)     '
                SqlBuf.Append("                    SGSTABL                      " & vbCrLf)     '
                SqlBuf.Append("                WHERE                            " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIRCOD = :sircod_7       " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_SHOCOD = :shocod_7       " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_NOUKBN = '0'             " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_NOUCD1 = :tokcod_7       " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_NOUCD2 = '00000'         " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_BMNCOD IN ('0000')       " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_SSWCOD IN (:sswcod_7)    " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_STRDAY <= :strday_7      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_ENDDAY >= :endday_7      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_MINSUU <= :minsuu_7      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_MAXSUU >= :maxsuu_7      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_DELFLG = '" & DELFLG_NOT & "' " & vbCrLf)     '
                SqlBuf.Append("            )                                    " & vbCrLf)     '
                SqlBuf.Append("    )                                            " & vbCrLf)     '
                '(0)客先一致・勘定科目ALL・客先部門一致
                SqlBuf.Append("    UNION ALL (                                  " & vbCrLf)     '
                SqlBuf.Append("        SELECT                                   " & vbCrLf)     ' 
                SqlBuf.Append("            8 As WRK_PRIORY ,                    " & vbCrLf)     '
                SqlBuf.Append("            SGS_SIRTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            SGS_SIBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            SGS_KKKNUM                           " & vbCrLf)     '
                SqlBuf.Append("        FROM                                     " & vbCrLf)     '
                SqlBuf.Append("            (                                    " & vbCrLf)     '
                SqlBuf.Append("                SELECT                           " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIRTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    SGS_KKKNUM                   " & vbCrLf)     '
                SqlBuf.Append("                FROM                             " & vbCrLf)     '
                SqlBuf.Append("                    SGSTABL                      " & vbCrLf)     '
                SqlBuf.Append("                WHERE                            " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIRCOD = :sircod_8       " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_SHOCOD = :shocod_8       " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_NOUKBN = '0'             " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_NOUCD1 = :tokcod_8       " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_NOUCD2 = '00000'         " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_BMNCOD IN (:bmncod_8)    " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_SSWCOD IN ('00')         " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_STRDAY <= :strday_8      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_ENDDAY >= :endday_8      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_MINSUU <= :minsuu_8      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_MAXSUU >= :maxsuu_8      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_DELFLG = '" & DELFLG_NOT & "' " & vbCrLf)     '
                SqlBuf.Append("            )                                    " & vbCrLf)     '
                SqlBuf.Append("    )                                            " & vbCrLf)     '
                '(0)客先一致・勘定科目ALL・客先部門ALL
                SqlBuf.Append("    UNION ALL (                                  " & vbCrLf)     '
                SqlBuf.Append("        SELECT                                   " & vbCrLf)     ' 
                SqlBuf.Append("            9 As WRK_PRIORY ,                    " & vbCrLf)     '
                SqlBuf.Append("            SGS_SIRTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            SGS_SIBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            SGS_KKKNUM                           " & vbCrLf)     '
                SqlBuf.Append("        FROM                                     " & vbCrLf)     '
                SqlBuf.Append("            (                                    " & vbCrLf)     '
                SqlBuf.Append("                SELECT                           " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIRTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    SGS_KKKNUM                   " & vbCrLf)     '
                SqlBuf.Append("                FROM                             " & vbCrLf)     '
                SqlBuf.Append("                    SGSTABL                      " & vbCrLf)     '
                SqlBuf.Append("                WHERE                            " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIRCOD = :sircod_9       " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_SHOCOD = :shocod_9       " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_NOUKBN = '0'             " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_NOUCD1 = :tokcod_9       " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_NOUCD2 = '00000'         " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_BMNCOD IN ('0000')       " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_SSWCOD IN ('00')         " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_STRDAY <= :strday_9      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_ENDDAY >= :endday_9      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_MINSUU <= :minsuu_9      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_MAXSUU >= :maxsuu_9      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_DELFLG = '" & DELFLG_NOT & "' " & vbCrLf)     '
                SqlBuf.Append("            )                                    " & vbCrLf)     '
                SqlBuf.Append("    )                                            " & vbCrLf)     '
                '(2)客先エリア一致・勘定科目一致・客先部門一致
                SqlBuf.Append("    UNION ALL (                                  " & vbCrLf)     '
                SqlBuf.Append("        SELECT                                   " & vbCrLf)     ' 
                SqlBuf.Append("            10 As WRK_PRIORY ,                   " & vbCrLf)     '
                SqlBuf.Append("            SGS_SIRTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            SGS_SIBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            SGS_KKKNUM                           " & vbCrLf)     '
                SqlBuf.Append("        FROM                                     " & vbCrLf)     '
                SqlBuf.Append("            (                                    " & vbCrLf)     '
                SqlBuf.Append("                SELECT                           " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIRTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    SGS_KKKNUM                   " & vbCrLf)     '
                SqlBuf.Append("                FROM                             " & vbCrLf)     '
                SqlBuf.Append("                    SGSTABL                      " & vbCrLf)     '
                SqlBuf.Append("                WHERE                            " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIRCOD = :sircod_10      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_SHOCOD = :shocod_10      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_NOUKBN = '2'             " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_NOUCD1 = :tokcod_10      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_NOUCD2 = '00' || :arecod_10 " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_BMNCOD IN (:bmncod_10)   " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_SSWCOD IN (:sswcod_10)   " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_STRDAY <= :strday_10     " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_ENDDAY >= :endday_10     " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_MINSUU <= :minsuu_10     " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_MAXSUU >= :maxsuu_10     " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_DELFLG = '" & DELFLG_NOT & "' " & vbCrLf)     '
                SqlBuf.Append("            )                                    " & vbCrLf)     '
                SqlBuf.Append("    )                                            " & vbCrLf)     '
                '(2)客先エリア一致・勘定科目一致・客先部門ALL
                SqlBuf.Append("    UNION ALL (                                  " & vbCrLf)     '
                SqlBuf.Append("        SELECT                                   " & vbCrLf)     ' 
                SqlBuf.Append("            11 As WRK_PRIORY ,                   " & vbCrLf)     '
                SqlBuf.Append("            SGS_SIRTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            SGS_SIBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            SGS_KKKNUM                           " & vbCrLf)     '
                SqlBuf.Append("        FROM                                     " & vbCrLf)     '
                SqlBuf.Append("            (                                    " & vbCrLf)     '
                SqlBuf.Append("                SELECT                           " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIRTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    SGS_KKKNUM                   " & vbCrLf)     '
                SqlBuf.Append("                FROM                             " & vbCrLf)     '
                SqlBuf.Append("                    SGSTABL                      " & vbCrLf)     '
                SqlBuf.Append("                WHERE                            " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIRCOD = :sircod_11      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_SHOCOD = :shocod_11      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_NOUKBN = '2'             " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_NOUCD1 = :tokcod_11      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_NOUCD2 = '00' || :arecod_11 " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_BMNCOD IN ('0000')       " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_SSWCOD IN (:sswcod_11)   " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_STRDAY <= :strday_11     " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_ENDDAY >= :endday_11     " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_MINSUU <= :minsuu_11     " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_MAXSUU >= :maxsuu_11     " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_DELFLG = '" & DELFLG_NOT & "'    " & vbCrLf)     '
                SqlBuf.Append("            )                                    " & vbCrLf)     '
                SqlBuf.Append("    )                                            " & vbCrLf)     '
                '(2)客先エリア一致・勘定科目ALL・客先部門一致
                SqlBuf.Append("    UNION ALL (                                  " & vbCrLf)     '
                SqlBuf.Append("        SELECT                                   " & vbCrLf)     ' 
                SqlBuf.Append("            12 As WRK_PRIORY ,                   " & vbCrLf)     '
                SqlBuf.Append("            SGS_SIRTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            SGS_SIBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            SGS_KKKNUM                           " & vbCrLf)     '
                SqlBuf.Append("        FROM                                     " & vbCrLf)     '
                SqlBuf.Append("            (                                    " & vbCrLf)     '
                SqlBuf.Append("                SELECT                           " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIRTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    SGS_KKKNUM                   " & vbCrLf)     '
                SqlBuf.Append("                FROM                             " & vbCrLf)     '
                SqlBuf.Append("                    SGSTABL                      " & vbCrLf)     '
                SqlBuf.Append("                WHERE                            " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIRCOD = :sircod_12      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_SHOCOD = :shocod_12      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_NOUKBN = '2'             " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_NOUCD1 = :tokcod_12      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_NOUCD2 = '00' || :arecod_12 " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_BMNCOD IN (:bmncod_12)   " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_SSWCOD IN ('00')         " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_STRDAY <= :strday_12     " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_ENDDAY >= :endday_12     " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_MINSUU <= :minsuu_12     " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_MAXSUU >= :maxsuu_12     " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_DELFLG = '" & DELFLG_NOT & "' " & vbCrLf)     '
                SqlBuf.Append("            )                                    " & vbCrLf)     '
                SqlBuf.Append("    )                                            " & vbCrLf)     '
                '(2)客先エリア一致・勘定科目ALL・客先部門ALL
                SqlBuf.Append("    UNION ALL (                                  " & vbCrLf)     '
                SqlBuf.Append("        SELECT                                   " & vbCrLf)     ' 
                SqlBuf.Append("            13 As WRK_PRIORY ,                   " & vbCrLf)     '
                SqlBuf.Append("            SGS_SIRTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            SGS_SIBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            SGS_KKKNUM                           " & vbCrLf)     '
                SqlBuf.Append("        FROM                                     " & vbCrLf)     '
                SqlBuf.Append("            (                                    " & vbCrLf)     '
                SqlBuf.Append("                SELECT                           " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIRTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    SGS_KKKNUM                   " & vbCrLf)     '
                SqlBuf.Append("                FROM                             " & vbCrLf)     '
                SqlBuf.Append("                    SGSTABL                      " & vbCrLf)     '
                SqlBuf.Append("                WHERE                            " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIRCOD = :sircod_13      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_SHOCOD = :shocod_13      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_NOUKBN = '2'             " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_NOUCD1 = :tokcod_13      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_NOUCD2 = '00' || :arecod_13 " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_BMNCOD IN ('0000')       " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_SSWCOD IN ('00')         " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_STRDAY <= :strday_13     " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_ENDDAY >= :endday_13     " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_MINSUU <= :minsuu_13     " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_MAXSUU >= :maxsuu_13     " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_DELFLG = '" & DELFLG_NOT & "' " & vbCrLf)     '
                SqlBuf.Append("            )                                    " & vbCrLf)     '
                SqlBuf.Append("    )                                            " & vbCrLf)     '
                '(4)都道府県 
                SqlBuf.Append("    UNION ALL (                                  " & vbCrLf)     '
                SqlBuf.Append("        SELECT                                   " & vbCrLf)     ' 
                SqlBuf.Append("            14 As WRK_PRIORY ,                   " & vbCrLf)     '
                SqlBuf.Append("            SGS_SIRTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            SGS_SIBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            SGS_KKKNUM                           " & vbCrLf)     '
                SqlBuf.Append("        FROM                                     " & vbCrLf)     '
                SqlBuf.Append("            (                                    " & vbCrLf)     '
                SqlBuf.Append("                SELECT                           " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIRTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    SGS_KKKNUM                   " & vbCrLf)     '
                SqlBuf.Append("                FROM                             " & vbCrLf)     '
                SqlBuf.Append("                    SGSTABL                      " & vbCrLf)     '
                SqlBuf.Append("                WHERE                            " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIRCOD = :sircod_14      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_SHOCOD = :shocod_14      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_NOUKBN = '4'             " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_NOUCD1 = '00000' || :sttcod_14 " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_NOUCD2 = '00000'         " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_BMNCOD In ('0000',:bmncod_14) " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_SSWCOD In ('00'  ,:sswcod_14) " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_STRDAY <= :strday_14     " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_ENDDAY >= :endday_14     " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_MINSUU <= :minsuu_14     " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_MAXSUU >= :maxsuu_14     " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_DELFLG = '" & DELFLG_NOT & "' " & vbCrLf)     '
                SqlBuf.Append("            )                                    " & vbCrLf)     '
                SqlBuf.Append("    )                                            " & vbCrLf)     '
                '(9)共通 
                SqlBuf.Append("    UNION ALL (                                  " & vbCrLf)     '
                SqlBuf.Append("        SELECT                                   " & vbCrLf)     ' 
                SqlBuf.Append("            15 As WRK_PRIORY ,                   " & vbCrLf)     '
                SqlBuf.Append("            SGS_SIRTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            SGS_SIBTNK ,                         " & vbCrLf)     '
                SqlBuf.Append("            SGS_KKKNUM                           " & vbCrLf)     '
                SqlBuf.Append("        FROM                                     " & vbCrLf)     '
                SqlBuf.Append("            (                                    " & vbCrLf)     '
                SqlBuf.Append("                SELECT                           " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIRTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIBTNK ,                 " & vbCrLf)     '
                SqlBuf.Append("                    SGS_KKKNUM                   " & vbCrLf)     '
                SqlBuf.Append("                FROM                             " & vbCrLf)     '
                SqlBuf.Append("                    SGSTABL                      " & vbCrLf)     '
                SqlBuf.Append("                WHERE                            " & vbCrLf)     '
                SqlBuf.Append("                    SGS_SIRCOD = :sircod_15      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_SHOCOD = :shocod_15      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_NOUKBN = '9'             " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_NOUCD1 = '00000000'      " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_NOUCD2 = '00000'         " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_BMNCOD In ('0000',:bmncod_15) " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_SSWCOD In ('00'  ,:sswcod_15) " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_STRDAY <= :strday_15     " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_ENDDAY >= :endday_15     " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_MINSUU <= :minsuu_15     " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_MAXSUU >= :maxsuu_15     " & vbCrLf)     '
                SqlBuf.Append("                AND SGS_DELFLG = '" & DELFLG_NOT & "' " & vbCrLf)     '
                SqlBuf.Append("            )                                    " & vbCrLf)     '
                SqlBuf.Append("    )                                            " & vbCrLf)     '

                SqlBuf.Append("ORDER BY                                         " & vbCrLf)     '
                SqlBuf.Append("    WRK_PRIORY DESC ,                            " & vbCrLf)     '
                SqlBuf.Append("    SGS_SIBTNK DESC                              " & vbCrLf)     '

                ' パラメータ組立
                ' --------------------------------------------------
                Call Ora_ParmRemAll()
                Call Ora_CreateParmString("sircod_1", ORAPARM_INPUT, 1, 7, ORA_EXEC_NORMAL) '  データ取得パラメータ作成
                Call Ora_CreateParmString("shocod_1", ORAPARM_INPUT, 1, 13, ORA_EXEC_NORMAL) '  データ取得パラメータ作成
                Call Ora_CreateParmString("bstcod_1", ORAPARM_INPUT, 1, 6, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("strday_1", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("endday_1", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("minsuu_1", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("maxsuu_1", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成

                Call Ora_CreateParmString("sircod_2", ORAPARM_INPUT, 1, 7, ORA_EXEC_NORMAL) '  データ取得パラメータ作成
                Call Ora_CreateParmString("shocod_2", ORAPARM_INPUT, 1, 13, ORA_EXEC_NORMAL) '  データ取得パラメータ作成
                Call Ora_CreateParmString("tokcod_2", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("tkscod_2", ORAPARM_INPUT, 1, 5, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("bmncod_2", ORAPARM_INPUT, 1, 4, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("sswcod_2", ORAPARM_INPUT, 1, 2, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("strday_2", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("endday_2", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("minsuu_2", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("maxsuu_2", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成

                Call Ora_CreateParmString("sircod_3", ORAPARM_INPUT, 1, 7, ORA_EXEC_NORMAL) '  データ取得パラメータ作成
                Call Ora_CreateParmString("shocod_3", ORAPARM_INPUT, 1, 13, ORA_EXEC_NORMAL) '  データ取得パラメータ作成
                Call Ora_CreateParmString("tokcod_3", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("tkscod_3", ORAPARM_INPUT, 1, 5, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("sswcod_3", ORAPARM_INPUT, 1, 2, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("strday_3", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("endday_3", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("minsuu_3", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("maxsuu_3", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成

                Call Ora_CreateParmString("sircod_4", ORAPARM_INPUT, 1, 7, ORA_EXEC_NORMAL) '  データ取得パラメータ作成
                Call Ora_CreateParmString("shocod_4", ORAPARM_INPUT, 1, 13, ORA_EXEC_NORMAL) '  データ取得パラメータ作成
                Call Ora_CreateParmString("tokcod_4", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("tkscod_4", ORAPARM_INPUT, 1, 5, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("bmncod_4", ORAPARM_INPUT, 1, 4, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("strday_4", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("endday_4", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("minsuu_4", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("maxsuu_4", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成

                Call Ora_CreateParmString("sircod_5", ORAPARM_INPUT, 1, 7, ORA_EXEC_NORMAL) '  データ取得パラメータ作成
                Call Ora_CreateParmString("shocod_5", ORAPARM_INPUT, 1, 13, ORA_EXEC_NORMAL) '  データ取得パラメータ作成
                Call Ora_CreateParmString("tokcod_5", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("tkscod_5", ORAPARM_INPUT, 1, 5, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("strday_5", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("endday_5", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("minsuu_5", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("maxsuu_5", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成

                Call Ora_CreateParmString("sircod_6", ORAPARM_INPUT, 1, 7, ORA_EXEC_NORMAL) '  データ取得パラメータ作成
                Call Ora_CreateParmString("shocod_6", ORAPARM_INPUT, 1, 13, ORA_EXEC_NORMAL) '  データ取得パラメータ作成
                Call Ora_CreateParmString("tokcod_6", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("bmncod_6", ORAPARM_INPUT, 1, 4, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("sswcod_6", ORAPARM_INPUT, 1, 2, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("strday_6", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("endday_6", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("minsuu_6", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("maxsuu_6", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成

                Call Ora_CreateParmString("sircod_7", ORAPARM_INPUT, 1, 7, ORA_EXEC_NORMAL) '  データ取得パラメータ作成
                Call Ora_CreateParmString("shocod_7", ORAPARM_INPUT, 1, 13, ORA_EXEC_NORMAL) '  データ取得パラメータ作成
                Call Ora_CreateParmString("tokcod_7", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("sswcod_7", ORAPARM_INPUT, 1, 2, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("strday_7", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("endday_7", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("minsuu_7", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("maxsuu_7", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成

                Call Ora_CreateParmString("sircod_8", ORAPARM_INPUT, 1, 7, ORA_EXEC_NORMAL) '  データ取得パラメータ作成
                Call Ora_CreateParmString("shocod_8", ORAPARM_INPUT, 1, 13, ORA_EXEC_NORMAL) '  データ取得パラメータ作成
                Call Ora_CreateParmString("tokcod_8", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("bmncod_8", ORAPARM_INPUT, 1, 4, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("strday_8", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("endday_8", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("minsuu_8", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("maxsuu_8", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成

                Call Ora_CreateParmString("sircod_9", ORAPARM_INPUT, 1, 7, ORA_EXEC_NORMAL) '  データ取得パラメータ作成
                Call Ora_CreateParmString("shocod_9", ORAPARM_INPUT, 1, 13, ORA_EXEC_NORMAL) '  データ取得パラメータ作成
                Call Ora_CreateParmString("tokcod_9", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("strday_9", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("endday_9", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("minsuu_9", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("maxsuu_9", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成

                Call Ora_CreateParmString("sircod_10", ORAPARM_INPUT, 1, 7, ORA_EXEC_NORMAL) '  データ取得パラメータ作成
                Call Ora_CreateParmString("shocod_10", ORAPARM_INPUT, 1, 13, ORA_EXEC_NORMAL) '  データ取得パラメータ作成
                Call Ora_CreateParmString("tokcod_10", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("arecod_10", ORAPARM_INPUT, 1, 3, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("bmncod_10", ORAPARM_INPUT, 1, 4, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("sswcod_10", ORAPARM_INPUT, 1, 2, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("strday_10", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("endday_10", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("minsuu_10", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("maxsuu_10", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成

                Call Ora_CreateParmString("sircod_11", ORAPARM_INPUT, 1, 7, ORA_EXEC_NORMAL) '  データ取得パラメータ作成
                Call Ora_CreateParmString("shocod_11", ORAPARM_INPUT, 1, 13, ORA_EXEC_NORMAL) '  データ取得パラメータ作成
                Call Ora_CreateParmString("tokcod_11", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("arecod_11", ORAPARM_INPUT, 1, 3, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("sswcod_11", ORAPARM_INPUT, 1, 2, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("strday_11", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("endday_11", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("minsuu_11", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("maxsuu_11", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成

                Call Ora_CreateParmString("sircod_12", ORAPARM_INPUT, 1, 7, ORA_EXEC_NORMAL) '  データ取得パラメータ作成
                Call Ora_CreateParmString("shocod_12", ORAPARM_INPUT, 1, 13, ORA_EXEC_NORMAL) '  データ取得パラメータ作成
                Call Ora_CreateParmString("tokcod_12", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("arecod_12", ORAPARM_INPUT, 1, 3, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("bmncod_12", ORAPARM_INPUT, 1, 4, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("strday_12", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("endday_12", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("minsuu_12", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("maxsuu_12", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成

                Call Ora_CreateParmString("sircod_13", ORAPARM_INPUT, 1, 7, ORA_EXEC_NORMAL) '  データ取得パラメータ作成
                Call Ora_CreateParmString("shocod_13", ORAPARM_INPUT, 1, 13, ORA_EXEC_NORMAL) '  データ取得パラメータ作成
                Call Ora_CreateParmString("tokcod_13", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("arecod_13", ORAPARM_INPUT, 1, 3, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("strday_13", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("endday_13", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("minsuu_13", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("maxsuu_13", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成

                Call Ora_CreateParmString("sircod_14", ORAPARM_INPUT, 1, 7, ORA_EXEC_NORMAL) '  データ取得パラメータ作成
                Call Ora_CreateParmString("shocod_14", ORAPARM_INPUT, 1, 13, ORA_EXEC_NORMAL) '  データ取得パラメータ作成
                Call Ora_CreateParmString("sttcod_14", ORAPARM_INPUT, 1, 3, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("bmncod_14", ORAPARM_INPUT, 1, 4, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("sswcod_14", ORAPARM_INPUT, 1, 2, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("strday_14", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("endday_14", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("minsuu_14", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("maxsuu_14", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成

                Call Ora_CreateParmString("sircod_15", ORAPARM_INPUT, 1, 7, ORA_EXEC_NORMAL) '  データ取得パラメータ作成
                Call Ora_CreateParmString("shocod_15", ORAPARM_INPUT, 1, 13, ORA_EXEC_NORMAL) '  データ取得パラメータ作成
                Call Ora_CreateParmString("bmncod_15", ORAPARM_INPUT, 1, 4, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("sswcod_15", ORAPARM_INPUT, 1, 2, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("strday_15", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmString("endday_15", ORAPARM_INPUT, 1, 8, ORA_EXEC_NORMAL) '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("minsuu_15", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成
                Call Ora_CreateParmNumber("maxsuu_15", ORAPARM_INPUT, 1, ORA_EXEC_NORMAL)    '   データ取得パラメータ作成

                Call Ora_SetParmTable("sircod_1", 0, I_SirCod)                              '   キーセット
                Call Ora_SetParmTable("shocod_1", 0, I_ShoCod)                              '   キーセット
                Call Ora_SetParmTable("bstcod_1", 0, I_BstCod)                              '   キーセット
                Call Ora_SetParmTable("strday_1", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("endday_1", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("minsuu_1", 0, I_BraSuu)                              '   キーセット
                Call Ora_SetParmTable("maxsuu_1", 0, I_BraSuu)                              '   キーセット

                Call Ora_SetParmTable("sircod_2", 0, I_SirCod)                              '   キーセット
                Call Ora_SetParmTable("shocod_2", 0, I_ShoCod)                              '   キーセット
                Call Ora_SetParmTable("tokcod_2", 0, I_TokCod)                              '   キーセット
                Call Ora_SetParmTable("tkscod_2", 0, I_TksCod)                              '   キーセット
                Call Ora_SetParmTable("bmncod_2", 0, I_BmnCod)                              '   キーセット
                Call Ora_SetParmTable("sswcod_2", 0, I_SswCod)                              '   キーセット
                Call Ora_SetParmTable("strday_2", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("endday_2", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("minsuu_2", 0, I_BraSuu)                              '   キーセット
                Call Ora_SetParmTable("maxsuu_2", 0, I_BraSuu)                              '   キーセット

                Call Ora_SetParmTable("sircod_3", 0, I_SirCod)                              '   キーセット
                Call Ora_SetParmTable("shocod_3", 0, I_ShoCod)                              '   キーセット
                Call Ora_SetParmTable("tokcod_3", 0, I_TokCod)                              '   キーセット
                Call Ora_SetParmTable("tkscod_3", 0, I_TksCod)                              '   キーセット
                Call Ora_SetParmTable("sswcod_3", 0, I_SswCod)                              '   キーセット
                Call Ora_SetParmTable("strday_3", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("endday_3", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("minsuu_3", 0, I_BraSuu)                              '   キーセット
                Call Ora_SetParmTable("maxsuu_3", 0, I_BraSuu)                              '   キーセット

                Call Ora_SetParmTable("sircod_4", 0, I_SirCod)                              '   キーセット
                Call Ora_SetParmTable("shocod_4", 0, I_ShoCod)                              '   キーセット
                Call Ora_SetParmTable("tokcod_4", 0, I_TokCod)                              '   キーセット
                Call Ora_SetParmTable("tkscod_4", 0, I_TksCod)                              '   キーセット
                Call Ora_SetParmTable("bmncod_4", 0, I_BmnCod)                              '   キーセット
                Call Ora_SetParmTable("strday_4", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("endday_4", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("minsuu_4", 0, I_BraSuu)                              '   キーセット
                Call Ora_SetParmTable("maxsuu_4", 0, I_BraSuu)                              '   キーセット

                Call Ora_SetParmTable("sircod_5", 0, I_SirCod)                              '   キーセット
                Call Ora_SetParmTable("shocod_5", 0, I_ShoCod)                              '   キーセット
                Call Ora_SetParmTable("tokcod_5", 0, I_TokCod)                              '   キーセット
                Call Ora_SetParmTable("tkscod_5", 0, I_TksCod)                              '   キーセット
                Call Ora_SetParmTable("strday_5", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("endday_5", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("minsuu_5", 0, I_BraSuu)                              '   キーセット
                Call Ora_SetParmTable("maxsuu_5", 0, I_BraSuu)                              '   キーセット

                Call Ora_SetParmTable("sircod_6", 0, I_SirCod)                              '   キーセット
                Call Ora_SetParmTable("shocod_6", 0, I_ShoCod)                              '   キーセット
                Call Ora_SetParmTable("tokcod_6", 0, I_TokCod)                              '   キーセット
                Call Ora_SetParmTable("bmncod_6", 0, I_BmnCod)                              '   キーセット
                Call Ora_SetParmTable("sswcod_6", 0, I_SswCod)                              '   キーセット
                Call Ora_SetParmTable("strday_6", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("endday_6", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("minsuu_6", 0, I_BraSuu)                              '   キーセット
                Call Ora_SetParmTable("maxsuu_6", 0, I_BraSuu)                              '   キーセット

                Call Ora_SetParmTable("sircod_7", 0, I_SirCod)                              '   キーセット
                Call Ora_SetParmTable("shocod_7", 0, I_ShoCod)                              '   キーセット
                Call Ora_SetParmTable("tokcod_7", 0, I_TokCod)                              '   キーセット
                Call Ora_SetParmTable("sswcod_7", 0, I_SswCod)                              '   キーセット
                Call Ora_SetParmTable("strday_7", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("endday_7", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("minsuu_7", 0, I_BraSuu)                              '   キーセット
                Call Ora_SetParmTable("maxsuu_7", 0, I_BraSuu)                              '   キーセット

                Call Ora_SetParmTable("sircod_8", 0, I_SirCod)                              '   キーセット
                Call Ora_SetParmTable("shocod_8", 0, I_ShoCod)                              '   キーセット
                Call Ora_SetParmTable("tokcod_8", 0, I_TokCod)                              '   キーセット
                Call Ora_SetParmTable("bmncod_8", 0, I_BmnCod)                              '   キーセット
                Call Ora_SetParmTable("strday_8", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("endday_8", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("minsuu_8", 0, I_BraSuu)                              '   キーセット
                Call Ora_SetParmTable("maxsuu_8", 0, I_BraSuu)                              '   キーセット

                Call Ora_SetParmTable("sircod_9", 0, I_SirCod)                              '   キーセット
                Call Ora_SetParmTable("shocod_9", 0, I_ShoCod)                              '   キーセット
                Call Ora_SetParmTable("tokcod_9", 0, I_TokCod)                              '   キーセット
                Call Ora_SetParmTable("strday_9", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("endday_9", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("minsuu_9", 0, I_BraSuu)                              '   キーセット
                Call Ora_SetParmTable("maxsuu_9", 0, I_BraSuu)                              '   キーセット

                Call Ora_SetParmTable("sircod_10", 0, I_SirCod)                              '   キーセット
                Call Ora_SetParmTable("shocod_10", 0, I_ShoCod)                              '   キーセット
                Call Ora_SetParmTable("tokcod_10", 0, I_TokCod)                              '   キーセット
                Call Ora_SetParmTable("arecod_10", 0, Com_AreCod)                                '   キーセット
                Call Ora_SetParmTable("bmncod_10", 0, I_BmnCod)                              '   キーセット
                Call Ora_SetParmTable("sswcod_10", 0, I_SswCod)                              '   キーセット
                Call Ora_SetParmTable("strday_10", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("endday_10", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("minsuu_10", 0, I_BraSuu)                              '   キーセット
                Call Ora_SetParmTable("maxsuu_10", 0, I_BraSuu)                              '   キーセット

                Call Ora_SetParmTable("sircod_11", 0, I_SirCod)                              '   キーセット
                Call Ora_SetParmTable("shocod_11", 0, I_ShoCod)                              '   キーセット
                Call Ora_SetParmTable("tokcod_11", 0, I_TokCod)                              '   キーセット
                Call Ora_SetParmTable("arecod_11", 0, Com_AreCod)                                '   キーセット
                Call Ora_SetParmTable("sswcod_11", 0, I_SswCod)                              '   キーセット
                Call Ora_SetParmTable("strday_11", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("endday_11", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("minsuu_11", 0, I_BraSuu)                              '   キーセット
                Call Ora_SetParmTable("maxsuu_11", 0, I_BraSuu)                              '   キーセット

                Call Ora_SetParmTable("sircod_12", 0, I_SirCod)                              '   キーセット
                Call Ora_SetParmTable("shocod_12", 0, I_ShoCod)                              '   キーセット
                Call Ora_SetParmTable("tokcod_12", 0, I_TokCod)                              '   キーセット
                Call Ora_SetParmTable("arecod_12", 0, Com_AreCod)                                '   キーセット
                Call Ora_SetParmTable("bmncod_12", 0, I_BmnCod)                              '   キーセット
                Call Ora_SetParmTable("strday_12", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("endday_12", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("minsuu_12", 0, I_BraSuu)                              '   キーセット
                Call Ora_SetParmTable("maxsuu_12", 0, I_BraSuu)                              '   キーセット

                Call Ora_SetParmTable("sircod_13", 0, I_SirCod)                              '   キーセット
                Call Ora_SetParmTable("shocod_13", 0, I_ShoCod)                              '   キーセット
                Call Ora_SetParmTable("tokcod_13", 0, I_TokCod)                              '   キーセット
                Call Ora_SetParmTable("arecod_13", 0, Com_AreCod)                                '   キーセット
                Call Ora_SetParmTable("strday_13", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("endday_13", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("minsuu_13", 0, I_BraSuu)                              '   キーセット
                Call Ora_SetParmTable("maxsuu_13", 0, I_BraSuu)                              '   キーセット

                Call Ora_SetParmTable("sircod_14", 0, I_SirCod)                              '   キーセット
                Call Ora_SetParmTable("shocod_14", 0, I_ShoCod)                              '   キーセット
                Call Ora_SetParmTable("sttcod_14", 0, Com_SttCod)                                 '   キーセット
                Call Ora_SetParmTable("bmncod_14", 0, I_BmnCod)                              '   キーセット
                Call Ora_SetParmTable("sswcod_14", 0, I_SswCod)                              '   キーセット
                Call Ora_SetParmTable("strday_14", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("endday_14", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("minsuu_14", 0, I_BraSuu)                              '   キーセット
                Call Ora_SetParmTable("maxsuu_14", 0, I_BraSuu)                              '   キーセット

                Call Ora_SetParmTable("sircod_15", 0, I_SirCod)                              '   キーセット
                Call Ora_SetParmTable("shocod_15", 0, I_ShoCod)                              '   キーセット
                Call Ora_SetParmTable("bmncod_15", 0, I_BmnCod)                              '   キーセット
                Call Ora_SetParmTable("sswcod_15", 0, I_SswCod)                              '   キーセット
                Call Ora_SetParmTable("strday_15", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("endday_15", 0, nouday)                                '   キーセット
                Call Ora_SetParmTable("minsuu_15", 0, I_BraSuu)                              '   キーセット
                Call Ora_SetParmTable("maxsuu_15", 0, I_BraSuu)                              '   キーセット

                _ret = Ora_DbOneReadSqlEx(oradyn, SqlBuf.ToString)                        '   ＳＱＬ発行

                Select Case _ret                                                          '   ＳＱＬ発行チェック
                    Case ORA_FOUNDREC                                                     '   ＳＱＬ正常発行の場合

                        Do While oradyn.Read = True
                            O_SshTnk.sirtnkDat = CDec(Trim(Com_NulCut(oradyn("SGS_SIRTNK"))))
                            O_SshTnk.sibtnkDat = CDec(Trim(Com_NulCut(oradyn("SGS_SIBTNK"))))
                            O_SshTnk.kkknumDat = Trim(Com_NulCut(oradyn("SGS_KKKNUM")))
                            cnt += 1
                        Loop

                        ' リーダークローズ
                        ' --------------------------------------------------
                        oradyn.Close()

                        ' パラメータ消去
                        ' --------------------------------------------------
                        Call Ora_ParmRemAll()

                        blnFound = True

                    Case ORA_NOTFOUND                                                     '   取得データなしの場合
                        ' パラメータ消去
                        ' --------------------------------------------------
                        Call Ora_ParmRemAll()

                        oradyn.Close()
                        oradyn.Dispose()
                        oradyn = Nothing
                    Case Else
                        ' パラメータ消去
                        ' --------------------------------------------------
                        Call Ora_ParmRemAll()

                        blnFound = True

                        O_SshTnk.sirtnkDat = 0
                        O_SshTnk.sibtnkDat = 0

                        MsgDat = MSG_E115 & " ERR:" & CStr(_ret)
                End Select
            End If


            If blnFound = False Then
                O_SshTnk.sirtnkDat = 0
                O_SshTnk.sibtnkDat = 0
                _ret = SUCCESS
            End If
        Catch ex As Exception
            MsgDat = ex.ToString
            _ret = NG
        Finally
            O_TnkCnt = cnt

            If Not oradyn Is Nothing Then                                             '   オブジェクト使用時
                oradyn.Dispose()
            End If
        End Try

        oradyn = Nothing                                                              '   オブジェクトを空にする

        Com_DbGetSgn = _ret                                                           '   関数内戻り値セット
    End Function
End Module
