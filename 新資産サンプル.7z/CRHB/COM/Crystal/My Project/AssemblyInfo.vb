﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' アセンブリに関する一般情報は以下の属性セットをとおして制御されます。 
' アセンブリに関連付けられている情報を変更するには、
' これらの属性値を変更してください。

' アセンブリ属性の値を確認します。

<Assembly: AssemblyTitle("帳票出力ライブラリ")> 
<Assembly: AssemblyDescription("CrystalReport")> 
<Assembly: AssemblyCompany("株式会社イシダテクノ")> 
<Assembly: AssemblyProduct("CRHB")> 
<Assembly: AssemblyCopyright("Copyright (C) 2018 IshidaTecno CO.")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'このプロジェクトが COM に公開される場合、次の GUID がタイプ ライブラリの ID になります。
<Assembly: Guid("a3bb311b-fa63-44e7-9456-5c14ecf2ad35")> 

' アセンブリのバージョン情報は、以下の 4 つの値で構成されています:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' すべての値を指定するか、下のように '*' を使ってビルドおよびリビジョン番号を 
' 既定値にすることができます:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("18.0.0.0")> 
<Assembly: AssemblyFileVersion("18.0.0.0")> 
