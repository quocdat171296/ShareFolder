'*****************************************************************************************
'*                                                                                       *
'*  �V�X�e��      ����  �F  �v�ʃV�X�e��                                                 *
'*  �T�u�V�X�e��  ����  �F  �v���W�F�N�g����                                             *
'*  �v���O����    ����  �F  �R�[�h�������                                               *
'*  �v���O����    �h�c  �F  �r�����e������                                               *
'*  �@�\�T�v            �F  �e�}�X�^�̈ꗗ�\�����s��                                     *
'*  �쐬���t            �F  �����Q�R�N�@�W���Q�O��                                       *
'*  �쐬�Җ�            �F  �V��@��                                                     *
'*  �ύX����            �F  �����Q�W�N�@�U���P�T��                                       *
'*  �C���Җ�            �F  �E�@�q��                                                     *
'*  �C�����e            �F  �����󎚃}�X�^�̒ǉ�                                       *
'*                                                                                       *
'*  All Rights Reserved,Copyright(C) 2010  Trio System Plans Co.                         *
'*  All Rights Reserved,Copyright(C) 2011  (��)�C�V�_�e�N�m                              *
'*****************************************************************************************  

Imports SYSCOM
Imports ITControl

Imports System
Imports System.Text
Imports System.Data
Imports System.Data.SqlClient
Imports System.Runtime.InteropServices

Public Class serform
    Inherits System.Windows.Forms.Form

#Region " Windows �t�H�[�� �f�U�C�i�Ő������ꂽ�R�[�h "

    Public Sub New()
        MyBase.New()

        ' ���̌Ăяo���� Windows �t�H�[�� �f�U�C�i�ŕK�v�ł��B
        InitializeComponent()

        ' InitializeComponent() �Ăяo���̌�ɏ�������ǉ����܂��B
        'Form_Initialize()
    End Sub

    ' Form �� dispose ���I�[�o�[���C�h���ăR���|�[�l���g�ꗗ���������܂��B
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

#End Region

#Region " �s�v�ȃt�H�[����� "

    '<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
    'Partial Class serform
    '    Inherits System.Windows.Forms.Form

    '    '�t�H�[�����R���|�[�l���g�̈ꗗ���N���[���A�b�v���邽�߂� dispose ���I�[�o�[���C�h���܂��B
    '    '<System.Diagnostics.DebuggerNonUserCode()> _
    '    'Protected Overrides Sub Dispose(ByVal disposing As Boolean)
    '    '    If disposing AndAlso components IsNot Nothing Then
    '    '        components.Dispose()
    '    '    End If
    '    '    MyBase.Dispose(disposing)
    '    'End Sub

    '    'Windows �t�H�[�� �f�U�C�i�ŕK�v�ł��B
    '    Private components As System.ComponentModel.IContainer

    '    '����: �ȉ��̃v���V�[�W���� Windows �t�H�[�� �f�U�C�i�ŕK�v�ł��B
    '    'Windows �t�H�[�� �f�U�C�i���g�p���ĕύX�ł��܂��B  
    '    '�R�[�h �G�f�B�^���g���ĕύX���Ȃ��ł��������B
    '    <System.Diagnostics.DebuggerStepThrough()> _
    '    Private Sub InitializeComponent()
    '        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(serform))
    '        Me.cmdCommand2_0 = New ITControl.ITCommandButton
    '        Me.fraFrame1 = New System.Windows.Forms.Panel
    '        Me.txtText1_0 = New ITControl.ITTextBox
    '        Me.msfMstGrid1 = New System.Windows.Forms.DataGridView
    '        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn
    '        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn
    '        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn
    '        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn
    '        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn
    '        Me.Column6 = New System.Windows.Forms.DataGridViewTextBoxColumn
    '        Me.Column7 = New System.Windows.Forms.DataGridViewTextBoxColumn
    '        Me.lstKeyCod = New System.Windows.Forms.ListBox
    '        Me.txtpage = New ITControl.ITTextBox
    '        Me.cmdCommand1_0 = New ITControl.ITCommandButton
    '        Me.cmdCommand1_4 = New ITControl.ITCommandButton
    '        Me.cmdCommand1_5 = New ITControl.ITCommandButton
    '        Me.cmdCommand1_11 = New ITControl.ITCommandButton
    '        Me.picEnd_1 = New System.Windows.Forms.PictureBox
    '        Me.picEnd_2 = New System.Windows.Forms.PictureBox
    '        Me.picEnd_3 = New System.Windows.Forms.PictureBox
    '        Me.picEnd_0 = New System.Windows.Forms.PictureBox
    '        Me.fraFrame1.SuspendLayout()
    '        CType(Me.msfMstGrid1, System.ComponentModel.ISupportInitialize).BeginInit()
    '        CType(Me.picEnd_1, System.ComponentModel.ISupportInitialize).BeginInit()
    '        CType(Me.picEnd_2, System.ComponentModel.ISupportInitialize).BeginInit()
    '        CType(Me.picEnd_3, System.ComponentModel.ISupportInitialize).BeginInit()
    '        CType(Me.picEnd_0, System.ComponentModel.ISupportInitialize).BeginInit()
    '        Me.SuspendLayout()
    '        '
    '        'cmdCommand2_0
    '        '
    '        Me.cmdCommand2_0.Font = New System.Drawing.Font("�l�r �S�V�b�N", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
    '        Me.cmdCommand2_0.Location = New System.Drawing.Point(4, 6)
    '        Me.cmdCommand2_0.Name = "cmdCommand2_0"
    '        Me.cmdCommand2_0.Size = New System.Drawing.Size(87, 23)
    '        Me.cmdCommand2_0.TabIndex = 1
    '        Me.cmdCommand2_0.Text = "�R�[�h"
    '        '
    '        'fraFrame1
    '        '
    '        Me.fraFrame1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
    '        Me.fraFrame1.Controls.Add(Me.txtText1_0)
    '        Me.fraFrame1.Controls.Add(Me.msfMstGrid1)
    '        Me.fraFrame1.Controls.Add(Me.cmdCommand2_0)
    '        Me.fraFrame1.Location = New System.Drawing.Point(-2, 8)
    '        Me.fraFrame1.Name = "fraFrame1"
    '        Me.fraFrame1.Size = New System.Drawing.Size(699, 480)
    '        Me.fraFrame1.TabIndex = 2
    '        '
    '        'txtText1_0
    '        '
    '        Me.txtText1_0.Ank = "9"
    '        Me.txtText1_0.Font = New System.Drawing.Font("�l�r �S�V�b�N", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
    '        Me.txtText1_0.ImeMode = System.Windows.Forms.ImeMode.Disable
    '        Me.txtText1_0.Location = New System.Drawing.Point(93, 6)
    '        Me.txtText1_0.MaxLength = 4
    '        Me.txtText1_0.Name = "txtText1_0"
    '        Me.txtText1_0.Search = False
    '        Me.txtText1_0.Size = New System.Drawing.Size(142, 23)
    '        Me.txtText1_0.TabIndex = 5
    '        Me.txtText1_0.Tag = ""
    '        Me.txtText1_0.Text = "XXXX"
    '        '
    '        'msfMstGrid1
    '        '
    '        Me.msfMstGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
    '        Me.msfMstGrid1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2, Me.Column3, Me.Column4, Me.Column5, Me.Column6, Me.Column7})
    '        Me.msfMstGrid1.Location = New System.Drawing.Point(2, 41)
    '        Me.msfMstGrid1.Name = "msfMstGrid1"
    '        Me.msfMstGrid1.RowTemplate.Height = 21
    '        Me.msfMstGrid1.Size = New System.Drawing.Size(692, 432)
    '        Me.msfMstGrid1.TabIndex = 2
    '        '
    '        'Column1
    '        '
    '        Me.Column1.HeaderText = "Column1"
    '        Me.Column1.Name = "Column1"
    '        '
    '        'Column2
    '        '
    '        Me.Column2.HeaderText = "Column2"
    '        Me.Column2.Name = "Column2"
    '        '
    '        'Column3
    '        '
    '        Me.Column3.HeaderText = "Column3"
    '        Me.Column3.Name = "Column3"
    '        '
    '        'Column4
    '        '
    '        Me.Column4.HeaderText = "Column4"
    '        Me.Column4.Name = "Column4"
    '        '
    '        'Column5
    '        '
    '        Me.Column5.HeaderText = "Column5"
    '        Me.Column5.Name = "Column5"
    '        '
    '        'Column6
    '        '
    '        Me.Column6.HeaderText = "Column6"
    '        Me.Column6.Name = "Column6"
    '        '
    '        'Column7
    '        '
    '        Me.Column7.HeaderText = "Column7"
    '        Me.Column7.Name = "Column7"
    '        '
    '        'lstKeyCod
    '        '
    '        Me.lstKeyCod.FormattingEnabled = True
    '        Me.lstKeyCod.ItemHeight = 12
    '        Me.lstKeyCod.Location = New System.Drawing.Point(844, 44)
    '        Me.lstKeyCod.Name = "lstKeyCod"
    '        Me.lstKeyCod.Size = New System.Drawing.Size(295, 400)
    '        Me.lstKeyCod.TabIndex = 3
    '        '
    '        'txtPage
    '        '
    '        Me.txtpage.Ank = "9"
    '        Me.txtpage.Font = New System.Drawing.Font("�l�r �S�V�b�N", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
    '        Me.txtpage.ImeMode = System.Windows.Forms.ImeMode.Disable
    '        Me.txtpage.Location = New System.Drawing.Point(844, 12)
    '        Me.txtpage.MaxLength = 4
    '        Me.txtpage.Name = "txtpage"
    '        Me.txtpage.Search = False
    '        Me.txtpage.Size = New System.Drawing.Size(43, 23)
    '        Me.txtpage.TabIndex = 4
    '        Me.txtpage.Tag = ""
    '        Me.txtpage.Text = "1"
    '        Me.txtpage.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '        '
    '        'cmdCommand1_0
    '        '
    '        Me.cmdCommand1_0.Font = New System.Drawing.Font("�l�r �S�V�b�N", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
    '        Me.cmdCommand1_0.Location = New System.Drawing.Point(4, 494)
    '        Me.cmdCommand1_0.Name = "cmdCommand1_0"
    '        Me.cmdCommand1_0.Size = New System.Drawing.Size(69, 25)
    '        Me.cmdCommand1_0.TabIndex = 5
    '        Me.cmdCommand1_0.Text = "�m�F"
    '        Me.cmdCommand1_0.TextAlign = System.Drawing.ContentAlignment.MiddleRight
    '        '
    '        'cmdCommand1_4
    '        '
    '        Me.cmdCommand1_4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
    '        Me.cmdCommand1_4.Font = New System.Drawing.Font("�l�r �S�V�b�N", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
    '        Me.cmdCommand1_4.Location = New System.Drawing.Point(74, 494)
    '        Me.cmdCommand1_4.Name = "cmdCommand1_4"
    '        Me.cmdCommand1_4.Size = New System.Drawing.Size(69, 25)
    '        Me.cmdCommand1_4.TabIndex = 6
    '        Me.cmdCommand1_4.Text = "�O��"
    '        Me.cmdCommand1_4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
    '        '
    '        'cmdCommand1_5
    '        '
    '        Me.cmdCommand1_5.Font = New System.Drawing.Font("�l�r �S�V�b�N", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
    '        Me.cmdCommand1_5.Location = New System.Drawing.Point(144, 494)
    '        Me.cmdCommand1_5.Name = "cmdCommand1_5"
    '        Me.cmdCommand1_5.Size = New System.Drawing.Size(69, 25)
    '        Me.cmdCommand1_5.TabIndex = 7
    '        Me.cmdCommand1_5.Text = "����"
    '        Me.cmdCommand1_5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
    '        '
    '        'cmdCommand1_11
    '        '
    '        Me.cmdCommand1_11.Font = New System.Drawing.Font("�l�r �S�V�b�N", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
    '        Me.cmdCommand1_11.Location = New System.Drawing.Point(214, 494)
    '        Me.cmdCommand1_11.Name = "cmdCommand1_11"
    '        Me.cmdCommand1_11.Size = New System.Drawing.Size(69, 25)
    '        Me.cmdCommand1_11.TabIndex = 8
    '        Me.cmdCommand1_11.Text = "�I��"
    '        Me.cmdCommand1_11.TextAlign = System.Drawing.ContentAlignment.MiddleRight
    '        '
    '        'picEnd_1
    '        '
    '        Me.picEnd_1.Image = CType(resources.GetObject("picEnd_1.Image"), System.Drawing.Image)
    '        Me.picEnd_1.Location = New System.Drawing.Point(9, 498)
    '        Me.picEnd_1.Name = "picEnd_1"
    '        Me.picEnd_1.Size = New System.Drawing.Size(19, 19)
    '        Me.picEnd_1.TabIndex = 9
    '        Me.picEnd_1.TabStop = False
    '        '
    '        'picEnd_2
    '        '
    '        Me.picEnd_2.Image = CType(resources.GetObject("picEnd_2.Image"), System.Drawing.Image)
    '        Me.picEnd_2.Location = New System.Drawing.Point(78, 497)
    '        Me.picEnd_2.Name = "picEnd_2"
    '        Me.picEnd_2.Size = New System.Drawing.Size(21, 20)
    '        Me.picEnd_2.TabIndex = 10
    '        Me.picEnd_2.TabStop = False
    '        '
    '        'picEnd_3
    '        '
    '        Me.picEnd_3.Image = CType(resources.GetObject("picEnd_3.Image"), System.Drawing.Image)
    '        Me.picEnd_3.Location = New System.Drawing.Point(149, 498)
    '        Me.picEnd_3.Name = "picEnd_3"
    '        Me.picEnd_3.Size = New System.Drawing.Size(21, 18)
    '        Me.picEnd_3.TabIndex = 11
    '        Me.picEnd_3.TabStop = False
    '        '
    '        'picEnd_0
    '        '
    '        Me.picEnd_0.Image = CType(resources.GetObject("picEnd_0.Image"), System.Drawing.Image)
    '        Me.picEnd_0.Location = New System.Drawing.Point(217, 498)
    '        Me.picEnd_0.Name = "picEnd_0"
    '        Me.picEnd_0.Size = New System.Drawing.Size(22, 18)
    '        Me.picEnd_0.TabIndex = 12
    '        Me.picEnd_0.TabStop = False
    '        '
    '        'serform
    '        '
    '        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
    '        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    '        Me.ClientSize = New System.Drawing.Size(1028, 614)
    '        Me.Controls.Add(Me.picEnd_0)
    '        Me.Controls.Add(Me.picEnd_3)
    '        Me.Controls.Add(Me.picEnd_2)
    '        Me.Controls.Add(Me.picEnd_1)
    '        Me.Controls.Add(Me.cmdCommand1_11)
    '        Me.Controls.Add(Me.cmdCommand1_5)
    '        Me.Controls.Add(Me.cmdCommand1_4)
    '        Me.Controls.Add(Me.cmdCommand1_0)
    '        Me.Controls.Add(Me.txtpage)
    '        Me.Controls.Add(Me.lstKeyCod)
    '        Me.Controls.Add(Me.fraFrame1)
    '        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
    '        Me.Name = "serform"
    '        Me.Text = "�e�[�u�����e�ꗗ"
    '        Me.fraFrame1.ResumeLayout(False)
    '        Me.fraFrame1.PerformLayout()
    '        CType(Me.msfMstGrid1, System.ComponentModel.ISupportInitialize).EndInit()
    '        CType(Me.picEnd_1, System.ComponentModel.ISupportInitialize).EndInit()
    '        CType(Me.picEnd_2, System.ComponentModel.ISupportInitialize).EndInit()
    '        CType(Me.picEnd_3, System.ComponentModel.ISupportInitialize).EndInit()
    '        CType(Me.picEnd_0, System.ComponentModel.ISupportInitialize).EndInit()
    '        Me.ResumeLayout(False)
    '        Me.PerformLayout()

    '    End Sub
    '    Friend WithEvents cmdCommand2_0 As ITControl.ITCommandButton
    '    Friend WithEvents fraFrame1 As System.Windows.Forms.Panel
    '    Friend WithEvents msfMstGrid1 As System.Windows.Forms.DataGridView
    '    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewTextBoxColumn
    '    Friend WithEvents Column2 As System.Windows.Forms.DataGridViewTextBoxColumn
    '    Friend WithEvents Column3 As System.Windows.Forms.DataGridViewTextBoxColumn
    '    Friend WithEvents lstKeyCod As System.Windows.Forms.ListBox
    '    Friend WithEvents txtpage As ITControl.ITTextBox
    '    Friend WithEvents cmdCommand1_0 As ITControl.ITCommandButton
    '    Friend WithEvents cmdCommand1_4 As ITControl.ITCommandButton
    '    Friend WithEvents cmdCommand1_5 As ITControl.ITCommandButton
    '    Friend WithEvents cmdCommand1_11 As ITControl.ITCommandButton
    '    Friend WithEvents picEnd_1 As System.Windows.Forms.PictureBox
    '    Friend WithEvents picEnd_2 As System.Windows.Forms.PictureBox
    '    Friend WithEvents picEnd_3 As System.Windows.Forms.PictureBox
    '    Friend WithEvents picEnd_0 As System.Windows.Forms.PictureBox
    '    Friend WithEvents Column4 As System.Windows.Forms.DataGridViewTextBoxColumn
    '    Friend WithEvents Column5 As System.Windows.Forms.DataGridViewTextBoxColumn
    '    Friend WithEvents Column6 As System.Windows.Forms.DataGridViewTextBoxColumn
    '    Friend WithEvents Column7 As System.Windows.Forms.DataGridViewTextBoxColumn
    '    Friend WithEvents txtText1_0 As ITControl.ITTextBox

    'End Class

#End Region

    '*****************************************************************************************
    '*  �t�H�[�������ʕϐ���`                                                               *
    '*****************************************************************************************

    'Dim SqlSelect As String                                                               '   �c�a�擾�C���f�b�N�X�w��
    'Dim SqlFrom As String                                                                 '   �c�a�擾�e�[�u���w��
    'Dim SqlWhere As String                                                                '   �c�a��������
    'Dim SqlGroup As String                                                                '   �c�a�����O���[�v����
    'Dim SqlOrder As String                                                                '   �c�a�����\�[�g��
    Dim SqlKey As String                                                                    '   �c�a�擾�L�[����

    Dim InpLoc As Integer                                                                   '   ���͋֎~���[�h�i�O  �F���͋���       �P�F���͋֎~           )
    Dim InpMode As Integer                                                                  '   ����    ���[�h (�O  �F�w�b�_         �P�F����       �Q�F�m�F�j
    Dim SysMode As Integer                                                                  '   �V�X�e�����[�h (�O  �F����           �P�F�t�@�C������       �j

    Dim TxtMode As Boolean                                                                  '   �����e�L�X�g���[�h
    Dim LstIndex As Integer                                                                 '   ���ڈʒu
    Dim ItemCnt As Integer                                                                  '   ���ڐ�
    Dim RecCnt As Integer                                                                   '   ���R�[�h�J�E���g

    Dim FldLen(10) As Integer                                                               '   ���ڒ�
    Dim SerFlg As Integer                                                                   '   �����t���O�i�O�F�R�[�h����      �P�F���Ȍ����j
    Dim SerNam As String                                                                    '   �����Ώۖ���
    'Dim SerTop As String                                                                    '   �����擾�f�[�^�őO�l
    Dim NxtDat As Boolean
    Dim serend As String                                                                    '   �����擾�f�[�^�ŏI�l
    Dim SerKeySirCod As String                                                              '   ���������i�d����R�[�h�j
    Dim SerKeyMekCod As String                                                              '   ���������i���[�J�R�[�h�j
    Dim loadflg As Boolean                                                                  '   �t�H�[�����[�h�t���O

    Const SerFlg_COD As Integer = 0                                                         '   �R�[�h����
    Const SerFlg_KNA As Integer = 1                                                         '   ���Ȍ���

    Dim Txt1Fmt(MAX_TXT1 - 1) As String                                                     '   �e�L�X�g�t�H�[�}�b�g�L���̈�
    Dim Txt1Ank(MAX_TXT1 - 1) As String                                                     '   �e�L�X�g�`�m�j�@�@�@�L���̈�
    Dim Txt1Len(MAX_TXT1 - 1) As Integer                                                    '   ���͕������@�@�@�@�@�L���̈�

    Dim Txt2Fmt(MAX_TXT2 - 1) As String                                                     '   �e�L�X�g�t�H�[�}�b�g�L���̈�
    Dim Txt2Ank(MAX_TXT2 - 1) As String                                                     '   �e�L�X�g�`�m�j�@�@�@�L���̈�
    Dim Txt2Len(MAX_TXT2 - 1) As Integer                                                    '   ���͕������@�@�@�@�@�L���̈�

    Dim txtText1(MAX_TXT1 - 1) As ITTextBox                                                 '   �e�L�X�g�P�@�@�@�@�@�i�[�̈�
    Dim txtText2(MAX_TXT2 - 1) As ITTextBox                                                 '   �e�L�X�g�Q�@�@�@�@�@�i�[�̈�

    Dim cmdCommand1(MAX_CMD - 1) As ITCommandButton                                         '   �R�}���h�{�^��      �i�[�̈�
    'Dim cmdCommand2(0) As ITCommandButton                                                   '   �R�}���h�{�^��      �i�[�̈�
    'Dim picAns(3) As PictureBox                                                            '   �s�N�`���[�{�b�N�X  �i�[�̈�
    Dim lblValue1(MAX_TXT1 - 1) As ITLabel                                                  '   ���x���P            �i�[�̈�
    'Dim lblValue2(MAX_TXT2 - 1) As ITLabel                                                  '   ���x���Q            �i�[�̈�

    ''' <summary>
    ''' �g�p�e�L�X�g�{�b�N�X���w��
    ''' </summary>
    ''' <remarks></remarks>
    Dim SertxtCNT As Integer                                                                '   �g�p�e�L�X�g�{�b�N�X��

    Dim SELECTDAT As DataTable

    Dim Inx1 As Integer

    ''' <summary>
    ''' �N�������������X�C�b�`
    ''' </summary>
    ''' <remarks>True ��������AFalse �������Ȃ�(Default)</remarks>
    Public blnViewFirst As Boolean = False

    ''' <summary>
    ''' �f�[�^�擾�J�n�e�L�X�g�{�b�N�X�C���f�b�N�X�ԍ�
    ''' </summary>
    ''' <remarks>
    ''' <para>���������������ڂ����͎��Ƀf�[�^���擾����e�L�X�g�{�b�N�X�̃C���f�b�N�X�ԍ�</para>
    ''' <para>�����l�F-1�@�ŏI����</para>
    ''' </remarks>
    Dim DataGetIndex As Integer = -1

    Dim DelFlg As String = "('0')"

    Dim RowCntPerPage As Integer = 0

    ''' <summary>
    ''' �m�F���͏���
    ''' </summary>
    ''' <remarks>�m�F���̓`�F�b�N���s��</remarks>
    Private Sub Gen_CmdAns()
        Dim lop As Integer                                                                  '   ���[�v�J�E���g
        Dim rowinx As Integer

        If RecCnt <> 0 Then                                                                 '   �ꗗ�f�[�^����̎�
            With msfMstGrid1
                SerData = ""
                SerList.Clear()

                rowinx = msfMstGrid1.CurrentCell.RowIndex

                For lop = 0 To ItemCnt - 1
                    '   �����f�[�^�Z�b�g
                    SerData = SerData & DirectCast(msfMstGrid1.Rows(rowinx).Cells(lop).Value, String)
                    SerList.Add(DirectCast(msfMstGrid1.Rows(rowinx).Cells(lop).Value, String))
                Next lop
            End With

            If Trim$(SerData) <> "" Then
                Call Gen_CmdEnd()                                                           '   �I��������
            Else
                msfMstGrid1.Focus()
            End If
        End If
    End Sub

    ''' <summary>
    ''' �v���O�����I������
    ''' </summary>
    ''' <remarks>�v���O�����̏I�����s��</remarks>
    Private Sub Gen_CmdEnd()
        Application.DoEvents()                                                              '   �E�C���h�E�Y�ɐ�����ڂ�

        Me.Close()                                                                          '   �t�H�[���̏������s��
    End Sub


    ''' <summary>
    ''' ����������
    ''' </summary>
    ''' <remarks>�������������s��</remarks>
    Private Sub Gen_CmdNxt()
        Dim cnt As Integer

        If msfMstGrid1.RowCount = 0 Then
            Exit Sub
        End If

        cmdCommand1(CMD_PRE).Enabled = True

        cnt = msfMstGrid1.FirstDisplayedScrollingRowIndex
        cnt = cnt + msfMstGrid1.DisplayedRowCount(False)

        If cnt + msfMstGrid1.DisplayedRowCount(False) > msfMstGrid1.RowCount - 1 Then
            If cnt > msfMstGrid1.RowCount - 1 Then
                cnt = msfMstGrid1.RowCount - 1
            End If

            cmdCommand1(CMD_NXT).Enabled = False
        End If

        msfMstGrid1.FirstDisplayedScrollingRowIndex = cnt
        msfMstGrid1.CurrentCell = msfMstGrid1(0, cnt)
        msfMstGrid1.Select()
    End Sub

    ''' <summary>
    ''' �O��������
    ''' </summary>
    ''' <remarks>�O�����������s��</remarks>
    Private Sub Gen_CmdPre()
        Dim cnt As Integer

        If msfMstGrid1.RowCount = 0 Then
            Exit Sub
        End If

        cmdCommand1(CMD_NXT).Enabled = True

        cnt = msfMstGrid1.FirstDisplayedScrollingRowIndex
        cnt = cnt - msfMstGrid1.DisplayedRowCount(False)

        If cnt < 0 Then
            cnt = 0
            cmdCommand1(CMD_PRE).Enabled = False
        End If

        msfMstGrid1.FirstDisplayedScrollingRowIndex = cnt
        msfMstGrid1.CurrentCell = msfMstGrid1(0, cnt)
        msfMstGrid1.Select()
    End Sub

    ''' <summary>
    ''' ��������
    ''' </summary>
    ''' <remarks>�����������s��</remarks>
    Private Sub Gen_CmdSer()
        Dim _savesermast As Integer = SerMast                                   '   ���t�H�[���Ăяo���O�̌����}�X�^
        Dim _myinx1 As Integer = Inx1                                           '   ���t�H�[���Ăяo���O�̃e�L�X�g�{�b�N�X�ʒu

        Dim _bkserkey1 As String = SerKey1                                      '   ���������ޔ�
        Dim _bkserkey2 As String = SerKey2                                      '   ���������ޔ�
        Dim _bkserkey3 As String = SerKey3                                      '   ���������ޔ�
        Dim _bkserkeyf As String = SerKeyf                                      '   ���������ޔ�

        Dim _key1 As String = String.Empty                                      '   �����L�[
        Dim _key1fmt As String = String.Empty                                   '   �R�[�h�t�H�[�}�b�g


        If Not cmdCommand1(CMD_SER).Enabled Then                                '   �{�^�����L���łȂ��ꍇ�͏����I��
            Return
        End If

        SerKey1 = String.Empty                                                  '   ���������N���A
        SerKey2 = String.Empty                                                  '   ���������N���A
        SerKey3 = String.Empty                                                  '   ���������N���A
        SerKeyf = String.Empty                                                  '   ���������N���A

        Select Case SerMast                                                     '   �������
            Case SER_SSHMAST                                                    '   �d���揤�i�}�X�^
                cmdCommand1(CMD_SER).Focus()                                    '   �t�H�[�J�X�Z�b�g

                Application.DoEvents()                                          '   �E�C���h�E�Y�ɐ����n��

                Select Case Inx1                                                '   ���̓e�L�X�g�{�b�N�X�ԍ�
                    Case TXTTSHS_KEYCD2
                        SerMast = SER_SIRVIEW                                   '   �����}�X�^�Z�b�g
                        _key1fmt = New String("0"c, txtText1(Inx1).MaxLength)   '   �����R�[�h�t�H�[�}�b�g�^�ݒ�

                        Try
                            _key1 = Format(Integer.Parse(txtText1(Inx1).Text), _key1fmt)
                        Catch ex As Exception
                            _key1 = Format(0I, _key1fmt)
                        End Try

                        SerKey1 = "SIR_SIRCOD >= '" & _key1 & "'"               '   ���������Z�b�g

                        Using frmSearch As New serform                          '   ���t�H�[�����ČĂяo��
                            With frmSearch
                                .ShowInTaskbar = False                          '   �����E�B���h�E��\��
                                .WindowState = FormWindowState.Normal
                                .StartPosition = FormStartPosition.CenterScreen

                                .ShowDialog()                                   '   �����E�B���h�E��\��
                            End With
                        End Using

                        Me.Activate()                                           '   ���t�H�[�����A�N�e�B�u�ɂ���

                        Inx1 = _myinx1                                          '   �ޔ������e�L�X�g�ԍ��Z�b�g

                        If Trim$(SerData) <> "" Then                            '   �����f�[�^����̎�
                            txtText1(Inx1).Text = SerList(0)
                            txtText1(Inx1).Focus()
                            SendKeys.Send("{ENTER}")                            '   ���s�L�[����������Ԃɂ���
                        End If

                        SerData = String.Empty                                  '   �������ʃN���A
                        txtText1(Inx1).Focus()                                  '   �t�H�[�J�X���Z�b�g
                    Case TXTTSHS_KEYCD4
                        SerMast = SER_SHOVIEW                                   '   �����}�X�^�Z�b�g
                        _key1fmt = New String("0"c, txtText1(Inx1).MaxLength)   '   �����R�[�h�t�H�[�}�b�g�^�ݒ�

                        Try
                            _key1 = Format(Long.Parse(txtText1(Inx1).Text), _key1fmt)
                        Catch ex As Exception
                            _key1 = Format(0L, _key1fmt)
                        End Try

                        SerKey1 = "SHO_SHOCOD >= '" & _key1 & "'"               '   ���������Z�b�g

                        Using frmSearch As New serform                          '   ���t�H�[�����ČĂяo��
                            With frmSearch
                                .ShowInTaskbar = False                          '   �����E�B���h�E��\��
                                .WindowState = FormWindowState.Normal
                                .StartPosition = FormStartPosition.CenterScreen

                                .ShowDialog()                                   '   �����E�B���h�E��\��
                            End With
                        End Using

                        Me.Activate()                                           '   ���t�H�[�����A�N�e�B�u�ɂ���

                        Inx1 = _myinx1                                          '   �ޔ������e�L�X�g�ԍ��Z�b�g

                        If Trim$(SerData) <> "" Then                            '   �����f�[�^����̎�
                            txtText1(Inx1).Text = SerList(0)
                            txtText1(Inx1).Focus()
                            SendKeys.Send("{ENTER}")                            '   ���s�L�[����������Ԃɂ���
                        End If

                        SerData = String.Empty                                  '   �������ʃN���A
                        txtText1(Inx1).Focus()                                  '   �t�H�[�J�X���Z�b�g
                    Case Else
                End Select
            Case SER_SSHVIEW                                                    '   �d���揤�i�}�X�^
                cmdCommand1(CMD_SER).Focus()                                    '   �t�H�[�J�X�Z�b�g

                Application.DoEvents()                                          '   �E�C���h�E�Y�ɐ����n��

                Select Case Inx1                                                '   ���̓e�L�X�g�{�b�N�X�ԍ�
                    Case TXTTSHS_KEYCD4
                        SerMast = SER_SIRVIEW                                   '   �����}�X�^�Z�b�g
                        _key1fmt = New String("0"c, txtText1(Inx1).MaxLength)   '   �����R�[�h�t�H�[�}�b�g�^�ݒ�

                        Try
                            _key1 = Format(Integer.Parse(txtText1(Inx1).Text), _key1fmt)
                        Catch ex As Exception
                            _key1 = Format(0I, _key1fmt)
                        End Try

                        SerKey1 = "SIR_SIRCOD >= '" & _key1 & "'"               '   ���������Z�b�g

                        Using frmSearch As New serform                          '   ���t�H�[�����ČĂяo��
                            With frmSearch
                                .ShowInTaskbar = False                          '   �����E�B���h�E��\��
                                .WindowState = FormWindowState.Normal
                                .StartPosition = FormStartPosition.CenterScreen

                                .ShowDialog()                                   '   �����E�B���h�E��\��
                            End With
                        End Using

                        Me.Activate()                                           '   ���t�H�[�����A�N�e�B�u�ɂ���

                        Inx1 = _myinx1                                          '   �ޔ������e�L�X�g�ԍ��Z�b�g

                        If Trim$(SerData) <> "" Then                            '   �����f�[�^����̎�
                            txtText1(Inx1).Text = SerList(0)
                            txtText1(Inx1).Focus()
                            SendKeys.Send("{ENTER}")                            '   ���s�L�[����������Ԃɂ���
                        End If

                        SerData = String.Empty                                  '   �������ʃN���A
                        txtText1(Inx1).Focus()                                  '   �t�H�[�J�X���Z�b�g
                    Case TXTTSHS_KEYCD2
                        SerMast = SER_SHOVIEW                                   '   �����}�X�^�Z�b�g
                        _key1fmt = New String("0"c, txtText1(Inx1).MaxLength)   '   �����R�[�h�t�H�[�}�b�g�^�ݒ�

                        Try
                            _key1 = Format(Long.Parse(txtText1(Inx1).Text), _key1fmt)
                        Catch ex As Exception
                            _key1 = Format(0L, _key1fmt)
                        End Try

                        SerKey1 = "SHO_SHOCOD >= '" & _key1 & "'"               '   ���������Z�b�g

                        Using frmSearch As New serform                          '   ���t�H�[�����ČĂяo��
                            With frmSearch
                                .ShowInTaskbar = False                          '   �����E�B���h�E��\��
                                .WindowState = FormWindowState.Normal
                                .StartPosition = FormStartPosition.CenterScreen

                                .ShowDialog()                                   '   �����E�B���h�E��\��
                            End With
                        End Using

                        Me.Activate()                                           '   ���t�H�[�����A�N�e�B�u�ɂ���

                        Inx1 = _myinx1                                          '   �ޔ������e�L�X�g�ԍ��Z�b�g

                        If Trim$(SerData) <> "" Then                            '   �����f�[�^����̎�
                            txtText1(Inx1).Text = SerList(0)
                            txtText1(Inx1).Focus()
                            SendKeys.Send("{ENTER}")                            '   ���s�L�[����������Ԃɂ���
                        End If

                        SerData = String.Empty                                  '   �������ʃN���A
                        txtText1(Inx1).Focus()                                  '   �t�H�[�J�X���Z�b�g
                    Case Else
                End Select
            Case SER_SSHMAST2                                                   '   �d���揤�i�}�X�^
                cmdCommand1(CMD_SER).Focus()                                    '   �t�H�[�J�X�Z�b�g

                Application.DoEvents()                                          '   �E�C���h�E�Y�ɐ����n��

                Select Case Inx1                                                '   ���̓e�L�X�g�{�b�N�X�ԍ�
                    Case TXTTSHS_KEYCD3
                        SerMast = SER_SHOVIEW                                   '   �����}�X�^�Z�b�g
                        _key1fmt = New String("0"c, txtText1(Inx1).MaxLength)   '   �����R�[�h�t�H�[�}�b�g�^�ݒ�

                        Try
                            _key1 = Format(Long.Parse(txtText1(Inx1).Text), _key1fmt)
                        Catch ex As Exception
                            _key1 = Format(0L, _key1fmt)
                        End Try

                        'SerKey1 = "SHO_SHOCOD >= '" & _key1 & "'"               '   ���������Z�b�g

                        Using frmSearch As New serform                          '   ���t�H�[�����ČĂяo��
                            With frmSearch
                                .ShowInTaskbar = False                          '   �����E�B���h�E��\��
                                .WindowState = FormWindowState.Normal
                                .StartPosition = FormStartPosition.CenterScreen

                                .ShowDialog()                                   '   �����E�B���h�E��\��
                            End With
                        End Using

                        Me.Activate()                                           '   ���t�H�[�����A�N�e�B�u�ɂ���

                        Inx1 = _myinx1                                          '   �ޔ������e�L�X�g�ԍ��Z�b�g

                        If Trim$(SerData) <> "" Then                            '   �����f�[�^����̎�
                            txtText1(Inx1).Text = SerList(0)
                            txtText1(Inx1).Focus()
                            SendKeys.Send("{ENTER}")                            '   ���s�L�[����������Ԃɂ���
                        End If

                        SerData = String.Empty                                  '   �������ʃN���A
                        txtText1(Inx1).Focus()                                  '   �t�H�[�J�X���Z�b�g
                    Case Else
                End Select
            Case SER_SSHVIEW2                                                   '   �d���揤�i�}�X�^
                cmdCommand1(CMD_SER).Focus()                                    '   �t�H�[�J�X�Z�b�g

                Application.DoEvents()                                          '   �E�C���h�E�Y�ɐ����n��

                Select Case Inx1                                                '   ���̓e�L�X�g�{�b�N�X�ԍ�
                    Case TXTTSHS_KEYCD2
                        SerMast = SER_SHOVIEW                                   '   �����}�X�^�Z�b�g
                        _key1fmt = New String("0"c, txtText1(Inx1).MaxLength)   '   �����R�[�h�t�H�[�}�b�g�^�ݒ�

                        Try
                            _key1 = Format(Long.Parse(txtText1(Inx1).Text), _key1fmt)
                        Catch ex As Exception
                            _key1 = Format(0L, _key1fmt)
                        End Try

                        'SerKey1 = "SHO_SHOCOD >= '" & _key1 & "'"               '   ���������Z�b�g

                        Using frmSearch As New serform                          '   ���t�H�[�����ČĂяo��
                            With frmSearch
                                .ShowInTaskbar = False                          '   �����E�B���h�E��\��
                                .WindowState = FormWindowState.Normal
                                .StartPosition = FormStartPosition.CenterScreen

                                .ShowDialog()                                   '   �����E�B���h�E��\��
                            End With
                        End Using

                        Me.Activate()                                           '   ���t�H�[�����A�N�e�B�u�ɂ���

                        Inx1 = _myinx1                                          '   �ޔ������e�L�X�g�ԍ��Z�b�g

                        If Trim$(SerData) <> "" Then                            '   �����f�[�^����̎�
                            txtText1(Inx1).Text = SerList(0)
                            txtText1(Inx1).Focus()
                            SendKeys.Send("{ENTER}")                            '   ���s�L�[����������Ԃɂ���
                        End If

                        SerData = String.Empty                                  '   �������ʃN���A
                        txtText1(Inx1).Focus()                                  '   �t�H�[�J�X���Z�b�g
                    Case Else
                End Select
            Case SER_TSHMAST, SER_TSHVIEW                                       '   �q�揤�i�}�X�^
                cmdCommand1(CMD_SER).Focus()                                    '   �t�H�[�J�X�Z�b�g

                Application.DoEvents()                                          '   �E�C���h�E�Y�ɐ����n��

                Select Case Inx1                                                '   ���̓e�L�X�g�{�b�N�X�ԍ�
                    Case TXTTSHS_KEYCD2
                        SerMast = SER_TOKVIEW                                   '   �����}�X�^�Z�b�g
                        _key1fmt = New String("0"c, txtText1(Inx1).MaxLength)   '   �����R�[�h�t�H�[�}�b�g�^�ݒ�

                        Try
                            _key1 = Format(Integer.Parse(txtText1(Inx1).Text), _key1fmt)
                        Catch ex As Exception
                            _key1 = Format(0I, _key1fmt)
                        End Try

                        SerKey1 = "TOK_TOKCOD >= '" & _key1 & "'"               '   ���������Z�b�g

                        Using frmSearch As New serform                          '   ���t�H�[�����ČĂяo��
                            With frmSearch
                                .ShowInTaskbar = False                          '   �����E�B���h�E��\��
                                .WindowState = FormWindowState.Normal
                                .StartPosition = FormStartPosition.CenterScreen

                                .ShowDialog()                                   '   �����E�B���h�E��\��
                            End With
                        End Using

                        Me.Activate()                                           '   ���t�H�[�����A�N�e�B�u�ɂ���

                        Inx1 = _myinx1                                          '   �ޔ������e�L�X�g�ԍ��Z�b�g

                        If Trim$(SerData) <> "" Then                            '   �����f�[�^����̎�
                            txtText1(Inx1).Text = SerList(0)
                            txtText1(Inx1).Focus()
                            SendKeys.Send("{ENTER}")                            '   ���s�L�[����������Ԃɂ���
                        End If

                        SerData = String.Empty                                  '   �������ʃN���A
                        txtText1(Inx1).Focus()                                  '   �t�H�[�J�X���Z�b�g
                    Case TXTTSHS_KEYCD3
                        SerMast = SER_SHOVIEW                                   '   �����}�X�^�Z�b�g
                        _key1fmt = New String("0"c, txtText1(Inx1).MaxLength)   '   �����R�[�h�t�H�[�}�b�g�^�ݒ�

                        Try
                            _key1 = Format(Long.Parse(txtText1(Inx1).Text), _key1fmt)
                        Catch ex As Exception
                            _key1 = Format(0L, _key1fmt)
                        End Try

                        'SerKey1 = "SHO_SHOCOD >= '" & _key1 & "'"               '   ���������Z�b�g

                        Using frmSearch As New serform                          '   ���t�H�[�����ČĂяo��
                            With frmSearch
                                .ShowInTaskbar = False                          '   �����E�B���h�E��\��
                                .WindowState = FormWindowState.Normal
                                .StartPosition = FormStartPosition.CenterScreen

                                .ShowDialog()                                   '   �����E�B���h�E��\��
                            End With
                        End Using

                        Me.Activate()                                           '   ���t�H�[�����A�N�e�B�u�ɂ���

                        Inx1 = _myinx1                                          '   �ޔ������e�L�X�g�ԍ��Z�b�g

                        If Trim$(SerData) <> "" Then                            '   �����f�[�^����̎�
                            txtText1(Inx1).Text = SerList(0)
                            txtText1(Inx1).Focus()
                            SendKeys.Send("{ENTER}")                            '   ���s�L�[����������Ԃɂ���
                        End If

                        SerData = String.Empty                                  '   �������ʃN���A
                        txtText1(Inx1).Focus()                                  '   �t�H�[�J�X���Z�b�g

                    Case TXTTSHS_KEYCD5                                         '   �d����R�[�h
                        SerMast = SER_SIRVIEW                                   '   �����}�X�^�Z�b�g
                        _key1fmt = New String("0"c, txtText1(Inx1).MaxLength)   '   �����R�[�h�t�H�[�}�b�g�^�ݒ�

                        Try
                            _key1 = Format(Integer.Parse(txtText1(Inx1).Text), _key1fmt)
                        Catch ex As Exception
                            _key1 = Format(0I, _key1fmt)
                        End Try

                        SerKey1 = "SIR_SIRCOD >= '" & _key1 & "'"               '   ���������Z�b�g

                        Using frmSearch As New serform                          '   ���t�H�[�����ČĂяo��
                            With frmSearch
                                .ShowInTaskbar = False                          '   �����E�B���h�E��\��
                                .WindowState = FormWindowState.Normal
                                .StartPosition = FormStartPosition.CenterScreen

                                .ShowDialog()                                   '   �����E�B���h�E��\��
                            End With
                        End Using

                        Me.Activate()                                           '   ���t�H�[�����A�N�e�B�u�ɂ���

                        Inx1 = _myinx1                                          '   �ޔ������e�L�X�g�ԍ��Z�b�g

                        If Trim$(SerData) <> "" Then                            '   �����f�[�^����̎�
                            txtText1(Inx1).Text = SerList(0)
                            txtText1(Inx1).Focus()
                            SendKeys.Send("{ENTER}")                            '   ���s�L�[����������Ԃɂ���
                        End If

                        SerData = String.Empty                                  '   �������ʃN���A
                        txtText1(Inx1).Focus()                                  '   �t�H�[�J�X���Z�b�g
                    Case TXTTSHS_KEYCD6                                         '   ���[�J�[�R�[�h
                        SerMast = SER_MEKVIEW                                   '   �����}�X�^�Z�b�g
                        _key1fmt = New String("0"c, txtText1(Inx1).MaxLength)   '   �����R�[�h�t�H�[�}�b�g�^�ݒ�

                        Try
                            _key1 = Format(Integer.Parse(txtText1(Inx1).Text), _key1fmt)
                        Catch ex As Exception
                            _key1 = Format(0I, _key1fmt)
                        End Try

                        SerKey1 = "MEK_MEKCOD >= '" & _key1 & "'"               '   ���������Z�b�g

                        Using frmSearch As New serform                          '   ���t�H�[�����ČĂяo��
                            With frmSearch
                                .ShowInTaskbar = False                          '   �����E�B���h�E��\��
                                .WindowState = FormWindowState.Normal
                                .StartPosition = FormStartPosition.CenterScreen

                                .ShowDialog()                                   '   �����E�B���h�E��\��
                            End With
                        End Using

                        Me.Activate()                                           '   ���t�H�[�����A�N�e�B�u�ɂ���

                        Inx1 = _myinx1                                          '   �ޔ������e�L�X�g�ԍ��Z�b�g

                        If Trim$(SerData) <> "" Then                            '   �����f�[�^����̎�
                            txtText1(Inx1).Text = SerList(0)
                            txtText1(Inx1).Focus()
                            SendKeys.Send("{ENTER}")                            '   ���s�L�[����������Ԃɂ���
                        End If

                        SerData = String.Empty                                  '   �������ʃN���A
                        txtText1(Inx1).Focus()                                  '   �t�H�[�J�X���Z�b�g
                    Case Else
                End Select
            Case SER_TSHMAST2, SER_TSHVIEW2                                     '   �q�揤�i�}�X�^
                cmdCommand1(CMD_SER).Focus()                                    '   �t�H�[�J�X�Z�b�g

                Application.DoEvents()                                          '   �E�C���h�E�Y�ɐ����n��

                Select Case Inx1                                                '   ���̓e�L�X�g�{�b�N�X�ԍ�
                    Case TXTTSHS_KEYCD2
                        SerMast = SER_SHOVIEW                                   '   �����}�X�^�Z�b�g
                        _key1fmt = New String("0"c, txtText1(Inx1).MaxLength)   '   �����R�[�h�t�H�[�}�b�g�^�ݒ�

                        Try
                            _key1 = Format(Long.Parse(txtText1(Inx1).Text), _key1fmt)
                        Catch ex As Exception
                            _key1 = Format(0L, _key1fmt)
                        End Try

                        'SerKey1 = "SHO_SHOCOD >= '" & _key1 & "'"               '   ���������Z�b�g

                        Using frmSearch As New serform                          '   ���t�H�[�����ČĂяo��
                            With frmSearch
                                .ShowInTaskbar = False                          '   �����E�B���h�E��\��
                                .WindowState = FormWindowState.Normal
                                .StartPosition = FormStartPosition.CenterScreen

                                .ShowDialog()                                   '   �����E�B���h�E��\��
                            End With
                        End Using

                        Me.Activate()                                           '   ���t�H�[�����A�N�e�B�u�ɂ���

                        Inx1 = _myinx1                                          '   �ޔ������e�L�X�g�ԍ��Z�b�g

                        If Trim$(SerData) <> "" Then                            '   �����f�[�^����̎�
                            txtText1(Inx1).Text = SerList(0)
                            txtText1(Inx1).Focus()
                            SendKeys.Send("{ENTER}")                            '   ���s�L�[����������Ԃɂ���
                        End If

                        SerData = String.Empty                                  '   �������ʃN���A
                        txtText1(Inx1).Focus()                                  '   �t�H�[�J�X���Z�b�g

                    Case TXTTSHS_KEYCD4                                         '   �d����R�[�h
                        SerMast = SER_SIRVIEW                                   '   �����}�X�^�Z�b�g
                        _key1fmt = New String("0"c, txtText1(Inx1).MaxLength)   '   �����R�[�h�t�H�[�}�b�g�^�ݒ�

                        Try
                            _key1 = Format(Integer.Parse(txtText1(Inx1).Text), _key1fmt)
                        Catch ex As Exception
                            _key1 = Format(0I, _key1fmt)
                        End Try

                        'SerKey1 = "SIR_SIRCOD >= '" & _key1 & "'"               '   ���������Z�b�g

                        Using frmSearch As New serform                          '   ���t�H�[�����ČĂяo��
                            With frmSearch
                                .ShowInTaskbar = False                          '   �����E�B���h�E��\��
                                .WindowState = FormWindowState.Normal
                                .StartPosition = FormStartPosition.CenterScreen

                                .ShowDialog()                                   '   �����E�B���h�E��\��
                            End With
                        End Using

                        Me.Activate()                                           '   ���t�H�[�����A�N�e�B�u�ɂ���

                        Inx1 = _myinx1                                          '   �ޔ������e�L�X�g�ԍ��Z�b�g

                        If Trim$(SerData) <> "" Then                            '   �����f�[�^����̎�
                            txtText1(Inx1).Text = SerList(0)
                            txtText1(Inx1).Focus()
                            SendKeys.Send("{ENTER}")                            '   ���s�L�[����������Ԃɂ���
                        End If

                        SerData = String.Empty                                  '   �������ʃN���A
                        txtText1(Inx1).Focus()                                  '   �t�H�[�J�X���Z�b�g
                    Case TXTTSHS_KEYCD5                                         '   ���[�J�[�R�[�h
                        SerMast = SER_MEKVIEW                                   '   �����}�X�^�Z�b�g
                        _key1fmt = New String("0"c, txtText1(Inx1).MaxLength)   '   �����R�[�h�t�H�[�}�b�g�^�ݒ�

                        Try
                            _key1 = Format(Integer.Parse(txtText1(Inx1).Text), _key1fmt)
                        Catch ex As Exception
                            _key1 = Format(0I, _key1fmt)
                        End Try

                        'SerKey1 = "MEK_MEKCOD >= '" & _key1 & "'"               '   ���������Z�b�g

                        Using frmSearch As New serform                          '   ���t�H�[�����ČĂяo��
                            With frmSearch
                                .ShowInTaskbar = False                          '   �����E�B���h�E��\��
                                .WindowState = FormWindowState.Normal
                                .StartPosition = FormStartPosition.CenterScreen

                                .ShowDialog()                                   '   �����E�B���h�E��\��
                            End With
                        End Using

                        Me.Activate()                                           '   ���t�H�[�����A�N�e�B�u�ɂ���

                        Inx1 = _myinx1                                          '   �ޔ������e�L�X�g�ԍ��Z�b�g

                        If Trim$(SerData) <> "" Then                            '   �����f�[�^����̎�
                            txtText1(Inx1).Text = SerList(0)
                            txtText1(Inx1).Focus()
                            SendKeys.Send("{ENTER}")                            '   ���s�L�[����������Ԃɂ���
                        End If

                        SerData = String.Empty                                  '   �������ʃN���A
                        txtText1(Inx1).Focus()                                  '   �t�H�[�J�X���Z�b�g
                    Case Else
                End Select
                '### 2021/05/13 S.SUGIURA ADD START PS3�Ή�
            Case SER_SHOMAST                                                    '   ���i�}�X�^(�폜�f�[�^��)
                cmdCommand1(CMD_SER).Focus()                                    '   �t�H�[�J�X�Z�b�g

                Application.DoEvents()                                          '   �E�C���h�E�Y�ɐ����n��

                Select Case Inx1                                                '   ���̓e�L�X�g�{�b�N�X�ԍ�
                    Case TXTTSHS_KEYCD7                                         '   ���[�J�[�R�[�h
                        SerMast = SER_MEKVIEW                                   '   �����}�X�^�Z�b�g
                        _key1fmt = New String("0"c, txtText1(Inx1).MaxLength)   '   �����R�[�h�t�H�[�}�b�g�^�ݒ�

                        Try
                            _key1 = Format(Integer.Parse(txtText1(Inx1).Text), _key1fmt)
                        Catch ex As Exception
                            _key1 = Format(0I, _key1fmt)
                        End Try

                        'SerKey1 = "MEK_MEKCOD >= '" & _key1 & "'"               '   ���������Z�b�g

                        Using frmSearch As New serform                          '   ���t�H�[�����ČĂяo��
                            With frmSearch
                                .ShowInTaskbar = False                          '   �����E�B���h�E��\��
                                .WindowState = FormWindowState.Normal
                                .StartPosition = FormStartPosition.CenterScreen

                                .ShowDialog()                                   '   �����E�B���h�E��\��
                            End With
                        End Using

                        Me.Activate()                                           '   ���t�H�[�����A�N�e�B�u�ɂ���

                        Inx1 = _myinx1                                          '   �ޔ������e�L�X�g�ԍ��Z�b�g

                        If Trim$(SerData) <> "" Then                            '   �����f�[�^����̎�
                            txtText1(Inx1).Text = SerList(0)
                            txtText1(Inx1).Focus()
                            SendKeys.Send("{ENTER}")                            '   ���s�L�[����������Ԃɂ���
                        End If

                        SerData = String.Empty                                  '   �������ʃN���A
                        txtText1(Inx1).Focus()                                  '   �t�H�[�J�X���Z�b�g
                    Case Else
                End Select
                '### 2021/05/13 S.SUGIURA ADD END
            Case Else
        End Select

        SerMast = _savesermast                                  '   �ޔ����������}�X�^����

        SerKey1 = _bkserkey1                                    '   �ޔ�����������������
        SerKey2 = _bkserkey2                                    '   �ޔ�����������������
        SerKey3 = _bkserkey3                                    '   �ޔ�����������������
        SerKeyf = _bkserkeyf                                    '   �ޔ�����������������

    End Sub

    ''' <summary>
    ''' �\���e�[�u������SQL�쐬���� 
    ''' </summary>
    ''' <param name="TblId">�����e�[�u���h�c</param>
    ''' <remarks>����SQL�̑g�ݗ��Ă��s��</remarks>
    Private Sub Gen_CreateSqlSelect(ByVal TblId As Integer)

        Dim getfld(10) As String

        Dim oradyn As System.Data.Common.DbDataReader = Nothing
        Dim orafld As Object = Nothing                                                      '   �I���N���I�u�W�F�N�g�i�t�B�[���h�j

        msfMstGrid1.RowCount = 0

        SqlBuf = New StringBuilder                                                          '   �r�p�k�o�b�t�@�[������

        Dim sercod As String = ""
        Dim sercd2 As String = ""
        Dim sercd3 As String = ""
        Dim sercd4 As String = ""
        Dim sercd5 As String = ""
        Dim sercd6 As String = ""
        Dim sercd7 As String = ""

        sercod = RTrim$(txtText1(TXTTSHS_KEYCD1).Text)
        sercd2 = RTrim$(txtText1(TXTTSHS_KEYCD2).Text)
        sercd3 = RTrim$(txtText1(TXTTSHS_KEYCD3).Text)
        sercd4 = RTrim$(txtText1(TXTTSHS_KEYCD4).Text)
        sercd5 = RTrim$(txtText1(TXTTSHS_KEYCD5).Text)
        sercd6 = RTrim$(txtText1(TXTTSHS_KEYCD6).Text)
        sercd7 = RTrim$(txtText1(TXTTSHS_KEYCD7).Text)

        '���ʕ����쐬
        SqlBuf.AppendLine("    SELECT                       ")
        SqlBuf.AppendLine("        MT01 ,                   ")                              '   �����f�[�^�i�J���}��؂�Ƃ���j
        SqlBuf.AppendLine("        COUNT(*) OVER() RECCNT   ")                              '   �s���擾�iGroup By�s�v�j
        SqlBuf.AppendLine("    FROM                         ")
        SqlBuf.AppendLine("    (                            ")

        '***********************************************************************************
        '   �����e�[�u���h�c���Ɏ擾���鍀�ڂ�MT01�Ƃ���SELECT�����쐬���� 
        '   �e�L�X�g�{�b�N�X�̓��͓��e�𒊏o�����Ƃ��Ďg�p����
        '***********************************************************************************
        Select Case TblId                                                                   '   �e�[�u���h�c�`�F�b�N
            Case SER_SHOVIEW                                                                '   ���i�}�X�^

                SqlBuf.AppendLine("        SELECT /*+ INDEX(SHOMAST SHOMAST1) */            ")
                SqlBuf.AppendLine("            SHO_SHOCOD || '|' ||                         ")
                SqlBuf.AppendLine("            SHO_SHONAM || '|' ||                         ")
                SqlBuf.AppendLine("            SHO_SHOKNA || '|' ||                         ")
                SqlBuf.AppendLine("            SHO_SHOKIK || '|' ||                         ")
                SqlBuf.AppendLine("            SHO_KATASK MT01                              ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            SHOMAST                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            SHO_DELFLG = '0'                             ")

                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND SHO_SHOCOD || ' ' || SHO_SHONAM || ' ' || SHO_SHOKNA || ' ' || SHO_SHOKIK || ' ' || SHO_KATASK LIKE '%" & sercod & "%' ")
                If Trim(sercd2) <> "" Then SqlBuf.AppendLine("        AND SHO_SHOCOD LIKE '%" & sercd2 & "%' ")
                If Trim(sercd3) <> "" Then SqlBuf.AppendLine("        AND SHO_SHONAM LIKE '%" & sercd3 & "%' ")
                If Trim(sercd4) <> "" Then SqlBuf.AppendLine("        AND SHO_SHOKNA LIKE '%" & sercd4 & "%' ")
                If Trim(sercd5) <> "" Then SqlBuf.AppendLine("        AND SHO_SHOKIK LIKE '%" & sercd5 & "%' ")
                If Trim(sercd6) <> "" Then SqlBuf.AppendLine("        AND SHO_KATASK LIKE '%" & sercd6 & "%' ")

            Case SER_SHOMAST                                                                '   ���i�}�X�^              �i�폜�f�[�^�܂ށj

                SqlBuf.AppendLine("        SELECT /*+ INDEX(SHOMAST SHOMAST1) */            ")
                SqlBuf.AppendLine("            SHO_SHOCOD || '|' ||                         ")
                SqlBuf.AppendLine("            SHO_SHONAM || '|' ||                         ")
                SqlBuf.AppendLine("            SHO_SHOKNA || '|' ||                         ")
                SqlBuf.AppendLine("            SHO_SHOKIK || '|' ||                         ")
                SqlBuf.AppendLine("            SHO_KATASK || '|' ||                         ")
                '### 2021/05/11 S.SUGIURA ADD START PS3�Ή�
                SqlBuf.AppendLine("            MEK_MEKNAM || '|' ||                         ")
                '### 2021/05/11 S.SUGIURA ADD END
                SqlBuf.AppendLine("            DECODE(SHO_DELFLG, '0', ' ', '1', '*') MT01  ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            SHOMAST                                      ")
                '### 2021/05/11 S.SUGIURA ADD START PS3�Ή�
                SqlBuf.AppendLine("                Left Join                                ")
                SqlBuf.AppendLine("            MEKTABL                                      ")
                SqlBuf.AppendLine("            On ( SHO_MEKCOD = MEK_MEKCOD )               ")
                '### 2021/05/11 S.SUGIURA ADD END
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            SHO_DELFLG IN " & DelFlg & "                 ")
                'SqlBuf.AppendLine("            1 = 1                                        ")

                '### 2021/05/13 S.SUGIURA UPD START PS3�Ή�
                'If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND SHO_SHOCOD || ' ' || SHO_SHONAM || ' ' || SHO_SHOKNA || ' ' || SHO_SHOKIK || ' ' || SHO_KATASK LIKE '%" & sercod & "%' ")
                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND SHO_SHOCOD || ' ' || SHO_SHONAM || ' ' || SHO_SHOKNA || ' ' || SHO_SHOKIK || ' ' || SHO_KATASK || ' ' || MEK_MEKNAM LIKE '%" & sercod & "%' ")
                If Trim(sercd2) <> "" Then SqlBuf.AppendLine("        AND SHO_SHOCOD LIKE '%" & sercd2 & "%' ")
                If Trim(sercd3) <> "" Then SqlBuf.AppendLine("        AND SHO_SHONAM LIKE '%" & sercd3 & "%' ")
                If Trim(sercd4) <> "" Then SqlBuf.AppendLine("        AND SHO_SHOKNA LIKE '%" & sercd4 & "%' ")
                If Trim(sercd5) <> "" Then SqlBuf.AppendLine("        AND SHO_SHOKIK LIKE '%" & sercd5 & "%' ")
                If Trim(sercd6) <> "" Then SqlBuf.AppendLine("        AND SHO_KATASK LIKE '%" & sercd6 & "%' ")
                If Trim(sercd7) <> "" Then SqlBuf.AppendLine("        AND MEK_MEKCOD LIKE '%" & sercd7 & "%' ")
                '### 2021/05/13 S.SUGIURA UPD END PS3�Ή�
            Case SER_SHOVIEW_ME                                                             '   ���i�}�X�^

                SqlBuf.AppendLine("        SELECT /*+ INDEX(SHOMAST SHOMAST1) */            ")
                SqlBuf.AppendLine("            SHO_SHOCOD || '|' ||                         ")
                SqlBuf.AppendLine("            SHO_SHONAM || '|' ||                         ")
                SqlBuf.AppendLine("            SHO_SHOKNA || '|' ||                         ")
                SqlBuf.AppendLine("            SHO_SHOKIK || '|' ||                         ")
                SqlBuf.AppendLine("            SHO_KATASK || '|' ||                         ")
                SqlBuf.AppendLine("            DECODE(SHO_DELFLG, '0', ' ', '1', '*') MT01  ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            SHOMAST                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            SHO_DELFLG IN " & DelFlg & "                 ")
                'SqlBuf.AppendLine("            1 = 1                                        ")

                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND SHO_SHOCOD LIKE '%" & sercod & "%' ")
                If Trim(sercd2) <> "" Then SqlBuf.AppendLine("        AND SHO_SHONAM LIKE '%" & sercd2 & "%' ")
                If Trim(sercd3) <> "" Then SqlBuf.AppendLine("        AND SHO_SHOKNA LIKE '%" & sercd3 & "%' ")
                If Trim(sercd4) <> "" Then SqlBuf.AppendLine("        AND SHO_SHOKIK LIKE '%" & sercd4 & "%' ")
                If Trim(sercd5) <> "" Then SqlBuf.AppendLine("        AND SHO_KATASK LIKE '%" & sercd5 & "%' ")

            Case SER_SHOVIEW_MEK                                                            '   ���i�}�X�^+���[�J�}�X�^

                SqlBuf.AppendLine("        SELECT /*+ INDEX(SHOMAST SHOMAST1) */            ")
                SqlBuf.AppendLine("            SHO_SHOCOD || '|' ||                         ")
                SqlBuf.AppendLine("            SHO_SHONAM || '|' ||                         ")
                SqlBuf.AppendLine("            SHO_SHOKNA || '|' ||                         ")
                SqlBuf.AppendLine("            SHO_MEKCOD || '|' ||                         ")
                SqlBuf.AppendLine("            MEK_MEKNAM            MT01                   ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            SHOMAST                                      ")
                SqlBuf.AppendLine("                Inner Join                               ")
                SqlBuf.AppendLine("            MEKTABL                                      ")
                SqlBuf.AppendLine("            On ( SHO_MEKCOD = MEK_MEKCOD )               ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            SHO_DELFLG = '0'                             ")

                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND SHO_SHOCOD || ' ' || SHO_SHOKNA || ' ' || SHO_KATASK LIKE '%" & sercod & "%' ")
                If Trim(sercd2) <> "" Then SqlBuf.AppendLine("        AND SHO_MEKCOD LIKE '%" & sercd2 & "%' ")

            Case SER_TOKVIEW                                                                '   ���Ӑ�}�X�^

                SqlBuf.AppendLine("        SELECT /*+ INDEX(TOKMAST TOKMAST1) */            ")
                SqlBuf.AppendLine("            TOK_TOKCOD || '|' ||                         ")
                SqlBuf.AppendLine("            TOK_TOKNAM || '|' ||                         ")
                SqlBuf.AppendLine("            TOK_TOKKNA            MT01                   ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            TOKMAST                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            TOK_DELFLG = '0'                             ")

                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND TOK_TOKCOD || ' ' || TOK_TOKKNA LIKE '%" & sercod & "%' ")

            Case SER_TOKMAST                                                                '   ���Ӑ�}�X�^            �i�폜�f�[�^�܂ށj

                SqlBuf.AppendLine("        SELECT /*+ INDEX(TOKMAST TOKMAST1) */            ")
                SqlBuf.AppendLine("            TOK_TOKCOD || '|' ||                         ")
                SqlBuf.AppendLine("            TOK_TOKNAM || '|' ||                         ")
                SqlBuf.AppendLine("            TOK_TOKKNA || '|' ||                         ")
                SqlBuf.AppendLine("            DECODE(TOK_DELFLG, '0', ' ', '1', '*') MT01  ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            TOKMAST                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            TOK_DELFLG IN " & DelFlg & "                 ")
                'SqlBuf.AppendLine("            1 = 1                                        ")

                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND TOK_TOKCOD || ' ' || TOK_TOKKNA LIKE '%" & sercod & "%' ")

            Case SER_SIRVIEW                                                                '   �d����}�X�^

                SqlBuf.AppendLine("        SELECT /*+ INDEX(SIRMAST SIRMAST1) */            ")
                SqlBuf.AppendLine("            SIR_SIRCOD || '|' ||                         ")
                SqlBuf.AppendLine("            SIR_SIRNAM || '|' ||                         ")
                SqlBuf.AppendLine("            SIR_SIRKNA            MT01                   ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            SIRMAST                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            SIR_DELFLG = '0'                             ")

                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND SIR_SIRCOD || ' ' || SIR_SIRKNA LIKE '%" & sercod & "%' ")

            Case SER_SIRMAST                                                                '   �d����}�X�^            �i�폜�f�[�^�܂ށj

                SqlBuf.AppendLine("        SELECT /*+ INDEX(SIRMAST SIRMAST1) */            ")
                SqlBuf.AppendLine("            SIR_SIRCOD || '|' ||                         ")
                SqlBuf.AppendLine("            SIR_SIRNAM || '|' ||                         ")
                SqlBuf.AppendLine("            SIR_SIRKNA || '|' ||                         ")
                SqlBuf.AppendLine("            DECODE(SIR_DELFLG, '0', ' ', '1', '*') MT01  ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            SIRMAST                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            SIR_DELFLG IN " & DelFlg & "                 ")
                'SqlBuf.AppendLine("            1 = 1                                        ")

                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND SIR_SIRCOD || ' ' || SIR_SIRKNA LIKE '%" & sercod & "%' ")

            Case SER_MEKVIEW                                                                '   ���[�J�}�X�^

                SqlBuf.AppendLine("        SELECT /*+ INDEX(MEKTABL MEKTABL1) */            ")
                SqlBuf.AppendLine("            MEK_MEKCOD || '|' ||                         ")
                SqlBuf.AppendLine("            MEK_MEKNAM || '|' ||                         ")
                SqlBuf.AppendLine("            MEK_MEKKNA            MT01                   ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            MEKTABL                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            MEK_DELFLG = '0'                             ")

                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND MEK_MEKCOD || ' ' || MEK_MEKKNA LIKE '%" & sercod & "%' ")

            Case SER_MEKTABL                                                                '   ���[�J�}�X�^            �i�폜�f�[�^�܂ށj

                SqlBuf.AppendLine("        SELECT /*+ INDEX(MEKTABL MEKTABL1) */            ")
                SqlBuf.AppendLine("            MEK_MEKCOD || '|' ||                         ")
                SqlBuf.AppendLine("            MEK_MEKNAM || '|' ||                         ")
                SqlBuf.AppendLine("            MEK_MEKKNA || '|' ||                         ")
                SqlBuf.AppendLine("            DECODE(MEK_DELFLG, '0', ' ', '1', '*') MT01  ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            MEKTABL                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            MEK_DELFLG IN " & DelFlg & "                 ")
                'SqlBuf.AppendLine("            1 = 1                                        ")

                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND MEK_MEKCOD || ' ' || MEK_MEKKNA LIKE '%" & sercod & "%' ")

            Case SER_TANVIEW                                                                '   �S���҃}�X�^

                SqlBuf.AppendLine("        SELECT /*+ INDEX(TANTABL TANTABL1) */            ")
                SqlBuf.AppendLine("            TAN_TANCOD || '|' ||                         ")
                SqlBuf.AppendLine("            TAN_TANNAM MT01                              ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            TANTABL                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            TAN_DELFLG = '0'                             ")

                'If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND TAN_TANCOD  >=   '" & sercod & "'   ")
                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND TAN_TANCOD || ' ' || TAN_TANNAM || ' ' || TAN_TANKNA LIKE '%" & sercod & "%' ")
                If Trim(sercd2) <> "" Then SqlBuf.AppendLine("        AND TAN_TANCOD LIKE '%" & sercd2 & "%'  ")
                If Trim(sercd3) <> "" Then SqlBuf.AppendLine("        AND TAN_TANNAM LIKE '%" & sercd3 & "%'  ")
                If Trim(sercd4) <> "" Then SqlBuf.AppendLine("        AND TAN_TANKNA LIKE '%" & sercd4 & "%'  ")

            Case SER_TANTABL                                                                '   �S���҃}�X�^            �i�폜�f�[�^�܂ށj

                SqlBuf.AppendLine("        SELECT /*+ INDEX(TANTABL TANTABL1) */            ")
                SqlBuf.AppendLine("            TAN_TANCOD || '|' ||                         ")
                SqlBuf.AppendLine("            TAN_TANNAM || '|' ||                         ")
                SqlBuf.AppendLine("            DECODE(TAN_DELFLG, '0', ' ', '1', '*') MT01  ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            TANTABL                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            TAN_DELFLG IN " & DelFlg & "                 ")
                'SqlBuf.AppendLine("            1 = 1                                        ")

                'If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND TAN_TANCOD  >=   '" & sercod & "'   ")
                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND TAN_TANCOD || ' ' || TAN_TANNAM || ' ' || TAN_TANKNA LIKE '%" & sercod & "%' ")
                If Trim(sercd2) <> "" Then SqlBuf.AppendLine("        AND TAN_TANCOD LIKE '%" & sercd2 & "%'  ")
                If Trim(sercd3) <> "" Then SqlBuf.AppendLine("        AND TAN_TANNAM LIKE '%" & sercd3 & "%'  ")
                If Trim(sercd4) <> "" Then SqlBuf.AppendLine("        AND TAN_TANKNA LIKE '%" & sercd4 & "%'  ")

            Case SER_TKSVIEW                                                                '   ���Ӑ�x�X�}�X�^

                SqlBuf.AppendLine("        SELECT /*+ INDEX(TKSMAST TKSMAST1) */            ")
                SqlBuf.AppendLine("            TKS_TOKCOD || '|' ||                         ")
                SqlBuf.AppendLine("            TKS_TKSCOD || '|' ||                         ")
                SqlBuf.AppendLine("            TKS_TKSNAM || '|' ||                         ")
                SqlBuf.AppendLine("            TKS_TKSKNA            MT01                   ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            TKSMAST                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            TKS_DELFLG = '0'                             ")

                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND TKS_TKSCOD || ' ' || TKS_TKSKNA LIKE '%" & sercod & "%' ")

            Case SER_TKSMAST                                                                '   ���Ӑ�x�X�}�X�^            �i�폜�f�[�^�܂ށj

                SqlBuf.AppendLine("        SELECT /*+ INDEX(TKSMAST TKSMAST1) */            ")
                SqlBuf.AppendLine("            TKS_TOKCOD || '|' ||                         ")
                SqlBuf.AppendLine("            TKS_TKSCOD || '|' ||                         ")
                SqlBuf.AppendLine("            TKS_TKSNAM || '|' ||                         ")
                SqlBuf.AppendLine("            TKS_TKSKNA || '|' ||                         ")
                SqlBuf.AppendLine("            DECODE(TKS_DELFLG, '0', ' ', '1', '*') MT01  ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            TKSMAST                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            TKS_DELFLG IN " & DelFlg & "                 ")
                'SqlBuf.AppendLine("            1 = 1                                        ")

                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND TKS_TKSCOD || ' ' || TKS_TKSKNA LIKE '%" & sercod & "%' ")

            Case SER_TKBVIEW                                                                '   ���Ӑ敔��e�[�u��

                SqlBuf.AppendLine("        SELECT /*+ INDEX(TKBTABL TKBTABL1) */            ")
                SqlBuf.AppendLine("            TKB_TOKCOD || '|' ||                         ")
                SqlBuf.AppendLine("            TKB_TKBCOD || '|' ||                         ")
                SqlBuf.AppendLine("            TKB_TKBNAM            MT01                   ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            TKBTABL                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            TKB_DELFLG = '0'                             ")

                'If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND TKB_TKBCOD >= '" & sercod & "'   ")
                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND TKB_TKBCOD LIKE '%" & sercod & "%'  ")

            Case SER_TSHVIEW                                                                '   ���Ӑ揤�i�}�X�^

                SqlBuf.AppendLine("        SELECT                                           ")
                SqlBuf.AppendLine("            TSH_TOKCOD || '|' ||                         ")
                SqlBuf.AppendLine("            TOK_TOKRYK || '|' ||                         ")
                SqlBuf.AppendLine("            SHO_SHOCOD || '|' ||                         ")
                SqlBuf.AppendLine("            TSH_TSHNAM || '|' ||                         ")
                SqlBuf.AppendLine("            SHO_SHONAM || '|' ||                         ")
                SqlBuf.AppendLine("            TSH_SIRCOD || '|' ||                         ")
                SqlBuf.AppendLine("            SIR_SIRNAM            MT01                   ")
                SqlBuf.AppendLine("           ,SHO_MEKCOD                                   ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            (   SELECT /*+ INDEX(TSHMAST TSHMAST1) */    ")
                SqlBuf.AppendLine("                    TSH_TOKCOD ,                         ")
                SqlBuf.AppendLine("                    TSH_TRICOD ,                         ")
                SqlBuf.AppendLine("                    TSH_SHOCOD ,                         ")
                SqlBuf.AppendLine("                    TSH_TSHNAM ,                         ")
                SqlBuf.AppendLine("                    TSH_SIRCOD                           ")
                SqlBuf.AppendLine("                FROM                                     ")
                SqlBuf.AppendLine("                    TSHMAST                              ")
                SqlBuf.AppendLine("                WHERE   TSH_DELFLG = '0'                 ")

                If Trim(sercd2) <> "" Then SqlBuf.AppendLine("        AND TSH_TOKCOD LIKE '%" & sercd2 & "%' ")
                'If Trim(sercd3) <> "" Then SqlBuf.AppendLine("        AND TSH_TSHNAM LIKE '%" & sercd3 & "%' ")
                SqlBuf.AppendLine("            )                                            ")

                SqlBuf.AppendLine("                Inner Join                               ")
                SqlBuf.AppendLine("            (   SELECT /*+ INDEX(SHOMAST SHOMAST1) */    ")
                SqlBuf.AppendLine("                    SHO_SHOCOD ,                         ")
                SqlBuf.AppendLine("                    SHO_SHOKNA ,                         ")
                SqlBuf.AppendLine("                    SHO_SHONAM ,                         ")
                SqlBuf.AppendLine("                    SHO_MEKCOD                           ")
                SqlBuf.AppendLine("                FROM                                     ")
                SqlBuf.AppendLine("                    SHOMAST                              ")
                SqlBuf.AppendLine("                WHERE                                    ")
                SqlBuf.AppendLine("                    SHO_DELFLG = '0'                     ")

                If Trim(sercd3) <> "" Then SqlBuf.AppendLine("        AND SHO_SHOCOD LIKE '%" & sercd3 & "%' ")
                If Trim(sercd6) <> "" Then SqlBuf.AppendLine("        AND SHO_MEKCOD LIKE '%" & sercd6 & "%' ")

                SqlBuf.AppendLine("            )                                            ")
                SqlBuf.AppendLine("            On ( TSH_SHOCOD = SHO_SHOCOD )               ")

                SqlBuf.AppendLine("                Inner Join                               ")
                SqlBuf.AppendLine("            (   SELECT /*+ INDEX(SIRMAST SIRMAST1) */    ")
                SqlBuf.AppendLine("                    SIR_SIRCOD ,                         ")
                SqlBuf.AppendLine("                    SIR_SIRNAM                           ")
                SqlBuf.AppendLine("                FROM                                     ")
                SqlBuf.AppendLine("                    SIRMAST                              ")
                SqlBuf.AppendLine("                WHERE                                    ")
                SqlBuf.AppendLine("                    SIR_DELFLG = '0'                     ")

                If Trim(sercd5) <> "" Then SqlBuf.AppendLine("        AND SIR_SIRCOD LIKE '%" & sercd5 & "%' ")

                SqlBuf.AppendLine("            )                                            ")
                SqlBuf.AppendLine("            On ( TSH_SIRCOD = SIR_SIRCOD )               ")

                SqlBuf.AppendLine("                Inner Join                               ")
                SqlBuf.AppendLine("            (   SELECT /*+ INDEX(TOKMAST TOKMAST2) */    ")
                SqlBuf.AppendLine("                    TOK_TOKCOD ,                         ")
                SqlBuf.AppendLine("                    TOK_TOKRYK                           ")
                SqlBuf.AppendLine("                FROM                                     ")
                SqlBuf.AppendLine("                    TOKMAST                              ")
                SqlBuf.AppendLine("                WHERE                                    ")
                SqlBuf.AppendLine("                    TOK_DELFLG = '0'                     ")
                SqlBuf.AppendLine("            )                                            ")
                SqlBuf.AppendLine("            On ( TSH_TOKCOD = TOK_TOKCOD )               ")

                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            1 = 1                                        ")
                If Trim(sercd4) <> "" Then SqlBuf.AppendLine("        AND TSH_TSHNAM || ' ' || SHO_SHOKNA || ' ' || SHO_SHONAM LIKE '%" & sercd4 & "%' ")
                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND TSH_TOKCOD || ' ' || SHO_SHOCOD || ' ' || TSH_TSHNAM || ' ' || SHO_SHOKNA || ' ' || SHO_SHONAM || ' ' || TSH_SIRCOD || ' ' || SHO_MEKCOD LIKE '%" & sercod & "%' ")

            Case SER_TSHVIEW2                                                               '   ���Ӑ揤�i�}�X�^

                '�q�揤�i�}�X�^�r���[
                SqlBuf.AppendLine("        SELECT                                           ")
                SqlBuf.AppendLine("            TSH_TOKCOD || '|' ||                         ")
                SqlBuf.AppendLine("            SHO_SHOCOD || '|' ||                         ")
                SqlBuf.AppendLine("            TSH_TSHNAM || '|' ||                         ")
                SqlBuf.AppendLine("            SHO_SHONAM || '|' ||                         ")
                SqlBuf.AppendLine("            TSH_SIRCOD || '|' ||                         ")
                SqlBuf.AppendLine("            SIR_SIRNAM            MT01                   ")
                SqlBuf.AppendLine("           ,SHO_MEKCOD                                   ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            (   SELECT /*+ INDEX(TSHMAST TSHMAST1) */    ")
                SqlBuf.AppendLine("                    TSH_TOKCOD ,                         ")
                SqlBuf.AppendLine("                    TSH_TRICOD ,                         ")
                SqlBuf.AppendLine("                    TSH_SHOCOD ,                         ")
                SqlBuf.AppendLine("                    TSH_TSHNAM ,                         ")
                SqlBuf.AppendLine("                    TSH_SIRCOD                           ")
                SqlBuf.AppendLine("                FROM                                     ")
                SqlBuf.AppendLine("                    TSHMAST                              ")
                SqlBuf.AppendLine("                WHERE   TSH_DELFLG = '0'                 ")
                SqlBuf.AppendLine("            )                                            ")
                SqlBuf.AppendLine("                Inner Join                               ")
                SqlBuf.AppendLine("            (   SELECT /*+ INDEX(SHOMAST SHOMAST1) */    ")
                SqlBuf.AppendLine("                    SHO_SHOCOD ,                         ")
                SqlBuf.AppendLine("                    SHO_SHOKNA ,                         ")
                SqlBuf.AppendLine("                    SHO_SHONAM ,                         ")
                SqlBuf.AppendLine("                    SHO_MEKCOD                           ")
                SqlBuf.AppendLine("                FROM                                     ")
                SqlBuf.AppendLine("                    SHOMAST                              ")
                SqlBuf.AppendLine("                WHERE                                    ")
                SqlBuf.AppendLine("                    SHO_DELFLG = '0'                     ")

                If Trim(sercd2) <> "" Then SqlBuf.AppendLine("        AND SHO_SHOCOD LIKE '%" & sercd2 & "%' ")
                If Trim(sercd5) <> "" Then SqlBuf.AppendLine("        AND SHO_MEKCOD LIKE '%" & sercd5 & "%' ")

                SqlBuf.AppendLine("            )                                            ")
                SqlBuf.AppendLine("            On ( TSH_SHOCOD = SHO_SHOCOD )               ")

                SqlBuf.AppendLine("                Inner Join                               ")
                SqlBuf.AppendLine("            (   SELECT /*+ INDEX(SIRMAST SIRMAST1) */    ")
                SqlBuf.AppendLine("                    SIR_SIRCOD ,                         ")
                SqlBuf.AppendLine("                    SIR_SIRNAM                           ")
                SqlBuf.AppendLine("                FROM                                     ")
                SqlBuf.AppendLine("                    SIRMAST                              ")
                SqlBuf.AppendLine("                WHERE                                    ")
                SqlBuf.AppendLine("                    SIR_DELFLG = '0'                     ")

                If Trim(sercd4) <> "" Then SqlBuf.AppendLine("        AND SIR_SIRCOD LIKE '%" & sercd4 & "%' ")

                SqlBuf.AppendLine("            )                                            ")
                SqlBuf.AppendLine("            On ( TSH_SIRCOD = SIR_SIRCOD )               ")

                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            1 = 1                                        ")
                If Trim(sercd3) <> "" Then SqlBuf.AppendLine("        AND TSH_TSHNAM || ' ' || SHO_SHOKNA || ' ' || SHO_SHONAM LIKE '%" & sercd3 & "%' ")
                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND SHO_SHOCOD || ' ' || TSH_TSHNAM || ' ' || SHO_SHOKNA || ' ' || SHO_SHONAM || ' ' || TSH_SIRCOD || ' ' || SHO_MEKCOD LIKE '%" & sercod & "%' ")

            Case SER_TSHMAST                                                                '   ���Ӑ揤�i�}�X�^

                SqlBuf.AppendLine("        SELECT                                           ")
                SqlBuf.AppendLine("            TSH_TOKCOD || '|' ||                         ")
                SqlBuf.AppendLine("            TOK_TOKRYK || '|' ||                         ")
                SqlBuf.AppendLine("            SHO_SHOCOD || '|' ||                         ")
                SqlBuf.AppendLine("            TSH_TSHNAM || '|' ||                         ")
                SqlBuf.AppendLine("            SHO_SHONAM || '|' ||                         ")
                SqlBuf.AppendLine("            TSH_SIRCOD || '|' ||                         ")
                SqlBuf.AppendLine("            SIR_SIRNAM || '|' ||                         ")
                SqlBuf.AppendLine("            DECODE(TSH_DELFLG, '0', ' ', '1', '*') MT01  ")
                SqlBuf.AppendLine("           ,SHO_MEKCOD                                   ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            (   SELECT /*+ INDEX(TSHMAST TSHMAST1) */    ")
                SqlBuf.AppendLine("                    TSH_TOKCOD ,                         ")
                SqlBuf.AppendLine("                    TSH_TRICOD ,                         ")
                SqlBuf.AppendLine("                    TSH_SHOCOD ,                         ")
                SqlBuf.AppendLine("                    TSH_TSHNAM ,                         ")
                SqlBuf.AppendLine("                    TSH_SIRCOD ,                         ")
                SqlBuf.AppendLine("                    TSH_DELFLG                           ")
                SqlBuf.AppendLine("                FROM                                     ")
                SqlBuf.AppendLine("                    TSHMAST                              ")
                SqlBuf.AppendLine("                WHERE                                    ")
                SqlBuf.AppendLine("                    1 = 1                                ")

                If Trim(sercd2) <> "" Then SqlBuf.AppendLine("        AND TSH_TOKCOD LIKE '%" & sercd2 & "%' ")
                'If Trim(sercd3) <> "" Then SqlBuf.AppendLine("        AND TSH_TSHNAM LIKE '%" & sercd3 & "%' ")

                SqlBuf.AppendLine("            )                                            ")
                SqlBuf.AppendLine("                Inner Join                               ")
                SqlBuf.AppendLine("            (   SELECT /*+ INDEX(SHOMAST SHOMAST1) */    ")
                SqlBuf.AppendLine("                    SHO_SHOCOD ,                         ")
                SqlBuf.AppendLine("                    SHO_SHOKNA ,                         ")
                SqlBuf.AppendLine("                    SHO_SHONAM ,                         ")
                SqlBuf.AppendLine("                    SHO_MEKCOD                           ")
                SqlBuf.AppendLine("                FROM                                     ")
                SqlBuf.AppendLine("                    SHOMAST                              ")
                SqlBuf.AppendLine("                WHERE                                    ")
                SqlBuf.AppendLine("                    1 = 1                                ")

                If Trim(sercd3) <> "" Then SqlBuf.AppendLine("        AND SHO_SHOCOD LIKE '%" & sercd3 & "%' ")
                If Trim(sercd6) <> "" Then SqlBuf.AppendLine("        AND SHO_MEKCOD LIKE '%" & sercd6 & "%' ")

                SqlBuf.AppendLine("            )                                            ")
                SqlBuf.AppendLine("            On ( TSH_SHOCOD = SHO_SHOCOD )               ")

                SqlBuf.AppendLine("                Inner Join                               ")
                SqlBuf.AppendLine("            (   SELECT /*+ INDEX(SIRMAST SIRMAST1) */    ")
                SqlBuf.AppendLine("                    SIR_SIRCOD ,                         ")
                SqlBuf.AppendLine("                    SIR_SIRNAM                           ")
                SqlBuf.AppendLine("                FROM                                     ")
                SqlBuf.AppendLine("                    SIRMAST                              ")
                SqlBuf.AppendLine("                WHERE                                    ")
                SqlBuf.AppendLine("                    SIR_DELFLG = '0'                     ")

                If Trim(sercd5) <> "" Then SqlBuf.AppendLine("        AND SIR_SIRCOD LIKE '%" & sercd5 & "%' ")

                SqlBuf.AppendLine("            )                                            ")
                SqlBuf.AppendLine("            On ( TSH_SIRCOD = SIR_SIRCOD )               ")

                SqlBuf.AppendLine("                Inner Join                               ")
                SqlBuf.AppendLine("            (   SELECT /*+ INDEX(TOKMAST TOKMAST2) */    ")
                SqlBuf.AppendLine("                    TOK_TOKCOD ,                         ")
                SqlBuf.AppendLine("                    TOK_TOKRYK                           ")
                SqlBuf.AppendLine("                FROM                                     ")
                SqlBuf.AppendLine("                    TOKMAST                              ")
                SqlBuf.AppendLine("                WHERE                                    ")
                SqlBuf.AppendLine("                    TOK_DELFLG = '0'                     ")
                SqlBuf.AppendLine("            )                                            ")
                SqlBuf.AppendLine("            On ( TSH_TOKCOD = TOK_TOKCOD )               ")

                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            TSH_DELFLG IN " & DelFlg & "                 ")
                'SqlBuf.AppendLine("            1 = 1                                        ")

                If Trim(sercd4) <> "" Then SqlBuf.AppendLine("        AND TSH_TSHNAM || ' ' || SHO_SHOKNA || ' ' || SHO_SHONAM LIKE '%" & sercd4 & "%' ")
                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND TSH_TOKCOD || ' ' || SHO_SHOCOD || ' ' || TSH_TSHNAM || ' ' || SHO_SHOKNA || ' ' || SHO_SHONAM || ' ' || TSH_SIRCOD || ' ' || SHO_MEKCOD LIKE '%" & sercod & "%' ")

            Case SER_TSHMAST2                                                               '   ���Ӑ揤�i�}�X�^

                SqlBuf.AppendLine("        SELECT                                           ")
                SqlBuf.AppendLine("            TSH_TOKCOD || '|' ||                         ")
                SqlBuf.AppendLine("            SHO_SHOCOD || '|' ||                         ")
                SqlBuf.AppendLine("            TSH_TSHNAM || '|' ||                         ")
                SqlBuf.AppendLine("            SHO_SHONAM || '|' ||                         ")
                SqlBuf.AppendLine("            TSH_SIRCOD || '|' ||                         ")
                SqlBuf.AppendLine("            SIR_SIRNAM || '|' ||                         ")
                SqlBuf.AppendLine("            DECODE(TSH_DELFLG, '0', ' ', '1', '*') MT01  ")
                SqlBuf.AppendLine("           ,SHO_MEKCOD                                   ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            (   SELECT /*+ INDEX(TSHMAST TSHMAST1) */    ")
                SqlBuf.AppendLine("                    TSH_TOKCOD ,                         ")
                SqlBuf.AppendLine("                    TSH_TRICOD ,                         ")
                SqlBuf.AppendLine("                    TSH_SHOCOD ,                         ")
                SqlBuf.AppendLine("                    TSH_TSHNAM ,                         ")
                SqlBuf.AppendLine("                    TSH_SIRCOD ,                         ")
                SqlBuf.AppendLine("                    TSH_DELFLG                           ")
                SqlBuf.AppendLine("                FROM                                     ")
                SqlBuf.AppendLine("                    TSHMAST                              ")
                SqlBuf.AppendLine("                WHERE                                    ")
                SqlBuf.AppendLine("                    1 = 1                                ")
                SqlBuf.AppendLine("            )                                            ")
                SqlBuf.AppendLine("                Inner Join                               ")
                SqlBuf.AppendLine("            (   SELECT /*+ INDEX(SHOMAST SHOMAST1) */    ")
                SqlBuf.AppendLine("                    SHO_SHOCOD ,                         ")
                SqlBuf.AppendLine("                    SHO_SHOKNA ,                         ")
                SqlBuf.AppendLine("                    SHO_SHONAM                           ")
                SqlBuf.AppendLine("                FROM                                     ")
                SqlBuf.AppendLine("                    SHOMAST                              ")
                SqlBuf.AppendLine("                WHERE                                    ")
                SqlBuf.AppendLine("                    1 = 1                                ")

                If Trim(sercd2) <> "" Then SqlBuf.AppendLine("        AND SHO_SHOCOD LIKE '%" & sercd2 & "%' ")
                If Trim(sercd5) <> "" Then SqlBuf.AppendLine("        AND SHO_MEKCOD LIKE '%" & sercd5 & "%' ")

                SqlBuf.AppendLine("            )                                            ")
                SqlBuf.AppendLine("            On ( TSH_SHOCOD = SHO_SHOCOD )               ")

                SqlBuf.AppendLine("                Inner Join                               ")
                SqlBuf.AppendLine("            (   SELECT /*+ INDEX(SIRMAST SIRMAST1) */    ")
                SqlBuf.AppendLine("                    SIR_SIRCOD ,                         ")
                SqlBuf.AppendLine("                    SIR_SIRNAM                           ")
                SqlBuf.AppendLine("                FROM                                     ")
                SqlBuf.AppendLine("                    SIRMAST                              ")
                SqlBuf.AppendLine("                WHERE                                    ")
                SqlBuf.AppendLine("                    SIR_DELFLG = '0'                     ")

                If Trim(sercd4) <> "" Then SqlBuf.AppendLine("        AND SIR_SIRCOD LIKE '%" & sercd4 & "%' ")

                SqlBuf.AppendLine("            )                                            ")
                SqlBuf.AppendLine("            On ( TSH_SIRCOD = SIR_SIRCOD )               ")

                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            TSH_DELFLG IN " & DelFlg & "                 ")
                'SqlBuf.AppendLine("            1 = 1                                        ")

                If Trim(sercd3) <> "" Then SqlBuf.AppendLine("        AND TSH_TSHNAM || ' ' || SHO_SHOKNA || ' ' || SHO_SHONAM LIKE '%" & sercd3 & "%' ")
                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND SHO_SHOCOD || ' ' || TSH_TSHNAM || ' ' || SHO_SHOKNA || ' ' || SHO_SHONAM || ' ' || TSH_SIRCOD || ' ' || SHO_MEKCOD LIKE '%" & sercod & "%' ")

            Case SER_SSHMAST                                                                '   �d���揤�i�}�X�^

                SqlBuf.AppendLine("        SELECT /*+ INDEX(SSHMAST SSHMAST1) */            ")
                SqlBuf.AppendLine("            SSH_SIRCOD || '|' ||                         ")
                SqlBuf.AppendLine("            SIR_SIRNAM || '|' ||                         ")
                SqlBuf.AppendLine("            SSH_SHOCOD || '|' ||                         ")
                SqlBuf.AppendLine("            SHO_SHONAM || '|' ||                         ")
                SqlBuf.AppendLine("            DECODE(SSH_DELFLG, '0', ' ', '1', '*') MT01  ")
                SqlBuf.AppendLine("           ,SIR_SIRKNA                                   ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            SSHMAST                                      ")
                SqlBuf.AppendLine("                Left Join                                ")
                SqlBuf.AppendLine("            SHOMAST                                      ")
                SqlBuf.AppendLine("            On ( SSH_SHOCOD = SHO_SHOCOD )               ")
                SqlBuf.AppendLine("                Left Join                                ")
                SqlBuf.AppendLine("            SIRMAST                                      ")
                SqlBuf.AppendLine("            On ( SSH_SIRCOD = SIR_SIRCOD )               ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            SHO_DELFLG = '0'                             ")
                SqlBuf.AppendLine("        AND                                              ")
                SqlBuf.AppendLine("            SSH_DELFLG IN " & DelFlg & "                 ")

                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND SSH_SIRCOD || ' ' || SIR_SIRKNA || ' ' || SHO_SHOKNA || ' ' || SHO_SHONAM || ' ' || SSH_SHOCOD LIKE '%" & sercod & "%' ")
                If Trim(sercd2) <> "" Then SqlBuf.AppendLine("        AND SSH_SIRCOD LIKE '%" & sercd2 & "%' ")
                If Trim(sercd3) <> "" Then SqlBuf.AppendLine("        AND SIR_SIRKNA LIKE '%" & sercd3 & "%' ")
                If Trim(sercd4) <> "" Then SqlBuf.AppendLine("        AND SSH_SHOCOD LIKE '%" & sercd4 & "%' ")
                If Trim(sercd5) <> "" Then SqlBuf.AppendLine("        AND SHO_SHOKNA || ' ' || SHO_SHONAM LIKE '%" & sercd5 & "%' ")

            Case SER_SSHMAST2                                                               '   �d���揤�i�}�X�^

                ' �d���揤�i�}�X�^
                SqlBuf.AppendLine("        SELECT /*+ INDEX(SSHMAST SSHMAST1) */            ")
                SqlBuf.AppendLine("            SSH_SIRCOD || '|' ||                         ")
                SqlBuf.AppendLine("            SIR_SIRNAM || '|' ||                         ")
                SqlBuf.AppendLine("            SSH_SHOCOD || '|' ||                         ")
                SqlBuf.AppendLine("            SHO_SHONAM || '|' ||                         ")
                SqlBuf.AppendLine("            DECODE(SSH_DELFLG, '0', ' ', '1', '*') MT01  ")
                SqlBuf.AppendLine("           ,SIR_SIRKNA                                   ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            SSHMAST                                      ")
                SqlBuf.AppendLine("                Left Join                                ")
                SqlBuf.AppendLine("            SHOMAST                                      ")
                SqlBuf.AppendLine("            On ( SSH_SHOCOD = SHO_SHOCOD )               ")
                SqlBuf.AppendLine("                Left Join                                ")
                SqlBuf.AppendLine("            SIRMAST                                      ")
                SqlBuf.AppendLine("            On ( SSH_SIRCOD = SIR_SIRCOD )               ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            SHO_DELFLG = '0'                             ")
                SqlBuf.AppendLine("        AND                                              ")
                SqlBuf.AppendLine("            SSH_DELFLG IN " & DelFlg & "                 ")

                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND SIR_SIRKNA || ' ' || SHO_SHOKNA || ' ' || SHO_SHONAM || ' ' || SSH_SHOCOD LIKE '%" & sercod & "%' ")
                If Trim(sercd3) <> "" Then SqlBuf.AppendLine("        AND SSH_SHOCOD LIKE '%" & sercd3 & "%' ")
                If Trim(sercd2) <> "" Then SqlBuf.AppendLine("        AND SIR_SIRKNA LIKE '%" & sercd2 & "%' ")
                If Trim(sercd4) <> "" Then SqlBuf.AppendLine("        AND SHO_SHOKNA || ' ' || SHO_SHONAM LIKE '%" & sercd4 & "%' ")

            Case SER_SSHVIEW                                                                '   �d���揤�i�}�X�^

                SqlBuf.AppendLine("        SELECT /*+ INDEX(SSHMAST SSHMAST1) */            ")
                SqlBuf.AppendLine("            SSH_SHOCOD || '|' ||                         ")
                SqlBuf.AppendLine("            SHO_SHONAM || '|' ||                         ")
                SqlBuf.AppendLine("            SSH_SIRCOD || '|' ||                         ")
                SqlBuf.AppendLine("            SIR_SIRNAM            MT01                   ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            SSHMAST                                      ")
                SqlBuf.AppendLine("                Left Join                                ")
                SqlBuf.AppendLine("            SHOMAST                                      ")
                SqlBuf.AppendLine("            On ( SSH_SHOCOD = SHO_SHOCOD )               ")
                SqlBuf.AppendLine("                Left Join                                ")
                SqlBuf.AppendLine("            SIRMAST                                      ")
                SqlBuf.AppendLine("            On ( SSH_SIRCOD = SIR_SIRCOD )               ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            SSH_DELFLG = '0'                             ")

                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND SSH_SIRCOD || ' ' || SIR_SIRKNA || ' ' || SHO_SHOKNA || ' ' || SHO_SHONAM || ' ' || SSH_SHOCOD LIKE '%" & sercod & "%' ")
                If Trim(sercd4) <> "" Then SqlBuf.AppendLine("        AND SSH_SIRCOD LIKE '%" & sercd4 & "%' ")
                If Trim(sercd2) <> "" Then SqlBuf.AppendLine("        AND SSH_SHOCOD LIKE '%" & sercd2 & "%' ")
                If Trim(sercd5) <> "" Then SqlBuf.AppendLine("        AND SIR_SIRKNA LIKE '%" & sercd3 & "%' ")
                If Trim(sercd3) <> "" Then SqlBuf.AppendLine("        AND SHO_SHOKNA || ' ' || SHO_SHONAM LIKE '%" & sercd3 & "%' ")

            Case SER_SSHVIEW2                                                                '   �d���揤�i�}�X�^

                ' �d���揤�i�}�X�^�r���[
                SqlBuf.AppendLine("        SELECT /*+ INDEX(SSHMAST SSHMAST1) */            ")
                SqlBuf.AppendLine("            SSH_SHOCOD || '|' ||                         ")
                SqlBuf.AppendLine("            SHO_SHONAM || '|' ||                         ")
                SqlBuf.AppendLine("            SSH_SIRCOD || '|' ||                         ")
                SqlBuf.AppendLine("            SIR_SIRNAM            MT01                   ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            SSHMAST                                      ")
                SqlBuf.AppendLine("                Left Join                                ")
                SqlBuf.AppendLine("            SHOMAST                                      ")
                SqlBuf.AppendLine("            On ( SSH_SHOCOD = SHO_SHOCOD )               ")
                SqlBuf.AppendLine("                Left Join                                ")
                SqlBuf.AppendLine("            SIRMAST                                      ")
                SqlBuf.AppendLine("            On ( SSH_SIRCOD = SIR_SIRCOD )               ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            SSH_DELFLG = '0'                             ")

                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND SIR_SIRKNA || ' ' || SHO_SHOKNA || ' ' || SHO_SHONAM || ' ' || SSH_SHOCOD LIKE '%" & sercod & "%' ")
                If Trim(sercd3) <> "" Then SqlBuf.AppendLine("        AND SSH_SIRCOD LIKE '%" & sercd3 & "%' ")
                If Trim(sercd4) <> "" Then SqlBuf.AppendLine("        AND SIR_SIRKNA LIKE '%" & sercd4 & "%' ")
                If Trim(sercd2) <> "" Then SqlBuf.AppendLine("        AND SHO_SHOKNA || ' ' || SHO_SHONAM LIKE '%" & sercd2 & "%' ")

            Case SER_BSHTABL                                                                '   �����Z���^�[�ʏ��i�e�[�u��

                SqlBuf.AppendLine("        SELECT /*+ INDEX(BSHTABL BSHTABL1) */            ")
                SqlBuf.AppendLine("            BSH_SNTCOD || '|' ||                         ")
                SqlBuf.AppendLine("            BSH_SHOCOD || '|' ||                         ")
                SqlBuf.AppendLine("            SHO_SHONAM || '|' ||                         ")
                SqlBuf.AppendLine("            DECODE(BSH_DELFLG, '0', ' ', '1', '*') MT01  ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            BSHTABL                                      ")
                SqlBuf.AppendLine("                Left Join                                ")
                SqlBuf.AppendLine("            SHOMAST                                      ")
                SqlBuf.AppendLine("            On ( BSH_SHOCOD = SHO_SHOCOD )               ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            BSH_DELFLG IN " & DelFlg & "                 ")
                'SqlBuf.AppendLine("            1 = 1                                        ")

                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND BSH_SNTCOD || ' ' || BSH_SHOCOD || ' ' || SHO_SHOKNA || ' ' || SHO_SHONAM LIKE '%" & sercod & "%' ")
                If Trim(sercd2) <> "" Then SqlBuf.AppendLine("        AND BSH_SNTCOD LIKE '%" & sercd2 & "%' ")
                If Trim(sercd3) <> "" Then SqlBuf.AppendLine("        AND BSH_SHOCOD LIKE '%" & sercd3 & "%' ")

            Case SER_BSHVIEW                                                                '   �����Z���^�[�ʏ��i�e�[�u��

                SqlBuf.AppendLine("        SELECT /*+ INDEX(BSHTABL BSHTABL1) */            ")
                SqlBuf.AppendLine("            BSH_SNTCOD || '|' ||                         ")
                SqlBuf.AppendLine("            BSH_SHOCOD || '|' ||                         ")
                SqlBuf.AppendLine("            SHO_SHONAM            MT01                   ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            BSHTABL                                      ")
                SqlBuf.AppendLine("                Left Join                                ")
                SqlBuf.AppendLine("            SHOMAST                                      ")
                SqlBuf.AppendLine("            On ( BSH_SHOCOD = SHO_SHOCOD )               ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            BSH_DELFLG = '0'                             ")

                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND BSH_SNTCOD || ' ' || BSH_SHOCOD || ' ' || SHO_SHOKNA || ' ' || SHO_SHONAM LIKE '%" & sercod & "%' ")
                If Trim(sercd2) <> "" Then SqlBuf.AppendLine("        AND BSH_SNTCOD LIKE '%" & sercd2 & "%' ")
                If Trim(sercd3) <> "" Then SqlBuf.AppendLine("        AND BSH_SHOCOD LIKE '%" & sercd3 & "%' ")

            Case SER_ARETABL                                                                '   �G���A�e�[�u��

                SqlBuf.AppendLine("        SELECT")
                SqlBuf.AppendLine("            ARE_ARECOD || '|' ||                         ")
                SqlBuf.AppendLine("            ARE_ARENAM || '|' ||                         ")
                SqlBuf.AppendLine("            DECODE(ARE_DELFLG, '0', ' ', '1', '*') MT01  ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            ARETABL                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            ARE_DELFLG IN " & DelFlg & "                 ")

                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND ARE_ARECOD || ' ' || ARE_ARENAM LIKE '%" & sercod & "%' ")

            Case SER_AREVIEW                                                                '   �G���A�e�[�u��

                SqlBuf.AppendLine("        SELECT")
                SqlBuf.AppendLine("            ARE_ARECOD || '|' ||                         ")
                SqlBuf.AppendLine("            ARE_ARENAM            MT01                   ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            ARETABL                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            ARE_DELFLG = '0'                             ")

                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND ARE_ARECOD || ' ' || ARE_ARENAM LIKE '%" & sercod & "%' ")

            Case SER_BMNTABL                                                                '   ����e�[�u��

                SqlBuf.AppendLine("        SELECT /*+ INDEX(BMNTABL BMNTABL1) */            ")
                SqlBuf.AppendLine("            BMN_BMNCOD || '|' ||                         ")
                SqlBuf.AppendLine("            BMN_BMNNAM || '|' ||                         ")
                SqlBuf.AppendLine("            DECODE(BMN_DELFLG, '0', ' ', '1', '*') MT01  ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            BMNTABL                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            BMN_DELFLG IN " & DelFlg & "                 ")
                'SqlBuf.AppendLine("            1 = 1                                        ")

                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND BMN_BMNCOD LIKE '%" & sercod & "%'   ")

            Case SER_BMNVIEW                                                                '   ����e�[�u��

                SqlBuf.AppendLine("        SELECT /*+ INDEX(BMNTABL BMNTABL1) */            ")
                SqlBuf.AppendLine("            BMN_BMNCOD || '|' ||                         ")
                SqlBuf.AppendLine("            BMN_BMNNAM            MT01                   ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            BMNTABL                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            BMN_DELFLG = '0'                             ")

                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND BMN_BMNCOD LIKE '%" & sercod & "%'   ")

            Case SER_SBNTABL                                                                '   ���i���ރe�[�u��

                SqlBuf.AppendLine("        SELECT /*+ INDEX(SBNTABL SBNTABL1) */            ")
                SqlBuf.AppendLine("            SBN_BURCOD || '|' ||                         ")
                SqlBuf.AppendLine("            RTRIM(SBN_BBUNAM) || '  '    ||              ")
                SqlBuf.AppendLine("            RTRIM(SBN_CBUNAM) || '  '    ||              ")
                SqlBuf.AppendLine("            SBN_SBUNAM || '|' ||                         ")
                SqlBuf.AppendLine("            DECODE(SBN_DELFLG, '0', ' ', '1', '*') MT01  ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            SBNTABL                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            SBN_DELFLG IN " & DelFlg & "                 ")
                'SqlBuf.AppendLine("            1 = 1                                        ")

                'If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND SBN_BURCOD >= '" & sercod & "'   ")
                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND SBN_BURCOD LIKE '%" & sercod & "%'  ")

            Case SER_SBNVIEW                                                                '   ���i���ރe�[�u��

                SqlBuf.AppendLine("        SELECT /*+ INDEX(SBNTABL SBNTABL1) */            ")
                SqlBuf.AppendLine("            SBN_BURCOD || '|' ||                         ")
                SqlBuf.AppendLine("            RTRIM(SBN_BBUNAM) || '  '    ||              ")
                SqlBuf.AppendLine("            RTRIM(SBN_CBUNAM) || '  '    ||              ")
                SqlBuf.AppendLine("            SBN_SBUNAM            MT01                   ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            SBNTABL                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            SBN_DELFLG = '0'                             ")

                'If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND SBN_BURCOD >= '" & sercod & "'   ")
                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND SBN_BURCOD LIKE '%" & sercod & "%'  ")

            Case SER_TKJTABL                                                                '   ���Ӑ抨��ȖڃR�[�h�e�[�u��

                SqlBuf.AppendLine("        SELECT /*+ INDEX(TKJTABL TKJTABL1) */            ")
                SqlBuf.AppendLine("            TKJ_SSWCOD || '|' ||                         ")
                SqlBuf.AppendLine("            TKJ_SSWNAM || '|' ||                         ")
                SqlBuf.AppendLine("            DECODE(TKJ_DELFLG, '0', ' ', '1', '*') MT01  ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            TKJTABL                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            TKJ_DELFLG IN " & DelFlg & "                 ")
                'SqlBuf.AppendLine("            1 = 1                                        ")

                'If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND TKJ_SSWCOD >= '" & sercod & "'   ")
                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND TKJ_SSWCOD LIKE '%" & sercod & "%'  ")

            Case SER_TKJVIEW                                                                '   ���Ӑ抨��ȖڃR�[�h�e�[�u��

                SqlBuf.AppendLine("        SELECT /*+ INDEX(TKJTABL TKJTABL1) */            ")
                SqlBuf.AppendLine("            TKJ_SSWCOD || '|' ||                         ")
                SqlBuf.AppendLine("            TKJ_SSWNAM            MT01                   ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            TKJTABL                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            TKJ_DELFLG = '0'                             ")

                'If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND TKJ_SSWCOD >= '" & sercod & "'   ")
                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND TKJ_SSWCOD LIKE '%" & sercod & "%'  ")

            Case SER_DNKTABL                                                                '   �`�[�敪�e�[�u��

                SqlBuf.AppendLine("        SELECT /*+ INDEX(DNKTABL DNKTABL1) */            ")
                SqlBuf.AppendLine("            DNK_DNKKBN || '|' ||                         ")
                SqlBuf.AppendLine("            DNK_DNKNAM || '|' ||                         ")
                SqlBuf.AppendLine("            DECODE(DNK_DELFLG, '0', ' ', '1', '*') MT01  ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            DNKTABL                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            DNK_DSPKBN = '1'                             ")
                SqlBuf.AppendLine("        AND                                              ")
                SqlBuf.AppendLine("            DNK_DELFLG IN " & DelFlg & "                 ")

                'If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND DNK_DNKKBN >= '" & sercod & "'   ")
                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND DNK_DNKKBN LIKE '%" & sercod & "%'  ")

            Case SER_DNKVIEW                                                                '   �`�[�敪�e�[�u��

                SqlBuf.AppendLine("        SELECT /*+ INDEX(DNKTABL DNKTABL1) */            ")
                SqlBuf.AppendLine("            DNK_DNKKBN || '|' ||                         ")
                SqlBuf.AppendLine("            DNK_DNKNAM            MT01                   ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            DNKTABL                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            DNK_DSPKBN = '1'                             ")
                SqlBuf.AppendLine("        AND DNK_DELFLG = '0'                             ")

                'If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND DNK_DNKKBN >= '" & sercod & "'   ")
                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND DNK_DNKKBN LIKE '%" & sercod & "%'  ")

            Case SER_DPTTABL                                                                '   �`�[�p�^�[���敪�e�[�u��

                SqlBuf.AppendLine("        SELECT /*+ INDEX(DPTTABL DPTTABL1) */            ")
                SqlBuf.AppendLine("            DPT_TDNPTN || '|' ||                         ")
                SqlBuf.AppendLine("            DPT_TDNNAM || '|' ||                         ")
                SqlBuf.AppendLine("            DECODE(DPT_DELFLG, '0', ' ', '1', '*') MT01  ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            DPTTABL                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            DPT_DELFLG IN " & DelFlg & "                 ")
                'SqlBuf.AppendLine("            1 = 1                                        ")

                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND DPT_TDNPTN LIKE '%" & sercod & "%'   ")
                If Trim(sercd2) <> "" Then SqlBuf.AppendLine("        AND DPT_TDNNAM LIKE '%" & sercd2 & "%'   ")

            Case SER_DPTVIEW                                                                '   �`�[�p�^�[���敪�e�[�u��

                SqlBuf.AppendLine("        SELECT /*+ INDEX(DPTTABL DPTTABL1) */            ")
                SqlBuf.AppendLine("            DPT_TDNPTN || '|' ||                         ")
                SqlBuf.AppendLine("            DPT_TDNNAM            MT01                   ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            DPTTABL                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            DPT_DELFLG = '0'                             ")

                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND DPT_TDNPTN LIKE '%" & sercod & "%'   ")
                If Trim(sercd2) <> "" Then SqlBuf.AppendLine("        AND DPT_TDNNAM LIKE '%" & sercd2 & "%'   ")

            Case SER_KBNTABL                                                                '   �敪���̃e�[�u��

                SqlBuf.AppendLine("        SELECT /*+ INDEX(KBNTABL KBNTABL1) */            ")
                SqlBuf.AppendLine("            KBN_KBNCOD || '|' ||                         ")
                SqlBuf.AppendLine("            KBN_KBNNAM || '|' ||                         ")
                SqlBuf.AppendLine("            DECODE(KBN_DELFLG, '0', ' ', '1', '*') MT01  ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            KBNTABL                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            KBN_DELFLG IN " & DelFlg & "                 ")
                'SqlBuf.AppendLine("            1 = 1                                        ")

                'If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND KBN_KBNCOD  >=   '" & sercod & "'    ")
                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND KBN_KBNCOD LIKE '%" & sercod & "%'   ")
                If Trim(sercd2) <> "" Then SqlBuf.AppendLine("        AND KBN_KBNNAM LIKE '%" & sercd2 & "%'   ")

            Case SER_KBNVIEW                                                                '   �敪���̃e�[�u��

                SqlBuf.AppendLine("        SELECT /*+ INDEX(KBNTABL KBNTABL1) */            ")
                SqlBuf.AppendLine("            KBN_KBNCOD || '|' ||                         ")
                SqlBuf.AppendLine("            KBN_KBNNAM            MT01                   ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            KBNTABL                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            KBN_DELFLG = '0'                             ")

                'If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND KBN_KBNCOD  >=   '" & sercod & "'    ")
                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND KBN_KBNCOD LIKE '%" & sercod & "%'   ")
                If Trim(sercd2) <> "" Then SqlBuf.AppendLine("        AND KBN_KBNNAM LIKE '%" & sercd2 & "%'   ")

            Case SER_BSTVIEW                                                                '   �����Z���^�[�}�X�^

                SqlBuf.AppendLine("        SELECT /*+ INDEX(BSTTABL BSTTABL1) */            ")
                SqlBuf.AppendLine("            BST_SNTCOD || '|' ||                         ")
                SqlBuf.AppendLine("            BST_SNTNAM            MT01                   ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            BSTTABL                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            BST_DELFLG = '0'                             ")

                'If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND BST_SNTCOD  >=   '" & sercod & "'   ")
                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND BST_SNTCOD || ' ' || BST_SNTNAM || ' ' || BST_SNTKNA LIKE '%" & sercod & "%' ")
                If Trim(sercd2) <> "" Then SqlBuf.AppendLine("        AND BST_SNTCOD LIKE '%" & sercd2 & "%'  ")
                If Trim(sercd3) <> "" Then SqlBuf.AppendLine("        AND BST_SNTNAM LIKE '%" & sercd3 & "%'  ")
                If Trim(sercd4) <> "" Then SqlBuf.AppendLine("        AND BST_SNTKNA LIKE '%" & sercd4 & "%'  ")

            Case SER_BSTTABL                                                                '   �����Z���^�[�}�X�^

                SqlBuf.AppendLine("        SELECT /*+ INDEX(BSTTABL BSTTABL1) */            ")
                SqlBuf.AppendLine("            BST_SNTCOD || '|' ||                         ")
                SqlBuf.AppendLine("            BST_SNTNAM || '|' ||                         ")
                SqlBuf.AppendLine("            DECODE(BST_DELFLG, '0', ' ', '1', '*') MT01  ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            BSTTABL                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            BST_DELFLG IN " & DelFlg & "                 ")
                'SqlBuf.AppendLine("            1 = 1                                        ")

                'If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND BST_SNTCOD  >=   '" & sercod & "'   ")
                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND BST_SNTCOD || ' ' || BST_SNTNAM || ' ' || BST_SNTKNA LIKE '%" & sercod & "%' ")
                If Trim(sercd2) <> "" Then SqlBuf.AppendLine("        AND BST_SNTCOD LIKE '%" & sercd2 & "%'  ")
                If Trim(sercd3) <> "" Then SqlBuf.AppendLine("        AND BST_SNTNAM LIKE '%" & sercd3 & "%'  ")
                If Trim(sercd4) <> "" Then SqlBuf.AppendLine("        AND BST_SNTKNA LIKE '%" & sercd4 & "%'  ")

            Case SER_SCGTABL                                                                '   ���i�ϊ��e�[�u��

                SqlBuf.AppendLine("        SELECT /*+ INDEX(SCGTABL SCGTABL1) */            ")
                SqlBuf.AppendLine("            SCG_TKBCOD || '|' ||                         ")
                SqlBuf.AppendLine("            TKB_TKBNAM || '|' ||                         ")
                SqlBuf.AppendLine("            SCG_SSWCOD || '|' ||                         ")
                SqlBuf.AppendLine("            TKJ_SSWNAM || '|' ||                         ")
                SqlBuf.AppendLine("            SCG_TSHCOD || '|' ||                         ")
                SqlBuf.AppendLine("            DECODE(SCG_DELFLG, '0', ' ', '1', '*') MT01  ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            SCGTABL                                      ")
                SqlBuf.AppendLine("                Inner Join                               ")
                SqlBuf.AppendLine("            TKBTABL                                      ")
                SqlBuf.AppendLine("            On ( SCG_TOKCOD = TKB_TOKCOD                 ")
                SqlBuf.AppendLine("            AND  SCG_TKBCOD = TKB_TKBCOD )               ")
                SqlBuf.AppendLine("                Left Outer Join                          ")
                SqlBuf.AppendLine("            TKJTABL                                      ")
                SqlBuf.AppendLine("            On ( SCG_TOKCOD = TKJ_TOKCOD                 ")
                SqlBuf.AppendLine("            And  SCG_SSWCOD = TKJ_SSWCOD )               ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            SCG_DELFLG IN " & DelFlg & "                 ")
                'SqlBuf.AppendLine("            1 = 1                                        ")

                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND SCG_TKBCOD || ' ' || SCG_TSHCOD || ' ' || TKB_TKBNAM LIKE '%" & sercod & "%' ")
                If Trim(sercd2) <> "" Then SqlBuf.AppendLine("        AND SCG_TKBCOD LIKE '%" & sercd2 & "%'   ")
                'If Trim(sercd3) <> "" Then SqlBuf.AppendLine("        AND SCG_SSWCOD LIKE '%" & sercd3 & "%'   ")
                If Trim(sercd3) <> "" Then SqlBuf.AppendLine("        AND SCG_TSHCOD LIKE '%" & sercd3 & "%'   ")

            Case SER_SCGVIEW                                                                '   ���i�ϊ��e�[�u��

                SqlBuf.AppendLine("        SELECT /*+ INDEX(SCGTABL SCGTABL1) */            ")
                SqlBuf.AppendLine("            SCG_TOKCOD || '|' ||                         ")
                SqlBuf.AppendLine("            TOK_TOKRYK || '|' ||                         ")
                SqlBuf.AppendLine("            SCG_TKBCOD || '|' ||                         ")
                SqlBuf.AppendLine("            TKB_TKBNAM || '|' ||                         ")
                SqlBuf.AppendLine("            SCG_SSWCOD || '|' ||                         ")
                SqlBuf.AppendLine("            TKJ_SSWNAM || '|' ||                         ")
                SqlBuf.AppendLine("            SCG_TSHCOD || '|' ||                         ")
                SqlBuf.AppendLine("            SCG_SHOCOD || '|' ||                         ")
                SqlBuf.AppendLine("            SHO_SHONAM || '|' ||                         ")
                SqlBuf.AppendLine("            DECODE(SCG_DELFLG, '0', ' ', '1', '*') MT01  ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            SCGTABL                                      ")
                SqlBuf.AppendLine("                Inner Join                               ")
                SqlBuf.AppendLine("            TOKMAST                                      ")
                SqlBuf.AppendLine("            On ( SCG_TOKCOD = TOK_TOKCOD )               ")
                SqlBuf.AppendLine("                Inner Join                               ")
                SqlBuf.AppendLine("            TKBTABL                                      ")
                SqlBuf.AppendLine("            On ( SCG_TOKCOD = TKB_TOKCOD                 ")
                SqlBuf.AppendLine("            AND  SCG_TKBCOD = TKB_TKBCOD )               ")
                SqlBuf.AppendLine("                Left Outer Join                          ")
                SqlBuf.AppendLine("            TKJTABL                                      ")
                SqlBuf.AppendLine("            On ( SCG_TOKCOD = TKJ_TOKCOD                 ")
                SqlBuf.AppendLine("            AND  SCG_SSWCOD = TKJ_SSWCOD )               ")
                SqlBuf.AppendLine("                Inner Join                               ")
                SqlBuf.AppendLine("            SHOMAST                                      ")
                SqlBuf.AppendLine("            On ( SCG_SHOCOD = SHO_SHOCOD )               ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            SCG_DELFLG IN " & DelFlg & "                 ")
                'SqlBuf.AppendLine("            1 = 1                                        ")

                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND SCG_TSHCOD || ' ' || SCG_SHOCOD || ' ' || SHO_SHOKNA || ' ' || SHO_SHONAM LIKE '%" & sercod & "%'   ")

            Case SER_BRBTABL                                                                '   �啪�ރe�[�u��

                SqlBuf.AppendLine("        SELECT /*+ INDEX(BRBTABL BRBTABL1) */            ")
                SqlBuf.AppendLine("            BRB_BRBCOD || '|' ||                         ")
                SqlBuf.AppendLine("            BRB_BRBNAM || '|' ||                         ")
                SqlBuf.AppendLine("            DECODE(BRB_DELFLG, '0', ' ', '1', '*') MT01  ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            BRBTABL                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            BRB_DELFLG IN " & DelFlg & "                 ")
                'SqlBuf.AppendLine("            1 = 1                                        ")

                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND BRB_BRBCOD LIKE '%" & sercod & "%'   ")

            Case SER_BRBVIEW                                                                '   �啪�ރe�[�u��

                SqlBuf.AppendLine("        SELECT /*+ INDEX(BRBTABL BRBTABL1) */            ")
                SqlBuf.AppendLine("            BRB_BRBCOD || '|' ||                         ")
                SqlBuf.AppendLine("            BRB_BRBNAM            MT01                   ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            BRBTABL                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            BRB_DELFLG = '0'                             ")

                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND BRB_BRBCOD LIKE '%" & sercod & "%'   ")

            Case SER_BRMTABL                                                                '   �����ރe�[�u��

                SqlBuf.AppendLine("        SELECT /*+ INDEX(BRMTABL BRMTABL1) */            ")
                SqlBuf.AppendLine("            BRM_BRBCOD || '|' ||                         ")
                SqlBuf.AppendLine("            BRM_BRMCOD || '|' ||                         ")
                SqlBuf.AppendLine("            BRM_BRMNAM || '|' ||                         ")
                SqlBuf.AppendLine("            DECODE(BRM_DELFLG, '0', ' ', '1', '*') MT01  ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            BRMTABL                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            BRM_DELFLG IN " & DelFlg & "                 ")
                'SqlBuf.AppendLine("            1 = 1                                        ")

                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND BRM_BRMCOD LIKE '%" & sercod & "%'   ")

            Case SER_BRMVIEW                                                                '   �����ރe�[�u��

                SqlBuf.AppendLine("        SELECT /*+ INDEX(BRMTABL BRMTABL1) */            ")
                SqlBuf.AppendLine("            BRM_BRBCOD || '|' ||                         ")
                SqlBuf.AppendLine("            BRM_BRMCOD || '|' ||                         ")
                SqlBuf.AppendLine("            BRM_BRMNAM            MT01                   ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            BRMTABL                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            BRM_DELFLG = '0'                             ")

                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND BRM_BRMCOD LIKE '%" & sercod & "%'   ")

            Case SER_BRSTABL                                                                '   �����ރe�[�u��

                SqlBuf.AppendLine("        SELECT /*+ INDEX(BRSTABL BRSTABL1) */            ")
                SqlBuf.AppendLine("            BRS_BRBCOD || '|' ||                         ")
                SqlBuf.AppendLine("            BRS_BRMCOD || '|' ||                         ")
                SqlBuf.AppendLine("            BRS_BRSCOD || '|' ||                         ")
                SqlBuf.AppendLine("            BRS_BRSNAM || '|' ||                         ")
                SqlBuf.AppendLine("            DECODE(BRS_DELFLG, '0', ' ', '1', '*') MT01  ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            BRSTABL                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            BRS_DELFLG IN " & DelFlg & "                 ")
                'SqlBuf.AppendLine("            1 = 1                                        ")

                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND BRS_BRSCOD LIKE '%" & sercod & "%'   ")

            Case SER_BRSVIEW                                                                '   �����ރe�[�u��

                SqlBuf.AppendLine("        SELECT /*+ INDEX(BRSTABL BRSTABL1) */            ")
                SqlBuf.AppendLine("            BRS_BRBCOD || '|' ||                         ")
                SqlBuf.AppendLine("            BRS_BRMCOD || '|' ||                         ")
                SqlBuf.AppendLine("            BRS_BRSCOD || '|' ||                         ")
                SqlBuf.AppendLine("            BRS_BRSNAM            MT01                   ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            BRSTABL                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            BRS_DELFLG = '0'                             ")

                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND BRS_BRSCOD LIKE '%" & sercod & "%'   ")

            Case SER_BSYVIEW                                                                '   �����e�[�u��

                SqlBuf.AppendLine("        SELECT /*+ INDEX(BSYTABL BSYTABL1) */            ")
                SqlBuf.AppendLine("            BSY_BSYCOD || '|' ||                         ")
                SqlBuf.AppendLine("            BSY_DSPNAM || '|' ||                         ")
                SqlBuf.AppendLine("            BSY_DSPKNA            MT01                   ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            BSYTABL                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            BSY_DELFLG = '0'                             ")
                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND BSY_BSYCOD || ' ' || BSY_DSPKNA LIKE '%" & sercod & "%' ")

            Case SER_BSYTABL                                                                '   �����e�[�u��            �i�폜�f�[�^�܂ށj

                SqlBuf.AppendLine("        SELECT /*+ INDEX(BSYTABL BSYTABL1) */            ")
                SqlBuf.AppendLine("            BSY_BSYCOD || '|' ||                         ")
                SqlBuf.AppendLine("            BSY_DSPNAM || '|' ||                         ")
                SqlBuf.AppendLine("            BSY_DSPKNA || '|' ||                         ")
                SqlBuf.AppendLine("            DECODE(BSY_DELFLG, '0', ' ', '1', '*') MT01  ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            BSYTABL                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            BSY_DELFLG IN " & DelFlg & "                 ")
                'SqlBuf.AppendLine("            1 = 1                                        ")

                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND BSY_BSYCOD || ' ' || BSY_DSPKNA LIKE '%" & sercod & "%' ")

            Case SER_KENTABL                                                                '   �s���{���e�[�u��

                SqlBuf.AppendLine("        SELECT /*+ INDEX(KENTABL KENTABL1) */            ")
                SqlBuf.AppendLine("            KEN_KENCOD || '|' ||                         ")
                SqlBuf.AppendLine("            KEN_KENNAM || '|' ||                         ")
                SqlBuf.AppendLine("            DECODE(KEN_DELFLG, '0', ' ', '1', '*') MT01  ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            KENTABL                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            KEN_DELFLG IN " & DelFlg & "                 ")
                'SqlBuf.AppendLine("            1 = 1                                        ")

                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND KEN_KENCOD || ' ' || KEN_KENNAM LIKE '%" & sercod & "%' ")

            Case SER_KENVIEW                                                                '   �s���{���e�[�u��

                SqlBuf.AppendLine("        SELECT /*+ INDEX(KENTABL KENTABL1) */            ")
                SqlBuf.AppendLine("            KEN_KENCOD || '|' ||                         ")
                SqlBuf.AppendLine("            KEN_KENNAM            MT01                   ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            KENTABL                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            KEN_DELFLG = '0'                             ")

                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND KEN_KENCOD || ' ' || KEN_KENNAM LIKE '%" & sercod & "%' ")

            Case SER_NHSTABL                                                                '   �[�i�����t��e�[�u��

                SqlBuf.AppendLine("        SELECT /*+ INDEX(NHSTABL NHSTABL1) */            ")
                SqlBuf.AppendLine("            NHS_NHSCOD || '|' ||                         ")
                SqlBuf.AppendLine("            NHS_TKSNAM || '|' ||                         ")
                SqlBuf.AppendLine("            DECODE(NHS_DELFLG, '0', ' ', '1', '*') MT01  ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            NHSTABL                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            NHS_DELFLG IN " & DelFlg & "                 ")
                'SqlBuf.AppendLine("            1 = 1                                        ")

                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND NHS_NHSCOD || ' ' || NHS_TKSNAM LIKE '%" & sercod & "%' ")

            Case SER_NHSVIEW                                                                '   �[�i�����t��e�[�u��

                SqlBuf.AppendLine("        SELECT /*+ INDEX(NHSTABL NHSTABL1) */            ")
                SqlBuf.AppendLine("            NHS_NHSCOD || '|' ||                         ")
                SqlBuf.AppendLine("            NHS_TKSNAM || '|' ||                         ")
                SqlBuf.AppendLine("            NHS_ZIPCOD || '|' ||                         ")
                SqlBuf.AppendLine("            NHS_ADRES1 || '|' ||                         ")
                SqlBuf.AppendLine("            NHS_ADRES2 || '|' ||                         ")
                SqlBuf.AppendLine("            NHS_TELNUM || '|' ||                         ")
                SqlBuf.AppendLine("            NHS_FAXNUM            MT01                   ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            NHSTABL                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            NHS_DELFLG = '0'                             ")

                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND NHS_NHSCOD || ' ' || NHS_TKSNAM LIKE '%" & sercod & "%' ")

            Case SER_TNSTABL                                                                '   �q��[�i�w��ꏊ�e�[�u��

                SqlBuf.AppendLine("        SELECT /*+ INDEX(TNSTABL TNSTABL1) */            ")
                SqlBuf.AppendLine("            TNS_TOKCOD || '|' ||                         ")
                SqlBuf.AppendLine("            TOK_TOKNAM || '|' ||                         ")
                SqlBuf.AppendLine("            TNS_TKSCOD || '|' ||                         ")
                SqlBuf.AppendLine("            TKS_TKSNAM || '|' ||                         ")
                SqlBuf.AppendLine("            TNS_TNSCOD || '|' ||                         ")
                SqlBuf.AppendLine("            TNS_TNSNAM || '|' ||                         ")
                SqlBuf.AppendLine("            DECODE(TNS_DELFLG, '0', ' ', '1', '*') MT01  ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            TNSTABL                                      ")
                SqlBuf.AppendLine("                Inner Join                               ")
                SqlBuf.AppendLine("            TOKMAST                                      ")
                SqlBuf.AppendLine("            On ( TNS_TOKCOD = TOK_TOKCOD )               ")
                SqlBuf.AppendLine("                Inner Join                               ")
                SqlBuf.AppendLine("            TKSMAST                                      ")
                SqlBuf.AppendLine("            On ( TNS_TOKCOD = TKS_TOKCOD                 ")
                SqlBuf.AppendLine("            And  TNS_TKSCOD = TKS_TKSCOD )               ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            TNS_DELFLG IN " & DelFlg & "                 ")
                'SqlBuf.AppendLine("            1 = 1                                        ")

                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND TOK_TOKCOD || ' ' || TOK_TOKNAM LIKE '%" & sercod & "%' ")
                If Trim(sercd2) <> "" Then SqlBuf.AppendLine("        AND TKS_TKSCOD || ' ' || TKS_TKSNAM LIKE '%" & sercd2 & "%' ")
                If Trim(sercd3) <> "" Then SqlBuf.AppendLine("        AND TNS_TNSCOD || ' ' || TNS_TNSNAM LIKE '%" & sercd3 & "%' ")

            Case SER_TNSVIEW                                                                '   �q��[�i�w��ꏊ�e�[�u��

                SqlBuf.AppendLine("        SELECT /*+ INDEX(TNSTABL TNSTABL1) */            ")
                SqlBuf.AppendLine("            TNS_TOKCOD || '|' ||                         ")
                SqlBuf.AppendLine("            TOK_TOKNAM || '|' ||                         ")
                SqlBuf.AppendLine("            TNS_TKSCOD || '|' ||                         ")
                SqlBuf.AppendLine("            TKS_TKSNAM || '|' ||                         ")
                SqlBuf.AppendLine("            TNS_TNSCOD || '|' ||                         ")
                SqlBuf.AppendLine("            TNS_TNSNAM            MT01                   ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            TNSTABL                                      ")
                SqlBuf.AppendLine("                Inner Join                               ")
                SqlBuf.AppendLine("            TOKMAST                                      ")
                SqlBuf.AppendLine("            On ( TNS_TOKCOD = TOK_TOKCOD )               ")
                SqlBuf.AppendLine("                Inner Join                               ")
                SqlBuf.AppendLine("            TKSMAST                                      ")
                SqlBuf.AppendLine("            On ( TNS_TOKCOD = TKS_TOKCOD                 ")
                SqlBuf.AppendLine("            AND  TNS_TKSCOD = TKS_TKSCOD )               ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            TNS_DELFLG = '0'                             ")

                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND TOK_TOKCOD || ' ' || TOK_TOKNAM LIKE '%" & sercod & "%' ")
                If Trim(sercd2) <> "" Then SqlBuf.AppendLine("        AND TKS_TKSCOD || ' ' || TKS_TKSNAM LIKE '%" & sercd2 & "%' ")
                If Trim(sercd3) <> "" Then SqlBuf.AppendLine("        AND TNS_TNSCOD || ' ' || TNS_TNSNAM LIKE '%" & sercd3 & "%' ")

            Case SER_TKKTABL                                                                '   �������e�[�u��

                SqlBuf.AppendLine("        SELECT /*+ INDEX(TKKTABL TKKTABL1) */            ")
                SqlBuf.AppendLine("            TKK_KKKNUM || '|' ||                         ")
                SqlBuf.AppendLine("            TKK_KKKNAM || '|' ||                         ")
                SqlBuf.AppendLine("            DECODE(TKK_DELFLG, '0', ' ', '1', '*') MT01  ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            TKKTABL                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            TKK_DELFLG IN " & DelFlg & "                 ")
                'SqlBuf.AppendLine("            1 = 1                                        ")

                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND TKK_KKKNUM || ' ' || TKK_KKKNAM LIKE '%" & sercod & "%' ")

            Case SER_TKKVIEW                                                                '   �������e�[�u��

                SqlBuf.AppendLine("        SELECT /*+ INDEX(TKKTABL TKKTABL1) */            ")
                SqlBuf.AppendLine("            TKK_KKKNUM || '|' ||                         ")
                SqlBuf.AppendLine("            TKK_KKKNAM            MT01                   ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            TKKTABL                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            TKK_DELFLG = '0'                             ")

                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND TKK_KKKNUM || ' ' || TKK_KKKNAM LIKE '%" & sercod & "%' ")

            Case SER_CATTABL                                                                '   �J�e�S���e�[�u��

                SqlBuf.AppendLine("        SELECT /*+ INDEX(CATTABL CATTABL1) */            ")
                SqlBuf.AppendLine("            CAT_CATEGO || '|' ||                         ")
                SqlBuf.AppendLine("            CAT_CATNAM || '|' ||                         ")
                SqlBuf.AppendLine("            DECODE(CAT_DELFLG, '0', ' ', '1', '*') MT01  ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            CATTABL                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            CAT_DELFLG IN " & DelFlg & "                 ")
                'SqlBuf.AppendLine("            1 = 1                                        ")

                'If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND CAT_CATEGO >= '" & sercod & "'   ")
                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND CAT_CATEGO LIKE '%" & sercod & "%'  ")

            Case SER_CATVIEW                                                                '   �J�e�S���e�[�u��

                SqlBuf.AppendLine("        SELECT /*+ INDEX(CATTABL CATTABL1) */            ")
                SqlBuf.AppendLine("            CAT_CATEGO || '|' ||                         ")
                SqlBuf.AppendLine("            CAT_CATNAM || '|' ||                         ")
                SqlBuf.AppendLine("            DECODE(CAT_DELFLG, '0', ' ', '1', '*') MT01  ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            CATTABL                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            CAT_DELFLG = '0'                             ")

                'If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND CAT_CATEGO >= '" & sercod & "'   ")
                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND CAT_CATEGO LIKE '%" & sercod & "%'  ")

            Case SER_KKMTABL                                                                '   ��v�Ȗڃe�[�u��

                SqlBuf.AppendLine("        SELECT /*+ INDEX(KKMTABL KKMTABL1) */            ")
                SqlBuf.AppendLine("            KKM_KKMCOD || '|' ||                         ")
                SqlBuf.AppendLine("            KKM_KKMNAM || '|' ||                         ")
                SqlBuf.AppendLine("            DECODE(KKM_DELFLG, '0', ' ', '1', '*') MT01  ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            KKMTABL                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            KKM_DELFLG IN " & DelFlg & "                 ")
                'SqlBuf.AppendLine("            1 = 1                                        ")

                'If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND KKM_KKMCOD >= '" & sercod & "'   ")
                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND KKM_KKMCOD LIKE '%" & sercod & "%'  ")

            Case SER_KKMVIEW                                                                '   ��v�Ȗڃe�[�u��

                SqlBuf.AppendLine("        SELECT /*+ INDEX(KKMTABL KKMTABL1) */            ")
                SqlBuf.AppendLine("            KKM_KKMCOD || '|' ||                         ")
                SqlBuf.AppendLine("            KKM_KKMNAM            MT01                   ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            KKMTABL                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            KKM_DELFLG = '0'                             ")

                'If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND KKM_KKMCOD >= '" & sercod & "'   ")
                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND KKM_KKMCOD LIKE '%" & sercod & "%'  ")

            Case SER_SCTTABL                                                                '   ���i�ϊ��e�[�u��

                'SqlBuf.AppendLine("        SELECT /*+ INDEX(SCGTABL SCGTABL1) */            ")
                'SqlBuf.AppendLine("            SCG_TKBCOD || '|' ||                         ")
                'SqlBuf.AppendLine("            TKB_TKBNAM || '|' ||                         ")
                'SqlBuf.AppendLine("            SCG_SSWCOD || '|' ||                         ")
                'SqlBuf.AppendLine("            TKJ_SSWNAM || '|' ||                         ")
                'SqlBuf.AppendLine("            SCG_TSHCOD || '|' ||                         ")
                'SqlBuf.AppendLine("            DECODE(SCG_DELFLG, '0', ' ', '1', '*') MT01  ")
                'SqlBuf.AppendLine("        FROM                                             ")
                'SqlBuf.AppendLine("            SCGTABL                                      ")
                'SqlBuf.AppendLine("                Inner Join                               ")
                'SqlBuf.AppendLine("            TKBTABL                                      ")
                'SqlBuf.AppendLine("            On ( SCG_TOKCOD = TKB_TOKCOD                 ")
                'SqlBuf.AppendLine("            AND  SCG_TKBCOD = TKB_TKBCOD )               ")
                'SqlBuf.AppendLine("                Left Outer Join                          ")
                'SqlBuf.AppendLine("            TKJTABL                                      ")
                'SqlBuf.AppendLine("            On ( SCG_TOKCOD = TKJ_TOKCOD                 ")
                'SqlBuf.AppendLine("            And  SCG_SSWCOD = TKJ_SSWCOD )               ")
                'SqlBuf.AppendLine("        WHERE                                            ")
                'SqlBuf.AppendLine("            1 = 1                                        ")

                SqlBuf.AppendLine("        SELECT /*+ INDEX(SCGTABL SCGTABL1) */            ")
                SqlBuf.AppendLine("            TSH_TOKCOD || '|' ||                         ")
                SqlBuf.AppendLine("            TOK_TOKRYK || '|' ||                         ")
                SqlBuf.AppendLine("            TKB_TKBCOD || '|' ||                         ")
                SqlBuf.AppendLine("            TKB_TKBNAM || '|' ||                         ")
                SqlBuf.AppendLine("            TKJ_SSWCOD || '|' ||                         ")
                SqlBuf.AppendLine("            TKJ_SSWNAM || '|' ||                         ")
                SqlBuf.AppendLine("            NVL(SCG_TSHCOD,LPAD(SHO_SHOCOD, 16, '0')) || '|' ||  ")
                SqlBuf.AppendLine("            SHO_SHOCOD || '|' ||                         ")
                SqlBuf.AppendLine("            SHO_SHONAM || '|' ||                         ")
                SqlBuf.AppendLine("            DECODE(TSH_DELFLG, '0', ' ', '1', '*') MT01  ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            (   SELECT /*+ INDEX(TSHMAST TSHMAST1) */    ")
                SqlBuf.AppendLine("                    TSH_TOKCOD ,                         ")
                SqlBuf.AppendLine("                    TSH_SHOCOD ,                         ")
                SqlBuf.AppendLine("                    TSH_TSHNAM ,                         ")
                SqlBuf.AppendLine("                    TSH_DELFLG                           ")
                SqlBuf.AppendLine("                FROM                                     ")
                SqlBuf.AppendLine("                    TSHMAST                              ")
                SqlBuf.AppendLine("            )                                            ")
                SqlBuf.AppendLine("            Inner Join                                   ")
                SqlBuf.AppendLine("            TOKMAST                                      ")
                SqlBuf.AppendLine("            On ( TSH_TOKCOD = TOK_TOKCOD)                ")
                SqlBuf.AppendLine("            Inner Join                                   ")
                SqlBuf.AppendLine("            (   SELECT /*+ INDEX(SHOMAST SHOMAST1) */    ")
                SqlBuf.AppendLine("                    SHO_SHOCOD ,                         ")
                SqlBuf.AppendLine("                    SHO_SHONAM ,                         ")
                SqlBuf.AppendLine("                    SHO_SHOKNA                           ")
                SqlBuf.AppendLine("                FROM                                     ")
                SqlBuf.AppendLine("                    SHOMAST                              ")
                SqlBuf.AppendLine("                WHERE                                    ")
                SqlBuf.AppendLine("                    SHO_DELFLG = '0'                     ")
                SqlBuf.AppendLine("            )                                            ")
                SqlBuf.AppendLine("            On ( TSH_SHOCOD = SHO_SHOCOD )               ")
                SqlBuf.AppendLine("                Inner Join                               ")
                SqlBuf.AppendLine("            (   SELECT /*+ INDEX(ZTABL SCGTABL1) */      ")
                SqlBuf.AppendLine("                    SCG_TOKCOD ,                         ")
                SqlBuf.AppendLine("                    SCG_TKBCOD ,                         ")
                SqlBuf.AppendLine("                    SCG_SSWCOD ,                         ")
                SqlBuf.AppendLine("                    SCG_TSHCOD ,                         ")
                SqlBuf.AppendLine("                    SCG_SHOCOD                           ")
                SqlBuf.AppendLine("                FROM                                     ")
                SqlBuf.AppendLine("                    SCGTABL                              ")
                SqlBuf.AppendLine("                WHERE                                    ")
                SqlBuf.AppendLine("                    SCG_DELFLG = '0'                     ")
                SqlBuf.AppendLine("                GROUP BY                                 ")
                SqlBuf.AppendLine("                    SCG_TOKCOD ,                         ")
                SqlBuf.AppendLine("                    SCG_TKBCOD ,                         ")
                SqlBuf.AppendLine("                    SCG_SSWCOD ,                         ")
                SqlBuf.AppendLine("                    SCG_TSHCOD ,                         ")
                SqlBuf.AppendLine("                    SCG_SHOCOD                           ")
                SqlBuf.AppendLine("            )                                            ")
                SqlBuf.AppendLine("            On ( TSH_TOKCOD = SCG_TOKCOD                 ")
                SqlBuf.AppendLine("            And  TSH_SHOCOD = SCG_SHOCOD )               ")
                SqlBuf.AppendLine("                Inner Join                               ")
                SqlBuf.AppendLine("            TKBTABL                                      ")
                SqlBuf.AppendLine("            On ( TSH_TOKCOD = TKB_TOKCOD                 ")
                SqlBuf.AppendLine("            And  SCG_TKBCOD = TKB_TKBCOD )               ")
                SqlBuf.AppendLine("                Left Outer Join                          ")
                SqlBuf.AppendLine("            TKJTABL                                      ")
                SqlBuf.AppendLine("            On ( TSH_TOKCOD = TKJ_TOKCOD                 ")
                SqlBuf.AppendLine("            And  SCG_SSWCOD = TKJ_SSWCOD )               ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            TSH_DELFLG IN " & DelFlg & "                 ")
                'SqlBuf.AppendLine("            1 = 1                                        ")
                SqlBuf.AppendLine("                                                         ")

                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND SCG_TKBCOD || ' ' || SCG_TSHCOD || ' ' || SHO_SHOCOD || ' ' || TOK_TOKRYK || ' ' || SHO_SHONAM || ' ' || SHO_SHOKNA || ' ' || TKB_TKBNAM LIKE '%" & sercod & "%'   ")
                If Trim(sercd2) <> "" Then SqlBuf.AppendLine("        AND SCG_TKBCOD LIKE '%" & sercd2 & "%'   ")
                'If Trim(sercd2) <> "" Then SqlBuf.AppendLine("        AND SCG_SSWCOD LIKE '%" & sercd2 & "%'   ")
                If Trim(sercd3) <> "" Then SqlBuf.AppendLine("        AND SCG_TSHCOD LIKE '%" & sercd3 & "%'   ")
                If Trim(sercd4) <> "" Then SqlBuf.AppendLine("        AND SHO_SHOCOD LIKE '%" & sercd4 & "%'   ")

            Case SER_SCTVIEW                                                                '   ���i�ϊ��e�[�u��

                SqlBuf.AppendLine("        SELECT /*+ INDEX(SCGTABL SCGTABL1) */            ")
                SqlBuf.AppendLine("            TSH_TOKCOD || '|' ||                         ")
                SqlBuf.AppendLine("            TOK_TOKRYK || '|' ||                         ")
                SqlBuf.AppendLine("            TKB_TKBCOD || '|' ||                         ")
                SqlBuf.AppendLine("            TKB_TKBNAM || '|' ||                         ")
                SqlBuf.AppendLine("            TKJ_SSWCOD || '|' ||                         ")
                SqlBuf.AppendLine("            TKJ_SSWNAM || '|' ||                         ")
                SqlBuf.AppendLine("            NVL(SCG_TSHCOD,LPAD(SHO_SHOCOD, 16, '0')) || '|' ||  ")
                SqlBuf.AppendLine("            SHO_SHOCOD || '|' ||                         ")
                SqlBuf.AppendLine("            SHO_SHONAM  MT01                             ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            (   SELECT /*+ INDEX(TSHMAST TSHMAST1) */    ")
                SqlBuf.AppendLine("                    TSH_TOKCOD ,                         ")
                SqlBuf.AppendLine("                    TSH_SHOCOD ,                         ")
                SqlBuf.AppendLine("                    TSH_TSHNAM                           ")
                SqlBuf.AppendLine("                FROM                                     ")
                SqlBuf.AppendLine("                    TSHMAST                              ")
                SqlBuf.AppendLine("                WHERE   TSH_DELFLG = '0'                 ")
                SqlBuf.AppendLine("                AND                                      ")
                SqlBuf.AppendLine("                    TSH_TOKCOD = '" & SerPrm1 & "'       ")
                SqlBuf.AppendLine("            )                                            ")
                SqlBuf.AppendLine("            Inner Join                                   ")
                SqlBuf.AppendLine("            TOKMAST                                      ")
                SqlBuf.AppendLine("            On ( TSH_TOKCOD = TOK_TOKCOD)                ")
                SqlBuf.AppendLine("                Inner Join                               ")
                SqlBuf.AppendLine("            TKBTABL                                      ")
                SqlBuf.AppendLine("            On ( TSH_TOKCOD = TKB_TOKCOD                 ")
                SqlBuf.AppendLine("            AND  TKB_TKBCOD = '" & SerPrm2 & "')         ")
                SqlBuf.AppendLine("                Inner Join                          ")
                SqlBuf.AppendLine("            TKJTABL                                      ")
                SqlBuf.AppendLine("            On ( TSH_TOKCOD = TKJ_TOKCOD                 ")
                SqlBuf.AppendLine("            AND  TKJ_SSWCOD = '" & SerPrm3 & "')         ")
                SqlBuf.AppendLine("            Inner Join                                   ")
                SqlBuf.AppendLine("            (   SELECT /*+ INDEX(SHOMAST SHOMAST1) */    ")
                SqlBuf.AppendLine("                    SHO_SHOCOD ,                         ")
                SqlBuf.AppendLine("                    SHO_SHONAM ,                         ")
                SqlBuf.AppendLine("                    SHO_SHOKNA                           ")
                SqlBuf.AppendLine("                FROM                                     ")
                SqlBuf.AppendLine("                    SHOMAST                              ")
                SqlBuf.AppendLine("                WHERE                                    ")
                SqlBuf.AppendLine("                    SHO_DELFLG = '0'                     ")
                SqlBuf.AppendLine("            )                                            ")
                SqlBuf.AppendLine("            On ( TSH_SHOCOD = SHO_SHOCOD )               ")
                SqlBuf.AppendLine("                Left Join                                ")
                SqlBuf.AppendLine("            (   SELECT /*+ INDEX(ZTABL SCGTABL1) */      ")
                SqlBuf.AppendLine("                    SCG_TOKCOD ,                         ")
                SqlBuf.AppendLine("                    SCG_TSHCOD ,                         ")
                SqlBuf.AppendLine("                    SCG_SHOCOD                           ")
                SqlBuf.AppendLine("                FROM                                     ")
                SqlBuf.AppendLine("                    SCGTABL                              ")
                SqlBuf.AppendLine("                WHERE                                    ")
                SqlBuf.AppendLine("                    SCG_DELFLG = '0'                     ")
                SqlBuf.AppendLine("                AND                                      ")
                SqlBuf.AppendLine("                    SCG_TOKCOD = '" & SerPrm1 & "'       ")
                SqlBuf.AppendLine("                AND                                      ")
                SqlBuf.AppendLine("                    SCG_TKBCOD = '" & SerPrm2 & "'       ")
                SqlBuf.AppendLine("                AND                                      ")
                'SqlBuf.AppendLine("                    SCG_SSWCOD = '" & SerPrm3 & "'       ")
                SqlBuf.AppendLine("                    SCG_SSWCOD = '00'                    ")
                SqlBuf.AppendLine("                GROUP BY                                 ")
                SqlBuf.AppendLine("                    SCG_TOKCOD ,                         ")
                SqlBuf.AppendLine("                    SCG_TSHCOD ,                         ")
                SqlBuf.AppendLine("                    SCG_SHOCOD                           ")
                SqlBuf.AppendLine("            )                                            ")
                SqlBuf.AppendLine("            On ( TSH_TOKCOD = SCG_TOKCOD                 ")
                SqlBuf.AppendLine("            And  TSH_SHOCOD = SCG_SHOCOD )               ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            1 = 1                                        ")
                SqlBuf.AppendLine("                                                         ")

                '### 2021/06/07 S.SUGIURA UPD START �����w��~�X
                'If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND TSH_TOKCOD || ' ' || SHO_SHOCOD || ' ' || SHO_SHOKNA || ' ' || SHO_SHONAM LIKE '%" & sercod & "%'   ")
                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND SCG_TSHCOD || ' ' || SHO_SHOCOD || ' ' || SHO_SHOKNA || ' ' || SHO_SHONAM LIKE '%" & sercod & "%'   ")
                '### 2021/06/07 S.SUGIURA UPD END

            Case SER_THSTABL                                                                '   �����x�X�e�[�u��

                SqlBuf.AppendLine("        SELECT /*+ INDEX(THSTABL TSHTABL1) */            ")
                SqlBuf.AppendLine("            THS_TRICOD || '|' ||                         ")
                SqlBuf.AppendLine("            THS_STNCOD || '|' ||                         ")
                SqlBuf.AppendLine("            THS_THSNAM  MT01                             ")
                SqlBuf.AppendLine("        FROM                                             ")
                SqlBuf.AppendLine("            THSTABL                                      ")
                SqlBuf.AppendLine("        WHERE                                            ")
                SqlBuf.AppendLine("            1 = 1                                        ")
                SqlBuf.AppendLine("                                                         ")

                If Trim(sercod) <> "" Then SqlBuf.AppendLine("        AND THS_TRICOD LIKE '%" & sercod & "%'   ")
                If Trim(sercd2) <> "" Then SqlBuf.AppendLine("        AND THS_STNCOD LIKE '%" & sercd2 & "%'   ")
                If Trim(sercd3) <> "" Then SqlBuf.AppendLine("        AND THS_THSNAM LIKE '%" & sercd3 & "%'   ")

            Case Else
        End Select

        '   ���������P�Z�b�g
        If Trim$(SerKey1) <> "" Then SqlBuf.AppendLine("        AND     " & SerKey1)
        '   ���������Q�Z�b�g
        If Trim$(SerKey2) <> "" Then SqlBuf.AppendLine("        AND     " & SerKey2)
        '   ���������R�Z�b�g
        If Trim$(SerKey3) <> "" Then SqlBuf.AppendLine("        AND     " & SerKey3)

        If Trim$(SerKeyf) <> "" Then SqlBuf.AppendLine("        AND     " & SerKeyf) '   �Œ茟�������ݒ�

        SqlBuf.AppendLine("    )                ")                                          '   ���ԃe�[�u��  ����
        SqlBuf.AppendLine("    Order By MT01    ")                                          '   ���ёւ�����  �ݒ�

        SerKey1 = String.Empty
        SerKey2 = String.Empty
        SerKey3 = String.Empty
    End Sub

    ''' <summary>
    ''' �������ʕ\������
    ''' </summary>
    ''' <param name="TblId">�����e�[�u���h�c</param>
    ''' <param name="RedMod">�Ǎ����[�h</param>
    ''' <remarks>����SQL�̎��s�ƕ\�����s��</remarks>
    Private Sub Gen_TblSelect(ByVal TblId As Integer, ByVal RedMod As Integer)
        Dim ret As Long                                                                     '   ���^�[���R�[�h

        Dim oradyn As System.Data.Common.DbDataReader = Nothing
        Dim orafld As Object = Nothing                                                      '   �I���N���I�u�W�F�N�g�i�t�B�[���h�j

        Dim prgfrm As New PrgForm.Form1                                                     '   �i���\�����
        'Dim drwcnt As Integer = Integer.Parse(Com_IniGet("SEARCH", "DRAW_CNT"))             '   �`�挏��
        'Dim reccnt As Integer
        'Dim ini_reccnt As Integer = Integer.Parse(Com_IniGet("SEARCH", "WARNING_CNT"))      '   �`��x������

        msfMstGrid1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None
        msfMstGrid1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None
        msfMstGrid1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing

        Dim IntervalTime As Integer = 0

        Try
            msfMstGrid1.Enabled = False

            '�����pSQL�쐬
            Call Gen_CreateSqlSelect(TblId)

            '�v���O���X�o�[�̍X�V�^�C�~���O��ݒ�i�~���b�j
            If IntervalTime = 0 Then
                IntervalTime = Display_Interval_default
            Else
                IntervalTime = Display_Interval
            End If

            '�v���O���X�o�[�i���\���ݒ�
            prgfrm.title = Me.Text                                                          '   �i���\����ʃv���p�e�B(�v���O������)
            prgfrm.outflg = PrgForm.OUT_GRID                                                '   �i���\����ʃv���p�e�B(�o�͋敪)
            'prgfrm.maxcnt = I_RecCnt                                                       '   �i���\����ʃv���p�e�B(�ő匏��)
            prgfrm.nowcnt = 0                                                               '   �i���\����ʃv���p�e�B(���݌���)
            prgfrm.maxcnt = 0                                                               '   �i���\����ʃv���p�e�B(�擾����)

            SELECTDAT = New DataTable
            msfMstGrid1.RowCount = 0
            RecCnt = 0

            '�^�X�N�o�[�ɕ\�����Ȃ�
            prgfrm.ShowInTaskbar = False
            '�w��ɉB��Ȃ��悤���[�h���X�t�H�[���ŕ\������
            prgfrm.Show(Me)

            ret = SUCCESS

            ' �p�����[�^����
            ' --------------------------------------------------
            Call Ora_ParmRemAll()

            ret = Ora_DbOneReadSqlEx(oradyn, SqlBuf.ToString)                               '   �}�X�^�擾�r�p�k���s�J�n

            Select Case ret                                                                 '   �r�p�k���s�`�F�b�N
                Case ORA_FOUNDREC                                                           '   �r�p�k���픭�s�̏ꍇ
                    Application.DoEvents()                                                  '   �E�C���h�E�Y�ɐ����n��

                    SELECTDAT.Load(oradyn)

                    oradyn.Close()

                    With msfMstGrid1
                        If RecCnt = 0 Then
                            '  �O���b�h�Z�b�g
                            prgfrm.maxcnt = CInt(Val(SELECTDAT.Rows(0)("RECCNT")))              '   �t�B�[���h�I�u�W�F�N�g�Z�b�g

                            Me.Show()

                            prgfrm.Show()

                            .RowCount = CInt(Val(SELECTDAT.Rows(0)("RECCNT")))                  '   �t�B�[���h�I�u�W�F�N�g�Z�b�g

                            Application.DoEvents()
                        End If

                        For Each recdat As DataRow In SELECTDAT.Rows

                            orafld = recdat("MT01")                                             '   �t�B�[���h�I�u�W�F�N�g�Z�b�g

                            Dim datarr() As String                                              '   �f�[�^

                            datarr = Split(DirectCast(orafld, String), "|")

                            'msfMstGrid1.Rows.Add()

                            RecCnt = RecCnt + 1                                                 '   �擾�����J�E���g�A�b�v

                            '   �擾�f�[�^�Z�b�g
                            For i As Integer = 0 To ItemCnt - 1
                                msfMstGrid1(i, RecCnt - 1).Value = datarr(i)
                                '.Rows(RecCnt - 1).Cells(i).Value = datarr(i)
                            Next

                            '�v���O���X�o�[�X�V

                            If Val(Format(Now, "fff")) Mod IntervalTime = 0 Then                '   �`�挏���ɒB������
                                prgfrm.nowcnt = RecCnt                                          '   �i���\����ʃv���p�e�B(���݌���)

                                If prgfrm.cancel Then                                           '   �L�����Z���{�^���������ꂽ�ꍇ
                                    .CurrentCell = msfMstGrid1.Item(0, 0)
                                    .RowCount = RecCnt                                          '   �]���ȍs���폜

                                    Exit For                                                    '   ���[�v�𔲂���
                                End If
                            ElseIf .RowCount = RecCnt Then
                                '�ŏI�s��\����
                                prgfrm.nowcnt = RecCnt                                          '   �i���\����ʃv���p�e�B(���݌���)

                                System.Threading.Thread.Sleep(3)
                            End If
                        Next
                    End With

                    'oradyn.Close()

                    'Do While oradyn.Read = True                                             '   �f�[�^���d�n�e�܂ŌJ�Ԃ�
                    '    orafld = oradyn("MT01")                                             '   �t�B�[���h�I�u�W�F�N�g�Z�b�g

                    '    If RecCnt = 0 Then
                    '        '  �O���b�h�Z�b�g
                    '        prgfrm.maxcnt = CInt(Val(oradyn("RECCNT")))                     '   �t�B�[���h�I�u�W�F�N�g�Z�b�g
                    '        msfMstGrid1.RowCount = CInt(Val(oradyn("RECCNT")))              '   �t�B�[���h�I�u�W�F�N�g�Z�b�g

                    '        Me.Show()
                    '        prgfrm.Show()

                    '        Application.DoEvents()
                    '    End If

                    '    Dim datarr() As String                                              '   �f�[�^

                    '    datarr = Split(DirectCast(orafld, String), TYP_CUM)

                    '    'msfMstGrid1.Rows.Add()

                    '    RecCnt = RecCnt + 1                                                 '   �擾�����J�E���g�A�b�v

                    '    '   �擾�f�[�^�Z�b�g
                    '    For i As Integer = 0 To ItemCnt - 1
                    '        msfMstGrid1.Rows(RecCnt - 1).Cells(i).Value = datarr(i)
                    '    Next

                    '    '�v���O���X�o�[�X�V
                    '    If Val(Format(Now, "fff")) Mod IntervalTime = 0 Then                '   �`�挏���ɒB������
                    '        prgfrm.nowcnt = RecCnt                                          '   �i���\����ʃv���p�e�B(���݌���)

                    '        If prgfrm.cancel Then                                           '   �L�����Z���{�^���������ꂽ�ꍇ
                    '            msfMstGrid1.RowCount = RecCnt                               '   �]���ȍs���폜
                    '            Exit Do                                                     '   ���[�v�𔲂���
                    '        End If
                    '    ElseIf msfMstGrid1.RowCount = RecCnt Then
                    '        '�ŏI�s��\����
                    '        prgfrm.nowcnt = RecCnt                                          '   �i���\����ʃv���p�e�B(���݌���)

                    '        System.Threading.Thread.Sleep(200)
                    '    End If
                    'Loop

                    'oradyn.Close()                                                          '   �J�[�\���N���[�Y

                Case ORA_NOTFOUND                                                           '   �擾�f�[�^�Ȃ��̏ꍇ
                    oradyn.Close()                                                          '   �J�[�\���N���[�Y

                    Select Case RedMod
                        Case RED_EQU
                            With msfMstGrid1
                                .RowCount = 0
                            End With
                        Case RED_PRE
                        Case RED_NXT
                        Case Else
                    End Select

                    cmdCommand1(CMD_PRE).Enabled = False                                    '   �O�Ń{�^���g�p�֎~����
                    cmdCommand1(CMD_NXT).Enabled = False                                    '   ���Ń{�^���g�p�֎~����

                    Application.DoEvents()                                                  '   �E�C���h�E�Y�ɐ����n��

                    Me.Show()

                    MsgBox(MSG_E113, vbCritical, Me.Text)

                Case Else                                                                   '   ���̑��ُ̈�
                    MsgBox(MSG_E115 & " ErrNo=" & Str(ret), vbCritical)

                    Gen_CmdEnd()

            End Select

            Application.DoEvents()                                                          '   �E�C���h�E�Y�ɐ����n��

        Catch ex As Exception
            MsgBox(ex.ToString)
            MsgBox(ex.StackTrace.ToString)
            Gen_CmdEnd()
        Finally
            If SysDebug = "DEBUG" Then
                My.Computer.FileSystem.WriteAllText(System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) & ERR_LOG_FILE,
                                                    Replace(LOG_COMMENT, "[PRCTIM]", Now.ToString("yyyy/MM/dd HH:mm:ss")) & vbCrLf &
                                                    SqlBuf.ToString, True)
            End If

            ' �p�����[�^����
            ' --------------------------------------------------
            Call Ora_ParmRemAll()

            orafld = Nothing                                                                '   ���ڃt�B�[���h�N���A

            If Not oradyn Is Nothing Then                                                   '   �I�u�W�F�N�g�g�p��
                oradyn.Dispose()
                oradyn = Nothing
            End If

            If Not prgfrm Is Nothing Then                                                   '   �I�u�W�F�N�g�g�p��
                prgfrm.Dispose()
                prgfrm = Nothing
            End If

            If Not SELECTDAT Is Nothing Then
                SELECTDAT.Dispose()
                SELECTDAT = Nothing
            End If

            msfMstGrid1.Enabled = True

            If msfMstGrid1.RowCount > 0 Then
                msfMstGrid1.Focus()                                                         '   �t�H�[�J�X���ړ�����

                If msfMstGrid1.RowCount > RowCntPerPage Then
                    cmdCommand1(CMD_NXT).Enabled = True
                End If
            Else
                txtText1(TXTTSHS_KEYCD1).Focus()
            End If
        End Try

    End Sub

    ''' <summary>
    ''' �R�}���h�{�^������
    ''' </summary>
    ''' <param name="Index">�R�}���h�{�^���C���f�b�N�X</param>
    ''' <remarks></remarks>
    Private Sub cmdCommand1_Click(ByVal Index As Integer)
        If SysMode = SYS_ON Then                                                            '   �V�X�e�����[�h��  �n�m�̎�
            Exit Sub                                                                        '   �ȉ��̏������s��Ȃ�
        Else                                                                                '   �V�X�e�����[�h���n�e�e�̎�
            SysMode = SYS_ON                                                                '   �V�X�e�����[�h���n�m
        End If

        Select Case Index                                                                   '   �R�}���h�{�^���̃`�F�b�N
            Case CMD_ANS                                                                    '   �o�^�E�폜�{�^��
                Call Gen_CmdAns()
            Case CMD_PRE                                                                    '   �O�Ń{�^��
                Call Gen_CmdPre()
            Case CMD_NXT                                                                    '   ���Ń{�^��
                Call Gen_CmdNxt()
            Case CMD_SER
                Call Gen_CmdSer()
            Case CMD_END                                                                    '   �I���{�^��
                Call Gen_CmdEnd()
            Case Else                                                                       '   ���̑��{�^��
        End Select

        SysMode = SYS_OFF                                                                   '   �V�X�e�����[�h���n�e�e
    End Sub

    ''' <summary>
    ''' serform_KeyDown����
    ''' </summary>
    ''' <param name="sender">�������e</param>
    ''' <param name="e">�C�x���g���</param>
    ''' <remarks>serform_KeyDown�������s��</remarks>
    Private Sub serform_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If SysMode = SYS_ON Then                                                            '   �V�X�e�����[�h��  �n�m�̎�
            Exit Sub                                                                        '   �ȉ��̏������s��Ȃ�
        Else                                                                                '   �V�X�e�����[�h���n�e�e�̎�
            SysMode = SYS_ON                                                                '   �V�X�e�����[�h���n�m
        End If

        Select Case e.KeyCode                                                               '   �L�[�R�[�h�`�F�b�N
            Case FUNC_WRK
                e.Handled = True                                                            '   �L�[�R�[�h�N���A
            Case FUNC_ANS                                                                   '   �m�F�L�[
                e.Handled = True                                                            '   �L�[�R�[�h�N���A

                cmdCommand1(CMD_ANS).Focus()

                Call Gen_CmdAns()
            Case FUNC_SER
                e.Handled = True                                                            '   �L�[�R�[�h�N���A
                If cmdCommand1(CMD_SER).Enabled = True Then
                    Call Gen_CmdSer()
                End If
            Case FUNC_PRE                                                                   '   �O�ŃL�[
                e.Handled = True                                                            '   �L�[�R�[�h�N���A

                If cmdCommand1(CMD_PRE).Enabled Then
                    cmdCommand1(CMD_PRE).Focus()

                    Call Gen_CmdPre()
                End If
            Case FUNC_NXT                                                                   '   ���ŃL�[
                e.Handled = True                                                            '   �L�[�R�[�h�N���A

                If cmdCommand1(CMD_NXT).Enabled Then
                    cmdCommand1(CMD_NXT).Focus()

                    Call Gen_CmdNxt()
                End If
            Case Keys.Return                                                                '   ���s�L�[
            Case FUNC_END                                                                   '   �I���L�[
                e.Handled = True                                                            '   �L�[�R�[�h�N���A

                cmdCommand1(CMD_END).Focus()

                Call Gen_CmdEnd()
            Case FUNC_ESC                                                                   '   �d�r�b�L�[
                txtText1(TXTTSHS_KEYCD1).Focus()                                                         '   �e�L�X�g�{�b�N�X�փt�H�[�J�X�Z�b�g
            Case Keys.Left                                                                  '   ���L�[
            Case Keys.Right                                                                 '   ���L�[
            Case Keys.Return                                                    '   �^�u�L�[
            Case Keys.Tab                                                       '   �^�u�L�[
            Case Keys.Insert                                                    '   �}���L�[������
                If InsMode = True Then                                          '   �}�����[�h��
                    InsMode = False                                             '   �㏑�����[�h�ɂ���
                Else                                                            '   �㏑�����[�h��
                    InsMode = True                                              '   �}�����[�h�ɂ���
                End If
            Case Else
        End Select

        SysMode = SYS_OFF                                                                   '   �V�X�e�����[�h���n�e�e
    End Sub

    ''' <summary>
    ''' �t�H�[������
    ''' </summary>
    ''' <param name="sender">�������e</param>
    ''' <param name="e">�C�x���g���</param>
    ''' <remarks>�{�^���������̏������s��</remarks>
    Private Sub serform_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        If InpLoc = LOC_ON Then                                                             '   ���͗}���ݒ�n�m��
            e.Handled = True                                                                '   �L�[���͂��N���A����
        End If

        If Asc(e.KeyChar) = Keys.Return Then                                                '   ENTER KEY�̏ꍇ
            e.Handled = True                                                                '   �L�[���͂��N���A����
        End If
    End Sub

    ''' <summary>
    ''' �N����Load����
    ''' </summary>
    ''' <param name="sender">�������e</param>
    ''' <param name="e">�C�x���g���</param>
    ''' <remarks>�N�����̃��[�h�������s��</remarks>
    Private Sub serform_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim strAppPth As String                                                             '   �A�v���P�[�V�����p�X
        Dim strAppNam As String                                                             '   �A�v���P�[�V������
        Dim intExtStr As Integer                                                            '   �g���q�J�n�ԍ�
        Dim dtp1 As New DateTimePanel                                                       '   �p�l���P
        Dim dtp2 As New DateTimePanel                                                       '   �p�l���Q

        SerData = ""                                                                        '   �������ʃN���A
        SerList.Clear()                                                                     '   �������ʃN���A

        LstIndex = 1                                                                        '   ���ڈʒu�Z�b�g
        TxtMode = True

        strAppPth = System.Reflection.Assembly.GetExecutingAssembly.Location                '   EXE�̃t���p�X���擾
        strAppNam = System.IO.Path.GetFileName(strAppPth)                                   '   �t�@�C�����擾

        intExtStr = InStrRev(strAppNam, ".", -1, CompareMethod.Binary)                      '   �g���q�܂ł̕������擾
        strAppNam = Mid$(strAppNam, 1, intExtStr - 1)                                       '   �t�@�C��������g���q���͂���

        'EnableDoubleBuffering(msfMstGrid1)                                                  '   �_�u���o�b�t�@�����O�L��

        With staStatus.Panels                                                               '   �p�l�����Z�b�g
            .Item(0).Text = PRG_CPY                                                         '   Copyrigth�\��

            .Item(1).Text = "ID:" & strAppNam                                               '   �v���O�����h�c

            dtp1.Format = ("d")
            dtp1.Alignment = HorizontalAlignment.Center
            dtp1.Width = 100
            .Add(dtp1)

            dtp2.Format = ("HH:mm:ss")
            dtp2.Alignment = HorizontalAlignment.Center
            .Add(dtp2)
        End With

        Gen_ArrayListSet()

        With Me
            .Height = FRMSIZ_HIGHT                                                          '   �T�C�Y�Z�b�g
            .Width = FRMSIZ_WIDTH                                                           '   �T�C�Y�Z�b�g
        End With

        Call Form_FrmCls()
        Call Gen_GridSet()

        For i As Integer = 0 To SertxtCNT - 1
            If Trim(SerKeys(i)) <> "" Then
                txtText1(i).Text = Trim(SerKeys(i))
            End If
        Next

        Me.Show()

        txtText1(TXTTSHS_KEYCD1).Focus()

        If blnViewFirst = True Then
            Call Gen_TblSelect(SerMast, RED_EQU)                                '   �f�[�^����
        End If

        Application.DoEvents()                                                              '   �E�C���h�E�Y�ɐ����n��
    End Sub

    ''' <summary>
    ''' ��ʏ�����
    ''' </summary>
    ''' <remarks>��ʂ̏��������s��</remarks>
    Private Sub Form_FrmCls()
        Dim strSerkey As List(Of String) = New List(Of String)()                            '   �����L�[���x���\������
        Dim lblWidth As List(Of Integer) = New List(Of Integer)()                           '   �����L�[���x����
        Dim txtWidth As List(Of Integer) = New List(Of Integer)()                           '   �����L�[�e�L�X�g�{�b�N�X��



        '�e�L�X�g�{�b�N�X������
        For i As Integer = 0 To txtText1.Length - 1
            With txtText1(i)
                .Text = ""
                .Visible = False
                .Enabled = False
                .Search = False
                .ImeMode = Windows.Forms.ImeMode.Disable
            End With
        Next

        '���x��������
        For i As Integer = 0 To lblValue1.Length - 1                                       '   �w�b�_�[���e�L�X�g�{�b�N�X������
            If Not lblValue1(i) Is Nothing Then
                With lblValue1(i)
                    .Text = ""
                    .Visible = False
                    .Enabled = False
                    .TextAlign = ContentAlignment.MiddleCenter
                End With
            End If
        Next

        '���W�I�{�^��������
        PNLSelect.Visible = False
        RBSelect_1.Select()

        '�^�C�g���ݒ�
        Select Case SerMast
            Case SER_SHOMAST, SER_SHOVIEW                                                   '   ���i�}�X�^
                Me.Text = TTL_SHOVIEW
            Case SER_SHOVIEW_ME                                                             '   ���i�}�X�^
                Me.Text = TTL_SHOVIEW
            Case SER_SHOVIEW_MEK                                                            '   ���i�}�X�^+���[�J�}�X�^
                Me.Text = TTL_SHOVIEW
            Case SER_TOKMAST, SER_TOKVIEW                                                   '   ���Ӑ�}�X�^
                Me.Text = LBL_TOKCAP & TTL_TOKVIEW
            Case SER_SIRMAST, SER_SIRVIEW                                                   '   �d����}�X�^
                Me.Text = TTL_SIRVIEW
            Case SER_MEKTABL, SER_MEKVIEW                                                   '   ���[�J�e�[�u��
                Me.Text = TTL_MEKVIEW
            Case SER_TANTABL, SER_TANVIEW                                                   '   �S���҃}�X�^
                Me.Text = TTL_TANVIEW
            Case SER_TKSMAST, SER_TKSVIEW                                                   '   ���Ӑ�x�X�}�X�^
                Me.Text = LBL_TOKCAP & TTL_TKSVIEW
            Case SER_TKBVIEW                                                                '   ���Ӑ敔��e�[�u��
                Me.Text = LBL_TOKCAP & TTL_TKBVIEW
            Case SER_TSHMAST, SER_TSHMAST2                                                  '   ���Ӑ揤�i�}�X�^
                Me.Text = LBL_TOKCAP & TTL_SHOVIEW
            Case SER_TSHVIEW, SER_TSHVIEW2                                                  '   ���Ӑ揤�i�}�X�^
                Me.Text = LBL_TOKCAP & TTL_SHOVIEW
            Case SER_SSHMAST, SER_SSHMAST2                                                  '   �d���揤�i�}�X�^
                Me.Text = TTL_SSHVIEW
            Case SER_SSHVIEW, SER_SSHVIEW2                                                  '   �d���揤�i�}�X�^
                Me.Text = TTL_SSHVIEW
            Case SER_BSHTABL, SER_BSHVIEW                                                   '   �����Z���^�[�ʏ��i�e�[�u��
                Me.Text = TTL_BSHVIEW
            Case SER_ARETABL, SER_AREVIEW                                                   '   �G���A�e�[�u��
                Me.Text = TTL_AREVIEW
            Case SER_BMNTABL, SER_BMNVIEW                                                   '   ����e�[�u��
                Me.Text = TTL_TKBVIEW
            Case SER_SBNTABL, SER_SBNVIEW                                                   '   ���i�啪�ރe�[�u��
                Me.Text = TTL_SBNVIEW
            Case SER_TKJTABL, SER_TKJVIEW                                                   '   ���Ӑ抨��ȖڃR�[�h�e�[�u��
                Me.Text = LBL_TOKCAP & TTL_TKJVIEW
            Case SER_DNKTABL, SER_DNKVIEW                                                   '   �`�[�敪�e�[�u��
                Me.Text = TTL_DNKVIEW
            Case SER_DPTTABL, SER_DPTVIEW                                                   '   �`�[�p�^�[���敪�e�[�u��
                Me.Text = TTL_DPTVIEW
            Case SER_KBNTABL, SER_KBNVIEW                                                   '   �敪���̃e�[�u��
                Me.Text = TTL_KBNVIEW
            Case SER_BSTTABL, SER_BSTVIEW                                                   '   �����Z���^�[�}�X�^
                Me.Text = TTL_BSTVIEW
            Case SER_SCGTABL, SER_SCTTABL                                                   '   ���i�ϊ��e�[�u��
                Me.Text = LBL_TOKCAP & TTL_SCTVIEW
            Case SER_SCGVIEW, SER_SCTVIEW                                                   '   ���i�ϊ��e�[�u��
                Me.Text = LBL_TOKCAP & TTL_SCTVIEW
            Case SER_BRBTABL, SER_BRBVIEW                                                   '   �啪�ރe�[�u��
                Me.Text = TTL_BRBVIEW
            Case SER_BRMTABL, SER_BRMVIEW                                                   '   �����ރe�[�u��
                Me.Text = TTL_BRMVIEW
            Case SER_BRSTABL, SER_BRSVIEW                                                   '   �����ރe�[�u��
                Me.Text = TTL_BRSVIEW
            Case SER_BSYTABL, SER_BSYVIEW                                                   '   �����e�[�u��
                Me.Text = TTL_BSYVIEW
            Case SER_KENTABL, SER_KENVIEW                                                   '   �s���{���e�[�u��
                Me.Text = TTL_KENVIEW
            Case SER_NHSTABL, SER_NHSVIEW                                                   '   �[�i�����t��e�[�u��
                Me.Text = TTL_NHSVIEW
            Case SER_TNSTABL, SER_TNSVIEW                                                   '   �q��[�i�w��ꏊ�e�[�u��
                Me.Text = LBL_TOKCAP & TTL_TNSVIEW
            Case SER_TKKTABL, SER_TKKVIEW                                                   '   �������e�[�u��
                Me.Text = TTL_TKKVIEW
            Case SER_CATTABL, SER_CATVIEW                                                   '   �J�e�S���e�[�u��
                Me.Text = TTL_CATVIEW
            Case SER_KKMTABL, SER_KKMTABL                                                   '   ��v�Ȗڃe�[�u��
                Me.Text = TTL_KKMVIEW
            Case SER_THSTABL                                                                '   �����x�X�e�[�u��
                Me.Text = TTL_THSVIEW
            Case Else
        End Select

        '***********************************************************************************
        '   �����e�[�u���h�c���Ƀe�L�X�g�{�b�N�X�̐ݒ���s��
        '   ���ڐ�   SertxtCNT
        '   ���x���� strSerkey.Add
        '   IME      .ImeMode
        '   ����     .MaxLength
        '   ������� .Ank
        '   ��   Windows10�ł�IME�ɃJ�^�J�i��ݒ肵�Ă��Ђ炪�ȂƂȂ�
        '   ��   �A�v���ł̑Ώ��͕s�B�ݒ�ł̂ݑΉ�
        '***********************************************************************************
        Select Case SerMast
            Case SER_SHOMAST, SER_SHOVIEW                                                   '   ���i�}�X�^

                '### 2021/05/13 S.SUGIURA UPD START PS3
                '���ڐ���   �ݒ�
                'SertxtCNT = 6
                SertxtCNT = 7
                DataGetIndex = 0

                '���x����   �ݒ�
                strSerkey.Add(TXT_LBL_SHOFKG)
                strSerkey.Add(TXT_LBL_SHOCOD)
                strSerkey.Add(TXT_LBL_SHONAM)
                strSerkey.Add(TXT_LBL_SHOKNA)
                strSerkey.Add(TXT_LBL_SHOKKK)
                strSerkey.Add(TXT_LBL_SHOKTS)
                strSerkey.Add(TXT_LBL_SHOMKC)

                For lbllop As Integer = 0 To SertxtCNT - 1
                    lblWidth.Add(162)
                Next

                txtWidth.Add(913)
                txtWidth.Add(357)
                txtWidth.Add(357)
                txtWidth.Add(357)
                txtWidth.Add(357)
                txtWidth.Add(357)
                txtWidth.Add(357)

                'IME        �ݒ�
                txtText1(TXTTSHS_KEYCD1).ImeMode = Windows.Forms.ImeMode.KatakanaHalf
                txtText1(TXTTSHS_KEYCD2).ImeMode = Windows.Forms.ImeMode.Disable
                txtText1(TXTTSHS_KEYCD3).ImeMode = Windows.Forms.ImeMode.Hiragana
                txtText1(TXTTSHS_KEYCD4).ImeMode = Windows.Forms.ImeMode.KatakanaHalf
                txtText1(TXTTSHS_KEYCD5).ImeMode = Windows.Forms.ImeMode.Hiragana
                txtText1(TXTTSHS_KEYCD6).ImeMode = Windows.Forms.ImeMode.Hiragana
                txtText1(TXTTSHS_KEYCD7).ImeMode = Windows.Forms.ImeMode.Disable

                '����       �ݒ�
                txtText1(TXTTSHS_KEYCD1).MaxLength = 114
                txtText1(TXTTSHS_KEYCD2).MaxLength = 13
                txtText1(TXTTSHS_KEYCD3).MaxLength = 40
                txtText1(TXTTSHS_KEYCD4).MaxLength = 40
                txtText1(TXTTSHS_KEYCD5).MaxLength = 20
                txtText1(TXTTSHS_KEYCD6).MaxLength = 20
                txtText1(TXTTSHS_KEYCD7).MaxLength = 7

                '�������   �ݒ�
                txtText1(TXTTSHS_KEYCD1).Ank = TAG_KON
                txtText1(TXTTSHS_KEYCD2).Ank = TAG_COD
                txtText1(TXTTSHS_KEYCD3).Ank = TAG_KON
                txtText1(TXTTSHS_KEYCD4).Ank = TAG_KNA
                txtText1(TXTTSHS_KEYCD5).Ank = TAG_KON
                txtText1(TXTTSHS_KEYCD6).Ank = TAG_KON
                txtText1(TXTTSHS_KEYCD7).Ank = TAG_COD

                '�R�}���h�{�^���@�@�ݒ�i�ʁj
                cmdCommand1(CMD_SER).Text = "����"

                '�����\���ځ@�@�ݒ�
                txtText1(TXTTSHS_KEYCD1).Search = False
                txtText1(TXTTSHS_KEYCD2).Search = False
                txtText1(TXTTSHS_KEYCD3).Search = False
                txtText1(TXTTSHS_KEYCD4).Search = False
                txtText1(TXTTSHS_KEYCD5).Search = False
                txtText1(TXTTSHS_KEYCD6).Search = False
                txtText1(TXTTSHS_KEYCD7).Search = True
                '### 2021/05/13 S.SUGIURA UPD END
            Case SER_SHOVIEW_ME                                                             '   ���i�}�X�^

                SertxtCNT = 5

                strSerkey.Add(TXT_LBL_SHOCOD)
                strSerkey.Add(TXT_LBL_SHONAM)
                strSerkey.Add(TXT_LBL_SHOKNA)
                strSerkey.Add(TXT_LBL_SHOKKK)
                strSerkey.Add(TXT_LBL_SHOKTS)

                txtText1(TXTTSHS_KEYCD1).ImeMode = Windows.Forms.ImeMode.Disable
                txtText1(TXTTSHS_KEYCD2).ImeMode = Windows.Forms.ImeMode.Hiragana
                txtText1(TXTTSHS_KEYCD3).ImeMode = Windows.Forms.ImeMode.KatakanaHalf
                txtText1(TXTTSHS_KEYCD4).ImeMode = Windows.Forms.ImeMode.Hiragana
                txtText1(TXTTSHS_KEYCD5).ImeMode = Windows.Forms.ImeMode.Hiragana

                txtText1(TXTTSHS_KEYCD1).MaxLength = 13
                txtText1(TXTTSHS_KEYCD2).MaxLength = 40
                txtText1(TXTTSHS_KEYCD3).MaxLength = 40
                txtText1(TXTTSHS_KEYCD4).MaxLength = 20
                txtText1(TXTTSHS_KEYCD5).MaxLength = 20

                txtText1(TXTTSHS_KEYCD1).Ank = TAG_COD
                txtText1(TXTTSHS_KEYCD2).Ank = TAG_KON
                txtText1(TXTTSHS_KEYCD3).Ank = TAG_KNA
                txtText1(TXTTSHS_KEYCD4).Ank = TAG_KON
                txtText1(TXTTSHS_KEYCD5).Ank = TAG_KON

            Case SER_SHOVIEW_MEK                                                            '   ���i�}�X�^+���[�J�}�X�^

                SertxtCNT = 2

                strSerkey.Add(TXT_LBL_SHOCOD & "�^" & TXT_LBL_SHONAM & "�^" & TXT_LBL_SHOKTS)
                strSerkey.Add(TXT_LBL_SHOMKC)

                txtText1(TXTTSHS_KEYCD1).ImeMode = Windows.Forms.ImeMode.Hiragana
                txtText1(TXTTSHS_KEYCD2).ImeMode = Windows.Forms.ImeMode.Disable

                txtText1(TXTTSHS_KEYCD1).MaxLength = 40
                txtText1(TXTTSHS_KEYCD2).MaxLength = 7

                txtText1(TXTTSHS_KEYCD1).Ank = TAG_KON
                txtText1(TXTTSHS_KEYCD2).Ank = TAG_COD

            Case SER_TOKMAST, SER_TOKVIEW                                                   '   ���Ӑ�}�X�^

                SertxtCNT = 1

                strSerkey.Add(TXT_LBL_TOKCOD & "�^" & TXT_LBL_TOKKNA)

                lblWidth.Add(270)

                txtWidth.Add(160)

                txtText1(TXTTSHS_KEYCD1).ImeMode = Windows.Forms.ImeMode.KatakanaHalf

                txtText1(TXTTSHS_KEYCD1).MaxLength = 20

                txtText1(TXTTSHS_KEYCD1).Ank = TAG_KNA

            Case SER_SIRMAST, SER_SIRVIEW                                                   '   �d����}�X�^

                SertxtCNT = 1

                strSerkey.Add(TXT_LBL_SIRCOD & "�^" & TXT_LBL_SIRKNA)

                lblWidth.Add(270)

                txtWidth.Add(160)

                txtText1(TXTTSHS_KEYCD1).ImeMode = Windows.Forms.ImeMode.KatakanaHalf

                txtText1(TXTTSHS_KEYCD1).MaxLength = 20

                txtText1(TXTTSHS_KEYCD1).Ank = TAG_KNA

            Case SER_MEKTABL, SER_MEKVIEW                                                   '   ���[�J�e�[�u��

                SertxtCNT = 1

                strSerkey.Add(TXT_LBL_MEKCOD & "�^" & TXT_LBL_MEKKNA)

                lblWidth.Add(270)

                txtWidth.Add(160)

                txtText1(TXTTSHS_KEYCD1).ImeMode = Windows.Forms.ImeMode.KatakanaHalf

                txtText1(TXTTSHS_KEYCD1).MaxLength = 20

                txtText1(TXTTSHS_KEYCD1).Ank = TAG_KNA

            Case SER_TANTABL, SER_TANVIEW                                                   '   �S���҃}�X�^

                SertxtCNT = 4
                DataGetIndex = 0

                strSerkey.Add(TXT_LBL_TANFGK)
                strSerkey.Add(TXT_LBL_TANCOD)
                strSerkey.Add(TXT_LBL_TANNAM)
                strSerkey.Add(TXT_LBL_TANKNA)

                lblWidth.Add(162)
                lblWidth.Add(162)
                lblWidth.Add(162)
                lblWidth.Add(162)

                txtWidth.Add(913)
                txtWidth.Add(48)
                txtWidth.Add(160)
                txtWidth.Add(160)

                txtText1(TXTTSHS_KEYCD1).ImeMode = Windows.Forms.ImeMode.KatakanaHalf
                txtText1(TXTTSHS_KEYCD2).ImeMode = Windows.Forms.ImeMode.Disable
                txtText1(TXTTSHS_KEYCD3).ImeMode = Windows.Forms.ImeMode.Hiragana
                txtText1(TXTTSHS_KEYCD4).ImeMode = Windows.Forms.ImeMode.KatakanaHalf

                txtText1(TXTTSHS_KEYCD1).MaxLength = 114
                txtText1(TXTTSHS_KEYCD2).MaxLength = 6
                txtText1(TXTTSHS_KEYCD3).MaxLength = 20
                txtText1(TXTTSHS_KEYCD4).MaxLength = 20

                txtText1(TXTTSHS_KEYCD1).Ank = TAG_KON
                txtText1(TXTTSHS_KEYCD2).Ank = TAG_COD
                txtText1(TXTTSHS_KEYCD3).Ank = TAG_KON
                txtText1(TXTTSHS_KEYCD4).Ank = "ANK"

            Case SER_TKSMAST, SER_TKSVIEW                                                   '   ���Ӑ�x�X�}�X�^

                SertxtCNT = 1

                strSerkey.Add(TXT_LBL_TKSCOD & "�^" & TXT_LBL_TKSKNA)

                lblWidth.Add(270)

                txtWidth.Add(320)

                txtText1(TXTTSHS_KEYCD1).ImeMode = Windows.Forms.ImeMode.KatakanaHalf

                txtText1(TXTTSHS_KEYCD1).MaxLength = 40

                txtText1(TXTTSHS_KEYCD1).Ank = TAG_KNA

            Case SER_TSHMAST                                                                '   ���Ӑ揤�i�}�X�^

                SertxtCNT = 6
                DataGetIndex = 0

                strSerkey.Add(TXT_LBL_TSHFGK)
                strSerkey.Add(TXT_LBL_TSHCOD)
                strSerkey.Add(TXT_LBL_JANCOD)
                strSerkey.Add(TXT_LBL_TSHSNM)
                strSerkey.Add(TXT_LBL_SIRCOD)
                strSerkey.Add(TXT_LBL_MEKCOD)

                For lbllop As Integer = 0 To SertxtCNT - 1
                    lblWidth.Add(162)
                Next

                txtWidth.Add(913)
                txtWidth.Add(64)
                txtWidth.Add(104)
                txtWidth.Add(349)
                txtWidth.Add(64)
                txtWidth.Add(104)

                txtText1(TXTTSHS_KEYCD1).ImeMode = Windows.Forms.ImeMode.KatakanaHalf
                txtText1(TXTTSHS_KEYCD2).ImeMode = Windows.Forms.ImeMode.Disable
                txtText1(TXTTSHS_KEYCD3).ImeMode = Windows.Forms.ImeMode.Disable
                txtText1(TXTTSHS_KEYCD4).ImeMode = Windows.Forms.ImeMode.Hiragana
                txtText1(TXTTSHS_KEYCD5).ImeMode = Windows.Forms.ImeMode.Disable
                txtText1(TXTTSHS_KEYCD6).ImeMode = Windows.Forms.ImeMode.Disable

                txtText1(TXTTSHS_KEYCD1).MaxLength = 114
                txtText1(TXTTSHS_KEYCD2).MaxLength = 8
                txtText1(TXTTSHS_KEYCD3).MaxLength = 13
                txtText1(TXTTSHS_KEYCD4).MaxLength = 40
                txtText1(TXTTSHS_KEYCD5).MaxLength = 7
                txtText1(TXTTSHS_KEYCD6).MaxLength = 7

                txtText1(TXTTSHS_KEYCD1).Ank = TAG_KON
                txtText1(TXTTSHS_KEYCD2).Ank = TAG_COD
                txtText1(TXTTSHS_KEYCD3).Ank = TAG_COD
                txtText1(TXTTSHS_KEYCD4).Ank = TAG_KON
                txtText1(TXTTSHS_KEYCD5).Ank = TAG_COD
                txtText1(TXTTSHS_KEYCD6).Ank = TAG_COD

                txtText1(TXTTSHS_KEYCD1).Search = False
                txtText1(TXTTSHS_KEYCD2).Search = True
                txtText1(TXTTSHS_KEYCD3).Search = True
                txtText1(TXTTSHS_KEYCD4).Search = False
                txtText1(TXTTSHS_KEYCD5).Search = True
                txtText1(TXTTSHS_KEYCD6).Search = True

                cmdCommand1(CMD_SER).Text = "����"

            Case SER_TSHMAST2                                                               '   ���Ӑ揤�i�}�X�^

                SertxtCNT = 5
                DataGetIndex = 0

                strSerkey.Add(TXT_LBL_TSHFGK)
                strSerkey.Add(TXT_LBL_JANCOD)
                strSerkey.Add(TXT_LBL_TSHSNM)
                strSerkey.Add(TXT_LBL_SIRCOD)
                strSerkey.Add(TXT_LBL_MEKCOD)

                For lbllop As Integer = 0 To SertxtCNT - 1
                    lblWidth.Add(162)
                Next

                txtWidth.Add(913)
                txtWidth.Add(104)
                txtWidth.Add(349)
                txtWidth.Add(56)
                txtWidth.Add(56)

                txtText1(TXTTSHS_KEYCD1).ImeMode = Windows.Forms.ImeMode.KatakanaHalf
                txtText1(TXTTSHS_KEYCD2).ImeMode = Windows.Forms.ImeMode.Disable
                txtText1(TXTTSHS_KEYCD3).ImeMode = Windows.Forms.ImeMode.Hiragana
                txtText1(TXTTSHS_KEYCD4).ImeMode = Windows.Forms.ImeMode.Disable
                txtText1(TXTTSHS_KEYCD5).ImeMode = Windows.Forms.ImeMode.Disable

                txtText1(TXTTSHS_KEYCD1).MaxLength = 114
                txtText1(TXTTSHS_KEYCD2).MaxLength = 13
                txtText1(TXTTSHS_KEYCD3).MaxLength = 40
                txtText1(TXTTSHS_KEYCD4).MaxLength = 7
                txtText1(TXTTSHS_KEYCD5).MaxLength = 7

                txtText1(TXTTSHS_KEYCD1).Ank = TAG_KON
                txtText1(TXTTSHS_KEYCD2).Ank = TAG_COD
                txtText1(TXTTSHS_KEYCD3).Ank = TAG_KON
                txtText1(TXTTSHS_KEYCD4).Ank = TAG_COD
                txtText1(TXTTSHS_KEYCD5).Ank = TAG_COD

                txtText1(TXTTSHS_KEYCD1).Search = False
                txtText1(TXTTSHS_KEYCD2).Search = True
                txtText1(TXTTSHS_KEYCD3).Search = False
                txtText1(TXTTSHS_KEYCD4).Search = True
                txtText1(TXTTSHS_KEYCD5).Search = True

                cmdCommand1(CMD_SER).Text = "����"

            Case SER_TSHVIEW                                                                '   ���Ӑ揤�i�}�X�^

                SertxtCNT = 6
                DataGetIndex = 0

                strSerkey.Add(TXT_LBL_TSHFGK)
                strSerkey.Add(TXT_LBL_TSHCOD)
                strSerkey.Add(TXT_LBL_JANCOD)
                strSerkey.Add(TXT_LBL_TSHSNM)
                strSerkey.Add(TXT_LBL_SIRCOD)
                strSerkey.Add(TXT_LBL_MEKCOD)

                For lbllop As Integer = 0 To SertxtCNT - 1
                    lblWidth.Add(162)
                Next

                txtWidth.Add(913)
                txtWidth.Add(64)
                txtWidth.Add(104)
                txtWidth.Add(349)
                txtWidth.Add(64)
                txtWidth.Add(104)

                txtText1(TXTTSHS_KEYCD1).ImeMode = Windows.Forms.ImeMode.KatakanaHalf
                txtText1(TXTTSHS_KEYCD2).ImeMode = Windows.Forms.ImeMode.Disable
                txtText1(TXTTSHS_KEYCD3).ImeMode = Windows.Forms.ImeMode.Disable
                txtText1(TXTTSHS_KEYCD4).ImeMode = Windows.Forms.ImeMode.Hiragana
                txtText1(TXTTSHS_KEYCD5).ImeMode = Windows.Forms.ImeMode.Disable
                txtText1(TXTTSHS_KEYCD6).ImeMode = Windows.Forms.ImeMode.Disable

                txtText1(TXTTSHS_KEYCD1).MaxLength = 114
                txtText1(TXTTSHS_KEYCD2).MaxLength = 8
                txtText1(TXTTSHS_KEYCD3).MaxLength = 13
                txtText1(TXTTSHS_KEYCD4).MaxLength = 40
                txtText1(TXTTSHS_KEYCD5).MaxLength = 7
                txtText1(TXTTSHS_KEYCD6).MaxLength = 7

                txtText1(TXTTSHS_KEYCD1).Ank = TAG_KON
                txtText1(TXTTSHS_KEYCD2).Ank = TAG_COD
                txtText1(TXTTSHS_KEYCD3).Ank = TAG_COD
                txtText1(TXTTSHS_KEYCD4).Ank = TAG_KON
                txtText1(TXTTSHS_KEYCD5).Ank = TAG_COD
                txtText1(TXTTSHS_KEYCD6).Ank = TAG_COD

                txtText1(TXTTSHS_KEYCD1).Search = False
                txtText1(TXTTSHS_KEYCD2).Search = True
                txtText1(TXTTSHS_KEYCD3).Search = True
                txtText1(TXTTSHS_KEYCD4).Search = False
                txtText1(TXTTSHS_KEYCD5).Search = True
                txtText1(TXTTSHS_KEYCD6).Search = True

                cmdCommand1(CMD_SER).Text = "����"

            Case SER_TSHVIEW2                                                                '   ���Ӑ揤�i�}�X�^

                SertxtCNT = 5
                DataGetIndex = 0

                strSerkey.Add(TXT_LBL_TSHFGK)
                strSerkey.Add(TXT_LBL_JANCOD)
                strSerkey.Add(TXT_LBL_TSHSNM)
                strSerkey.Add(TXT_LBL_SIRCOD)
                strSerkey.Add(TXT_LBL_MEKCOD)

                For lbllop As Integer = 0 To SertxtCNT - 1
                    lblWidth.Add(162)
                Next

                txtWidth.Add(913)
                txtWidth.Add(104)
                txtWidth.Add(349)
                txtWidth.Add(64)
                txtWidth.Add(104)

                txtText1(TXTTSHS_KEYCD1).ImeMode = Windows.Forms.ImeMode.KatakanaHalf
                txtText1(TXTTSHS_KEYCD2).ImeMode = Windows.Forms.ImeMode.Disable
                txtText1(TXTTSHS_KEYCD3).ImeMode = Windows.Forms.ImeMode.Hiragana
                txtText1(TXTTSHS_KEYCD4).ImeMode = Windows.Forms.ImeMode.Disable
                txtText1(TXTTSHS_KEYCD5).ImeMode = Windows.Forms.ImeMode.Disable

                txtText1(TXTTSHS_KEYCD1).MaxLength = 114
                txtText1(TXTTSHS_KEYCD2).MaxLength = 13
                txtText1(TXTTSHS_KEYCD3).MaxLength = 40
                txtText1(TXTTSHS_KEYCD4).MaxLength = 7
                txtText1(TXTTSHS_KEYCD5).MaxLength = 7

                txtText1(TXTTSHS_KEYCD1).Ank = TAG_KON
                txtText1(TXTTSHS_KEYCD2).Ank = TAG_COD
                txtText1(TXTTSHS_KEYCD3).Ank = TAG_KON
                txtText1(TXTTSHS_KEYCD4).Ank = TAG_COD
                txtText1(TXTTSHS_KEYCD5).Ank = TAG_COD

                txtText1(TXTTSHS_KEYCD1).Search = False
                txtText1(TXTTSHS_KEYCD2).Search = True
                txtText1(TXTTSHS_KEYCD3).Search = False
                txtText1(TXTTSHS_KEYCD4).Search = True
                txtText1(TXTTSHS_KEYCD5).Search = True

                cmdCommand1(CMD_SER).Text = "����"

            Case SER_SSHMAST                                                                '   �d���揤�i�}�X�^

                SertxtCNT = 5
                DataGetIndex = 0

                strSerkey.Add(TXT_LBL_SSHFGK)
                strSerkey.Add(TXT_LBL_SSHSIC)
                strSerkey.Add(TXT_LBL_SSHSKN)
                strSerkey.Add(TXT_LBL_SSHSHC)
                strSerkey.Add(TXT_LBL_SSHKNA)

                For lbllop As Integer = 0 To SertxtCNT - 1
                    lblWidth.Add(162)
                Next

                txtWidth.Add(913)
                txtWidth.Add(104)
                txtWidth.Add(610)
                txtWidth.Add(104)
                txtWidth.Add(610)

                txtText1(TXTTSHS_KEYCD1).ImeMode = Windows.Forms.ImeMode.KatakanaHalf
                txtText1(TXTTSHS_KEYCD2).ImeMode = Windows.Forms.ImeMode.Disable
                txtText1(TXTTSHS_KEYCD3).ImeMode = Windows.Forms.ImeMode.KatakanaHalf
                txtText1(TXTTSHS_KEYCD4).ImeMode = Windows.Forms.ImeMode.Disable
                txtText1(TXTTSHS_KEYCD5).ImeMode = Windows.Forms.ImeMode.KatakanaHalf

                txtText1(TXTTSHS_KEYCD1).MaxLength = 114
                txtText1(TXTTSHS_KEYCD2).MaxLength = 7
                txtText1(TXTTSHS_KEYCD3).MaxLength = 20
                txtText1(TXTTSHS_KEYCD4).MaxLength = 13
                txtText1(TXTTSHS_KEYCD5).MaxLength = 40

                txtText1(TXTTSHS_KEYCD1).Ank = TAG_KON
                txtText1(TXTTSHS_KEYCD2).Ank = TAG_COD
                txtText1(TXTTSHS_KEYCD3).Ank = TAG_KNA
                txtText1(TXTTSHS_KEYCD4).Ank = TAG_COD
                txtText1(TXTTSHS_KEYCD5).Ank = TAG_KON

                txtText1(TXTTSHS_KEYCD1).Search = False
                txtText1(TXTTSHS_KEYCD2).Search = True
                txtText1(TXTTSHS_KEYCD3).Search = False
                txtText1(TXTTSHS_KEYCD4).Search = True
                txtText1(TXTTSHS_KEYCD5).Search = False

                cmdCommand1(CMD_SER).Text = "����"
            Case SER_SSHMAST2                                                                '   �d���揤�i�}�X�^

                SertxtCNT = 4
                DataGetIndex = 0

                For lbllop As Integer = 0 To SertxtCNT - 1
                    lblWidth.Add(162)
                Next

                txtWidth.Add(913)
                txtWidth.Add(357)
                txtWidth.Add(357)
                txtWidth.Add(357)

                strSerkey.Add(TXT_LBL_SSHFGK)
                strSerkey.Add(TXT_LBL_SSHSKN)
                strSerkey.Add(TXT_LBL_SSHSHC)
                strSerkey.Add(TXT_LBL_SSHKNA)

                txtText1(TXTTSHS_KEYCD1).ImeMode = Windows.Forms.ImeMode.KatakanaHalf
                txtText1(TXTTSHS_KEYCD2).ImeMode = Windows.Forms.ImeMode.KatakanaHalf
                txtText1(TXTTSHS_KEYCD3).ImeMode = Windows.Forms.ImeMode.Disable
                txtText1(TXTTSHS_KEYCD4).ImeMode = Windows.Forms.ImeMode.KatakanaHalf

                txtText1(TXTTSHS_KEYCD1).MaxLength = 120
                txtText1(TXTTSHS_KEYCD2).MaxLength = 20
                txtText1(TXTTSHS_KEYCD3).MaxLength = 13
                txtText1(TXTTSHS_KEYCD4).MaxLength = 40

                txtText1(TXTTSHS_KEYCD1).Ank = TAG_KON
                txtText1(TXTTSHS_KEYCD2).Ank = TAG_KNA
                txtText1(TXTTSHS_KEYCD3).Ank = TAG_COD
                txtText1(TXTTSHS_KEYCD4).Ank = TAG_KON

                txtText1(TXTTSHS_KEYCD1).Search = False
                txtText1(TXTTSHS_KEYCD2).Search = False
                txtText1(TXTTSHS_KEYCD3).Search = True
                txtText1(TXTTSHS_KEYCD4).Search = False

                cmdCommand1(CMD_SER).Text = "����"
            Case SER_SSHVIEW                                                                '   �d���揤�i�}�X�^

                SertxtCNT = 5
                DataGetIndex = 0

                strSerkey.Add(TXT_LBL_SSHFGK)
                strSerkey.Add(TXT_LBL_SSHSHC)
                strSerkey.Add(TXT_LBL_SSHKNA)
                strSerkey.Add(TXT_LBL_SSHSIC)
                strSerkey.Add(TXT_LBL_SSHSKN)

                For lbllop As Integer = 0 To SertxtCNT - 1
                    lblWidth.Add(162)
                Next

                txtWidth.Add(913)
                txtWidth.Add(104)
                txtWidth.Add(610)
                txtWidth.Add(104)
                txtWidth.Add(610)

                txtText1(TXTTSHS_KEYCD1).ImeMode = Windows.Forms.ImeMode.KatakanaHalf
                txtText1(TXTTSHS_KEYCD2).ImeMode = Windows.Forms.ImeMode.Disable
                txtText1(TXTTSHS_KEYCD3).ImeMode = Windows.Forms.ImeMode.KatakanaHalf
                txtText1(TXTTSHS_KEYCD4).ImeMode = Windows.Forms.ImeMode.Disable
                txtText1(TXTTSHS_KEYCD5).ImeMode = Windows.Forms.ImeMode.KatakanaHalf

                txtText1(TXTTSHS_KEYCD1).MaxLength = 120
                txtText1(TXTTSHS_KEYCD2).MaxLength = 13
                txtText1(TXTTSHS_KEYCD3).MaxLength = 40
                txtText1(TXTTSHS_KEYCD4).MaxLength = 7
                txtText1(TXTTSHS_KEYCD5).MaxLength = 20

                txtText1(TXTTSHS_KEYCD1).Ank = TAG_KON
                txtText1(TXTTSHS_KEYCD2).Ank = TAG_COD
                txtText1(TXTTSHS_KEYCD3).Ank = TAG_KON
                txtText1(TXTTSHS_KEYCD4).Ank = TAG_COD
                txtText1(TXTTSHS_KEYCD5).Ank = TAG_KNA

                txtText1(TXTTSHS_KEYCD1).Search = False
                txtText1(TXTTSHS_KEYCD2).Search = True
                txtText1(TXTTSHS_KEYCD3).Search = False
                txtText1(TXTTSHS_KEYCD4).Search = True
                txtText1(TXTTSHS_KEYCD5).Search = False

                cmdCommand1(CMD_SER).Text = "����"

            Case SER_SSHVIEW2                                                                '   �d���揤�i�}�X�^

                SertxtCNT = 4
                DataGetIndex = 0

                strSerkey.Add(TXT_LBL_SSHFGK)
                strSerkey.Add(TXT_LBL_SSHKNA)
                strSerkey.Add(TXT_LBL_SSHSIC)
                strSerkey.Add(TXT_LBL_SSHSKN)

                For lbllop As Integer = 0 To SertxtCNT - 1
                    lblWidth.Add(162)
                Next

                txtWidth.Add(913)
                txtWidth.Add(357)
                txtWidth.Add(357)
                txtWidth.Add(357)

                txtText1(TXTTSHS_KEYCD1).ImeMode = Windows.Forms.ImeMode.KatakanaHalf
                txtText1(TXTTSHS_KEYCD2).ImeMode = Windows.Forms.ImeMode.KatakanaHalf
                txtText1(TXTTSHS_KEYCD3).ImeMode = Windows.Forms.ImeMode.Disable
                txtText1(TXTTSHS_KEYCD4).ImeMode = Windows.Forms.ImeMode.KatakanaHalf

                txtText1(TXTTSHS_KEYCD1).MaxLength = 120
                txtText1(TXTTSHS_KEYCD2).MaxLength = 40
                txtText1(TXTTSHS_KEYCD3).MaxLength = 7
                txtText1(TXTTSHS_KEYCD4).MaxLength = 20

                txtText1(TXTTSHS_KEYCD1).Ank = TAG_KON
                txtText1(TXTTSHS_KEYCD2).Ank = TAG_KNA
                txtText1(TXTTSHS_KEYCD3).Ank = TAG_COD
                txtText1(TXTTSHS_KEYCD4).Ank = TAG_KON

                txtText1(TXTTSHS_KEYCD1).Search = False
                txtText1(TXTTSHS_KEYCD2).Search = False
                txtText1(TXTTSHS_KEYCD3).Search = True
                txtText1(TXTTSHS_KEYCD4).Search = False

                cmdCommand1(CMD_SER).Text = "����"

            Case SER_BSHTABL, SER_BSHVIEW                                                   '   �����Z���^�[�ʏ��i�e�[�u��

                SertxtCNT = 3
                DataGetIndex = 0

                strSerkey.Add(TXT_LBL_BSHFGK)
                strSerkey.Add(TXT_LBL_BSHBSC)
                strSerkey.Add(TXT_LBL_BSHSCD)

                For lbllop As Integer = 0 To SertxtCNT - 1
                    lblWidth.Add(162)
                Next

                txtWidth.Add(913)
                txtWidth.Add(48)
                txtWidth.Add(667)

                txtText1(TXTTSHS_KEYCD1).ImeMode = Windows.Forms.ImeMode.KatakanaHalf
                txtText1(TXTTSHS_KEYCD2).ImeMode = Windows.Forms.ImeMode.Disable
                txtText1(TXTTSHS_KEYCD3).ImeMode = Windows.Forms.ImeMode.Disable

                txtText1(TXTTSHS_KEYCD1).MaxLength = 114
                txtText1(TXTTSHS_KEYCD2).MaxLength = 6
                txtText1(TXTTSHS_KEYCD3).MaxLength = 13

                txtText1(TXTTSHS_KEYCD1).Ank = TAG_KON
                txtText1(TXTTSHS_KEYCD2).Ank = TAG_COD
                txtText1(TXTTSHS_KEYCD3).Ank = TAG_COD

            Case SER_TKBVIEW                                                                '   ���Ӑ敔��e�[�u��

                SertxtCNT = 1

                strSerkey.Add(TXT_LBL_TKBBMC)

                lblWidth.Add(162)

                txtWidth.Add(32)

                txtText1(TXTTSHS_KEYCD1).ImeMode = Windows.Forms.ImeMode.Disable

                txtText1(TXTTSHS_KEYCD1).MaxLength = 4

                txtText1(TXTTSHS_KEYCD1).Ank = TAG_COD

                blnViewFirst = True

            Case SER_ARETABL, SER_AREVIEW                                                    '   �G���A�e�[�u��

                SertxtCNT = 1

                strSerkey.Add(TXT_LBL_ARENAM)

                lblWidth.Add(270)

                txtWidth.Add(160)

                txtText1(TXTTSHS_KEYCD1).ImeMode = Windows.Forms.ImeMode.KatakanaHalf

                txtText1(TXTTSHS_KEYCD1).MaxLength = 20

                txtText1(TXTTSHS_KEYCD1).Ank = TAG_KON

            Case SER_BMNTABL, SER_BMNVIEW                                                   '   ����e�[�u��

                SertxtCNT = 1

                strSerkey.Add(TXT_LBL_BMNCOD)

                lblWidth.Add(162)

                txtWidth.Add(32)

                txtText1(TXTTSHS_KEYCD1).ImeMode = Windows.Forms.ImeMode.Disable

                txtText1(TXTTSHS_KEYCD1).MaxLength = 4

                txtText1(TXTTSHS_KEYCD1).Ank = TAG_COD

                blnViewFirst = True

            Case SER_SBNTABL, SER_SBNVIEW                                                   '   ���i�啪�ރe�[�u��

                SertxtCNT = 1

                strSerkey.Add(TXT_LBL_SBNCOD)

                lblWidth.Add(162)

                txtWidth.Add(48)

                txtText1(TXTTSHS_KEYCD1).ImeMode = Windows.Forms.ImeMode.Disable

                txtText1(TXTTSHS_KEYCD1).MaxLength = 6

                txtText1(TXTTSHS_KEYCD1).Ank = TAG_COD

                blnViewFirst = True

            Case SER_TKJTABL, SER_TKJVIEW                                                   '   ���Ӑ抨��ȖڃR�[�h�e�[�u��

                SertxtCNT = 1

                strSerkey.Add(TXT_LBL_TKJCOD)

                lblWidth.Add(162)

                txtWidth.Add(16)

                txtText1(TXTTSHS_KEYCD1).ImeMode = Windows.Forms.ImeMode.Disable

                txtText1(TXTTSHS_KEYCD1).MaxLength = 2

                txtText1(TXTTSHS_KEYCD1).Ank = TAG_COD

                blnViewFirst = True

            Case SER_DNKTABL, SER_DNKVIEW                                                   '   �`�[�敪�e�[�u��

                SertxtCNT = 1

                strSerkey.Add(TXT_LBL_DNKKBN)

                lblWidth.Add(162)

                txtWidth.Add(16)

                txtText1(TXTTSHS_KEYCD1).ImeMode = Windows.Forms.ImeMode.Disable

                txtText1(TXTTSHS_KEYCD1).MaxLength = 2

                txtText1(TXTTSHS_KEYCD1).Ank = TAG_COD

                blnViewFirst = True

            Case SER_DPTTABL, SER_DPTVIEW                                                   '   �`�[�p�^�[���敪�e�[�u��

                SertxtCNT = 2

                strSerkey.Add(TXT_LBL_DPTKBN)
                strSerkey.Add(TXT_LBL_DPTNAM)

                lblWidth.Add(162)
                lblWidth.Add(162)

                txtWidth.Add(64)
                txtWidth.Add(160)

                txtText1(TXTTSHS_KEYCD1).ImeMode = Windows.Forms.ImeMode.Disable
                txtText1(TXTTSHS_KEYCD2).ImeMode = Windows.Forms.ImeMode.Hiragana

                txtText1(TXTTSHS_KEYCD1).MaxLength = 8
                txtText1(TXTTSHS_KEYCD2).MaxLength = 20

                txtText1(TXTTSHS_KEYCD1).Ank = TAG_COD
                txtText1(TXTTSHS_KEYCD2).Ank = TAG_KON

                blnViewFirst = True

            Case SER_KBNTABL, SER_KBNVIEW                                                   '   �敪���̃e�[�u��

                SertxtCNT = 2

                strSerkey.Add(TXT_LBL_KBNCOD)
                strSerkey.Add(TXT_LBL_KBNNAM)

                lblWidth.Add(162)
                lblWidth.Add(162)

                txtWidth.Add(16)
                txtWidth.Add(320)

                txtText1(TXTTSHS_KEYCD1).ImeMode = Windows.Forms.ImeMode.Disable
                txtText1(TXTTSHS_KEYCD2).ImeMode = Windows.Forms.ImeMode.Hiragana

                txtText1(TXTTSHS_KEYCD1).MaxLength = 2
                txtText1(TXTTSHS_KEYCD2).MaxLength = 40

                txtText1(TXTTSHS_KEYCD1).Ank = TAG_COD
                txtText1(TXTTSHS_KEYCD2).Ank = TAG_KON

                blnViewFirst = True

            Case SER_BSTTABL, SER_BSTVIEW                                                   '   �����Z���^�[�}�X�^

                SertxtCNT = 4
                DataGetIndex = 0

                strSerkey.Add(TXT_LBL_BSTFGK)
                strSerkey.Add(TXT_LBL_BSTCOD)
                strSerkey.Add(TXT_LBL_BSTNAM)
                strSerkey.Add(TXT_LBL_BSTKNA)

                lblWidth.Add(162)
                lblWidth.Add(162)
                lblWidth.Add(162)
                lblWidth.Add(162)

                txtWidth.Add(913)
                txtWidth.Add(160)
                txtWidth.Add(320)
                txtWidth.Add(160)

                txtText1(TXTTSHS_KEYCD1).ImeMode = Windows.Forms.ImeMode.KatakanaHalf
                txtText1(TXTTSHS_KEYCD2).ImeMode = Windows.Forms.ImeMode.Disable
                txtText1(TXTTSHS_KEYCD3).ImeMode = Windows.Forms.ImeMode.Hiragana
                txtText1(TXTTSHS_KEYCD4).ImeMode = Windows.Forms.ImeMode.KatakanaHalf

                txtText1(TXTTSHS_KEYCD1).MaxLength = 114
                txtText1(TXTTSHS_KEYCD2).MaxLength = 6
                txtText1(TXTTSHS_KEYCD3).MaxLength = 40
                txtText1(TXTTSHS_KEYCD4).MaxLength = 20

                txtText1(TXTTSHS_KEYCD1).Ank = TAG_KON
                txtText1(TXTTSHS_KEYCD2).Ank = TAG_COD
                txtText1(TXTTSHS_KEYCD3).Ank = TAG_KON
                txtText1(TXTTSHS_KEYCD4).Ank = "ANK"

            Case SER_SCGTABL                                                                '   ���i�ϊ��e�[�u��

                SertxtCNT = 3
                DataGetIndex = 0

                strSerkey.Add(TXT_LBL_SCGFGK)
                strSerkey.Add(TXT_LBL_SCGBMC)
                'strSerkey.Add(TXT_LBL_SCGKJC)
                strSerkey.Add(TXT_LBL_SCGSHC)

                lblWidth.Add(162)
                lblWidth.Add(162)
                'lblWidth.Add(162)
                lblWidth.Add(162)

                txtWidth.Add(913)
                txtWidth.Add(32)
                'txtWidth.Add(16)
                txtWidth.Add(485)

                txtText1(TXTTSHS_KEYCD1).ImeMode = Windows.Forms.ImeMode.KatakanaHalf
                txtText1(TXTTSHS_KEYCD2).ImeMode = Windows.Forms.ImeMode.Disable
                'txtText1(TXTTSHS_KEYCD3).ImeMode = Windows.Forms.ImeMode.Disable
                txtText1(TXTTSHS_KEYCD3).ImeMode = Windows.Forms.ImeMode.Disable
                
                txtText1(TXTTSHS_KEYCD1).MaxLength = 114
                txtText1(TXTTSHS_KEYCD2).MaxLength = 4
                'txtText1(TXTTSHS_KEYCD3).MaxLength = 2
                '### 2021/06/07 S.SUGIURA UPD START 16�����͉�
                'txtText1(TXTTSHS_KEYCD3).MaxLength = 13
                txtText1(TXTTSHS_KEYCD3).MaxLength = 16
                '### 2021/06/07 S.SUGIURA UPD END

                txtText1(TXTTSHS_KEYCD1).Ank = TAG_KON
                txtText1(TXTTSHS_KEYCD2).Ank = TAG_COD
                '### 2021/06/07 S.SUGIURA UPD START �p���L�����͋��Ή�
                'txtText1(TXTTSHS_KEYCD3).Ank = TAG_COD
                txtText1(TXTTSHS_KEYCD3).Ank = TAG_EIJ & TAG_COD & TAG_KGU
                '### 2021/06/07 S.SUGIURA UPD END
                'txtText1(TXTTSHS_KEYCD4).Ank = TAG_COD

                blnViewFirst = True

            Case SER_SCGVIEW                                                                '   ���i�ϊ��e�[�u��

                SertxtCNT = 1

                strSerkey.Add(TXT_LBL_SCGSHC & "�^" & TXT_LBL_SCGCHC & "�^" & TXT_LBL_SCGSNM)

                lblWidth.Add(360)

                txtWidth.Add(320)

                txtText1(TXTTSHS_KEYCD1).ImeMode = Windows.Forms.ImeMode.KatakanaHalf

                txtText1(TXTTSHS_KEYCD1).MaxLength = 40

                txtText1(TXTTSHS_KEYCD1).Ank = TAG_KON

            Case SER_BRBTABL, SER_BRBVIEW                                                   '   �啪�ރe�[�u��

                SertxtCNT = 1

                strSerkey.Add(TXT_LBL_BRBCOD)

                lblWidth.Add(162)

                txtWidth.Add(32)

                txtText1(TXTTSHS_KEYCD1).ImeMode = Windows.Forms.ImeMode.Disable

                txtText1(TXTTSHS_KEYCD1).MaxLength = 4

                txtText1(TXTTSHS_KEYCD1).Ank = TAG_COD

                blnViewFirst = True

            Case SER_BRMTABL, SER_BRMVIEW                                                   '   �����ރe�[�u��

                SertxtCNT = 1

                strSerkey.Add(TXT_LBL_BRMCOD)

                lblWidth.Add(162)

                txtWidth.Add(32)

                txtText1(TXTTSHS_KEYCD1).ImeMode = Windows.Forms.ImeMode.Disable

                txtText1(TXTTSHS_KEYCD1).MaxLength = 4

                txtText1(TXTTSHS_KEYCD1).Ank = TAG_COD

                blnViewFirst = True

            Case SER_BRSTABL, SER_BRSVIEW                                                   '   �����ރe�[�u��

                SertxtCNT = 1

                strSerkey.Add(TXT_LBL_BRSCOD)

                lblWidth.Add(162)

                txtWidth.Add(32)

                txtText1(TXTTSHS_KEYCD1).ImeMode = Windows.Forms.ImeMode.Disable

                txtText1(TXTTSHS_KEYCD1).MaxLength = 4

                txtText1(TXTTSHS_KEYCD1).Ank = TAG_COD

                blnViewFirst = True

            Case SER_BSYTABL, SER_BSYVIEW                                                   '   �����e�[�u��

                SertxtCNT = 1

                strSerkey.Add(TXT_LBL_BSYCOD)

                lblWidth.Add(270)

                txtWidth.Add(160)

                txtText1(TXTTSHS_KEYCD1).ImeMode = Windows.Forms.ImeMode.KatakanaHalf

                txtText1(TXTTSHS_KEYCD1).MaxLength = 20

                txtText1(TXTTSHS_KEYCD1).Ank = TAG_KNA

                blnViewFirst = True

            Case SER_KENTABL, SER_KENVIEW                                                   '   �s���{���e�[�u��

                SertxtCNT = 1

                strSerkey.Add(TXT_LBL_KENCOD)

                lblWidth.Add(270)

                txtWidth.Add(320)

                txtText1(TXTTSHS_KEYCD1).ImeMode = Windows.Forms.ImeMode.Hiragana

                txtText1(TXTTSHS_KEYCD1).MaxLength = 40

                txtText1(TXTTSHS_KEYCD1).Ank = TAG_KON

            Case SER_NHSTABL, SER_NHSVIEW                                                   '   �[�i�����t��e�[�u��

                SertxtCNT = 1

                strSerkey.Add(TXT_LBL_NHSCOD)

                lblWidth.Add(270)

                txtWidth.Add(320)

                txtText1(TXTTSHS_KEYCD1).ImeMode = Windows.Forms.ImeMode.Hiragana

                txtText1(TXTTSHS_KEYCD1).MaxLength = 40

                txtText1(TXTTSHS_KEYCD1).Ank = TAG_KON

            Case SER_TNSTABL, SER_TNSVIEW                                                   '   �q��[�i�w��ꏊ�e�[�u��

                SertxtCNT = 3

                strSerkey.Add(TXT_LBL_TNSCOD & "�^" & TXT_LBL_TNSNAM)
                strSerkey.Add(TXT_LBL_TNSSTC & "�^" & TXT_LBL_TNSSTN)
                strSerkey.Add(TXT_LBL_TNSNSC & "�^" & TXT_LBL_TNSNSN)

                lblWidth.Add(324)
                lblWidth.Add(324)
                lblWidth.Add(324)

                txtWidth.Add(320)
                txtWidth.Add(320)
                txtWidth.Add(320)

                txtText1(TXTTSHS_KEYCD1).ImeMode = Windows.Forms.ImeMode.Hiragana
                txtText1(TXTTSHS_KEYCD2).ImeMode = Windows.Forms.ImeMode.Hiragana
                txtText1(TXTTSHS_KEYCD3).ImeMode = Windows.Forms.ImeMode.Hiragana

                txtText1(TXTTSHS_KEYCD1).MaxLength = 40
                txtText1(TXTTSHS_KEYCD2).MaxLength = 40
                txtText1(TXTTSHS_KEYCD3).MaxLength = 40

                txtText1(TXTTSHS_KEYCD1).Ank = TAG_KON
                txtText1(TXTTSHS_KEYCD2).Ank = TAG_KON
                txtText1(TXTTSHS_KEYCD3).Ank = TAG_KON

            Case SER_TKKTABL, SER_TKKVIEW                                                   '   �������e�[�u��

                SertxtCNT = 1

                strSerkey.Add(TXT_LBL_TKKCOD)

                lblWidth.Add(270)

                txtWidth.Add(320)

                txtText1(TXTTSHS_KEYCD1).ImeMode = Windows.Forms.ImeMode.Hiragana

                txtText1(TXTTSHS_KEYCD1).MaxLength = 40

                txtText1(TXTTSHS_KEYCD1).Ank = TAG_KON

            Case SER_CATTABL, SER_CATVIEW                                                   '   �J�e�S���e�[�u��

                SertxtCNT = 1

                strSerkey.Add(TXT_LBL_CATCOD)

                lblWidth.Add(162)

                txtWidth.Add(32)

                txtText1(TXTTSHS_KEYCD1).ImeMode = Windows.Forms.ImeMode.Disable

                txtText1(TXTTSHS_KEYCD1).MaxLength = 4

                txtText1(TXTTSHS_KEYCD1).Ank = TAG_COD

                blnViewFirst = True

            Case SER_KKMTABL, SER_KKMVIEW                                                   '   ��v�Ȗڃe�[�u��

                SertxtCNT = 1

                strSerkey.Add(TXT_LBL_KKMCOD)

                lblWidth.Add(162)

                txtWidth.Add(32)

                txtText1(TXTTSHS_KEYCD1).ImeMode = Windows.Forms.ImeMode.Disable

                txtText1(TXTTSHS_KEYCD1).MaxLength = 4

                txtText1(TXTTSHS_KEYCD1).Ank = TAG_COD

            Case SER_SCTTABL                                                                '   ���i�ϊ��e�[�u��

                SertxtCNT = 4
                DataGetIndex = 0

                strSerkey.Add(TXT_LBL_SCTFGK)
                strSerkey.Add(TXT_LBL_SCTBMC)
                strSerkey.Add(TXT_LBL_SCTSHC)
                strSerkey.Add(TXT_LBL_SCTCHC)

                lblWidth.Add(162)
                lblWidth.Add(162)
                lblWidth.Add(162)
                lblWidth.Add(162)

                txtWidth.Add(913)
                txtWidth.Add(32)
                txtWidth.Add(125)
                txtWidth.Add(104)

                txtText1(TXTTSHS_KEYCD1).ImeMode = Windows.Forms.ImeMode.KatakanaHalf
                txtText1(TXTTSHS_KEYCD2).ImeMode = Windows.Forms.ImeMode.Disable
                txtText1(TXTTSHS_KEYCD3).ImeMode = Windows.Forms.ImeMode.Disable
                txtText1(TXTTSHS_KEYCD4).ImeMode = Windows.Forms.ImeMode.Disable

                txtText1(TXTTSHS_KEYCD1).MaxLength = 114
                txtText1(TXTTSHS_KEYCD2).MaxLength = 4
                txtText1(TXTTSHS_KEYCD3).MaxLength = 16
                txtText1(TXTTSHS_KEYCD4).MaxLength = 13

                txtText1(TXTTSHS_KEYCD1).Ank = TAG_KON
                txtText1(TXTTSHS_KEYCD2).Ank = TAG_COD
                '### 2021/06/07 S.SUGIURA UPD START �p���L�����͋��Ή�
                'txtText1(TXTTSHS_KEYCD3).Ank = TAG_COD
                txtText1(TXTTSHS_KEYCD3).Ank = TAG_EIJ & TAG_COD & TAG_KGU
                '### 2021/06/07 S.SUGIURA UPD END
                txtText1(TXTTSHS_KEYCD4).Ank = TAG_COD

            Case SER_SCTVIEW                                                                '   ���i�ϊ��e�[�u��

                SertxtCNT = 1

                strSerkey.Add(TXT_LBL_SCTSHC & "�^" & TXT_LBL_SCTCHC & "�^" & TXT_LBL_SCTSNM)

                lblWidth.Add(360)

                txtWidth.Add(320)

                txtText1(TXTTSHS_KEYCD1).ImeMode = Windows.Forms.ImeMode.KatakanaHalf

                txtText1(TXTTSHS_KEYCD1).MaxLength = 40

                txtText1(TXTTSHS_KEYCD1).Ank = TAG_KON
            Case SER_THSTABL                                                                '   �����x�Xð���

                SertxtCNT = 3
                DataGetIndex = 0

                strSerkey.Add(TXT_LBL_TRICOD)
                strSerkey.Add(TXT_LBL_STNCOD)
                strSerkey.Add(TXT_LBL_THSNAM)

                For lbllop As Integer = 0 To SertxtCNT - 1
                    lblWidth.Add(162)
                Next

                txtWidth.Add(104)
                txtWidth.Add(40)
                txtWidth.Add(349)

                txtText1(TXTTSHS_KEYCD1).ImeMode = Windows.Forms.ImeMode.Disable
                txtText1(TXTTSHS_KEYCD2).ImeMode = Windows.Forms.ImeMode.Disable
                txtText1(TXTTSHS_KEYCD3).ImeMode = Windows.Forms.ImeMode.Hiragana

                txtText1(TXTTSHS_KEYCD1).MaxLength = 13
                txtText1(TXTTSHS_KEYCD2).MaxLength = 5
                txtText1(TXTTSHS_KEYCD3).MaxLength = 40

                txtText1(TXTTSHS_KEYCD1).Ank = TAG_COD
                txtText1(TXTTSHS_KEYCD2).Ank = TAG_COD
                txtText1(TXTTSHS_KEYCD3).Ank = TAG_KON

                txtText1(TXTTSHS_KEYCD1).Search = False
                txtText1(TXTTSHS_KEYCD2).Search = false
                txtText1(TXTTSHS_KEYCD3).Search = False

                cmdCommand1(CMD_SER).Text = "����"

            Case Else
        End Select

        'If SerFlg = 0 Then
        '    '   ���������P�Z�b�g
        '    If Trim$(SerKey1) <> "" Then SqlWhere = SqlWhere & "AND     " & SerKey1 & vbLf
        '    '   ���������Q�Z�b�g
        '    If Trim$(SerKey2) <> "" Then SqlWhere = SqlWhere & "AND     " & SerKey2 & vbLf
        '    '   ���������R�Z�b�g
        '    If Trim$(SerKey3) <> "" Then SqlWhere = SqlWhere & "AND     " & SerKey3 & vbLf
        'End If
        ''   �Œ茟�������Z�b�g
        'If Trim$(SerKeyf) <> "" Then SqlWhere = SqlWhere & "AND     " & SerKeyf & vbLf

        '�g�p����e�L�X�g�{�b�N�X��L����
        '�e�L�X�g�{�b�N�X�̃v���p�e�B�ݒ�
        '���x���̃v���p�e�B�ݒ�
        '�e�L�X�g�{�b�N�X�E���x���̈ʒu�ݒ�
        '�e�L�X�g�{�b�N�X+���x���̈ʒu������Ȃ��ꍇ�͉��Ɉړ�

        Dim start_position_left As Integer = LblSerTitle.Right + 10 ' ���[�J�n�ʒu
        Dim start_position_top As Integer = LblSerTitle.Top         ' ��[�J�n�ʒu
        Dim end_position_right As Integer = fraFrame1.Right - 16    ' �E�[�I���ʒu
        Dim end_position_bottom As Integer = pnlTail.Top - 20       ' ���[�I���ʒu

        Dim position_left As Integer = 0
        Dim position_top As Integer = 0

        Dim set_width As List(Of Integer) = New List(Of Integer)() '   �ݒ肵�悤�Ƃ��Ă���e�L�X�g�{�b�N�X+���x���̕�

        For i As Integer = 0 To txtText1.Length - 1
            If SertxtCNT > i Then
                '��������
                set_width.Add(0)

                With lblValue1(i)
                    .Text = ""
                    .Visible = True
                    .Enabled = True

                    '.Width = (9 * LenB(strSerkey(i))) + 10                                  '   �\���T�C�Y��ݒ�  ��
                    .Width = lblWidth(i) + 10                                  '   �\���T�C�Y��ݒ�  ��
                    .Text = strSerkey(i)                                                    '   �����L�[�\��

                    '���x������ݒ�
                    set_width(i) = .Width
                End With

                With txtText1(i)
                    .Text = ""
                    .Visible = True
                    .Enabled = True
                    .Width = (8 * .MaxLength) + 11
                    .Width = txtWidth(i) + 11

                    Txt1Fmt(i) = .Text                                                      '   �t�H�[�}�b�g���L��
                    Txt1Ank(i) = Trim$(.Ank)                                                '   �^�O        ���L��
                    Txt1Len(i) = .MaxLength                                                 '   �ő啶�������L��

                    If Txt1Ank(i) = TAG_KON Then                                            '   ���ݍ��ڂ̏ꍇ
                        .MaxLength = 0                                                      '   �ő啶�����𖳐����ɂ���
                    End If

                    '���x����+�]��+�e�L�X�g�{�b�N�X����ݒ�
                    set_width(i) = set_width(i) + 5 + .Width
                End With
            End If
        Next

        position_left = start_position_left
        position_top = start_position_top

        For i As Integer = 0 To txtText1.Length - 1
            If SertxtCNT > i Then

                If position_left + set_width(i) < end_position_right Then
                Else
                    '���[���Z�b�g/��[��ύX
                    position_left = start_position_left
                    position_top = lblValue1(i - 1).Bottom + 5
                End If

                lblValue1(i).Left = position_left + 5                                 '   ���ʒu�ݒ�
                lblValue1(i).Top = position_top                                 '   ���ʒu�ݒ�

                txtText1(i).Left = lblValue1(i).Right + 5                        '   ���ʒu�ݒ�
                txtText1(i).Top = position_top                                 '   ���ʒu�ݒ�

                '���[�J�n�ʒu
                position_left += set_width(i) + 10
            End If
        Next

        '���W�I�{�^���z�u�ݒ�
        If position_left + 5 > PNLSelect.Left Then
            position_top = txtText1(SertxtCNT - 1).Bottom + 5
        End If

        PNLSelect.Top = position_top

        '�O���b�h�z�u�ݒ�
        If SertxtCNT = 0 Then
            LblSerTitle.Visible = False

            msfMstGrid1.Top = LblSerTitle.Bottom + 10
            msfMstGrid1.Height = pnlTail.Top - msfMstGrid1.Top - 10
        Else
            msfMstGrid1.Top = txtText1(SertxtCNT - 1).Bottom + 10
            msfMstGrid1.Top = PNLSelect.Bottom + 10
            msfMstGrid1.Height = pnlTail.Top - msfMstGrid1.Top - 10
        End If

        cmdCommand1(CMD_SER).Enabled = False                                                '   �R�}���h�{�^����\��
        cmdCommand1(CMD_PRN).Enabled = False                                                '   �R�}���h�{�^����\��
        cmdCommand1(CMD_EXT).Enabled = False                                                '   �R�}���h�{�^����\��
        cmdCommand1(CMD_ANS).Enabled = True                                                 '   �R�}���h�{�^���\��
        cmdCommand1(CMD_DEL).Enabled = False                                                '   �R�}���h�{�^����\��
        cmdCommand1(CMD_CRT).Enabled = False                                                '   �R�}���h�{�^����\��
        cmdCommand1(CMD_PRE).Enabled = False                                                '   �R�}���h�{�^����\��
        cmdCommand1(CMD_NXT).Enabled = False                                                '   �R�}���h�{�^����\��
        'Todo �����@�\�L����
        'cmdCommand1(CMD_PRE).Enabled = True                                                 '   �R�}���h�{�^����\��
        'cmdCommand1(CMD_NXT).Enabled = True                                                 '   �R�}���h�{�^����\��
        'cmdCommand1(CMD_PRE).Text = "�O��"                                                  '   �R�}���h�{�^����\��
        'cmdCommand1(CMD_NXT).Text = "����"                                                  '   �R�}���h�{�^����\��

        cmdCommand1(CMD_ETC).Enabled = False                                                '   �R�}���h�{�^����\��
        cmdCommand1(CMD_CAN).Enabled = False                                                '   �R�}���h�{�^����\��
        cmdCommand1(CMD_REN).Enabled = False                                                '   �R�}���h�{�^����\��
        cmdCommand1(CMD_END).Enabled = True                                                 '   �R�}���h�{�^���\��

    End Sub

    ''' <summary>
    ''' txtText1_KeyDown����
    ''' </summary>
    ''' <param name="sender">�������e</param>
    ''' <param name="e">�C�x���g���</param>
    ''' <remarks>txtText1�ɂă{�^���������ɏ������s��</remarks>
    Private Sub txtText1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs)
        'Dim sercod As String
        Dim index As Integer = DirectCast(sender, ITTextBox).Index
        Dim w_event As System.Windows.Forms.KeyEventArgs
        Dim shift_on As Boolean = False
        Dim inptxtchk As Boolean = False


        If SysMode = SYS_ON Then                                                            '   �V�X�e�����[�h��  �n�m�̎�
            Exit Sub                                                                        '   �ȉ��̏������s��Ȃ�
        Else                                                                                '   �V�X�e�����[�h���n�e�e�̎�
            SysMode = SYS_ON                                                                '   �V�X�e�����[�h���n�m
        End If

        Select Case e.KeyCode                                                               '   �L�[�R�[�h�`�F�b�N
            Case Keys.Return, Keys.Down                                                     '   ���s�L�[�E���L�[
                shift_on = e.Shift

                e.Handled = True                                                            '   �L�[�R�[�h�N���A

                If shift_on Then
                    Call Gen_TblSelect(SerMast, RED_EQU)                                '   �f�[�^����
                Else
                    With txtText1(index)
                        '���͕�����̕�����ʃ`�F�b�N���\��t���Ή�
                        .Text = Com_ChkInpDat(.Text, Txt1Ank(index))

                        .SelectionStart = 0                                                     '   �I�𕶎��ʒu���Z�b�g����

                        If InpTyp = ITY_ORG Then                                                '   ���͕����`�F�b�N�i�Ǝ������j
                            If InsMode = False Then                                             '   �㏑�����[�h�̏ꍇ
                                If Len(.Text) <> 0 Then                                         '   ����͂łȂ��ꍇ
                                    .SelectionLength = 1                                        '   �I�𕶎������Z�b�g����
                                End If
                            End If
                        Else                                                                    '   �v��������
                            If Len(.Text) <> 0 Then                                             '   ����͂łȂ��ꍇ
                                .SelectionLength = Len(.Text)                                   '   �I�𕶎������Z�b�g����
                            End If
                        End If
                    End With

                    Select Case index
                        Case TXTTSHS_KEYCD1

                        Case TXTTSHS_KEYCD2

                        Case TXTTSHS_KEYCD3

                        Case TXTTSHS_KEYCD4

                        Case TXTTSHS_KEYCD5

                        Case TXTTSHS_KEYCD6

                        Case Else

                    End Select

                    Select Case index
                        Case SertxtCNT - 1
                            Call Gen_TblSelect(SerMast, RED_EQU)                                '   �f�[�^����
                        Case Else
                            If index = DataGetIndex Then
                                For txtlop As Integer = 0 To DataGetIndex
                                    If Not String.IsNullOrEmpty(Trim(txtText1(txtlop).Text)) Then
                                        inptxtchk = True
                                    End If
                                Next

                                If inptxtchk Then
                                    Call Gen_TblSelect(SerMast, RED_EQU)                            '   �f�[�^����
                                Else
                                    Call Gen_Text1FocusSet(index, Keys.Down)                        '   �t�H�[�J�X�Z�b�g�T�u�b������
                                End If
                            Else
                                Call Gen_Text1FocusSet(index, Keys.Down)                        '   �t�H�[�J�X�Z�b�g�T�u�b������
                            End If
                    End Select
                End If
            Case Keys.Up                                                        '   ���L�[
                e.Handled = True                                                '   �L�[�R�[�h�N���A

                Call Gen_Text1FocusSet(index, Keys.Up)                          '   �t�H�[�J�X�Z�b�g�T�u�b������
            Case Keys.Left                                                      '   ���L�[
                If InsMode = False Then                                         '   �㏑�����[�h�̏ꍇ
                    e.Handled = True                                            '   �L�[�R�[�h�N���A

                    With txtText1(index)
                        If .SelectionStart <> 0 Then                            '   �J�[�\���ʒu���擪�łȂ��ꍇ
                            .SelectionStart = .SelectionStart - 1               '   �I�𕶎��ʒu���Z�b�g����
                            .SelectionLength = 1                                '   �I�𕶎������Z�b�g����
                        End If
                    End With
                End If
            Case Keys.Tab                                                       '   �^�u�L�[
                e.Handled = True                                                '   �L�[���͂��N���A����

                If Not e.Shift Then                                             '   �V�t�g��������Ă��Ȃ���
                    w_event = New System.Windows.Forms.KeyEventArgs(Keys.Down)
                Else                                                            '   �V�t�g��������Ă��鎞
                    w_event = New System.Windows.Forms.KeyEventArgs(Keys.Up)
                End If

                SysMode = SYS_OFF

                txtText1_KeyDown(sender, w_event)
            Case Else
        End Select

        SysMode = SYS_OFF                                                                   '   �V�X�e�����[�h���n�e�e
    End Sub

    ''' <summary>
    ''' txtText1_KeyPress����
    ''' </summary>
    ''' <param name="sender">�������e</param>
    ''' <param name="e">�C�x���g���</param>
    ''' <remarks>txtText1�ɂă{�^���������̏������s��</remarks>
    Private Sub txtText1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs)
        Dim Index As Integer = DirectCast(sender, ITTextBox).Index
        Dim KeyAscii As Integer = Asc(e.KeyChar)

        Select Case KeyAscii
            Case Keys.Return                                                                '   ���s�L�[
                e.Handled = True
            Case Keys.Escape                                                                '   �G�X�P�[�v�L�[
                e.Handled = True
            Case Keys.Back
            Case Else                                                                       '   ���̃L�[�̎�
                Call Com_ChrTypChk(Txt1Ank(Index), KeyAscii)                                '   ���͕�����̃`�F�b�N

                If KeyAscii = 0 Then
                    e.Handled = True
                End If
        End Select
    End Sub

    ''' <summary>
    ''' txtText1_LostFocus����
    ''' </summary>
    ''' <param name="sender">�������e</param>
    ''' <param name="e">�C�x���g���</param>
    ''' <remarks>txtText1�ɂă��X�g�t�H�[�J�X���̏������s��</remarks>
    Private Sub txtText1_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim Index As Integer = DirectCast(sender, ITTextBox).Index

        With txtText1(Index)
            .ForeColor = TEXT_FLST_COLOR                                            '   �����F��ύX����
            .BackColor = TEXT_LOST_COLOR                                            '   �w�i�F��ʏ�ɖ߂�
        End With
    End Sub

    ''' <summary>
    ''' �w�b�_�[�t�H�[�J�X�ړ�����
    ''' </summary>
    ''' <param name="Index">�ΏۃC���f�b�N�X�ԍ�</param>
    ''' <param name="KeyMode">�w�b�_�[�e�L�X�g�{�b�N�X�t�H�[�J�X�̐�����s��</param>
    ''' <remarks></remarks>
    Private Sub Gen_Text1FocusSet(ByVal Index As Integer, ByVal KeyMode As Integer)
        Select Case KeyMode                                                                 '   �L�[���[�h�`�F�b�N
            Case Keys.Down                                                                  '   ���s�L�[������
                Index = Index + 1                                                            '   ���̃e�L�X�g�{�b�N�X��

                Do While Index < SertxtCNT - 1
                    If txtText1(Index).ReadOnly Then                                        '   ���͋֎~���ڎ�
                        Index = Index + 1                                                    '   ���̃e�L�X�g�{�b�N�X��
                    Else
                        Exit Do                                                             '   �`�F�b�N�I��
                    End If
                Loop

                Inx1 = Index
            Case Keys.Up                                                                    '   �ど�L�[������
                If Index <> 0 Then                                                          '   �擪�̃e�L�X�g�{�b�N�X�łȂ��ꍇ
                    Index = Index - 1                                                        '   ���̃e�L�X�g�{�b�N�X��

                    Do While Index > 0
                        If txtText1(Index).ReadOnly Then                                    '   ���͋֎~���ڎ�
                            Index = Index - 1                                                '   �O�̃e�L�X�g�{�b�N�X��
                        Else
                            Exit Do                                                         '   �`�F�b�N�I��
                        End If
                    Loop

                    If Index = 0 And txtText1(Index).ReadOnly Then                          '   �擪���ڂ����͋֎~��
                        Do While Index < SertxtCNT - 1
                            If txtText1(Index).ReadOnly Then                                '   ���͋֎~���ڎ�
                                Index = Index + 1                                            '   ���̃e�L�X�g�{�b�N�X��
                            Else
                                Exit Do                                                     '   �`�F�b�N�I��
                            End If
                        Loop
                    End If
                End If

                Inx1 = Index
        End Select

        txtText1(Index).Focus()                                                              '   �t�H�[�J�X�Z�b�g
        Application.DoEvents()                                                              '   �E�C���h�E�Y�ɐ����n��
    End Sub

    ''' <summary>
    ''' serform�N������
    ''' </summary>
    ''' <param name="sender">�������e</param>
    ''' <param name="e">�C�x���g���</param>
    ''' <remarks>serform�N�����̏������s��</remarks>
    Private Sub serform_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated
        txtText1(TXTTSHS_KEYCD1).Focus()
        'msfMstGrid1.Focus()
    End Sub

    ''' <summary>
    ''' �O���b�h����������
    ''' </summary>
    ''' <remarks>�O���b�h�̏������������s��</remarks>
    Private Sub Gen_GridSet()

        SysMode = SYS_ON                                                                    '   �V�X�e�����[�h�Z�b�g

        ' �f�[�^�O���b�h�r���[
        With msfMstGrid1
            '������h�~
            Dim myType As Type = GetType(DataGridView)
            Dim myPropInfo As System.Reflection.PropertyInfo = myType.GetProperty("DoubleBuffered", System.Reflection.BindingFlags.Instance Or System.Reflection.BindingFlags.NonPublic)
            myPropInfo.SetValue(Me.msfMstGrid1, True, Nothing)
            For Each c As DataGridViewColumn In msfMstGrid1.Columns
                c.SortMode = DataGridViewColumnSortMode.NotSortable
            Next c

            .EnableHeadersVisualStyles = False
            .ColumnHeadersDefaultCellStyle.BackColor = LBL_BACK_COLOR
            .ColumnHeadersDefaultCellStyle.ForeColor = LBL_FORE_COLOR

            .Font = New System.Drawing.Font("�l�r �S�V�b�N", 12, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        End With


        Me.Cursor = Cursors.WaitCursor

        SerFlg = 0                                                                          '   �����t���O������

        '�O���b�h�񕝂̍��v�l��1210�Ƃ���

        Select Case SerMast
            Case SER_SHOVIEW                                                                '   ���i�}�X�^
                ItemCnt = 5

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_SHO_SHOCOD
                    .Columns(1).HeaderText = GRD_SHO_SHONAM
                    .Columns(2).HeaderText = GRD_SHO_SHOKNA
                    .Columns(3).HeaderText = GRD_SHO_SHOKKK
                    .Columns(4).HeaderText = GRD_SHO_SHOKTS

                    .Columns(0).Width = 120
                    .Columns(1).Width = 350
                    .Columns(2).Width = 350
                    .Columns(3).Width = 180
                    .Columns(4).Width = 210

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft

                    RowCntPerPage = 35
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

            Case SER_SHOMAST                                                                '   ���i�}�X�^
                '### 2021/05/11 S.SUGIURA UPD START PS3�Ή� ���ځF���[�J����ǉ�
                ItemCnt = 7

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_SHO_SHOCOD
                    .Columns(1).HeaderText = GRD_SHO_SHONAM
                    .Columns(2).HeaderText = GRD_SHO_SHOKNA
                    .Columns(3).HeaderText = GRD_SHO_SHOKKK
                    .Columns(4).HeaderText = GRD_SHO_SHOKTS
                    .Columns(5).HeaderText = GRD_MEK_MEKNAM
                    .Columns(6).HeaderText = GRD_CMM_DELFLG

                    .Columns(0).Width = 120
                    .Columns(1).Width = 350
                    .Columns(2).Width = 350
                    .Columns(3).Width = 180
                    .Columns(4).Width = 180
                    .Columns(5).Width = 350
                    .Columns(6).Width = 30

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(6).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

                    'RowCntPerPage = 35
                    RowCntPerPage = 34
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

                PNLSelect.Visible = True
                '### 2021/05/11 S.SUGIURA UPD END
            Case SER_SHOVIEW_ME                                                             '   ���i�}�X�^
                ItemCnt = 6

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_SHO_SHOCOD
                    .Columns(1).HeaderText = GRD_SHO_SHONAM
                    .Columns(2).HeaderText = GRD_SHO_SHOKNA
                    .Columns(3).HeaderText = GRD_SHO_SHOKKK
                    .Columns(4).HeaderText = GRD_SHO_SHOKTS
                    .Columns(5).HeaderText = GRD_CMM_DELFLG

                    .Columns(0).Width = 180
                    .Columns(1).Width = 500
                    .Columns(2).Width = 300
                    .Columns(3).Width = 200
                    .Columns(4).Width = 200
                    .Columns(5).Width = 30

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                End With

                PNLSelect.Visible = True

            Case SER_SHOVIEW_MEK                                                            '   ���i�}�X�^+���[�J�}�X�^
                ItemCnt = 5

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_SHO_SHOCOD
                    .Columns(1).HeaderText = GRD_SHO_SHONAM
                    .Columns(2).HeaderText = GRD_SHO_SHOKNA
                    .Columns(3).HeaderText = GRD_SHO_MEKCOD
                    .Columns(4).HeaderText = GRD_SHO_MEKNAM

                    .Columns(0).Width = 150
                    .Columns(1).Width = 400
                    .Columns(2).Width = 300
                    .Columns(3).Width = 120
                    .Columns(4).Width = 240

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                End With

            Case SER_TOKVIEW                                                                '   ���Ӑ�}�X�^
                ItemCnt = 3

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_TOK_TOKCOD
                    .Columns(1).HeaderText = GRD_TOK_TOKNAM
                    .Columns(2).HeaderText = GRD_TOK_TOKKNA

                    .Columns(0).Width = 120
                    .Columns(1).Width = 350
                    .Columns(2).Width = 740

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft

                    RowCntPerPage = 39
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

            Case SER_TOKMAST                                                                '   ���Ӑ�}�X�^
                ItemCnt = 4

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_TOK_TOKCOD
                    .Columns(1).HeaderText = GRD_TOK_TOKNAM
                    .Columns(2).HeaderText = GRD_TOK_TOKKNA
                    .Columns(3).HeaderText = GRD_CMM_DELFLG

                    .Columns(0).Width = 120
                    .Columns(1).Width = 350
                    .Columns(2).Width = 710
                    .Columns(3).Width = 30

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

                    RowCntPerPage = 39
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

                PNLSelect.Visible = True

            Case SER_SIRVIEW                                                                '   �d����}�X�^
                ItemCnt = 3

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_SIR_SIRCOD
                    .Columns(1).HeaderText = GRD_SIR_SIRNAM
                    .Columns(2).HeaderText = GRD_SIR_SIRKNA

                    .Columns(0).Width = 120
                    .Columns(1).Width = 350
                    .Columns(2).Width = 740

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft

                    RowCntPerPage = 39
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

            Case SER_SIRMAST                                                                '   �d����}�X�^
                ItemCnt = 4

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_SIR_SIRCOD
                    .Columns(1).HeaderText = GRD_SIR_SIRNAM
                    .Columns(2).HeaderText = GRD_SIR_SIRKNA
                    .Columns(3).HeaderText = GRD_CMM_DELFLG

                    .Columns(0).Width = 120
                    .Columns(1).Width = 350
                    .Columns(2).Width = 710
                    .Columns(3).Width = 30

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

                    RowCntPerPage = 39
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

                PNLSelect.Visible = True

            Case SER_MEKVIEW                                                                '   ���[�J�}�X�^
                ItemCnt = 3

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_MEK_MEKCOD
                    .Columns(1).HeaderText = GRD_MEK_MEKNAM
                    .Columns(2).HeaderText = GRD_MEK_MEKKNA

                    .Columns(0).Width = 120
                    .Columns(1).Width = 350
                    .Columns(2).Width = 740

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft

                    RowCntPerPage = 39
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

            Case SER_MEKTABL                                                                '   ���[�J�}�X�^
                ItemCnt = 4

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_MEK_MEKCOD
                    .Columns(1).HeaderText = GRD_MEK_MEKNAM
                    .Columns(2).HeaderText = GRD_MEK_MEKKNA
                    .Columns(3).HeaderText = GRD_CMM_DELFLG

                    .Columns(0).Width = 120
                    .Columns(1).Width = 350
                    .Columns(2).Width = 710
                    .Columns(3).Width = 30

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

                    RowCntPerPage = 39
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

                PNLSelect.Visible = True

            Case SER_TANVIEW                                                                '   �S���҃}�X�^
                ItemCnt = 2

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_TAN_TANCOD
                    .Columns(1).HeaderText = GRD_TAN_TANNAM

                    .Columns(0).Width = 120
                    .Columns(1).Width = 1090

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft

                    RowCntPerPage = 38
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

            Case SER_TANTABL                                                                '   �S���҃}�X�^
                ItemCnt = 3

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_TAN_TANCOD
                    .Columns(1).HeaderText = GRD_TAN_TANNAM
                    .Columns(2).HeaderText = GRD_CMM_DELFLG

                    .Columns(0).Width = 120
                    .Columns(1).Width = 1060
                    .Columns(2).Width = 30

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

                    RowCntPerPage = 37
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

                PNLSelect.Visible = True

            Case SER_TKSVIEW                                                                '   ���Ӑ�x�X�}�X�^
                ItemCnt = 4

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_TKS_TKSTKC
                    .Columns(1).HeaderText = GRD_TKS_TKSCOD
                    .Columns(2).HeaderText = GRD_TKS_TKSTNM
                    .Columns(3).HeaderText = GRD_TKS_TKSNAM

                    .Columns(0).Width = 120
                    .Columns(1).Width = 130
                    .Columns(2).Width = 350
                    .Columns(3).Width = 610

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft

                    RowCntPerPage = 39
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

            Case SER_TKSMAST                                                                '   ���Ӑ�x�X�}�X�^
                ItemCnt = 5

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_TKS_TKSTKC
                    .Columns(1).HeaderText = GRD_TKS_TKSCOD
                    .Columns(2).HeaderText = GRD_TKS_TKSTNM
                    .Columns(3).HeaderText = GRD_TKS_TKSNAM
                    .Columns(4).HeaderText = GRD_CMM_DELFLG

                    .Columns(0).Width = 120
                    .Columns(1).Width = 130
                    .Columns(2).Width = 350
                    .Columns(3).Width = 580
                    .Columns(4).Width = 30

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

                    RowCntPerPage = 39
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

                PNLSelect.Visible = True

            Case SER_TSHMAST                                                    '   ���Ӑ揤�i�}�X�^
                ItemCnt = 8

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_TSH_TOKCOD
                    .Columns(1).HeaderText = GRD_TSH_TOKNAM
                    .Columns(2).HeaderText = GRD_TSH_JANCOD
                    .Columns(3).HeaderText = GRD_TSH_TSHNAM
                    .Columns(4).HeaderText = GRD_TSH_SHONAM
                    .Columns(5).HeaderText = GRD_TSH_SIRCOD
                    .Columns(6).HeaderText = GRD_TSH_SIRNAM
                    .Columns(7).HeaderText = GRD_CMM_DELFLG

                    .Columns(0).Width = 120
                    .Columns(1).Width = 200
                    .Columns(2).Width = 120
                    .Columns(3).Width = 350
                    .Columns(4).Width = 0
                    .Columns(5).Width = 120
                    .Columns(6).Width = 270
                    .Columns(7).Width = 30

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(6).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(7).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

                    .Columns(4).Visible = False

                    RowCntPerPage = 37
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

                PNLSelect.Visible = True

            Case SER_TSHMAST2                                                   '   ���Ӑ揤�i�}�X�^
                ItemCnt = 7

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_TSH_TOKCOD
                    .Columns(1).HeaderText = GRD_TSH_JANCOD
                    .Columns(2).HeaderText = GRD_TSH_TSHNAM
                    .Columns(3).HeaderText = GRD_TSH_SHONAM
                    .Columns(4).HeaderText = GRD_TSH_SIRCOD
                    .Columns(5).HeaderText = GRD_TSH_SIRNAM
                    .Columns(6).HeaderText = GRD_CMM_DELFLG

                    .Columns(0).Width = 120
                    .Columns(1).Width = 120
                    .Columns(2).Width = 350
                    .Columns(3).Width = 0
                    .Columns(4).Width = 120
                    .Columns(5).Width = 470
                    .Columns(6).Width = 30

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(6).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

                    .Columns(3).Visible = False

                    RowCntPerPage = 37
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

                PNLSelect.Visible = True

            Case SER_TSHVIEW                                                    '   ���Ӑ揤�i�}�X�^
                ItemCnt = 7

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_TSH_TOKCOD
                    .Columns(1).HeaderText = GRD_TSH_TOKNAM
                    .Columns(2).HeaderText = GRD_TSH_JANCOD
                    .Columns(3).HeaderText = GRD_TSH_TSHNAM
                    .Columns(4).HeaderText = GRD_TSH_SHONAM
                    .Columns(5).HeaderText = GRD_TSH_SIRCOD
                    .Columns(6).HeaderText = GRD_TSH_SIRNAM

                    .Columns(0).Width = 120
                    .Columns(1).Width = 200
                    .Columns(2).Width = 120
                    .Columns(3).Width = 350
                    .Columns(4).Width = 0
                    .Columns(5).Width = 120
                    .Columns(6).Width = 300

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(6).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft

                    .Columns(4).Visible = False

                    RowCntPerPage = 37
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

            Case SER_TSHVIEW2                                                   '   ���Ӑ揤�i�}�X�^
                ItemCnt = 6

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_TSH_TOKCOD
                    .Columns(1).HeaderText = GRD_TSH_JANCOD
                    .Columns(2).HeaderText = GRD_TSH_TSHNAM
                    .Columns(3).HeaderText = GRD_TSH_SHONAM
                    .Columns(4).HeaderText = GRD_TSH_SIRCOD
                    .Columns(5).HeaderText = GRD_TSH_SIRNAM

                    .Columns(0).Width = 120
                    .Columns(1).Width = 120
                    .Columns(2).Width = 350
                    .Columns(3).Width = 0
                    .Columns(4).Width = 120
                    .Columns(5).Width = 500

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft

                    .Columns(3).Visible = False

                    RowCntPerPage = 37
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

            Case SER_SSHMAST, SER_SSHMAST2                                                      '   �d���揤�i�}�X�^
                ItemCnt = 5

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_SSH_SIRCOD
                    .Columns(1).HeaderText = GRD_SSH_SRINAM
                    .Columns(2).HeaderText = GRD_SSH_SHOCOD
                    .Columns(3).HeaderText = GRD_SSH_SHONAM
                    .Columns(4).HeaderText = GRD_CMM_DELFLG

                    .Columns(0).Width = 120
                    .Columns(1).Width = 350
                    .Columns(2).Width = 120
                    .Columns(3).Width = 590
                    .Columns(4).Width = 30

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

                    If SerMast = SER_SSHMAST Then
                        RowCntPerPage = 35
                    Else
                        RowCntPerPage = 37
                    End If

                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

                PNLSelect.Visible = True

            Case SER_SSHVIEW, SER_SSHVIEW2                                                      '   �d���揤�i�}�X�^
                ItemCnt = 4

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_SSH_SHOCOD
                    .Columns(1).HeaderText = GRD_SSH_SHONAM
                    .Columns(2).HeaderText = GRD_SSH_SIRCOD
                    .Columns(3).HeaderText = GRD_SSH_SRINAM

                    .Columns(0).Width = 120
                    .Columns(1).Width = 350
                    .Columns(2).Width = 120
                    .Columns(3).Width = 620

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft

                    RowCntPerPage = 37
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

            Case SER_BSHTABL                                                                '   �����Z���^�[�ʏ��i�e�[�u��
                ItemCnt = 4

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_BSH_BSHCOD
                    .Columns(1).HeaderText = GRD_BSH_SHOCOD
                    .Columns(2).HeaderText = GRD_BSH_SHONAM
                    .Columns(3).HeaderText = GRD_CMM_DELFLG

                    .Columns(0).Width = 120
                    .Columns(1).Width = 120
                    .Columns(2).Width = 940
                    .Columns(3).Width = 30

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

                    RowCntPerPage = 37
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

                PNLSelect.Visible = True

            Case SER_BSHVIEW                                                                '   �����Z���^�[�ʏ��i�e�[�u��
                ItemCnt = 3

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_BSH_BSHCOD
                    .Columns(1).HeaderText = GRD_BSH_SHOCOD
                    .Columns(2).HeaderText = GRD_BSH_SHONAM

                    .Columns(0).Width = 120
                    .Columns(1).Width = 120
                    .Columns(2).Width = 970

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft

                    RowCntPerPage = 38
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

            Case SER_TKBVIEW                                                                '   ���Ӑ敔��e�[�u��
                ItemCnt = 3

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_TKB_TOKCOD
                    .Columns(1).HeaderText = GRD_TKB_TKBCOD
                    .Columns(2).HeaderText = GRD_TKB_TKBNAM

                    .Columns(0).Width = 120
                    .Columns(1).Width = 130
                    .Columns(2).Width = 960

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft

                    RowCntPerPage = 39
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

            Case SER_ARETABL                                                                '   �G���A�e�[�u��
                ItemCnt = 3

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_ARE_ARECOD
                    .Columns(1).HeaderText = GRD_ARE_ARENAM
                    .Columns(2).HeaderText = GRD_CMM_DELFLG

                    .Columns(0).Width = 120
                    .Columns(1).Width = 590 + 470
                    .Columns(2).Width = 30

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

                    RowCntPerPage = 39
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

                PNLSelect.Visible = True

            Case SER_AREVIEW                                                                '   �G���A�e�[�u��
                ItemCnt = 2

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_ARE_ARECOD
                    .Columns(1).HeaderText = GRD_ARE_ARENAM

                    .Columns(0).Width = 120
                    .Columns(1).Width = 620 + 470

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft

                    RowCntPerPage = 39
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

            Case SER_BMNTABL                                                                '   ����e�[�u��
                ItemCnt = 3

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_BMN_BMNCOD
                    .Columns(1).HeaderText = GRD_BMN_BMNNAM
                    .Columns(2).HeaderText = GRD_CMM_DELFLG

                    .Columns(0).Width = 120
                    .Columns(1).Width = 1060
                    .Columns(2).Width = 30

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

                    RowCntPerPage = 39
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

                PNLSelect.Visible = True

            Case SER_BMNVIEW                                                                '   ����e�[�u��
                ItemCnt = 2

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_BMN_BMNCOD
                    .Columns(1).HeaderText = GRD_BMN_BMNNAM

                    .Columns(0).Width = 160
                    .Columns(1).Width = 1050

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft

                    RowCntPerPage = 39
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

            Case SER_SBNTABL                                                                '   ���i�����ރe�[�u��
                ItemCnt = 3

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_SBN_SBNCOD
                    .Columns(1).HeaderText = GRD_SBN_SBNNAM
                    .Columns(2).HeaderText = GRD_CMM_DELFLG

                    .Columns(0).Width = 120
                    .Columns(1).Width = 1060
                    .Columns(2).Width = 30

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

                    RowCntPerPage = 39
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

                PNLSelect.Visible = True

            Case SER_SBNVIEW                                                                '   ���i�����ރe�[�u��
                ItemCnt = 2

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_SBN_SBNCOD
                    .Columns(1).HeaderText = GRD_SBN_SBNNAM

                    .Columns(0).Width = 160
                    .Columns(1).Width = 1050

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft

                    RowCntPerPage = 39
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

            Case SER_TKJTABL                                                                '   ���Ӑ抨��ȖڃR�[�h�e�[�u��
                ItemCnt = 3

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_TKJ_TKJCOD
                    .Columns(1).HeaderText = GRD_TKJ_TKJNAM
                    .Columns(2).HeaderText = GRD_CMM_DELFLG

                    .Columns(0).Width = 130
                    .Columns(1).Width = 1050
                    .Columns(2).Width = 30

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

                    RowCntPerPage = 39
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

                PNLSelect.Visible = True

            Case SER_TKJVIEW                                                                '   ���Ӑ抨��ȖڃR�[�h�e�[�u��
                ItemCnt = 2

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_TKJ_TKJCOD
                    .Columns(1).HeaderText = GRD_TKJ_TKJNAM

                    .Columns(0).Width = 130
                    .Columns(1).Width = 1080

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft

                    RowCntPerPage = 39
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

            Case SER_DNKTABL                                                                '   �`�[�敪�e�[�u��
                ItemCnt = 3

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_DNK_DNKKBN
                    .Columns(1).HeaderText = GRD_DNK_DNKNAM
                    .Columns(2).HeaderText = GRD_CMM_DELFLG

                    .Columns(0).Width = 120
                    .Columns(1).Width = 1060
                    .Columns(2).Width = 30

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

                    RowCntPerPage = 39
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

                PNLSelect.Visible = True

            Case SER_DNKVIEW                                                                '   �`�[�敪�e�[�u��
                ItemCnt = 2

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_DNK_DNKKBN
                    .Columns(1).HeaderText = GRD_DNK_DNKNAM

                    .Columns(0).Width = 160
                    .Columns(1).Width = 1050

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft

                    RowCntPerPage = 39
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

            Case SER_DPTTABL                                                                '   �`�[�p�^�[���敪�e�[�u��
                ItemCnt = 3

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_DPT_DPTKBN
                    .Columns(1).HeaderText = GRD_DPT_DPTNAM
                    .Columns(2).HeaderText = GRD_CMM_DELFLG

                    .Columns(0).Width = 150
                    .Columns(1).Width = 1030
                    .Columns(2).Width = 30

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

                    RowCntPerPage = 39
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

                PNLSelect.Visible = True

            Case SER_DPTVIEW                                                                '   �`�[�p�^�[���敪�e�[�u��
                ItemCnt = 2

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_DPT_DPTKBN
                    .Columns(1).HeaderText = GRD_DPT_DPTNAM

                    .Columns(0).Width = 150
                    .Columns(1).Width = 1060

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft

                    RowCntPerPage = 39
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

            Case SER_KBNTABL                                                                '   �敪���̃e�[�u��
                ItemCnt = 3

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_KBN_KBNCOD
                    .Columns(1).HeaderText = GRD_KBN_KBNNAM
                    .Columns(2).HeaderText = GRD_CMM_DELFLG

                    .Columns(0).Width = 120
                    .Columns(1).Width = 1060
                    .Columns(2).Width = 30

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

                    RowCntPerPage = 39
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

                PNLSelect.Visible = True

            Case SER_KBNVIEW                                                                '   �敪���̃e�[�u��
                ItemCnt = 2

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_KBN_KBNCOD
                    .Columns(1).HeaderText = GRD_KBN_KBNNAM

                    .Columns(0).Width = 160
                    .Columns(1).Width = 1050

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft

                    RowCntPerPage = 39
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

            Case SER_BSTVIEW                                                                '   �����Z���^�[�e�[�u��
                ItemCnt = 2

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_BST_BSTCOD
                    .Columns(1).HeaderText = GRD_BST_BSTNAM

                    .Columns(0).Width = 180
                    .Columns(1).Width = 1030

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft

                    RowCntPerPage = 37
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

            Case SER_BSTTABL                                                                '   �����Z���^�[�e�[�u��
                ItemCnt = 3

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_BST_BSTCOD
                    .Columns(1).HeaderText = GRD_BST_BSTNAM
                    .Columns(2).HeaderText = GRD_CMM_DELFLG

                    .Columns(0).Width = 180
                    .Columns(1).Width = 1000
                    .Columns(2).Width = 30

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

                    RowCntPerPage = 37
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

                PNLSelect.Visible = True

            Case SER_SCGTABL                                                                '   ���i�ϊ��e�[�u��
                ItemCnt = 6

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_SCG_BMNCOD
                    .Columns(1).HeaderText = GRD_SCG_BMNNAM
                    .Columns(2).HeaderText = GRD_SCG_TKJCOD
                    .Columns(3).HeaderText = GRD_SCG_TKJNAM
                    .Columns(4).HeaderText = GRD_SCG_TSHCOD
                    .Columns(5).HeaderText = GRD_CMM_DELFLG

                    .Columns(0).Width = 120
                    .Columns(1).Width = 350
                    .Columns(2).Width = 0
                    .Columns(3).Width = 0
                    .Columns(4).Width = 740
                    .Columns(5).Width = 0

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

                    .Columns(2).Visible = False
                    .Columns(3).Visible = False
                    .Columns(5).Visible = False

                    RowCntPerPage = 38
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With
                'Case SER_SCGTABL                                                                '   ���i�ϊ��e�[�u��
                '    ItemCnt = 3

                '    With msfMstGrid1
                '        .ColumnCount = ItemCnt
                '        .Columns(0).HeaderText = "����R�[�h"
                '        .Columns(1).HeaderText = "���@��@���@��"
                '        .Columns(2).HeaderText = LBL_TOKCAP & "���i�R�[�h"

                '        .Columns(0).Width = 160
                '        .Columns(1).Width = 800
                '        .Columns(2).Width = 250

                '        .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                '        .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                '        .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                '    End With

            Case SER_SCGVIEW                                                                '   ���i�ϊ��e�[�u��
                ItemCnt = 10

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_SCG_TOKCOD
                    .Columns(1).HeaderText = GRD_SCG_TOKNAM
                    .Columns(2).HeaderText = GRD_SCG_BMNCDH
                    .Columns(3).HeaderText = GRD_SCG_BMNNMH
                    .Columns(4).HeaderText = GRD_SCG_TKJCOD
                    .Columns(5).HeaderText = GRD_SCG_TKJNAM
                    .Columns(6).HeaderText = GRD_SCG_TOKNAM
                    .Columns(7).HeaderText = GRD_SCG_SHOCOD
                    .Columns(8).HeaderText = GRD_SCG_SHONAM
                    .Columns(9).HeaderText = GRD_CMM_DELFLG

                    .Columns(0).Width = 80
                    .Columns(1).Width = 200
                    .Columns(2).Width = 80
                    .Columns(3).Width = 120
                    .Columns(4).Width = 0
                    .Columns(5).Width = 0
                    .Columns(6).Width = 140
                    .Columns(7).Width = 120
                    .Columns(8).Width = 440
                    .Columns(9).Width = 30

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(6).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(7).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(8).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(9).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

                    .Columns(4).Visible = False
                    .Columns(5).Visible = False

                    RowCntPerPage = 38
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

                PNLSelect.Visible = True

            Case SER_BRBTABL                                                                '   �啪�ރe�[�u��
                ItemCnt = 3

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_BRB_BRBCOD
                    .Columns(1).HeaderText = GRD_BRB_BRBNAM
                    .Columns(2).HeaderText = GRD_CMM_DELFLG

                    .Columns(0).Width = 120
                    .Columns(1).Width = 1060
                    .Columns(2).Width = 30

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

                    RowCntPerPage = 39
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

                PNLSelect.Visible = True

            Case SER_BRBVIEW                                                                '   �啪�ރe�[�u��
                ItemCnt = 2

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_BRB_BRBCOD
                    .Columns(1).HeaderText = GRD_BRB_BRBNAM

                    .Columns(0).Width = 160
                    .Columns(1).Width = 1050

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft

                    RowCntPerPage = 39
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

            Case SER_BRMTABL                                                                '   �����ރe�[�u��
                ItemCnt = 4

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_BRM_BRBCOD
                    .Columns(1).HeaderText = GRD_BRM_BRMCOD
                    .Columns(2).HeaderText = GRD_BRM_BRBNAM
                    .Columns(3).HeaderText = GRD_CMM_DELFLG

                    .Columns(0).Width = 120
                    .Columns(1).Width = 120
                    .Columns(2).Width = 940
                    .Columns(3).Width = 30

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter


                    RowCntPerPage = 39
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

                PNLSelect.Visible = True

            Case SER_BRMVIEW                                                                '   �����ރe�[�u��
                ItemCnt = 3

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_BRM_BRBCOD
                    .Columns(1).HeaderText = GRD_BRM_BRMCOD
                    .Columns(2).HeaderText = GRD_BRM_BRBNAM

                    .Columns(0).Width = 160
                    .Columns(1).Width = 160
                    .Columns(2).Width = 890

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft

                    RowCntPerPage = 39
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

            Case SER_BRSTABL                                                                '   �����ރe�[�u��
                ItemCnt = 5

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_BRS_BRBCOD
                    .Columns(1).HeaderText = GRD_BRS_BRMCOD
                    .Columns(2).HeaderText = GRD_BRS_BRSCOD
                    .Columns(3).HeaderText = GRD_BRS_BRSNAM
                    .Columns(4).HeaderText = GRD_CMM_DELFLG

                    .Columns(0).Width = 120
                    .Columns(1).Width = 120
                    .Columns(2).Width = 120
                    .Columns(3).Width = 820
                    .Columns(4).Width = 30

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

                    RowCntPerPage = 39
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

                PNLSelect.Visible = True

            Case SER_BRSVIEW                                                                '   �����ރe�[�u��
                ItemCnt = 4

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_BRS_BRBCOD
                    .Columns(1).HeaderText = GRD_BRS_BRMCOD
                    .Columns(2).HeaderText = GRD_BRS_BRSCOD
                    .Columns(3).HeaderText = GRD_BRS_BRSNAM

                    .Columns(0).Width = 160
                    .Columns(1).Width = 160
                    .Columns(2).Width = 160
                    .Columns(3).Width = 730

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft

                    RowCntPerPage = 39
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

            Case SER_BSYVIEW                                                                '   �����e�[�u��
                ItemCnt = 3

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_BSY_BMNCOD
                    .Columns(1).HeaderText = GRD_BSY_BMNNAM
                    .Columns(2).HeaderText = GRD_BSY_BMNKNA

                    .Columns(0).Width = 120
                    .Columns(1).Width = 350
                    .Columns(2).Width = 740

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft

                    RowCntPerPage = 39
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

            Case SER_BSYTABL                                                                '   �����e�[�u��
                ItemCnt = 4

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_BSY_BMNCOD
                    .Columns(1).HeaderText = GRD_BSY_BMNNAM
                    .Columns(2).HeaderText = GRD_BSY_BMNKNA
                    .Columns(3).HeaderText = GRD_CMM_DELFLG

                    .Columns(0).Width = 120
                    .Columns(1).Width = 350
                    .Columns(2).Width = 710
                    .Columns(3).Width = 30

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter


                    RowCntPerPage = 39
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

                PNLSelect.Visible = True

            Case SER_KENTABL                                                                '   �s���{���e�[�u��
                ItemCnt = 3

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_KEN_KENCOD
                    .Columns(1).HeaderText = GRD_KEN_KENNAM
                    .Columns(2).HeaderText = GRD_CMM_DELFLG

                    .Columns(0).Width = 200
                    .Columns(1).Width = 980
                    .Columns(2).Width = 30

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

                    RowCntPerPage = 39
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

                PNLSelect.Visible = True

            Case SER_KENVIEW                                                                '   �s���{���e�[�u��
                ItemCnt = 2

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_KEN_KENCOD
                    .Columns(1).HeaderText = GRD_KEN_KENNAM

                    .Columns(0).Width = 150
                    .Columns(1).Width = 1060

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft

                    RowCntPerPage = 39
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

            Case SER_NHSTABL                                                                '   �[�i�����t��e�[�u��
                ItemCnt = 3

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_NHS_NHSCOD
                    .Columns(1).HeaderText = GRD_NHS_NHSNAM
                    .Columns(2).HeaderText = GRD_CMM_DELFLG

                    .Columns(0).Width = 180
                    .Columns(1).Width = 1000
                    .Columns(2).Width = 30

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

                    RowCntPerPage = 39
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

                PNLSelect.Visible = True

            Case SER_NHSVIEW                                                                '   �[�i�����t��e�[�u��
                ItemCnt = 7

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_NHS_NHSCOD
                    .Columns(1).HeaderText = GRD_NHS_NHSNAM
                    .Columns(2).HeaderText = GRD_NHS_ZIPCOD
                    .Columns(3).HeaderText = GRD_NHS_ADRES1
                    .Columns(4).HeaderText = GRD_NHS_ADRES2
                    .Columns(5).HeaderText = GRD_NHS_TELNUM
                    .Columns(6).HeaderText = GRD_NHS_FAXNUM

                    .Columns(0).Width = 180
                    .Columns(1).Width = 350
                    .Columns(2).Width = 120
                    .Columns(3).Width = 350
                    .Columns(4).Width = 350
                    .Columns(5).Width = 160
                    .Columns(6).Width = 160

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(6).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft

                    RowCntPerPage = 37
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * 37) + 19
                End With

            Case SER_TNSTABL                                                                '   �q��[�i�w��ꏊ�e�[�u��
                ItemCnt = 7

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_TNS_TOKCOD
                    .Columns(1).HeaderText = GRD_TNS_TOKNAM
                    .Columns(2).HeaderText = GRD_TNS_TKSCOD
                    .Columns(3).HeaderText = GRD_TNS_TKSNAM
                    .Columns(4).HeaderText = GRD_TNS_BSHCOD
                    .Columns(5).HeaderText = GRD_TNS_NSTNAM
                    .Columns(6).HeaderText = GRD_CMM_DELFLG

                    .Columns(0).Width = 100
                    .Columns(1).Width = 350
                    .Columns(2).Width = 130
                    .Columns(3).Width = 350
                    .Columns(4).Width = 100
                    .Columns(5).Width = 350
                    .Columns(6).Width = 30

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(6).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

                    RowCntPerPage = 36
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 19
                End With

                PNLSelect.Visible = True

            Case SER_TNSVIEW                                                                '   �q��[�i�w��ꏊ�e�[�u��
                ItemCnt = 6

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_TNS_TOKCOD
                    .Columns(1).HeaderText = GRD_TNS_TOKNAM
                    .Columns(2).HeaderText = GRD_TNS_TKSCOD
                    .Columns(3).HeaderText = GRD_TNS_TKSNAM
                    .Columns(4).HeaderText = GRD_TNS_BSHCOD
                    .Columns(5).HeaderText = GRD_TNS_NSTNAM

                    .Columns(0).Width = 100
                    .Columns(1).Width = 350
                    .Columns(2).Width = 130
                    .Columns(3).Width = 350
                    .Columns(4).Width = 100
                    .Columns(5).Width = 380

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft

                    RowCntPerPage = 37
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

            Case SER_TKKTABL                                                                '   �������e�[�u��
                ItemCnt = 3

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_TKK_KKKCOD
                    .Columns(1).HeaderText = GRD_TKK_KKKNAM
                    .Columns(2).HeaderText = GRD_CMM_DELFLG

                    .Columns(0).Width = 130
                    .Columns(1).Width = 1050
                    .Columns(2).Width = 30

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

                    RowCntPerPage = 39
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

                PNLSelect.Visible = True

            Case SER_TKKVIEW                                                                '   �������e�[�u��
                ItemCnt = 2

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_TKK_KKKCOD
                    .Columns(1).HeaderText = GRD_TKK_KKKNAM

                    .Columns(0).Width = 130
                    .Columns(1).Width = 1080

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft

                    RowCntPerPage = 39
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

            Case SER_CATTABL                                                                '   �J�e�S���e�[�u��
                ItemCnt = 3

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_CAT_CTGCOD
                    .Columns(1).HeaderText = GRD_CAT_CTGNAM
                    .Columns(2).HeaderText = GRD_CMM_DELFLG

                    .Columns(0).Width = 130
                    .Columns(1).Width = 1050
                    .Columns(2).Width = 30

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

                    RowCntPerPage = 39
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

                PNLSelect.Visible = True

            Case SER_CATVIEW                                                                '   �J�e�S���e�[�u��
                ItemCnt = 2

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_CAT_CTGCOD
                    .Columns(1).HeaderText = GRD_CAT_CTGNAM

                    .Columns(0).Width = 130
                    .Columns(1).Width = 1080

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft

                    RowCntPerPage = 39
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

            Case SER_KKMTABL                                                                '   ��v�Ȗڃe�[�u��
                ItemCnt = 3

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_KKM_KKMCOD
                    .Columns(1).HeaderText = GRD_KKM_KKMNAM
                    .Columns(2).HeaderText = GRD_CMM_DELFLG

                    .Columns(0).Width = 130
                    .Columns(1).Width = 1050
                    .Columns(2).Width = 30

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

                    RowCntPerPage = 39
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

                PNLSelect.Visible = True

            Case SER_KKMVIEW                                                                '   ��v�Ȗڃe�[�u��
                ItemCnt = 2

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_KKM_KKMCOD
                    .Columns(1).HeaderText = GRD_KKM_KKMNAM

                    .Columns(0).Width = 130
                    .Columns(1).Width = 1080

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft

                    RowCntPerPage = 39
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

            Case SER_SCTTABL                                                                '   ���i�ϊ��e�[�u��
                ItemCnt = 10

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_SCT_TOKCOD
                    .Columns(1).HeaderText = GRD_SCT_TOKNAM
                    .Columns(2).HeaderText = GRD_SCT_BMNCDH
                    .Columns(3).HeaderText = GRD_SCT_BMNNMH
                    .Columns(4).HeaderText = GRD_SCT_TKJCOD
                    .Columns(5).HeaderText = GRD_SCT_TKJNAM
                    .Columns(6).HeaderText = GRD_SCT_TSHCOD
                    .Columns(7).HeaderText = GRD_SCT_SHOCOD
                    .Columns(8).HeaderText = GRD_SCT_SHONAM
                    .Columns(9).HeaderText = GRD_CMM_DELFLG

                    .Columns(0).Width = 80
                    .Columns(1).Width = 200
                    .Columns(2).Width = 80
                    .Columns(3).Width = 120
                    .Columns(4).Width = 0
                    .Columns(5).Width = 0
                    .Columns(6).Width = 140
                    .Columns(7).Width = 120
                    .Columns(8).Width = 440
                    .Columns(9).Width = 30

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(6).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(7).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(8).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(9).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

                    .Columns(4).Visible = False
                    .Columns(5).Visible = False

                    RowCntPerPage = 37
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

                PNLSelect.Visible = True

            Case SER_SCTVIEW                                                                '   ���i�ϊ��e�[�u��
                ItemCnt = 9

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_SCT_TOKCOD
                    .Columns(1).HeaderText = GRD_SCT_TOKNAM
                    .Columns(2).HeaderText = GRD_SCT_BMNCDH
                    .Columns(3).HeaderText = GRD_SCT_BMNNMH
                    .Columns(4).HeaderText = GRD_SCT_TKJCOD
                    .Columns(5).HeaderText = GRD_SCT_TKJNAM
                    .Columns(6).HeaderText = GRD_SCT_TSHCOD
                    .Columns(7).HeaderText = GRD_SCT_SHOCOD
                    .Columns(8).HeaderText = GRD_SCT_SHONAM

                    .Columns(0).Width = 80
                    .Columns(1).Width = 200
                    .Columns(2).Width = 80
                    .Columns(3).Width = 120
                    .Columns(4).Width = 0
                    .Columns(5).Width = 0
                    .Columns(6).Width = 140
                    .Columns(7).Width = 120
                    .Columns(8).Width = 470

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                    .Columns(6).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(7).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(8).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft

                    .Columns(4).Visible = False
                    .Columns(5).Visible = False

                    RowCntPerPage = 39
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

            Case SER_THSTABL                                                                '   ���[�J�}�X�^
                ItemCnt = 3

                With msfMstGrid1
                    .ColumnCount = ItemCnt
                    .Columns(0).HeaderText = GRD_THS_TRICOD
                    .Columns(1).HeaderText = GRD_THS_STNCOD
                    .Columns(2).HeaderText = GRD_THS_THSNAM

                    .Columns(0).Width = 140
                    .Columns(1).Width = 70
                    .Columns(2).Width = 740

                    .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft

                    RowCntPerPage = 39
                    .Height = .ColumnHeadersHeight + (.RowTemplate.Height * RowCntPerPage) + 2
                End With

            Case Else
        End Select

        If Not PNLSelect.Visible Then
            msfMstGrid1.Top = txtText1(SertxtCNT - 1).Bottom + 10
        End If

        Application.DoEvents()                                                              '   �E�C���h�E�Y�ɐ����n��

        'Select Case SerMast
        '    Case SER_BSYVIEW
        '        Call Gen_TblSelect(SerMast, RED_EQU)                                        '   �\���e�[�u���I������
        'End Select

        If SerFlg = 1 Then
            For i As Integer = 0 To MAX_TXT1 - 1
                txtText1(i).Text = ""
            Next
        End If

        msfMstGrid1.Focus()

        Me.Cursor = Cursors.Default

        SysMode = SYS_OFF                                                                   '   �V�X�e�����[�h�Z�b�g
    End Sub

    ''' <summary>
    ''' TabKey�����C�x���g
    ''' </summary>
    ''' <param name="forward">�������</param>
    ''' <returns>���s����</returns>
    ''' <remarks>TabKey�����C�x���g���㏑������</remarks>
    Protected Overrides Function ProcessTabKey(ByVal forward As Boolean) As Boolean
        Return False    '[Tab]�𖳌��ɂ���
    End Function

    ''' <summary>
    ''' �e�L�X�g�{�b�N�X�ύX����
    ''' </summary>
    ''' <param name="sender">�������e</param>
    ''' <param name="e">�C�x���g���</param>
    ''' <remarks>�e�L�X�g�{�b�N�X�̒l��ύX���ɏ������s��</remarks>
    Private Sub txtText1_Change(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim Index As Integer = DirectCast(sender, ITTextBox).Index

        If InsMode = False Then                                                             '   �㏑�����[�h�̏ꍇ
            With txtText1(Index)
                If Trim$(.Text) <> "" Then                                                  '   ����͂łȂ��ꍇ
                    .SelectionLength = 1                                                    '   �I�𕶎������Z�b�g����
                End If
            End With
        End If
    End Sub

    ''' <summary>
    ''' �e�L�X�g�{�b�N�X�t�H�[�J�X������
    ''' </summary>
    ''' <param name="sender">�������e</param>
    ''' <param name="e">�C�x���g���</param>
    ''' <remarks>�e�L�X�g�{�b�N�X�̃t�H�[�J�X���ɏ������s��</remarks>
    Private Sub txtText1_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim Index As Integer

        Index = DirectCast(sender, ITTextBox).Index

        With txtText1(Index)
            .TabIndex = 0                                                       '   �^�u�C���f�b�N�X�O�Z�b�g

            cmdCommand1(CMD_SER).Enabled = False
            If .Search Then
                If Not .ReadOnly Then
                    cmdCommand1(CMD_SER).Enabled = True
                End If
            End If

            .ForeColor = TEXT_FGOT_COLOR                                    '   �����F��ύX����
            .BackColor = TEXT_GOT_COLOR                                     '   �w�i�F��ύX����

            .SelectionStart = 0                                                 '   �I���J�n�ʒu���Z�b�g����
            '   �������ڂ̏ꍇ

            If Len(.Text) <> 0 Then                                             '   ����͂łȂ��ꍇ
                .SelectionLength = Len(.Text)                                   '   �I�𕶎������Z�b�g����
            End If

            Inx1 = Index                                                        '   �C���f�b�N�X�ԍ��Z�b�g
        End With
    End Sub

    ''' <summary>
    ''' �R���g���[���z�񉻏���
    ''' </summary>
    ''' <remarks>��ʃR���g���[����z�񉻂���</remarks>
    Private Sub Gen_ArrayListSet()
        Dim lop As Integer
        Dim txt As ITTextBox
        Dim lbl As ITLabel
        Dim cmd As ITCommandButton

        Try
            For lop = 0 To fraFrame1.Controls.Count - 1
                If TypeOf fraFrame1.Controls(lop) Is ITTextBox Then
                    txt = DirectCast(fraFrame1.Controls(lop), ITControl.ITTextBox)

                    If txt.SubName = "txtText1" Then
                        txtText1(txt.Index) = txt

                        AddHandler txtText1(txt.Index).TextChanged, AddressOf txtText1_Change
                        AddHandler txtText1(txt.Index).Click, AddressOf txtText1_GotFocus
                        AddHandler txtText1(txt.Index).Enter, AddressOf txtText1_GotFocus
                        AddHandler txtText1(txt.Index).Leave, AddressOf txtText1_LostFocus
                        AddHandler txtText1(txt.Index).KeyDown, AddressOf txtText1_KeyDown
                        AddHandler txtText1(txt.Index).KeyPress, AddressOf txtText1_KeyPress
                    End If
                ElseIf TypeOf fraFrame1.Controls(lop) Is ITLabel Then
                    lbl = DirectCast(fraFrame1.Controls(lop), ITControl.ITLabel)

                    If lbl.SubName = "lblValue1" Then
                        lblValue1(lbl.Index) = lbl
                    End If
                End If
            Next

            For lop = 0 To pnlTail.Controls.Count - 1
                If TypeOf pnlTail.Controls(lop) Is ITCommandButton Then
                    cmd = DirectCast(pnlTail.Controls(lop), ITCommandButton)
                    If cmd.SubName = "cmdCommand1" Then
                        cmdCommand1(cmd.Index) = cmd
                        AddHandler cmdCommand1(cmd.Index).Click, AddressOf cmdCommand1_Click
                    End If
                End If
            Next

        Catch ex As Exception
            MsgBox(lop)
            MsgBox(ex.ToString)
            MsgBox(ex.StackTrace)
        End Try
    End Sub

    ''' <summary>
    ''' �R�}���h�{�^��1����
    ''' </summary>
    ''' <param name="sender">�������e</param>
    ''' <param name="e">�C�x���g���</param>
    ''' <remarks>�R�}���h�{�^������</remarks>
    Private Sub cmdCommand1_Click(ByVal sender As System.Object, ByVal e As EventArgs)
        If SysMode = SYS_ON Then                                                            '   �V�X�e�����[�h��  �n�m�̎�
            Exit Sub                                                                        '   �ȉ��̏������s��Ȃ�
        Else                                                                                '   �V�X�e�����[�h���n�e�e�̎�
            SysMode = SYS_ON                                                                '   �V�X�e�����[�h���n�m
        End If

        Select Case DirectCast(sender, ITCommandButton).Index                               '   �R�}���h�{�^���̃`�F�b�N
            Case CMD_END                                                                    '   �I���{�^��
                Call Gen_CmdEnd()
            Case CMD_CAN                                                                    '   �N���A�{�^��
            Case CMD_ETC                                                                    '   �g���@�\
            Case CMD_SER                                                                    '   ����
                Call Gen_CmdSer()
            Case CMD_PRE                                                                    '   �O����
                Call Gen_CmdPre()
            Case CMD_NXT                                                                    '   ������
                Call Gen_CmdNxt()
            Case CMD_ANS                                                                    '   �o�^�E�폜�{�^��
                Call Gen_CmdAns()
            Case Else
        End Select

        SysMode = SYS_OFF                                                                   '   �V�X�e�����[�h�n�e�e
    End Sub

    ''' <summary>
    ''' �Z���_�u���N���b�N����
    ''' </summary>
    ''' <param name="sender">�������e</param>
    ''' <param name="e">�C�x���g���</param>
    ''' <remarks>�Z�����_�u���N���b�N�����ꍇ�̏������s��</remarks>
    Private Sub msfMstGrid1_CellDoubleClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles msfMstGrid1.CellDoubleClick
        Dim lop As Integer                                                                  '   ���[�v�J�E���g

        If SysMode = SYS_ON Then                                                            '   �V�X�e�����[�h��  �n�m�̎�
            Exit Sub                                                                        '   �ȉ��̏������s��Ȃ�
        Else                                                                                '   �V�X�e�����[�h���n�e�e�̎�
            SysMode = SYS_ON                                                                '   �V�X�e�����[�h���n�m
        End If

        If e.RowIndex > -1 Then
            If RecCnt <> 0 Then                                                             '   �ꗗ�f�[�^����̎�
                With msfMstGrid1
                    SerData = ""
                    SerList.Clear()
                    If .Rows.Count <> 0 Then
                        For lop = 0 To ItemCnt - 1
                            '   �����f�[�^�Z�b�g
                            SerData = SerData & DirectCast(.Rows(e.RowIndex).Cells(lop).Value, String)
                            SerList.Add(DirectCast(msfMstGrid1.Rows(e.RowIndex).Cells(lop).Value, String))
                        Next lop
                    End If
                End With

                If Trim$(SerData) <> "" Then
                    Call Gen_CmdEnd()                                                       '   �I��������
                End If
            End If
        End If

        SysMode = SYS_OFF                                                                   '   �V�X�e�����[�h�n�e�e

    End Sub

    Private Sub msfMstGrid1_CurrentCellChanged(sender As Object, e As EventArgs) Handles msfMstGrid1.CurrentCellChanged
        Dim dgv As DataGridView = CType(sender, DataGridView)

        Dim lop As Integer
        Dim curcolidx As Integer
        Dim headerwidth As Integer
        Dim celwidth As Integer


        Try
            With dgv
                '���X�N���[���̕\���ʒu����
                curcolidx = .CurrentCell.ColumnIndex
                If .Rows(0).HeaderCell.Visible Then
                    headerwidth = .Rows(0).HeaderCell.Size.Width
                End If

                For lop = 0 To .ColumnCount - 1
                    If .Columns(lop).Frozen Then
                        headerwidth += .Columns(lop).Width
                    End If
                Next

                celwidth = .ClientSize.Width - headerwidth
                For lop = curcolidx To .FirstDisplayedScrollingColumnIndex Step -1
                    If Not .Columns(lop).Frozen AndAlso .Columns(lop).Visible Then
                        celwidth -= .Columns(lop).Width
                    End If

                    If celwidth <= 0 Then
                        .FirstDisplayedScrollingColumnIndex = curcolidx
                        Exit For
                    End If
                Next
            End With
        Catch ex As Exception

        End Try
    End Sub

    ''' <summary>
    ''' �O���b�h�{�^����������
    ''' </summary>
    ''' <param name="sender">�������e</param>
    ''' <param name="e">�C�x���g���</param>
    ''' <remarks>�O���b�h��ł̃{�^���������ɏ������s��</remarks>
    Private Sub msfMstGrid1_KeyDown1(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles msfMstGrid1.KeyDown
        Dim lop As Integer                                                                  '   ���[�v�J�E���g

        If SysMode = SYS_ON Then                                                            '   �V�X�e�����[�h��  �n�m�̎�
            Exit Sub                                                                        '   �ȉ��̏������s��Ȃ�
        Else                                                                                '   �V�X�e�����[�h���n�e�e�̎�
            SysMode = SYS_ON                                                                '   �V�X�e�����[�h���n�m
        End If

        Select Case e.KeyCode                                                               '   �L�[�R�[�h�`�F�b�N
            Case Keys.Return                                                                '   �m�F�L�[�E���s�L�[
                If RecCnt <> 0 Then                                                         '   �ꗗ�f�[�^����̎�
                    With msfMstGrid1
                        SerData = ""
                        SerList.Clear()
                        For lop = 0 To ItemCnt - 1
                            '   �����f�[�^�Z�b�g
                            SerData = SerData & DirectCast(.Rows(.CurrentCell.RowIndex).Cells(lop).Value, String)
                            SerList.Add(DirectCast(.Rows(.CurrentCell.RowIndex).Cells(lop).Value, String))
                        Next lop
                    End With
                End If

                If Trim$(SerData) <> "" Then
                    Call Gen_CmdEnd()                                                       '   �I��������
                End If
            Case Else
        End Select

        SysMode = SYS_OFF                                                                   '   �V�X�e�����[�h���n�e�e
    End Sub

    Private Sub RBSelect_CheckedChanged(sender As Object, e As EventArgs) Handles RBSelect_0.CheckedChanged, RBSelect_1.CheckedChanged, RBSelect_2.CheckedChanged
        Dim rb As RadioButton = CType(sender, RadioButton)


        If rb.Checked Then
            Select Case rb.Name
                Case "RBSelect_0"
                    DelFlg = "('0', '1')"
                Case "RBSelect_1"
                    DelFlg = "('0')"
                Case "RBSelect_2"
                    DelFlg = "('1')"
                Case Else
                    'MsgBox("���̑�")
                    DelFlg = "('0')"
            End Select

            If msfMstGrid1.RowCount > 0 Then
                Call Gen_TblSelect(SerMast, RED_EQU)                            '   �f�[�^����
            Else
                txtText1(Inx1).Focus()
            End If
        End If
    End Sub

    Private Sub RBSelect_Click(sender As Object, e As EventArgs) Handles RBSelect_0.Click, RBSelect_1.Click, RBSelect_2.Click
        If msfMstGrid1.RowCount > 0 Then
            msfMstGrid1.Focus()
        Else
            txtText1(Inx1).Focus()
        End If
    End Sub
End Class