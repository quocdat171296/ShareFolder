﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class serform
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    '<System.Diagnostics.DebuggerNonUserCode()> _
    'Protected Overrides Sub Dispose(ByVal disposing As Boolean)
    '    If disposing AndAlso components IsNot Nothing Then
    '        components.Dispose()
    '    End If
    '    MyBase.Dispose(disposing)
    'End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(serform))
        Me.fraFrame1 = New System.Windows.Forms.Panel()
        Me.lblValue1_8 = New ITControl.ITLabel()
        Me.txtText1_8 = New ITControl.ITTextBox()
        Me.lblValue1_7 = New ITControl.ITLabel()
        Me.txtText1_7 = New ITControl.ITTextBox()
        Me.lblValue1_6 = New ITControl.ITLabel()
        Me.txtText1_6 = New ITControl.ITTextBox()
        Me.lblValue1_5 = New ITControl.ITLabel()
        Me.txtText1_5 = New ITControl.ITTextBox()
        Me.lblValue1_4 = New ITControl.ITLabel()
        Me.txtText1_4 = New ITControl.ITTextBox()
        Me.lblValue1_3 = New ITControl.ITLabel()
        Me.txtText1_3 = New ITControl.ITTextBox()
        Me.lblValue1_2 = New ITControl.ITLabel()
        Me.txtText1_2 = New ITControl.ITTextBox()
        Me.lblValue1_1 = New ITControl.ITLabel()
        Me.txtText1_1 = New ITControl.ITTextBox()
        Me.lblValue1_0 = New ITControl.ITLabel()
        Me.txtText1_0 = New ITControl.ITTextBox()
        Me.LblSerTitle = New ITControl.ITLabel()
        Me.msfMstGrid1 = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PNLSelect = New System.Windows.Forms.Panel()
        Me.RBSelect_0 = New System.Windows.Forms.RadioButton()
        Me.RBSelect_2 = New System.Windows.Forms.RadioButton()
        Me.RBSelect_1 = New System.Windows.Forms.RadioButton()
        Me.lblTtlNam = New ITControl.ITLabel()
        Me.pnlTail = New ITControl.ITPanel()
        Me.lblF12 = New ITControl.ITLabel()
        Me.lblF11 = New ITControl.ITLabel()
        Me.cmdCommand1_8 = New ITControl.ITCommandButton()
        Me.lblF10 = New ITControl.ITLabel()
        Me.cmdCommand1_0 = New ITControl.ITCommandButton()
        Me.lblF9 = New ITControl.ITLabel()
        Me.cmdCommand1_1 = New ITControl.ITCommandButton()
        Me.lblF8 = New ITControl.ITLabel()
        Me.cmdCommand1_2 = New ITControl.ITCommandButton()
        Me.lblF7 = New ITControl.ITLabel()
        Me.cmdCommand1_3 = New ITControl.ITCommandButton()
        Me.lblF6 = New ITControl.ITLabel()
        Me.cmdCommand1_4 = New ITControl.ITCommandButton()
        Me.lblF5 = New ITControl.ITLabel()
        Me.cmdCommand1_5 = New ITControl.ITCommandButton()
        Me.lblF4 = New ITControl.ITLabel()
        Me.cmdCommand1_6 = New ITControl.ITCommandButton()
        Me.lblF3 = New ITControl.ITLabel()
        Me.cmdCommand1_7 = New ITControl.ITCommandButton()
        Me.lblF2 = New ITControl.ITLabel()
        Me.cmdCommand1_9 = New ITControl.ITCommandButton()
        Me.lblF1 = New ITControl.ITLabel()
        Me.cmdCommand1_10 = New ITControl.ITCommandButton()
        Me.cmdCommand1_11 = New ITControl.ITCommandButton()
        Me.staStatus = New System.Windows.Forms.StatusBar()
        Me.StatusBarPanel1 = New System.Windows.Forms.StatusBarPanel()
        Me.StatusBarPanel2 = New System.Windows.Forms.StatusBarPanel()
        Me.fraFrame1.SuspendLayout()
        CType(Me.msfMstGrid1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PNLSelect.SuspendLayout()
        Me.pnlTail.SuspendLayout()
        CType(Me.StatusBarPanel1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StatusBarPanel2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'fraFrame1
        '
        Me.fraFrame1.BackColor = System.Drawing.SystemColors.Control
        Me.fraFrame1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.fraFrame1.Controls.Add(Me.lblValue1_8)
        Me.fraFrame1.Controls.Add(Me.txtText1_8)
        Me.fraFrame1.Controls.Add(Me.lblValue1_7)
        Me.fraFrame1.Controls.Add(Me.txtText1_7)
        Me.fraFrame1.Controls.Add(Me.lblValue1_6)
        Me.fraFrame1.Controls.Add(Me.txtText1_6)
        Me.fraFrame1.Controls.Add(Me.lblValue1_5)
        Me.fraFrame1.Controls.Add(Me.txtText1_5)
        Me.fraFrame1.Controls.Add(Me.lblValue1_4)
        Me.fraFrame1.Controls.Add(Me.txtText1_4)
        Me.fraFrame1.Controls.Add(Me.lblValue1_3)
        Me.fraFrame1.Controls.Add(Me.txtText1_3)
        Me.fraFrame1.Controls.Add(Me.lblValue1_2)
        Me.fraFrame1.Controls.Add(Me.txtText1_2)
        Me.fraFrame1.Controls.Add(Me.lblValue1_1)
        Me.fraFrame1.Controls.Add(Me.txtText1_1)
        Me.fraFrame1.Controls.Add(Me.lblValue1_0)
        Me.fraFrame1.Controls.Add(Me.txtText1_0)
        Me.fraFrame1.Controls.Add(Me.LblSerTitle)
        Me.fraFrame1.Controls.Add(Me.msfMstGrid1)
        Me.fraFrame1.Controls.Add(Me.PNLSelect)
        Me.fraFrame1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.fraFrame1.Location = New System.Drawing.Point(0, 0)
        Me.fraFrame1.Name = "fraFrame1"
        Me.fraFrame1.Size = New System.Drawing.Size(1264, 985)
        Me.fraFrame1.TabIndex = 2
        '
        'lblValue1_8
        '
        Me.lblValue1_8.BackColor = System.Drawing.Color.Navy
        Me.lblValue1_8.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!)
        Me.lblValue1_8.ForeColor = System.Drawing.Color.White
        Me.lblValue1_8.Location = New System.Drawing.Point(836, 62)
        Me.lblValue1_8.Name = "lblValue1_8"
        Me.lblValue1_8.Size = New System.Drawing.Size(180, 23)
        Me.lblValue1_8.TabIndex = 1091
        Me.lblValue1_8.Text = "検索キー名称4"
        Me.lblValue1_8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtText1_8
        '
        Me.txtText1_8.Ank = "9"
        Me.txtText1_8.BackColor = System.Drawing.Color.White
        Me.txtText1_8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtText1_8.CustomBorderColor = System.Drawing.Color.DodgerBlue
        Me.txtText1_8.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.txtText1_8.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.txtText1_8.Location = New System.Drawing.Point(1021, 62)
        Me.txtText1_8.MaxLength = 4
        Me.txtText1_8.Name = "txtText1_8"
        Me.txtText1_8.Search = True
        Me.txtText1_8.Size = New System.Drawing.Size(114, 23)
        Me.txtText1_8.TabIndex = 1090
        Me.txtText1_8.Text = "0000000000"
        '
        'lblValue1_7
        '
        Me.lblValue1_7.BackColor = System.Drawing.Color.Navy
        Me.lblValue1_7.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!)
        Me.lblValue1_7.ForeColor = System.Drawing.Color.White
        Me.lblValue1_7.Location = New System.Drawing.Point(489, 62)
        Me.lblValue1_7.Name = "lblValue1_7"
        Me.lblValue1_7.Size = New System.Drawing.Size(180, 23)
        Me.lblValue1_7.TabIndex = 1091
        Me.lblValue1_7.Text = "検索キー名称4"
        Me.lblValue1_7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtText1_7
        '
        Me.txtText1_7.Ank = "9"
        Me.txtText1_7.BackColor = System.Drawing.Color.White
        Me.txtText1_7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtText1_7.CustomBorderColor = System.Drawing.Color.DodgerBlue
        Me.txtText1_7.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.txtText1_7.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.txtText1_7.Location = New System.Drawing.Point(674, 62)
        Me.txtText1_7.MaxLength = 4
        Me.txtText1_7.Name = "txtText1_7"
        Me.txtText1_7.Search = True
        Me.txtText1_7.Size = New System.Drawing.Size(114, 23)
        Me.txtText1_7.TabIndex = 1090
        Me.txtText1_7.Text = "0000000000"
        '
        'lblValue1_6
        '
        Me.lblValue1_6.BackColor = System.Drawing.Color.Navy
        Me.lblValue1_6.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!)
        Me.lblValue1_6.ForeColor = System.Drawing.Color.White
        Me.lblValue1_6.Location = New System.Drawing.Point(142, 62)
        Me.lblValue1_6.Name = "lblValue1_6"
        Me.lblValue1_6.Size = New System.Drawing.Size(180, 23)
        Me.lblValue1_6.TabIndex = 1091
        Me.lblValue1_6.Text = "検索キー名称4"
        Me.lblValue1_6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtText1_6
        '
        Me.txtText1_6.Ank = "9"
        Me.txtText1_6.BackColor = System.Drawing.Color.White
        Me.txtText1_6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtText1_6.CustomBorderColor = System.Drawing.Color.DodgerBlue
        Me.txtText1_6.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.txtText1_6.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.txtText1_6.Location = New System.Drawing.Point(327, 62)
        Me.txtText1_6.MaxLength = 4
        Me.txtText1_6.Name = "txtText1_6"
        Me.txtText1_6.Search = True
        Me.txtText1_6.Size = New System.Drawing.Size(114, 23)
        Me.txtText1_6.TabIndex = 1090
        Me.txtText1_6.Text = "0000000000"
        '
        'lblValue1_5
        '
        Me.lblValue1_5.BackColor = System.Drawing.Color.Navy
        Me.lblValue1_5.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!)
        Me.lblValue1_5.ForeColor = System.Drawing.Color.White
        Me.lblValue1_5.Location = New System.Drawing.Point(836, 33)
        Me.lblValue1_5.Name = "lblValue1_5"
        Me.lblValue1_5.Size = New System.Drawing.Size(180, 23)
        Me.lblValue1_5.TabIndex = 1089
        Me.lblValue1_5.Text = "検索キー名称6"
        Me.lblValue1_5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtText1_5
        '
        Me.txtText1_5.Ank = "9"
        Me.txtText1_5.BackColor = System.Drawing.Color.White
        Me.txtText1_5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtText1_5.CustomBorderColor = System.Drawing.Color.DodgerBlue
        Me.txtText1_5.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.txtText1_5.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.txtText1_5.Location = New System.Drawing.Point(1021, 33)
        Me.txtText1_5.MaxLength = 5
        Me.txtText1_5.Name = "txtText1_5"
        Me.txtText1_5.Search = True
        Me.txtText1_5.Size = New System.Drawing.Size(114, 23)
        Me.txtText1_5.TabIndex = 5
        Me.txtText1_5.Text = "00000"
        '
        'lblValue1_4
        '
        Me.lblValue1_4.BackColor = System.Drawing.Color.Navy
        Me.lblValue1_4.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!)
        Me.lblValue1_4.ForeColor = System.Drawing.Color.White
        Me.lblValue1_4.Location = New System.Drawing.Point(489, 33)
        Me.lblValue1_4.Name = "lblValue1_4"
        Me.lblValue1_4.Size = New System.Drawing.Size(180, 23)
        Me.lblValue1_4.TabIndex = 1087
        Me.lblValue1_4.Text = "検索キー名称5"
        Me.lblValue1_4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtText1_4
        '
        Me.txtText1_4.Ank = "9"
        Me.txtText1_4.BackColor = System.Drawing.Color.White
        Me.txtText1_4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtText1_4.CustomBorderColor = System.Drawing.Color.DodgerBlue
        Me.txtText1_4.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.txtText1_4.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.txtText1_4.Location = New System.Drawing.Point(674, 33)
        Me.txtText1_4.MaxLength = 7
        Me.txtText1_4.Name = "txtText1_4"
        Me.txtText1_4.Search = True
        Me.txtText1_4.Size = New System.Drawing.Size(114, 23)
        Me.txtText1_4.TabIndex = 4
        Me.txtText1_4.Text = "0000000"
        '
        'lblValue1_3
        '
        Me.lblValue1_3.BackColor = System.Drawing.Color.Navy
        Me.lblValue1_3.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!)
        Me.lblValue1_3.ForeColor = System.Drawing.Color.White
        Me.lblValue1_3.Location = New System.Drawing.Point(142, 33)
        Me.lblValue1_3.Name = "lblValue1_3"
        Me.lblValue1_3.Size = New System.Drawing.Size(180, 23)
        Me.lblValue1_3.TabIndex = 1085
        Me.lblValue1_3.Text = "検索キー名称4"
        Me.lblValue1_3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtText1_3
        '
        Me.txtText1_3.Ank = "9"
        Me.txtText1_3.BackColor = System.Drawing.Color.White
        Me.txtText1_3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtText1_3.CustomBorderColor = System.Drawing.Color.DodgerBlue
        Me.txtText1_3.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.txtText1_3.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.txtText1_3.Location = New System.Drawing.Point(327, 33)
        Me.txtText1_3.MaxLength = 4
        Me.txtText1_3.Name = "txtText1_3"
        Me.txtText1_3.Search = True
        Me.txtText1_3.Size = New System.Drawing.Size(114, 23)
        Me.txtText1_3.TabIndex = 3
        Me.txtText1_3.Text = "0000000000"
        '
        'lblValue1_2
        '
        Me.lblValue1_2.BackColor = System.Drawing.Color.Navy
        Me.lblValue1_2.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!)
        Me.lblValue1_2.ForeColor = System.Drawing.Color.White
        Me.lblValue1_2.Location = New System.Drawing.Point(836, 4)
        Me.lblValue1_2.Name = "lblValue1_2"
        Me.lblValue1_2.Size = New System.Drawing.Size(180, 23)
        Me.lblValue1_2.TabIndex = 1083
        Me.lblValue1_2.Text = "検索キー名称3"
        Me.lblValue1_2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtText1_2
        '
        Me.txtText1_2.Ank = "9"
        Me.txtText1_2.BackColor = System.Drawing.Color.White
        Me.txtText1_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtText1_2.CustomBorderColor = System.Drawing.Color.DodgerBlue
        Me.txtText1_2.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.txtText1_2.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.txtText1_2.Location = New System.Drawing.Point(1021, 4)
        Me.txtText1_2.MaxLength = 5
        Me.txtText1_2.Name = "txtText1_2"
        Me.txtText1_2.Search = True
        Me.txtText1_2.Size = New System.Drawing.Size(114, 23)
        Me.txtText1_2.TabIndex = 2
        Me.txtText1_2.Text = "00000"
        '
        'lblValue1_1
        '
        Me.lblValue1_1.BackColor = System.Drawing.Color.Navy
        Me.lblValue1_1.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!)
        Me.lblValue1_1.ForeColor = System.Drawing.Color.White
        Me.lblValue1_1.Location = New System.Drawing.Point(489, 4)
        Me.lblValue1_1.Name = "lblValue1_1"
        Me.lblValue1_1.Size = New System.Drawing.Size(180, 23)
        Me.lblValue1_1.TabIndex = 1081
        Me.lblValue1_1.Text = "検索キー名称2"
        Me.lblValue1_1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtText1_1
        '
        Me.txtText1_1.Ank = "9"
        Me.txtText1_1.BackColor = System.Drawing.Color.White
        Me.txtText1_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtText1_1.CustomBorderColor = System.Drawing.Color.DodgerBlue
        Me.txtText1_1.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.txtText1_1.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.txtText1_1.Location = New System.Drawing.Point(674, 4)
        Me.txtText1_1.MaxLength = 7
        Me.txtText1_1.Name = "txtText1_1"
        Me.txtText1_1.Search = True
        Me.txtText1_1.Size = New System.Drawing.Size(114, 23)
        Me.txtText1_1.TabIndex = 1
        Me.txtText1_1.Text = "0000000"
        '
        'lblValue1_0
        '
        Me.lblValue1_0.BackColor = System.Drawing.Color.Navy
        Me.lblValue1_0.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!)
        Me.lblValue1_0.ForeColor = System.Drawing.Color.White
        Me.lblValue1_0.Location = New System.Drawing.Point(142, 4)
        Me.lblValue1_0.Name = "lblValue1_0"
        Me.lblValue1_0.Size = New System.Drawing.Size(180, 23)
        Me.lblValue1_0.TabIndex = 1079
        Me.lblValue1_0.Text = "検索キー名称1"
        Me.lblValue1_0.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtText1_0
        '
        Me.txtText1_0.Ank = "9"
        Me.txtText1_0.BackColor = System.Drawing.Color.White
        Me.txtText1_0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtText1_0.CustomBorderColor = System.Drawing.Color.DodgerBlue
        Me.txtText1_0.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.txtText1_0.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.txtText1_0.Location = New System.Drawing.Point(327, 4)
        Me.txtText1_0.MaxLength = 4
        Me.txtText1_0.Name = "txtText1_0"
        Me.txtText1_0.Search = True
        Me.txtText1_0.Size = New System.Drawing.Size(114, 23)
        Me.txtText1_0.TabIndex = 0
        Me.txtText1_0.Text = "0000000000"
        '
        'LblSerTitle
        '
        Me.LblSerTitle.BackColor = System.Drawing.Color.Lavender
        Me.LblSerTitle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LblSerTitle.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.LblSerTitle.ForeColor = System.Drawing.Color.MediumBlue
        Me.LblSerTitle.Location = New System.Drawing.Point(16, 4)
        Me.LblSerTitle.Name = "LblSerTitle"
        Me.LblSerTitle.Size = New System.Drawing.Size(120, 23)
        Me.LblSerTitle.TabIndex = 7
        Me.LblSerTitle.Text = "検索キー"
        Me.LblSerTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'msfMstGrid1
        '
        Me.msfMstGrid1.AllowUserToAddRows = False
        Me.msfMstGrid1.AllowUserToDeleteRows = False
        Me.msfMstGrid1.AllowUserToResizeColumns = False
        Me.msfMstGrid1.AllowUserToResizeRows = False
        Me.msfMstGrid1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.msfMstGrid1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.msfMstGrid1.CausesValidation = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!)
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.msfMstGrid1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.msfMstGrid1.ColumnHeadersHeight = 24
        Me.msfMstGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.msfMstGrid1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2, Me.Column3, Me.Column4, Me.Column5, Me.Column6, Me.Column7, Me.Column8, Me.Column9, Me.Column10})
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle12.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.msfMstGrid1.DefaultCellStyle = DataGridViewCellStyle12
        Me.msfMstGrid1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.msfMstGrid1.Location = New System.Drawing.Point(15, 103)
        Me.msfMstGrid1.MultiSelect = False
        Me.msfMstGrid1.Name = "msfMstGrid1"
        Me.msfMstGrid1.ReadOnly = True
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle13.Font = New System.Drawing.Font("MS UI Gothic", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.msfMstGrid1.RowHeadersDefaultCellStyle = DataGridViewCellStyle13
        Me.msfMstGrid1.RowHeadersVisible = False
        Me.msfMstGrid1.RowTemplate.Height = 21
        Me.msfMstGrid1.RowTemplate.ReadOnly = True
        Me.msfMstGrid1.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.msfMstGrid1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.msfMstGrid1.Size = New System.Drawing.Size(1233, 793)
        Me.msfMstGrid1.TabIndex = 6
        '
        'Column1
        '
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!)
        Me.Column1.DefaultCellStyle = DataGridViewCellStyle2
        Me.Column1.Frozen = True
        Me.Column1.HeaderText = ""
        Me.Column1.MaxInputLength = 6
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        Me.Column1.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Column1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'Column2
        '
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        DataGridViewCellStyle3.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!)
        Me.Column2.DefaultCellStyle = DataGridViewCellStyle3
        Me.Column2.HeaderText = ""
        Me.Column2.MaxInputLength = 20
        Me.Column2.Name = "Column2"
        Me.Column2.ReadOnly = True
        Me.Column2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'Column3
        '
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        DataGridViewCellStyle4.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!)
        Me.Column3.DefaultCellStyle = DataGridViewCellStyle4
        Me.Column3.HeaderText = ""
        Me.Column3.MaxInputLength = 1
        Me.Column3.Name = "Column3"
        Me.Column3.ReadOnly = True
        Me.Column3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'Column4
        '
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        DataGridViewCellStyle5.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!)
        Me.Column4.DefaultCellStyle = DataGridViewCellStyle5
        Me.Column4.HeaderText = ""
        Me.Column4.MaxInputLength = 1
        Me.Column4.Name = "Column4"
        Me.Column4.ReadOnly = True
        Me.Column4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'Column5
        '
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        DataGridViewCellStyle6.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!)
        Me.Column5.DefaultCellStyle = DataGridViewCellStyle6
        Me.Column5.HeaderText = ""
        Me.Column5.Name = "Column5"
        Me.Column5.ReadOnly = True
        Me.Column5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'Column6
        '
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        DataGridViewCellStyle7.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!)
        Me.Column6.DefaultCellStyle = DataGridViewCellStyle7
        Me.Column6.HeaderText = ""
        Me.Column6.Name = "Column6"
        Me.Column6.ReadOnly = True
        Me.Column6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'Column7
        '
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        DataGridViewCellStyle8.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!)
        Me.Column7.DefaultCellStyle = DataGridViewCellStyle8
        Me.Column7.HeaderText = ""
        Me.Column7.Name = "Column7"
        Me.Column7.ReadOnly = True
        Me.Column7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'Column8
        '
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        DataGridViewCellStyle9.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!)
        Me.Column8.DefaultCellStyle = DataGridViewCellStyle9
        Me.Column8.HeaderText = ""
        Me.Column8.Name = "Column8"
        Me.Column8.ReadOnly = True
        Me.Column8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'Column9
        '
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        DataGridViewCellStyle10.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!)
        Me.Column9.DefaultCellStyle = DataGridViewCellStyle10
        Me.Column9.HeaderText = ""
        Me.Column9.Name = "Column9"
        Me.Column9.ReadOnly = True
        Me.Column9.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'Column10
        '
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        DataGridViewCellStyle11.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!)
        Me.Column10.DefaultCellStyle = DataGridViewCellStyle11
        Me.Column10.HeaderText = ""
        Me.Column10.Name = "Column10"
        Me.Column10.ReadOnly = True
        Me.Column10.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'PNLSelect
        '
        Me.PNLSelect.Controls.Add(Me.RBSelect_0)
        Me.PNLSelect.Controls.Add(Me.RBSelect_2)
        Me.PNLSelect.Controls.Add(Me.RBSelect_1)
        Me.PNLSelect.Location = New System.Drawing.Point(1044, 62)
        Me.PNLSelect.Name = "PNLSelect"
        Me.PNLSelect.Size = New System.Drawing.Size(204, 23)
        Me.PNLSelect.TabIndex = 1093
        '
        'RBSelect_0
        '
        Me.RBSelect_0.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.RBSelect_0.Location = New System.Drawing.Point(0, 0)
        Me.RBSelect_0.Name = "RBSelect_0"
        Me.RBSelect_0.Size = New System.Drawing.Size(68, 23)
        Me.RBSelect_0.TabIndex = 1092
        Me.RBSelect_0.TabStop = True
        Me.RBSelect_0.Text = "全て"
        Me.RBSelect_0.UseVisualStyleBackColor = True
        '
        'RBSelect_2
        '
        Me.RBSelect_2.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.RBSelect_2.Location = New System.Drawing.Point(136, 0)
        Me.RBSelect_2.Name = "RBSelect_2"
        Me.RBSelect_2.Size = New System.Drawing.Size(68, 23)
        Me.RBSelect_2.TabIndex = 1092
        Me.RBSelect_2.TabStop = True
        Me.RBSelect_2.Text = "削除"
        Me.RBSelect_2.UseVisualStyleBackColor = True
        '
        'RBSelect_1
        '
        Me.RBSelect_1.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.RBSelect_1.Location = New System.Drawing.Point(68, 0)
        Me.RBSelect_1.Name = "RBSelect_1"
        Me.RBSelect_1.Size = New System.Drawing.Size(68, 23)
        Me.RBSelect_1.TabIndex = 1092
        Me.RBSelect_1.TabStop = True
        Me.RBSelect_1.Text = "登録"
        Me.RBSelect_1.UseVisualStyleBackColor = True
        '
        'lblTtlNam
        '
        Me.lblTtlNam.BackColor = System.Drawing.Color.White
        Me.lblTtlNam.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTtlNam.Font = New System.Drawing.Font("HGP創英角ｺﾞｼｯｸUB", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblTtlNam.ForeColor = System.Drawing.Color.Blue
        Me.lblTtlNam.Location = New System.Drawing.Point(4, 7)
        Me.lblTtlNam.Name = "lblTtlNam"
        Me.lblTtlNam.Size = New System.Drawing.Size(602, 42)
        Me.lblTtlNam.TabIndex = 9
        Me.lblTtlNam.Text = "ItLabel1"
        Me.lblTtlNam.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblTtlNam.Visible = False
        '
        'pnlTail
        '
        Me.pnlTail.BackColor = System.Drawing.SystemColors.Control
        Me.pnlTail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlTail.Controls.Add(Me.lblF12)
        Me.pnlTail.Controls.Add(Me.lblF11)
        Me.pnlTail.Controls.Add(Me.cmdCommand1_8)
        Me.pnlTail.Controls.Add(Me.lblF10)
        Me.pnlTail.Controls.Add(Me.cmdCommand1_0)
        Me.pnlTail.Controls.Add(Me.lblF9)
        Me.pnlTail.Controls.Add(Me.cmdCommand1_1)
        Me.pnlTail.Controls.Add(Me.lblF8)
        Me.pnlTail.Controls.Add(Me.cmdCommand1_2)
        Me.pnlTail.Controls.Add(Me.lblF7)
        Me.pnlTail.Controls.Add(Me.cmdCommand1_3)
        Me.pnlTail.Controls.Add(Me.lblF6)
        Me.pnlTail.Controls.Add(Me.cmdCommand1_4)
        Me.pnlTail.Controls.Add(Me.lblF5)
        Me.pnlTail.Controls.Add(Me.cmdCommand1_5)
        Me.pnlTail.Controls.Add(Me.lblF4)
        Me.pnlTail.Controls.Add(Me.cmdCommand1_6)
        Me.pnlTail.Controls.Add(Me.lblF3)
        Me.pnlTail.Controls.Add(Me.cmdCommand1_7)
        Me.pnlTail.Controls.Add(Me.lblF2)
        Me.pnlTail.Controls.Add(Me.cmdCommand1_9)
        Me.pnlTail.Controls.Add(Me.lblF1)
        Me.pnlTail.Controls.Add(Me.cmdCommand1_10)
        Me.pnlTail.Controls.Add(Me.cmdCommand1_11)
        Me.pnlTail.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlTail.Location = New System.Drawing.Point(0, 905)
        Me.pnlTail.Name = "pnlTail"
        Me.pnlTail.RadiusBottomLeft = 30
        Me.pnlTail.RadiusBottomRight = 30
        Me.pnlTail.RadiusTopLeft = 30
        Me.pnlTail.RadiusTopRight = 30
        Me.pnlTail.Size = New System.Drawing.Size(1264, 80)
        Me.pnlTail.TabIndex = 23
        '
        'lblF12
        '
        Me.lblF12.BackColor = System.Drawing.Color.Transparent
        Me.lblF12.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblF12.Font = New System.Drawing.Font("ＭＳ Ｐゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblF12.ForeColor = System.Drawing.Color.Black
        Me.lblF12.Location = New System.Drawing.Point(1150, 8)
        Me.lblF12.Name = "lblF12"
        Me.lblF12.Size = New System.Drawing.Size(90, 23)
        Me.lblF12.TabIndex = 1018
        Me.lblF12.Text = "F12"
        Me.lblF12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblF11
        '
        Me.lblF11.BackColor = System.Drawing.Color.Transparent
        Me.lblF11.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblF11.Font = New System.Drawing.Font("ＭＳ Ｐゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblF11.ForeColor = System.Drawing.Color.Black
        Me.lblF11.Location = New System.Drawing.Point(1055, 8)
        Me.lblF11.Name = "lblF11"
        Me.lblF11.Size = New System.Drawing.Size(90, 23)
        Me.lblF11.TabIndex = 1017
        Me.lblF11.Text = "F11"
        Me.lblF11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmdCommand1_8
        '
        Me.cmdCommand1_8.BackColor = System.Drawing.Color.Transparent
        Me.cmdCommand1_8.Font = New System.Drawing.Font("ＭＳ Ｐゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.cmdCommand1_8.Location = New System.Drawing.Point(865, 32)
        Me.cmdCommand1_8.Name = "cmdCommand1_8"
        Me.cmdCommand1_8.Size = New System.Drawing.Size(90, 35)
        Me.cmdCommand1_8.TabIndex = 8
        Me.cmdCommand1_8.UseVisualStyleBackColor = False
        '
        'lblF10
        '
        Me.lblF10.BackColor = System.Drawing.Color.Transparent
        Me.lblF10.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblF10.Font = New System.Drawing.Font("ＭＳ Ｐゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblF10.ForeColor = System.Drawing.Color.Black
        Me.lblF10.Location = New System.Drawing.Point(960, 8)
        Me.lblF10.Name = "lblF10"
        Me.lblF10.Size = New System.Drawing.Size(90, 23)
        Me.lblF10.TabIndex = 1016
        Me.lblF10.Text = "F10"
        Me.lblF10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmdCommand1_0
        '
        Me.cmdCommand1_0.BackColor = System.Drawing.Color.Transparent
        Me.cmdCommand1_0.Font = New System.Drawing.Font("ＭＳ Ｐゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.cmdCommand1_0.Location = New System.Drawing.Point(15, 32)
        Me.cmdCommand1_0.Name = "cmdCommand1_0"
        Me.cmdCommand1_0.Size = New System.Drawing.Size(90, 35)
        Me.cmdCommand1_0.TabIndex = 0
        Me.cmdCommand1_0.UseVisualStyleBackColor = False
        '
        'lblF9
        '
        Me.lblF9.BackColor = System.Drawing.Color.Transparent
        Me.lblF9.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblF9.Font = New System.Drawing.Font("ＭＳ Ｐゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblF9.ForeColor = System.Drawing.Color.Black
        Me.lblF9.Location = New System.Drawing.Point(865, 8)
        Me.lblF9.Name = "lblF9"
        Me.lblF9.Size = New System.Drawing.Size(90, 23)
        Me.lblF9.TabIndex = 1015
        Me.lblF9.Text = "F9"
        Me.lblF9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmdCommand1_1
        '
        Me.cmdCommand1_1.BackColor = System.Drawing.Color.Transparent
        Me.cmdCommand1_1.Font = New System.Drawing.Font("ＭＳ Ｐゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.cmdCommand1_1.Location = New System.Drawing.Point(110, 32)
        Me.cmdCommand1_1.Name = "cmdCommand1_1"
        Me.cmdCommand1_1.Size = New System.Drawing.Size(90, 35)
        Me.cmdCommand1_1.TabIndex = 1
        Me.cmdCommand1_1.UseVisualStyleBackColor = False
        '
        'lblF8
        '
        Me.lblF8.BackColor = System.Drawing.Color.Transparent
        Me.lblF8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblF8.Font = New System.Drawing.Font("ＭＳ Ｐゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblF8.ForeColor = System.Drawing.Color.Black
        Me.lblF8.Location = New System.Drawing.Point(725, 8)
        Me.lblF8.Name = "lblF8"
        Me.lblF8.Size = New System.Drawing.Size(90, 23)
        Me.lblF8.TabIndex = 1014
        Me.lblF8.Text = "F8"
        Me.lblF8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmdCommand1_2
        '
        Me.cmdCommand1_2.BackColor = System.Drawing.Color.Transparent
        Me.cmdCommand1_2.Font = New System.Drawing.Font("ＭＳ Ｐゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.cmdCommand1_2.Location = New System.Drawing.Point(205, 32)
        Me.cmdCommand1_2.Name = "cmdCommand1_2"
        Me.cmdCommand1_2.Size = New System.Drawing.Size(90, 35)
        Me.cmdCommand1_2.TabIndex = 2
        Me.cmdCommand1_2.UseVisualStyleBackColor = False
        '
        'lblF7
        '
        Me.lblF7.BackColor = System.Drawing.Color.Transparent
        Me.lblF7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblF7.Font = New System.Drawing.Font("ＭＳ Ｐゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblF7.ForeColor = System.Drawing.Color.Black
        Me.lblF7.Location = New System.Drawing.Point(630, 8)
        Me.lblF7.Name = "lblF7"
        Me.lblF7.Size = New System.Drawing.Size(90, 23)
        Me.lblF7.TabIndex = 1013
        Me.lblF7.Text = "F7"
        Me.lblF7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmdCommand1_3
        '
        Me.cmdCommand1_3.BackColor = System.Drawing.Color.Transparent
        Me.cmdCommand1_3.Font = New System.Drawing.Font("ＭＳ Ｐゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.cmdCommand1_3.Location = New System.Drawing.Point(300, 32)
        Me.cmdCommand1_3.Name = "cmdCommand1_3"
        Me.cmdCommand1_3.Size = New System.Drawing.Size(90, 35)
        Me.cmdCommand1_3.TabIndex = 0
        Me.cmdCommand1_3.Text = "確定"
        Me.cmdCommand1_3.UseVisualStyleBackColor = False
        '
        'lblF6
        '
        Me.lblF6.BackColor = System.Drawing.Color.Transparent
        Me.lblF6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblF6.Font = New System.Drawing.Font("ＭＳ Ｐゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblF6.ForeColor = System.Drawing.Color.Black
        Me.lblF6.Location = New System.Drawing.Point(535, 8)
        Me.lblF6.Name = "lblF6"
        Me.lblF6.Size = New System.Drawing.Size(90, 23)
        Me.lblF6.TabIndex = 1012
        Me.lblF6.Text = "F6"
        Me.lblF6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmdCommand1_4
        '
        Me.cmdCommand1_4.BackColor = System.Drawing.Color.Transparent
        Me.cmdCommand1_4.Font = New System.Drawing.Font("ＭＳ Ｐゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.cmdCommand1_4.Location = New System.Drawing.Point(440, 32)
        Me.cmdCommand1_4.Name = "cmdCommand1_4"
        Me.cmdCommand1_4.Size = New System.Drawing.Size(90, 35)
        Me.cmdCommand1_4.TabIndex = 4
        Me.cmdCommand1_4.UseVisualStyleBackColor = False
        '
        'lblF5
        '
        Me.lblF5.BackColor = System.Drawing.Color.Transparent
        Me.lblF5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblF5.Font = New System.Drawing.Font("ＭＳ Ｐゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblF5.ForeColor = System.Drawing.Color.Black
        Me.lblF5.Location = New System.Drawing.Point(440, 8)
        Me.lblF5.Name = "lblF5"
        Me.lblF5.Size = New System.Drawing.Size(90, 23)
        Me.lblF5.TabIndex = 1011
        Me.lblF5.Text = "F5"
        Me.lblF5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmdCommand1_5
        '
        Me.cmdCommand1_5.BackColor = System.Drawing.Color.Transparent
        Me.cmdCommand1_5.Font = New System.Drawing.Font("ＭＳ Ｐゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.cmdCommand1_5.Location = New System.Drawing.Point(535, 32)
        Me.cmdCommand1_5.Name = "cmdCommand1_5"
        Me.cmdCommand1_5.Size = New System.Drawing.Size(90, 35)
        Me.cmdCommand1_5.TabIndex = 5
        Me.cmdCommand1_5.UseVisualStyleBackColor = False
        '
        'lblF4
        '
        Me.lblF4.BackColor = System.Drawing.Color.Transparent
        Me.lblF4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblF4.Font = New System.Drawing.Font("ＭＳ Ｐゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblF4.ForeColor = System.Drawing.Color.Black
        Me.lblF4.Location = New System.Drawing.Point(300, 8)
        Me.lblF4.Name = "lblF4"
        Me.lblF4.Size = New System.Drawing.Size(90, 23)
        Me.lblF4.TabIndex = 1010
        Me.lblF4.Text = "F4"
        Me.lblF4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmdCommand1_6
        '
        Me.cmdCommand1_6.BackColor = System.Drawing.Color.Transparent
        Me.cmdCommand1_6.Font = New System.Drawing.Font("ＭＳ Ｐゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.cmdCommand1_6.Location = New System.Drawing.Point(630, 32)
        Me.cmdCommand1_6.Name = "cmdCommand1_6"
        Me.cmdCommand1_6.Size = New System.Drawing.Size(90, 35)
        Me.cmdCommand1_6.TabIndex = 6
        Me.cmdCommand1_6.Text = "前頁"
        Me.cmdCommand1_6.UseVisualStyleBackColor = False
        '
        'lblF3
        '
        Me.lblF3.BackColor = System.Drawing.Color.Transparent
        Me.lblF3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblF3.Font = New System.Drawing.Font("ＭＳ Ｐゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblF3.ForeColor = System.Drawing.Color.Black
        Me.lblF3.Location = New System.Drawing.Point(205, 8)
        Me.lblF3.Name = "lblF3"
        Me.lblF3.Size = New System.Drawing.Size(90, 23)
        Me.lblF3.TabIndex = 1009
        Me.lblF3.Text = "F3"
        Me.lblF3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmdCommand1_7
        '
        Me.cmdCommand1_7.BackColor = System.Drawing.Color.Transparent
        Me.cmdCommand1_7.Font = New System.Drawing.Font("ＭＳ Ｐゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.cmdCommand1_7.Location = New System.Drawing.Point(725, 32)
        Me.cmdCommand1_7.Name = "cmdCommand1_7"
        Me.cmdCommand1_7.Size = New System.Drawing.Size(90, 35)
        Me.cmdCommand1_7.TabIndex = 7
        Me.cmdCommand1_7.Text = "次頁"
        Me.cmdCommand1_7.UseVisualStyleBackColor = False
        '
        'lblF2
        '
        Me.lblF2.BackColor = System.Drawing.Color.Transparent
        Me.lblF2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblF2.Font = New System.Drawing.Font("ＭＳ Ｐゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblF2.ForeColor = System.Drawing.Color.Black
        Me.lblF2.Location = New System.Drawing.Point(110, 8)
        Me.lblF2.Name = "lblF2"
        Me.lblF2.Size = New System.Drawing.Size(90, 23)
        Me.lblF2.TabIndex = 1008
        Me.lblF2.Text = "F2"
        Me.lblF2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmdCommand1_9
        '
        Me.cmdCommand1_9.BackColor = System.Drawing.Color.Transparent
        Me.cmdCommand1_9.Font = New System.Drawing.Font("ＭＳ Ｐゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.cmdCommand1_9.Location = New System.Drawing.Point(960, 32)
        Me.cmdCommand1_9.Name = "cmdCommand1_9"
        Me.cmdCommand1_9.Size = New System.Drawing.Size(90, 35)
        Me.cmdCommand1_9.TabIndex = 9
        Me.cmdCommand1_9.UseVisualStyleBackColor = False
        '
        'lblF1
        '
        Me.lblF1.BackColor = System.Drawing.Color.Transparent
        Me.lblF1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblF1.Font = New System.Drawing.Font("ＭＳ Ｐゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblF1.ForeColor = System.Drawing.Color.Black
        Me.lblF1.Location = New System.Drawing.Point(15, 8)
        Me.lblF1.Name = "lblF1"
        Me.lblF1.Size = New System.Drawing.Size(90, 23)
        Me.lblF1.TabIndex = 1007
        Me.lblF1.Text = "F1"
        Me.lblF1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmdCommand1_10
        '
        Me.cmdCommand1_10.BackColor = System.Drawing.Color.Transparent
        Me.cmdCommand1_10.Font = New System.Drawing.Font("ＭＳ Ｐゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.cmdCommand1_10.Location = New System.Drawing.Point(1055, 32)
        Me.cmdCommand1_10.Name = "cmdCommand1_10"
        Me.cmdCommand1_10.Size = New System.Drawing.Size(90, 35)
        Me.cmdCommand1_10.TabIndex = 10
        Me.cmdCommand1_10.UseVisualStyleBackColor = False
        '
        'cmdCommand1_11
        '
        Me.cmdCommand1_11.BackColor = System.Drawing.Color.Transparent
        Me.cmdCommand1_11.Font = New System.Drawing.Font("ＭＳ Ｐゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.cmdCommand1_11.Location = New System.Drawing.Point(1150, 32)
        Me.cmdCommand1_11.Name = "cmdCommand1_11"
        Me.cmdCommand1_11.Size = New System.Drawing.Size(90, 35)
        Me.cmdCommand1_11.TabIndex = 1
        Me.cmdCommand1_11.Text = "処理終了"
        Me.cmdCommand1_11.UseVisualStyleBackColor = False
        '
        'staStatus
        '
        Me.staStatus.Dock = System.Windows.Forms.DockStyle.None
        Me.staStatus.Font = New System.Drawing.Font("ＭＳ Ｐゴシック", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.staStatus.Location = New System.Drawing.Point(0, 883)
        Me.staStatus.Name = "staStatus"
        Me.staStatus.Panels.AddRange(New System.Windows.Forms.StatusBarPanel() {Me.StatusBarPanel1, Me.StatusBarPanel2})
        Me.staStatus.ShowPanels = True
        Me.staStatus.Size = New System.Drawing.Size(1264, 22)
        Me.staStatus.SizingGrip = False
        Me.staStatus.TabIndex = 24
        Me.staStatus.Visible = False
        '
        'StatusBarPanel1
        '
        Me.StatusBarPanel1.Name = "StatusBarPanel1"
        Me.StatusBarPanel1.Width = 685
        '
        'StatusBarPanel2
        '
        Me.StatusBarPanel2.Alignment = System.Windows.Forms.HorizontalAlignment.Center
        Me.StatusBarPanel2.Name = "StatusBarPanel2"
        Me.StatusBarPanel2.Width = 130
        '
        'serform
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(1264, 985)
        Me.Controls.Add(Me.pnlTail)
        Me.Controls.Add(Me.fraFrame1)
        Me.Controls.Add(Me.lblTtlNam)
        Me.Controls.Add(Me.staStatus)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.Name = "serform"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "テーブル内容一覧"
        Me.fraFrame1.ResumeLayout(False)
        Me.fraFrame1.PerformLayout()
        CType(Me.msfMstGrid1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PNLSelect.ResumeLayout(False)
        Me.pnlTail.ResumeLayout(False)
        CType(Me.StatusBarPanel1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StatusBarPanel2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents fraFrame1 As System.Windows.Forms.Panel

    Friend WithEvents msfMstGrid1 As System.Windows.Forms.DataGridView
    Friend WithEvents lblTtlNam As ITControl.ITLabel
    Friend WithEvents pnlTail As ITControl.ITPanel
    Friend WithEvents lblF12 As ITControl.ITLabel
    Friend WithEvents lblF11 As ITControl.ITLabel
    Friend WithEvents cmdCommand1_8 As ITControl.ITCommandButton
    Friend WithEvents lblF10 As ITControl.ITLabel
    Friend WithEvents cmdCommand1_0 As ITControl.ITCommandButton
    Friend WithEvents lblF9 As ITControl.ITLabel
    Friend WithEvents cmdCommand1_1 As ITControl.ITCommandButton
    Friend WithEvents lblF8 As ITControl.ITLabel
    Friend WithEvents cmdCommand1_2 As ITControl.ITCommandButton
    Friend WithEvents lblF7 As ITControl.ITLabel
    Friend WithEvents cmdCommand1_3 As ITControl.ITCommandButton
    Friend WithEvents lblF6 As ITControl.ITLabel
    Friend WithEvents cmdCommand1_4 As ITControl.ITCommandButton
    Friend WithEvents lblF5 As ITControl.ITLabel
    Friend WithEvents cmdCommand1_5 As ITControl.ITCommandButton
    Friend WithEvents lblF4 As ITControl.ITLabel
    Friend WithEvents cmdCommand1_6 As ITControl.ITCommandButton
    Friend WithEvents lblF3 As ITControl.ITLabel
    Friend WithEvents cmdCommand1_7 As ITControl.ITCommandButton
    Friend WithEvents lblF2 As ITControl.ITLabel
    Friend WithEvents cmdCommand1_9 As ITControl.ITCommandButton
    Friend WithEvents lblF1 As ITControl.ITLabel
    Friend WithEvents cmdCommand1_10 As ITControl.ITCommandButton
    Friend WithEvents cmdCommand1_11 As ITControl.ITCommandButton
    Friend WithEvents staStatus As System.Windows.Forms.StatusBar
    Friend WithEvents StatusBarPanel1 As System.Windows.Forms.StatusBarPanel
    Friend WithEvents StatusBarPanel2 As System.Windows.Forms.StatusBarPanel
    Friend WithEvents lblValue1_5 As ITControl.ITLabel
    Friend WithEvents txtText1_5 As ITControl.ITTextBox
    Friend WithEvents lblValue1_4 As ITControl.ITLabel
    Friend WithEvents txtText1_4 As ITControl.ITTextBox
    Friend WithEvents lblValue1_3 As ITControl.ITLabel
    Friend WithEvents txtText1_3 As ITControl.ITTextBox
    Friend WithEvents lblValue1_2 As ITControl.ITLabel
    Friend WithEvents txtText1_2 As ITControl.ITTextBox
    Friend WithEvents lblValue1_1 As ITControl.ITLabel
    Friend WithEvents txtText1_1 As ITControl.ITTextBox
    Friend WithEvents lblValue1_0 As ITControl.ITLabel
    Friend WithEvents txtText1_0 As ITControl.ITTextBox
    Friend WithEvents LblSerTitle As ITControl.ITLabel
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column7 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column8 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column9 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column10 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents lblValue1_8 As ITControl.ITLabel
    Friend WithEvents txtText1_8 As ITControl.ITTextBox
    Friend WithEvents lblValue1_7 As ITControl.ITLabel
    Friend WithEvents txtText1_7 As ITControl.ITTextBox
    Friend WithEvents lblValue1_6 As ITControl.ITLabel
    Friend WithEvents txtText1_6 As ITControl.ITTextBox
    Friend WithEvents RBSelect_2 As System.Windows.Forms.RadioButton
    Friend WithEvents RBSelect_1 As System.Windows.Forms.RadioButton
    Friend WithEvents RBSelect_0 As System.Windows.Forms.RadioButton
    Friend WithEvents PNLSelect As System.Windows.Forms.Panel
End Class
