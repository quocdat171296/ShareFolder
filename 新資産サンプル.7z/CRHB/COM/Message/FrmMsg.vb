Public Class FrmMsg

    Dim getStr As String

    Public WriteOnly Property PrvMsg()
        Set(ByVal value)
            getStr = value
        End Set
    End Property

    Private Sub FrmMsg_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        lblMessage.Text = getStr

        timMsg.Enabled = True

        timMsg.Start()

        Application.DoEvents()

        Me.Show()
    End Sub

    Private Sub timMsg_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles timMsg.Tick
        If lblMessage.Visible = True Then
            lblMessage.Visible = False
        Else
            lblMessage.Visible = True
        End If

        Application.DoEvents()
    End Sub
End Class
