﻿
Public Class ITFlowLayoutPanel
    Inherits System.Windows.Forms.FlowLayoutPanel
    Protected Overrides Property DoubleBuffered() As Boolean
        Get
            Return True
        End Get
        Set(ByVal value As Boolean)
        End Set
    End Property

End Class
